# Changelog

## [2.1.0] - Unreleased

### Added
- Expose the logical model name separately from an object’s physical store route so Swift virtual results can select the correct concrete type after attachment.
- Add bounded, selected-column file reads with one owned snapshot cursor,
  row and copied-value byte budgets, cooperative cancellation, deadlines,
  explicit resource admission, and completion notification after cleanup.
  Preserve predicate bindings, order, grouping, distinct and geographic
  bounds. WebAssembly projection execution remains unsupported.
- Add native memory-store projected reads that capture selected values on
  first demand, then release the writer before yielding batches. Capture
  storage defaults to32 MiB per request with a64 MiB per-parent ceiling;
  retained batches remain charged. Require committed idle state, supported
  SQLite objects and Lattice-owned attachment changes; reject escaped raw
  handles and unsafe expressions explicitly.
- Add transaction-owned selected-object mutation batches with timestamp
  assignment and checked atomic integer increments. Validate all selected
  rows and physical attachment routes before writing; retain ordinary audit
  and trigger behavior.
- Expose immutable collection-query row images and statement-free managed
  identity separately from live fields and materialized values.
- Add payload-free coarse invalidation hooks as reconciliation hints.
  These hooks do not provide a durable event cursor or transaction replay.

### Fixed
- Retain internal ordinary and cross-process readers through complete queries
  while maintenance replaces connections. Restore attached views before reader
  publication and release retired connections outside bookkeeping locks.
  Raw connection references remain caller-serialized, and the parent must
  outlive owned read borrows. Rebuild Core and bridge consumers together.
- Suppress SIGPIPE per socket send on Linux when an IPC peer closes during
  framing. Return the existing write failure instead of terminating the
  process; retain Darwin socket setup and generic non-socket behavior.
- Preserve each physical route and attachment token through heterogeneous
  virtual UNION queries, including models present only in attached stores.
  Keep ordinary main-store arms pinned to main when a TEMP view shadows them.
- Read live primitive fields through one owned SQL cell, avoiding generic
  row containers while preserving fresh queries, physical routing and types.
- Initialize the default native Double fallback to zero instead of reading
  uninitialized storage when a live value is absent or has the wrong type.
- Deliver each stored AuditLog insertion once on WebAssembly persistent stores;
  use the existing direct hook events instead of deriving duplicates.
- Destroy projection-pressure maps in the native translation unit so optimized
  Swift callers do not need to emit their nested libc++ deletion helpers.
- Claim each audit-retention interval with one conditional SQLite write so
  simultaneous maintenance handles cannot both acquire the same interval.
  Release a failed pass's own claim for retry while preserving newer claims;
  keep insertion-time watermarks, upload floors and audit IDs unchanged.
- Route managed scalar and geographic SQL to the physical store when an
  attached UNION view shadows the model's logical name. Keep geographic list
  sidecars and their RTree updates in that same schema, including quoted
  attachment aliases. Seal geographic SQL failures at the Swift bridge.
- Expose the shared native close state to Swift so retained collection caches
  can reject new reads after their database closes.
- Preserve geographic query shape, bound precision and physical-store
  identity through attached queries, counts and pagination. Resolve update
  hook identities from the callback's quoted physical schema and table.
- Retire projected snapshots across parent close, maintenance, attachment
  topology changes and physical-store WAL pressure without interrupting a
  subsequent writer or unrelated store.
- Capture attachment identity and schema metadata within their owning SQLite
  execution scope so a continuously active writer cannot win every repeated
  metadata acquisition. Keep existing metadata types and filtering; report a
  null SQLite TEXT conversion as an allocation error instead of an empty name.

### Compatibility and validation scope
- Rebuild Core and all C++/Swift bridge consumers together. Internal object
  layouts changed; binary interchangeability is not assumed. The public C
  ABI declarations and export list remain unchanged.
- This is a qualification candidate. Full native, C ABI, SDK and JS/WASM
  compatibility remain release gates. No benchmark speedup is claimed;
  native memory projection and durable cursor-backed observation remain open.

## [2.0.7] - 2026-09-21

### Fixed
- Serialize concurrent access to the shared global row-ID random generator.
  Concurrent writers in separate database instances could race while drawing
  random values. Initialization and both draws now use one shared mutex;
  UUID formatting occurs after releasing the mutex.
- Preserve the existing random algorithm and UUID representation. This prevents
  the shared-generator data race in future writes; it does not repair earlier
  duplicate identities or restore overwritten values.

### Compatibility
- No persistent schema, sync wire format, or public C ABI change is intended.
- Automatic recovery and the broader performance work remain in development.
  This maintenance release does not claim a measured latency improvement.

## [2.0.6] - 2026-09-19

### Fixed
- Preserve complete SQLite TEXT byte lengths, including embedded NUL bytes,
  when binding and extracting native values.
- Escape quoted attachment aliases when building attached views and detaching
  databases.
- Initialize missing or wrong-type native Double values deterministically.
- Initialize snapshot-reader caches at their final size, avoiding a redundant
  cache-setting statement while retaining ordinary reader defaults.

### Compatibility
- Rebuild Core and generated C++ bridge consumers together. No persistent
  schema, sync wire format, or public C ABI change is intended.
- This maintenance release does not include the development projection,
  exact-read, batch-mutation, relay-admission, or automatic-recovery APIs.
  It does not claim the broader 2× p95 performance target.

## [2.0.5] - 2026-09-19

### Fixed
- Deliver each audit row once for persistent Emscripten stores, including link
  table changes. These stores already buffer audit inserts directly; avoid
  deriving a second notification from the same committed model change.
- Pass the synchronizer's actual scheduler to transport factories, including
  lazy connection setup and handoff to another owner. Browser bindings can now
  retire queued transport callbacks with their database owner. Existing
  factories retain their behavior through the original no-argument method.
- This adds a C++ virtual overload. Rebuild Core and C++ transport implementations
  together; prebuilt C++ factory binaries are not interchangeable across this
  change. The C ABI, database schema and sync wire format are unchanged.

## [2.0.4] - 2026-09-18

### Fixed
- Serialize scheduled native sync work when a synchronizer receives the exact
  C++ `immediate_scheduler`, including overlapping pacer and caller requests.
  Keep each upload pass's enumeration-limit result local to that pass.
- Copy ACK timeout inputs before starting the detached watchdog, so delayed
  startup does not read the synchronizer before checking its lifetime guard.
- Protect mock transport state, message storage and callback slots against
  concurrent access; invoke copied callbacks outside the transport mutex.
- Keep internal ordinary and cross-process reader connections alive through
  their complete query when maintenance retires or replaces a connection.
  Restore attached views before publishing replacement readers, and release
  retired connections outside publication and attachment locks.
- Read audit-retention safety bounds and delete eligible history in one owned
  transaction. Concurrent writer-slot registration or reset can no longer
  invalidate a floor read before pruning begins. Preserve caller transactions,
  trigger flags, rollback errors and post-commit observer work.
- Generate each audit-history batch in its own owned transaction and capture
  its inserted-row count before a concurrent acknowledgement can overwrite it.
  Force regeneration uses a finite row frontier and snapshots current complete
  rows, including rows with partial remote-update history.
- Detect cooperative destructive maintenance or schema changes between
  regeneration batches. Prepare the existing remote-dedup receipt table before
  capturing the schema version, and preserve its receipts during regeneration.
  Batches commit independently; this is not one snapshot across all model tables.
- Add bounded regressions for reader retirement, routing, topology restoration
  and audit-maintenance ownership. Legacy raw connection references still
  require caller serialization; an internal read borrow does not extend its
  parent Lattice object's lifetime or grant write access.
- Rebuild Core and C++/Swift bridge consumers together: connection ownership
  changes private object layout. No schema migration or C API signature change.

### Changed
- For the exact native immediate scheduler, dispatched work runs inline while
  idle; overlapping or reentrant `sync_now()` work queues and returns. Existing
  upload coalescing still applies. This call is not an upload/ACK completion
  barrier. `drain(deadline)` is a bounded wait for an external caller and may
  expire; do not call it from a sync callback or while holding a database lock
  the queued work needs.
- Custom schedulers, including subclasses of `immediate_scheduler`, retain
  their dispatch policy. Worker/actor schedulers and WASM behavior are unchanged;
  custom native schedulers remain responsible for serialized sync operations.
- `mock_sync_transport::get_sent_messages()` now returns an owning snapshot.
  Replace borrowed `auto&` bindings with owning values and keep the snapshot
  alive while using its references/iterators; fetch again for later messages.
  The mock is now noncopyable. Rebuild downstream C++ test helpers and bridge
  consumers; no production transport or C API signature changes are introduced.

## [2.0.3] - Unreleased

### Fixed
- Allocate table and object observer tokens through one shared atomic counter.
  Concurrent registration previously incremented a plain counter under two
  different registry locks, causing an unsynchronized access.
- Preserve the shared token namespace, initial token 1, existing unsigned wrap
  behavior and per-registry cancellation semantics. Add a bounded concurrent
  registration/cancellation regression. No schema or public API changes.
- Rebuild Core and all C++/Swift bridge consumers together: the private counter
  member type changed, so binary layout compatibility is not assumed.

## [2.0.2] - Unreleased

### Fixed
- Destroy removed table, object and invalidation observer captures after
  releasing their registry locks. A captured object can synchronously cancel
  another observer during destruction without deadlocking the same registry.
- Preserve survivor order, missing-token behavior and existing in-flight
  callback semantics; add bounded native child regressions for each removal
  path. No schema or public API changes.

## [2.0.1] - Unreleased

### Fixed
- Read the committed audit cursor from the writer connection when flushing
  local observations. An unfinished SELECT on the ordinary reader could
  retain an older snapshot, rewind that cursor, and cause cross-process
  handling to deliver the same local insert twice.
- Add focused observer regressions for pinned-reader delivery and existing
  rollback/audit-disabled cursor recovery. No schema or public API changes.

## [2.0.0] - Unreleased

Audit-history hygiene. A consumer that rewrote one row ~10×/s grew an
AuditLog to 142K rows / 17 GB with under 1 MB of live data: nothing pruned
history on a store without sync partners, the only alternative renumbered
ids (deafening every sibling process), a streamed column copied its whole
growing body into every UPDATE row, force-compaction dropped link tables,
and VACUUM's outcome was never reported.

### Breaking changes
- Public C++/Swift bridge `vacuum()` now returns `bool`, and `checkpoint()`
  returns `checkpoint_outcome`, instead of `void`. Update explicitly typed
  method references and wrappers to the new result types. Calls that simply
  discard the results retain their ordinary call form.
- Rebuild bridge consumers against the selected 2.0.0 headers and library.
  This release does not claim binary interchangeability with 1.4.x.

### Added
- Add an error-reporting overload for preserving-global-ID insertion and
  expose list bridge error messages; retain the existing insertion overload.
- **`lattice_db::prune_audit_log(retention_seconds)`** — cursor-safe,
  age-based pruning that never touches `sqlite_sequence`. The bound is
  INSERTION time from recorded watermarks (`record_audit_watermark()` stores
  `(now, MAX(id))` in `_lattice_meta`), not the row's own `timestamp` (an
  applied remote row keeps its origin timestamp), capped by the floor of
  non-observer replication slots. O(1) per sample, no index, no scan.
- **`configuration::audit_retention_seconds`** (0 = off) arms one small
  maintenance thread per database that runs the prune every half-window;
  N handles/processes on one file coordinate through
  `_lattice_meta['audit_prune_at']` and do ONE prune per interval.
- **`property_descriptor::no_history`** — a column whose UPDATE audit rows
  record the column NAME but not its value (`changedFields` carries `null`,
  `changedFieldsNames` still lists it, the trigger still fires). INSERT and
  DELETE rows keep full values. Sync **late-binds** the live value:
  `query_audit_log_for_sync` and `events_after` fill such columns from the
  live row (or drop the column when the row is gone); receivers never bind a
  null for a `no_history` column (`apply_remote_changes` drops it instead).
  `no_history_live_values_json()` provides the same fill for audit rows
  serialized outside core. A schema that gains the flag rebuilds its UPDATE
  trigger once on the next open (`_lattice_meta['trigger_flags:<table>']`).
- **Observer replication slots** — `sync_config::is_observer` /
  `configuration::sync_is_observer`, `register_replication_slot(db, id,
  is_observer)`, `set_replication_slot_observer()`: a read-only dial's own
  slot never advances a floor, so it is excluded from `safe_compact_audit_log`
  and `prune_audit_log` bounds and evicted on clean disconnect. The column is
  added lazily (`ensure_observer_column`, the `last_received_event_id`
  pattern) — no schema epoch bump.
- **Bridge** (`swift_lattice`): `reclaim_space()` — VACUUM → TRUNCATE
  checkpoint → reopen, in the order WAL mode needs for the MAIN file to
  shrink, reporting page counts; `bool vacuum()`; `checkpoint()` returns a
  `checkpoint_outcome`; `checkpoint_bounded` returns -2 when the call threw
  (a legitimate 0 used to be indistinguishable); `audit_header_for(id)` (row
  header without touching the payload); `prune_audit_log`,
  `record_audit_watermark`, `set_replication_slot_observer`,
  `no_history_live_values_json` forwarders.
- **C API**: `lattice_db_prune_audit_log`, `lattice_db_record_audit_watermark`,
  `lattice_db_reclaim_space`, `lattice_db_set_slot_observer`;
  `lattice_sync_options_t` gains `audit_retention_seconds` and
  `sync_is_observer` at the tail (size-prefixed; sentinel -1 keeps defaults).
  LatticeJS/wasm bindings mirror the bridge by hand and need a follow-up bump.

### Fixed
- Route standard C++ exceptions from integer increments, list access and
  mutation, and object removal through the bridge error channel so Swift
  callers can detect these failures. Direct bridge consumers should inspect
  the error channel rather than rely on those exceptions escaping.

### Changed
- **`force_compact_audit_log()` keeps the AUTOINCREMENT sequence.** Every
  attached process seeds its cross-process cursor from `MAX(id)` and reads
  forward, and the relay's observer-push cursor is a raw pk; restarting ids at
  1 put every regenerated row BELOW those cursors. Regenerated snapshots now
  take ids above the old maximum and flow through every live cursor. Slots
  still reset to floor 0 (a full re-scan, not incorrect).
- **`generate_history()` regenerates link tables.** The blanket
  underscore-prefix exclusion dropped every `_Parent_Child_prop` link table,
  so a compaction regenerated rows detached from their relationships. Tables
  are now classified by shape (link: `lhs`/`rhs`[/`rhs_type`] + `globalId`,
  no `id`; model: `id` + `globalId`; anything else skipped), and link rows are
  emitted in the live trigger's payload shape.
- `safe_compact_audit_log` computes its floor over non-observer slots only.

## [1.2.1] - 2026-08-05

### Changed
- **Parse-once wire codec**: `server_sent_event::from_json` hands each
  auditLog array element to the entry parser as the ALREADY-PARSED object;
  it used to `dump()` each sub-object and re-parse it, so every entry on
  the wire was parsed twice (changedFields a third time). Symmetrically,
  `server_sent_event::to_json` embeds `entry_to_json_obj(...)` directly
  instead of `json::parse(entry.to_json())`. Wire format is byte-identical;
  this is pure per-entry overhead removal on the exact path catch-up
  hammers — the browser client (2,155 MB measured catch-up payload) is the
  main beneficiary, but every relay hop shares the codec.

## [1.2.0] - 2026-08-04

### Added
- **`lattice_db::delete_rows_no_relay(table, global_row_ids)`** (bridged on
  `swift_lattice_ref`): hard-delete rows and log each as a DELETE audit
  entry carrying the `__lattice_filter_removal` marker — the shape WSS
  receivers skip-and-ack (defense-in-depth gate shipped in 1.1.0/A4) and
  IPC receivers record fully-synchronized. The rows vanish locally; every
  peer keeps its own copy. Row deletion runs with sync disabled so the
  audit triggers stay silent (a trigger-written unmarked DELETE alongside
  the marked one would relay fleet-wide), the marked entries are written by
  hand, and everything commits in one transaction with the pre-existing
  `_SyncControl.disabled` value restored.

  This is the sanctioned emitter of group-wide hard deletes for Engram's
  admin tombstone purge; a normal delete on a shared group DB classifies
  through members' spoke→hub sync sets and cascades into their personal
  hubs. No schema change; purely additive → MINOR.

## [1.1.0] - 2026-08-04

Stage A sync hardening: multi-channel hubs (one database feeding several
independently-filtered synchronizers) are now correct. Public API is
purely additive; the schema-format epoch moves 3 → 6, which migrates
forward automatically but is NOT downgrade-safe (an older binary's
two-column insert into the rebuilt `_lattice_sync_set` hits
`sync_id NOT NULL`).

### Added
- **Stage A sync hardening for multi-channel hubs (A2–A6, Engram Groups increment 1)**:
  - **A2 — per-channel filter control**: `lattice_db::update_sync_filter(channel, filter)` /
    `clear_sync_filter(channel)` ("" = WSS) target ONE synchronizer; the
    fan-out overloads remain but are documented single-channel-only. Bridge:
    `update_sync_filter_for_channel` / `clear_sync_filter_for_channel`.
    `ipc_target.narrowing_emits_removals` plumbs through to the synchronizer.
  - **A3 — schema-skew tolerance**: apply drops unknown columns (loudly) and
    applies the remainder; unknown-table entries skip-and-ack; an
    unknown-only UPDATE acks as a no-op. Ends the silent unacked-resend
    wedge class; the receiver's AuditLog bookkeeping keeps the ORIGINAL
    payload so onward relay is lossless.
  - **A4 — narrowing never deletes beyond bookkeeping**: marked
    filter-removal DELETEs applied over any per-sync channel are recorded
    fully-synchronized (they clear the local mirror and stop dead — an
    unfiltered uplink can no longer forward them to a shared server DB);
    `sync_config.narrowing_emits_removals=false` makes narrowing
    bookkeeping-only (group-channel semantics: spokes stay full mirrors).
  - **A5 — synthesized snapshots are insert-if-absent**: new
    `audit_log_entry.synthesized` provenance flag (AuditLog column, epoch 5;
    optional wire key, ignored by old peers) set by reconcile Phase-2
    additions, classify's UPDATE→INSERT conversion, and nuclear-compact
    regeneration (`generate_history(mark_synthesized:)`). Apply skips the
    SQL when the row already exists — stale local snapshots can no longer
    revert newer peer edits or resurrect tombstones.
  - **A6 — channel teardown hygiene**: eager-collapse counts only sync_ids
    with LIVE replication slots (a dead channel's stale confirmations could
    collapse an entry before a live channel relayed it — silent relay
    loss); new `remove_sync_channel_state(sync_id)` retires a channel
    (state + set + slot) so it can't pin compaction.
  - Tests: `SkewToleranceTests` (3), `FilterRemovalGateTests` (3),
    `SynthesisNoClobberTests` (4), + 2 A6 cases in `MultiChannelSyncSet`.
    Full suite 249/249.

### Changed
- **`_lattice_sync_set` is per-synchronizer (A1, Engram Groups increment 0)**:
  PK widened from `(table_name, global_row_id)` to
  `(sync_id, table_name, global_row_id)`; all membership reads/writes
  (`sync_set_add/remove/contains`, `clear_sync_filter`, both
  `reconcile_sync_filter` phases, `classify_entries` preload, the
  pending-query sync-set EXISTS) scope to the owning synchronizer's
  `sync_id`. Two filtered channels on one database no longer share (or
  clobber) membership state — the shared shape made channel A synthesize
  cross-channel DELETEs for channel B's rows (`!matches && in_set`, and
  reconcile Phase-1 removals over the global set), the mechanism class
  behind the Mar 2026 filter-narrowing data loss. `reset_sync_state` now
  wipes only the named channel's set (the multi-slot skip hack is gone).
  Existing databases rebuild on open via `migrate_sync_set_to_per_sync_id`
  (schema-format epoch 4 → 5): one registered replication slot → rows
  attributed to it; otherwise rows drop and reconcile Phase 2
  re-synthesizes membership idempotently. New `MultiChannelSyncSet` gtest
  suite (5 tests) pins isolation, scoped reconcile, both migration paths,
  and scoped reset.

## [1.0.1] - 2026-07-25

### Fixed
- **In-transaction read routing is now thread-scoped.** 1.0.0's fix for
  C-ABI reads missing an open transaction's uncommitted writes routed ALL
  reads through the write connection while a transaction was open — so a
  concurrent reader on another thread could observe uncommitted state,
  breaking reader isolation (caught by the Swift suite's
  `fileStore_otherThreadReads_neverSeeTheOpenTransaction` pin on the first
  run against the released core). `read_db()` now routes through the write
  connection only for the thread that opened the transaction; every other
  thread keeps the dedicated reader and sees committed state only.

## [1.0.0] - 2026-07-25

LatticeCore 1.0.0. The C ABI is frozen and additive-only from this release
(docs/CAPI-STABILITY.md): exactly the 118 exported `lattice_*` functions in
`lattice_capi.symbols`, enforced by an `nm` diff in CI on macOS and Linux.
The on-disk schema-format epoch is 4.

Consolidates 1.0.0-rc.1 (the freeze) plus the post-rc conformance-driven
fixes below. Changes relative to 0.10.11:

### Fixed
- **Cross-SDK conformance: per-property `is_unique` now produces DDL on the
  C-ABI/core paths.** `lattice_property_t.is_unique` survived into the
  descriptors and the schema fingerprint but generated no `CREATE UNIQUE
  INDEX` anywhere — only the Swift bridge's constraint-driven pass ("Phase 8")
  emitted unique indexes, so C-ABI-created databases (Python/Kotlin/JS) never
  enforced uniqueness that Swift-created ones did, including on the same file.
  The C ABI now canonicalizes `is_unique` into single-column constraints (in
  property declaration order) so Phase 8 emits them, and the core registry
  ensure path gained an equivalent `ensure_unique_property_indexes` pass.
  Index naming is identical across all paths (`unique_<table>_<ordinal>`), so
  mixed-SDK reopens find the index already present instead of double-indexing.
  `kLatticeSchemaFormatEpoch` bumped to 4 (guarded, auto-migration-safe DDL;
  existing fingerprinted databases revalidate once and gain the indexes).
- **Cross-SDK conformance: C-ABI reads inside an open transaction see the
  transaction's uncommitted writes.** `lattice_db_count`/`lattice_db_query`
  always executed on the dedicated read-only connection, which under WAL
  cannot see an open transaction on the write connection
  (`lattice_db_begin_transaction`). `read_db()` now routes reads through the
  write connection while it has an open transaction (live autocommit state —
  self-correcting on COMMIT/ROLLBACK); outside a transaction, read routing is
  unchanged.
- **Cross-SDK conformance: dynamic add with a geo-bounds property no longer
  fails with "table has no column named `<name>`".**
  `lattice_object_create_with_schema` rebuilt property descriptors by hand and
  dropped every index/constraint/geo/vector flag, so an `is_geo_bounds`
  property was treated as a plain column and the INSERT targeted the raw
  property name instead of the four expanded
  `<name>_minLat/_maxLat/_minLon/_maxLon` columns. It now shares the C ABI's
  full descriptor conversion, and `swift_dynamic_object` seeds non-nullable
  geo defaults into the expanded columns rather than the raw name.

### From 1.0.0-rc.1


The C ABI freeze (plan WS-C C1 exit; docs/CAPI-STABILITY.md becomes binding:
additive-only from here).

### Changed
- **Default-hidden visibility + `LATTICE_EXPORT`** (stability rule 8): the
  shared library now exports exactly the 118 declared `lattice_*` functions;
  the static libs it absorbs (LatticeCore, LatticeSwiftCppBridge) build
  hidden too, so their C++ symbols no longer re-export through the `.so`.
- `LATTICE_CAPI_VERSION*` macros bumped to 1.0.0 (`lattice_capi_version()`
  returns 1000000). The rc identity is the git tag; the version string keeps
  its documented MAJOR.MINOR.PATCH shape.

### Added
- **C1 slice 3 — Linux SwiftPM fix, C-ABI CI leg, to_json, unified-open
  decision** (plan WS-C; `docs/capi-gap-audit.md` V1, A-11, A-33):
  - **Linux `swift build` of ALL targets fixed** (audit V1): handwritten
    `module.modulemap`s for `LatticeSwiftCppBridge` and
    `LatticeCAPIHeaderCheck` (the pattern LatticeCore/SqliteVec/GoogleTest
    already used). The bridge map needed a twist the audit's fix shape
    missed: an all-textual map fixes Linux but empties the module for the
    Lattice Swift package's `import LatticeSwiftCppBridge` (C++ interop).
    New `swift_module_umbrella.hpp` is the module's single real header —
    Swift's ClangImporter builds the module from it (all bridge headers
    textually inlined, same alphabetical order the synthesized umbrella
    used); every other header is `textual`, and no C++ TU may ever include
    the anchor. Verified: `swift build` green in swift:6.3-noble (all
    targets) AND the Lattice Swift package builds against the fixed tree.
  - **`lattice_object_to_json(obj, max_depth)`** (audit A-11, sized M):
    object-graph → JSON walker implemented ONCE in the bridge
    (`dynamic_object::to_json`, Swift-reachable as `toJson(maxDepth:)`)
    and wrapped by the C ABI. Output contract PINNED to Swift's
    `DynamicObject.jsonObject(maxDepth:)` shape — `globalId`/`id`,
    primitives by declared column type (blobs base64, embedded JSON text
    inlined), vectors omitted, geo `{lat,lon}`/`{minLat…}`, links recursed
    to depth with `{"globalId"}` stubs at boundary/cycle revisits, lists as
    arrays or `{"count"}`/`{"geoBoundsCount"}` summaries, unions
    `{"unionRef"}`, `table:globalId` cycle guard. Feature string `to_json`
    flipped true; contract documented in `lattice.h` +
    `docs/CAPI-STABILITY.md`. 5 new LatticeCAPITests (28 total): scalar
    types/base64/embedded-JSON, link depth + stubs, cycle termination,
    list expand/summarize, unmanaged + error contract.
  - **C-ABI CI leg** (`.github/workflows/capi.yml`, Linux + macOS): builds
    the SHARED LatticeCAPI via CMake, diffs `nm` exports against
    `lattice_capi.symbols` (the freeze gate, now enforced at the linker
    level), runs LatticeCAPITests against the shared library, compiles
    `lattice.h` as pure C11, and pins the V1 fix with a full Linux
    `swift build`. Kept as its own workflow: the linux/macos legs gate the
    core suite; this one gates the ABI.
  - **CMake-on-Linux portability** (surfaced by the new CI leg; the CMake
    path had only ever been exercised on Android/macOS): `LatticeCore` now
    defines `SQLITE_CORE` (parity with Package.swift — without it,
    sqlite-vec.h flips into sqlite3ext.h extension mode on Linux and every
    sqlite3_* call expands to the undefined `sqlite3_api` thunk table), and
    the SqliteVec NEON kernels are gated to Clang (GCC's strict intrinsic
    signatures reject them on aarch64).
  - **Unified `lattice_db_open`: DEFERRED TO 1.1** (drop-gate applied
    honestly — `docs/design-unified-open.md`): the migration value-union
    ABI cannot be pinned while G3's `(rowId, [String: ColumnValue])` shape
    is unlanded in the Swift repo (its `enumerateObjects` is still a stub),
    write-path ownership is undecided, and the bridge's single
    row-migration slot lacks version dispatch. The plan prices the
    fallback as free (additive post-1.0). `unified_open` stays
    reserved-false; the design doc carries the full proposed
    `lattice_open_options_t`/`lattice_migration_step_t` shape and the 1.1
    checklist. Symbols file: 117 → 118 exports
    (`lattice_object_to_json`).

- **C1 slice 2 — C-ABI sync surface + feature functions** (plan WS-C;
  `docs/capi-gap-audit.md` A-8/9/10, A-15, A-22..A-30, A-32):
  - **Sync options** (audit A-22): size-prefixed `lattice_sync_options_t`
    (`struct_size` first member, impl reads `min(caller_size, sizeof)`)
    carrying the 9 sync-tuning knobs + `sync_filter_json`;
    `lattice_sync_options_init()` fills "keep the library default"
    sentinels; `lattice_db_create_with_sync_options(...)` =
    `lattice_db_create_with_sync` + trailing options pointer (the old
    positional creator stays as-is per the additive policy). Knobs wire
    through `configuration::sync_tuning` via the bridge setters, so
    nonsensical values are ignored identically. `sync_id` field is
    RESERVED (must be NULL — fails loudly, so a future override can't be
    silently dropped by older libraries).
  - **Sync progress + observers** (A-22..A-28): size-prefixed
    `lattice_sync_progress_t` + `lattice_db_get_sync_progress` (zeroed on
    a sync-less db); `lattice_db_observe_sync_progress` /
    `lattice_db_observe_sync_state` / `lattice_db_observe_sync_error`
    (context + fn-pointer + destroy pattern, token-returning,
    multi-observer fan-out over the bridge's single callback slot, keyed
    by the underlying instance so cached-instance-sharing handles don't
    clobber each other) + `lattice_db_remove_sync_observer`;
    `lattice_db_close` tears observers down and fires their destroys.
  - **Attach completion** (A-29/30): `lattice_db_detach` (idempotent,
    same bool + reason contract as attach) and
    `lattice_db_last_attach_error` (thread-local copy of the core's
    mutex-guarded accessor).
  - **Feature functions**: row cache on objects
    (`lattice_object_enable/disable/refresh_row_cache`,
    `lattice_object_is_row_cache_enabled`; per-object receiver — A-8),
    `lattice_object_increment_int` (SQL-side atomic increment — A-9),
    `lattice_db_total_statement_count` / `lattice_db_thread_statement_count`
    (A-10), `lattice_db_checkpoint(db, mode)` (0=passive, 1=truncate —
    A-15), `lattice_db_read_upload_floor(db, sync_id)` (A-32; sync-id
    derivation documented in the header).
  - Feature strings flipped true: `checkpoint`, `detach`, `row_cache`,
    `statement_counters`, `sync_progress`, `sync_tuning` (still reserved:
    `read_generations`, `to_json`, `unified_open`). Symbols file
    regenerated (99 → 117 exports).
  - **Tests/LatticeCAPITests**: new gtest target that LINKS the C surface
    (SwiftPM: macOS-only executable, so the Linux `swift run
    LatticeCoreTests` closure never grows the C API library —
    `docs/capi-gap-audit.md` V1; CMake: built everywhere). Behavioral
    coverage for every slice-2 addition plus slice-1 pins: the
    formerly-phantom cross-process observers fire for sibling-instance
    writes, and `receive_sync_data` per-entry isolation.

### Fixed
- `apply_remote_changes` per-entry isolation now covers the WHOLE entry
  apply, not just the instruction execute: an entry naming an unknown
  table (schema drift) threw out of the pre-apply row lookup and aborted
  the whole batch — and entries applied in earlier committed chunks were
  never reported to the caller (the audit's B-2 "applied but unreported"
  pathology recurring at chunk granularity). Failing entries are now
  skipped (not acked; the sender re-sends) while the rest of the batch
  applies. Surfaced by the new C-level
  `CAPIReceiveSyncData.PerEntryErrorIsolation` test.

### Added
- **C1 slice 1 — C-ABI foundation** (plan WS-C; `docs/capi-gap-audit.md`):
  - Versioning/introspection on the C ABI: `lattice_capi_version()`,
    `lattice_capi_version_string()`, `lattice_schema_format_epoch()`,
    `lattice_capi_has_feature(name)` (+ `LATTICE_CAPI_VERSION*` header
    macros). Feature strings cover what exists today; reserved strings are
    documented and return false until they land.
  - Implemented the two **phantom symbols** (audit B-9):
    `lattice_db_observe_cross_process` /
    `lattice_db_remove_cross_process_observer` — declared in the frozen
    header since 2026-03-27 but never defined. Registered over the core
    cross-process notifier's shared batched change-dispatch path.
  - **ABI freeze enforcement**: checked-in canonical export list
    `Sources/LatticeCAPI/lattice_capi.symbols` + `CAPISurfaceTests`
    (declared⊆implemented, implemented⊆declared, symbols-file exact match)
    + `capi_header_compiles.c` compiled as pure C11 in the suite (new
    C-only target `LatticeCAPIHeaderCheck`). Would have caught B-9 the day
    it happened.
  - ABI policy: `docs/CAPI-STABILITY.md` (additive-only post-1.0, enums
    grow at tail, `struct_size` on new pointer-structs, deprecated wrappers
    survive 1.x, thread-local `lattice_last_error`, symbols-file gate).
  - Core: public `lattice_db::schema_format_epoch()` accessor for the
    protected epoch constant.

### Fixed
- `lattice_db_receive_sync_data` (audit B-2, P1): replaced a divergent
  all-or-nothing reimplementation with the same core path the Swift bridge
  uses (`swift_lattice::receive_sync_data` → `apply_remote_changes`):
  per-entry error isolation, returns ONLY successfully-applied ids; total
  failure returns NULL with `lattice_last_error()` set.
- `lattice_db_set_sync_filter` (audit B-3, P1): the impl parsed only the
  core key `"where_clause"` while the header documented `"predicate"` — a
  documented-form filter silently synced ALL rows. Both keys are now
  accepted (documented; `"predicate"` preferred).
- `lattice_db_create_with_migration` (audit B-8, P1): the JSON row
  round-trip silently dropped BLOB columns. Migrating a table with BLOB
  columns (declared, or encountered in old rows) is now an explicit
  documented error instead of silent data loss; full BLOB-capable migration
  rides the unified-open ABI work.

## [0.10.11] - 2026-07-16

### Added
- **Item-A core machinery (additive)**: synchronous invalidation hooks
  (commit/rollback/advance, fired post-commit on the writer thread via the
  transaction-settled drain), the read-generation keeper pool (held-read-txn
  MVCC generations on pooled read-only connections; max 3, TTL + WAL-threshold
  + lifecycle retirement, force-retire protocol), per-path WAL-threshold
  propagation, pacer-driven read-pool maintenance, and the bridge surface for
  all of it (generation-scoped reads, changed-fields hook variant, data_version,
  exception containment throughout). Consumed by lattice 1.0's Results
  redesign; no existing API changed.

### Fixed
- Generation-read TOCTOU: a read racing a force-retire could serve rows from
  the WRONG snapshot with no error — reads now re-validate retirement after
  the statement and retired keepers with in-flight reads are never re-pooled.

### Added
- **Live Results item A, Commit 4** (lattice repo
  `docs/design-results-item-A-SPEC.md`; bridge — consumed by the lattice
  repo's Commit 5): generation + hook surface on
  `swift_lattice`/`swift_lattice_ref`, exception containment.
  - **Synchronous invalidation hook trampoline** (spec §2.3):
    `add_invalidation_hook(context, c_fn, destroy)` /
    `remove_invalidation_hook(token)` — established C-function-pointer +
    context pattern; the callback receives the changed-table array + reason
    (0 = commit, 1 = rollback, 2 = advance) INLINE on the writer's thread,
    and the §2.3 restrictions (atomics only; no SQL; nothing that throws)
    apply to the Swift body verbatim. Additive overload
    `add_invalidation_hook_with_fields` also delivers per-table
    `changed_fields` — non-empty only for UPDATE-only batches with known
    fields (comma-joined deduped union); delivered now, consumed by the
    v1.1 changedFields skip (Commit 8). Backed by new core
    `add_invalidation_hook_detailed` (+ `invalidation_table_change`);
    the Commit-3 basic hook API and payload are unchanged.
  - **Read-generation pool forwarding** (spec §2.2/§3):
    `acquire_read_generation` (0 = refused/no keeper),
    `retain_read_generation`, `release_read_generation`,
    `retire_all_read_generations` (§3.6 lifecycle),
    `read_generations_outstanding` (+`local_`), `run_read_pool_maintenance`,
    and the §1.7 tunables (`set_read_generation_ttl_ms`,
    `set_read_generation_max_age_ms`,
    `set_wal_keeper_eviction_threshold_bytes` + getter,
    `wal_eviction_pending`). Every wrapper is catch-all — sentinels, never
    a throw across interop.
  - **Generation-scoped reads** routed through core `query_at_generation`
    with the SAME SQL builders as the live paths (`build_query_rows_sql` /
    `build_count_sql` extracted in core; bbox builder factored in the
    bridge): `objects_at`, `count_at` (−1 sentinel),
    `objects_within_bbox_at`. Failures (retired/unknown generation,
    interrupted statement, throwing read) return empty/−1 plus the
    per-thread `last_generation_read_stale()` flag (§2.5 tolerant ladder).
  - **`query_ids_at(table, where, orderBy) → [int64]`** (spec §4.1
    materialized-id capture for the memory family): capture transaction +
    per-store write gate + bounded LOCKED sleep-backoff retry (~250 ms
    budget), degrading to empty + stale. Id order ≡ row query order by
    construction (same builder, `id` select list).
  - **`data_version() → int64`** on the dedicated non-transaction
    `xproc_read_db_` connection (−1 on failure) — the §4.4 cross-process
    belt Commit 6 consumes; changes on foreign-connection commit only.
  - Tests: 8 new (`BridgeGeneration.*`) — synchronous same-thread hook
    delivery through the bridge, generation read round-trip + MVCC pin,
    retired/unknown-generation sentinel path, memory-store acquire refusal,
    id-vector order ≡ row order, fault injection (throwing read ⇒ empty +
    stale, process alive), data_version foreign-commit-only, changed_fields
    payload (INSERT ⇒ empty; UPDATE-only list append ⇒ property name).
    Full suite 223/223 green.
- **Live Results item A, Commit 3** (lattice repo
  `docs/design-results-item-A-SPEC.md`; core only — bridged in Commit 4):
  - **Synchronous invalidation hooks** (spec §2.3):
    `lattice_db::add_invalidation_hook`/`remove_invalidation_hook` fire
    inline on the writer's thread once per settled top-level transaction —
    after the commit is durable, BEFORE the scheduler-dispatched
    table-observer fan-out — fanned to every alive same-path instance via
    the instance registry (sync-handle commits reach app-handle hooks
    synchronously). Payload: changed table names + reason
    (`commit`/`rollback`/`advance`). Rollbacks signal too (wired at the
    `discard_change_buffer` rollback hook); empty-buffer commits
    (bookkeeping-only transactions) signal with an empty payload — every
    commit grows the WAL a keeper pins. Callback contract is normative:
    atomics/leaf-locks only, no SQL, nothing that can throw.
  - **Read-generation keeper pool** (spec §2.2/§2.5):
    `acquire_read_generation`/`retain`/`release` pin a held read transaction
    (`BEGIN` + pin SELECT) on a pooled dedicated read-only connection (cap
    3, cache_size clamped to 2,000 pages); `query_at_generation` executes
    reads at that MVCC snapshot and never throws (retired/interrupted reads
    return nullopt → tolerant ladder). Memory-family stores (private
    `:memory:`, named shared-cache) and Emscripten are refused keepers
    (spec §4.1). Pool exhaustion force-retires the oldest generation.
  - **WAL-retention policy** (spec §3): `run_read_pool_maintenance()` —
    callable with no synchronizer — TTL-retires idle generations (30 s
    default; "active reads" = in-flight statements), force-retires past an
    absolute age cap, and executes pending threshold evictions. The WAL
    hook's frame count arms a per-path eviction flag at
    `wal_keeper_eviction_threshold_bytes` (16 MB default, tunable): ALL
    same-path keepers force-retire (§3.4 protocol: retiring flag +
    `sqlite3_interrupt` + bounded COMMIT retry) and one bounded
    TRUNCATE-else-PASSIVE checkpoint runs in the reader gap.
    `read_generations_outstanding()` aggregates per PATH across
    `instance_registry::for_each_alive` (the synchronizer owns its own
    `lattice_db` — consulting one instance would always read 0).
  - **Pacer interplay** (spec §3.3): `maybe_checkpoint`'s TRUNCATE keeps its
    attempt-with-budget + PASSIVE fallback (no outstanding-gate); when
    beaten by a keeper it now issues `request_generation_advance()`,
    delivered through the invalidation-hook path per path.
  - **Per-store write gate** (spec §4.1): shared-cache memory stores publish
    a per-path recursive gate (`instance_registry::write_gate`); lattice
    write-transaction entry points (`begin_transaction`/`commit`/`rollback`,
    `write`, `add`, `add_bulk`, `remove` cascade) and sync's chunked apply /
    mark-synced paths hold it for the transaction, so generation captures
    and cross-connection writes never overlap (no surfaced SQLITE_LOCKED in
    either direction). File/isolated-`:memory:` stores: no-op.
  - **Close ordering** (spec §4.6): `close()`/`~lattice_db` retire the pool
    (COMMIT keeper txns, close pooled connections) before `db_`/`read_db_`
    teardown; post-close generation reads return empty.
  - `database::interrupt()` (sqlite3_interrupt wrapper) for the force-retire
    protocol.

### Fixed
- **Item-A adversarial verification, CORE findings** (spec
  `docs/design-results-item-A-SPEC.md` in the lattice repo):
  - **Finding 1 (MAJOR — `query_at_generation` TOCTOU):** a reader that
    passed the liveness check and bumped `in_flight` but was descheduled
    before its statement started could be lapped by a force-retire
    (pool-cap victim / max-age / retire-all / WAL eviction):
    `sqlite3_interrupt` no-ops on a not-yet-started statement, the keeper
    COMMITted, the connection was re-pooled, and a new acquire re-pinned
    it — the delayed SELECT then ran at the WRONG snapshot with no error
    and no stale sentinel. Two-sided fix: (a) `commit_and_pool` never pools
    a connection whose generation still has `in_flight > 0` statements
    (drops it — closing a connection is cheaper than a wrong-snapshot
    read); (b) `query_at_generation` re-checks `retiring` after the
    statement returns (`retiring` is set, release, under the pool lock
    before every keeper COMMIT, so a wrong-snapshot read must observe it)
    and yields nullopt → tolerant ladder. Pinned deterministically via a
    new test seam (`test_hook_generation_query_gap_`) that widens the gap
    between the in-flight bump and statement execution; new diagnostics
    accessor `idle_read_pool_size()`.
  - **Finding 2 (MAJOR — WAL eviction threshold never reached
    synchronizer/IPC instances):** `wal_keeper_eviction_threshold_bytes_`
    is read by each instance's OWN WAL hook, and the synchronizer owns its
    OWN `lattice_db` per path — so sync-applied commits policed the default
    forever. `set_wal_keeper_eviction_threshold_bytes` now fans out to
    every alive same-path instance via `instance_registry::for_each_alive`
    AND records a registry-level per-path value
    (`instance_registry::set_wal_eviction_threshold_for_path` /
    `wal_eviction_threshold_for_path`) that new instances adopt at open
    (after registration). Isolated `:memory:` stores stay instance-local
    (they share the literal registry key without sharing storage).
  - **Finding 3 (MINOR — spec §3.2's second enforcement caller dropped):**
    the sync pacer now runs read-pool maintenance each cycle at the
    `maybe_checkpoint` cadence via new
    `lattice_db::run_read_pool_maintenance_all_instances()`, aggregated
    per path like the TRUNCATE gate — the keepers live on the app handles,
    not the synchronizer's own instance.
  - Tests: `ReadGeneration.ForceRetireRaceNeverServesWrongSnapshot`
    (deterministic TOCTOU pin; verified to fail with either fix half
    reverted), `ReadGeneration.QuiescentRetirePoolsConnection` (no pooling
    regression), `ReadGeneration.WalEvictionThresholdPropagatesAcrossSamePathInstances`,
    `ReadGeneration.WalEvictionThresholdIsolatedMemoryStaysLocal`,
    `Sync.PacerRunsReadPoolMaintenancePerPath` (verified to fail without
    the pacer call).

## [0.10.10] - 2026-07-12

### Added
- Bridge forwards `rollback()` on `swift_lattice`/`swift_lattice_ref`
  (core `lattice_db::rollback` already existed) — enables the Swift
  `transaction { }` rollback-on-throw fix (1.0 item G8).

## [0.10.9] - 2026-07-12

### Fixed
- **Transaction-settled observer delivery for memory DBs**: in-memory (and
  Emscripten) update hooks now only buffer; delivery drains after the
  statement that closes the transaction — observers no longer run inside the
  writer's open transaction (shared-cache readers can't hit SQLITE_LOCKED;
  callback exceptions no longer unwind through SQLite's C hook frame).
  Memory-DB observers now see ONE batch per logical transaction in commit
  order, matching file DBs. A rollback hook discards buffered changes (fixes
  a latent file-DB phantom-notification-on-rollback bug), and flush_changes
  drains until empty (fixes stranded observer write-backs).
- **Sync fan-out for named memory**: synced-status AuditLog updates now reach
  all same-name shared-cache handles (new storage_shared_across_instances()
  policy helper); isolated `:memory:` stays local-only.
- **vec0 gap-reconcile reads `main.<table>`**: on an attached clone
  connection the bare table name resolved to the TEMP union view, healing
  the attached lattice's rows into main's vec index as permanent orphans
  (scheduling-dependent; surfaced as a CI flake).

## [0.10.8] - 2026-07-11

### Fixed
- **Path-exact detach**: `lattice_db::detach(lattice&)` resolved the alias by
  recomputing it from the filename stem with no path verification — detaching
  a never-attached lattice whose stem matched an attached one silently
  DETACHed the wrong database. Now resolves by exact path; unknown path is a
  clean no-op.
- **Uncached clone factory**: new `LatticeCache::create_uncached` /
  `swift_lattice_ref.createUncached` for query-only clone connections — the
  keyed cache deduped a clone whose stripped config matched its parent and
  returned the PARENT instance, so the clone's ATTACH mutated the parent's
  own connection.
- ATTACH alias identifier double-quote escaped; `sync_tuning::apply()` drops
  `chunk_size` 0 and nonpositive backoff delays; bridge delay setters require
  `> 0`; `path_is_memory` only classifies `file:`-prefixed URIs (an on-disk
  path merely containing `mode=memory` is a regular file).

## [0.10.7] - 2026-07-11

### Fixed
- **URI-capable connections everywhere**: `SQLITE_OPEN_URI` is set on every
  connection (SQLite only URI-parses names starting with `file:`, so plain
  paths are unaffected). Fixes attaching a named-memory lattice to a
  file-backed lattice, which previously created and attached an empty
  LITERAL file named `file:<name>?mode=memory&cache=shared`.
- **attach SQL escaping**: the attached path and the union views'
  `'<label>' AS _source` literal are single-quote escaped.
- **Sync tuning validation**: `swift_configuration.set_sync_*` setters ignore
  nonsensical values (`chunk_size <= 0` would permanently stall uploads;
  negative delays/windows dropped).
- **Instance-cache tuning fingerprint**: two opens of the same path with
  different sync tuning no longer silently share the first opener's
  synchronizer.
- **`last_attach_error()` thread safety**: mutex-guarded.

## [0.10.6] - 2026-07-11

### Added
- **Sync tuning plumb-through (1.0 item I1)**: `configuration::sync_tuning` —
  an all-optional overlay (chunk_size, reconnect/backoff knobs,
  stable_connection_ms, upload_coalesce_ms, checkpoint intervals,
  use_upload_floor) forwarded into every synchronizer the database creates
  (WSS and IPC). Unset fields keep sync.hpp's defaults. Bridge:
  `swift_configuration.set_sync_*` setters expose every knob to Swift.
- **Named in-memory identity (1.0 item E1, core side)**:
  `configuration::path_is_memory()` / `is_in_memory()` recognize named memory
  URIs (`file:<name>?mode=memory&cache=shared`). Same-name handles share one
  same-process database with exactly-once cross-instance observation via the
  URI-keyed instance registry; distinct names are isolated. Read-only side
  connections (`read_db_`, `xproc_read_db_`) stay null for all memory forms,
  and no cross-process notifier is created for memory URIs (process-local).

## [0.10.5] - 2026-07-11

(Note: the apply-path scan-storm and destroy-from-callback fixes formerly
listed here actually shipped in 0.10.4 — see that entry.)


### Added
- **attach/detach rework (1.0 items ATT-1..ATT-3)**: `lattice_db::attach` is
  now idempotent (repeat attach of the same (alias, path) is a no-op; duplicate
  SQLite alias tolerated), serialized behind an attach mutex, validates the
  peer's schema through its own live handle BEFORE attaching (mismatch throws
  cleanly with no side effects), and is null-tolerant on sync-enabled lattices
  (fixes a `read_db_` null-deref crash). New `detach(lattice_db&)` /
  `detach_alias()` drop the attachment's union views, DETACH with bounded
  retry on transient locks, and rebuild remaining views order-independently
  via `rebuild_attached_views()`. Bridge: `swift_lattice::attach/detach`
  return `bool` with `last_attach_error()` — C++ exceptions no longer cross
  the Swift interop boundary (consumed by lattice's throwing ATT-4 surface).

## [0.10.4] - 2026-07-08

### Added
- **Upload pacing machinery (ships default-off)**: the hot upload-trigger sites
  (AuditLog observer, upload tail-call, post-ACK next-window kick, ack-timeout
  resend) now route through `request_upload()` — the first request after an idle
  period dispatches immediately (leading edge), while requests inside the
  coalescing window collapse into one trailing-edge tick fired by a
  per-synchronizer pacer thread. `sync_config::upload_coalesce_ms` defaults to
  `0` (exact legacy immediate dispatch) for the built-in WSS/IPC synchronizers;
  consumers that measure a need can opt in.
- **Periodic WAL checkpointing**: the pacer drives a PASSIVE checkpoint every
  `checkpoint_passive_interval_ms` (default 60s) — unconditionally, including
  while disconnected — and an idle-gated TRUNCATE every
  `checkpoint_truncate_interval_ms` (default 300s) with a busy budget and a
  same-cycle PASSIVE fallback so backfill progress always happens. New
  `database::wal_checkpoint(truncate, busy_budget_ms)` primitive returns
  `(rc, busy, log, checkpointed)`. Fixes unbounded `-wal` growth under
  long-lived daemon connections (1.1 GB observed).
- **Incremental upload floor**: a per-slot `upload_floor` cursor on
  `_lattice_replication_slots` (guarded ALTER; schema format epoch 1 → 2) turns
  each upload pass from O(AuditLog) into O(send window).
  `query_audit_log_for_sync` gains `(min_id_exclusive, limit)` — the pending
  query is a PK range scan bounded to one send window even against a stalled
  server. The floor is only a scan bound (sync-state rows stay the source of
  truth): it advances only past resolved entries (ACK or skip), and a stale-low
  floor merely re-scans a window that filters back out. The send window now caps
  total in-flight, not sends-per-invocation. Kill-switch:
  `sync_config::use_upload_floor` (default true) restores the unbounded queries.
- **Opt-in row cache on `dynamic_object`**: `enableRowCache()` puts an object in
  materialized-read mode — property gets serve from the hydrated snapshot (zero
  SQL for query-fetched objects; `refreshRowCache()` is one `SELECT *`), with a
  known-NULL contract (`nullptr` in the snapshot = known NULL; an absent key
  falls through to the live per-column path — slower, never wrong). Writes stay
  write-through and mirror stored forms into the snapshot; links/lists/unions
  always read live; `disableRowCache()` restores the default path, which is
  untouched when the cache is off. Ref-level forwards expose the API to Swift,
  and materialized reads serve the primary key from the handle itself —
  `detached()` on a materialized object is 0 SQL statements.
- `dynamic_object::increment_int_field()` — atomic SQL-side
  `SET col = col + ?` increment under the write lock: no read-modify-write race
  and half the statements of get+set.
- SQL statement counters for statement-budget regression tests: process-global
  `database::total_statement_count()` (spans all connections) and thread-local
  `database::thread_statement_count()` (race-free under parallel test suites).

### Changed
- `classify_entries` preloads are gated on batch size: batches of ≤64 entries
  use the indexed per-row helpers instead of scanning all of
  `_lattice_sync_set` and every filtered table — steady-state paced ticks carry
  a handful of entries; bulk catch-up batches preload exactly as before.
- Catch-up continuation: when an upload pass fills its send window and makes
  progress (sent or skip-resolved), the next pass dispatches immediately instead
  of waiting for a coalesce/ACK signal — a floor-bounded backlog drains without
  per-window added latency, and a stalled server still can't spin the loop.
- The ack-timeout resend gains consecutive-failure backoff (10s → 20s → …
  capped at 5 min, reset by any ACK) — a stalled server is no longer
  re-hammered with the same window at a fixed cadence.

### Fixed
- **Self-hang when an observer callback releases the last lattice
  reference**: the destructor's in-flight-callback drain wait now excludes
  the current thread's own holds (it spun on itself forever — the
  long-standing intermittent test-suite hang), and a scheduler shutdown
  reached from its own worker detaches instead of self-joining.
- **Apply-path scan storm**: per-sync-mode applies write one
  `_lattice_sync_state` row per entry, and `flush_changes`' change→audit
  lookup reverse-scanned the entire AuditLog for each (no covering index) —
  1000-entry IPC batches against a 187k-row AuditLog burned minutes of CPU
  per batch, starving ACKs into a permanent resend storm. Pass 2 now skips
  never-audited bookkeeping tables, and AuditLog gains
  `idx_audit_log_change_lookup` (schema format epoch 2 → 3, same unreleased
  train).
- **Pacer ABBA deadlock**: the pacer thread held its coordination mutex while
  performing DB work (WAL checkpoints, inline coalesced ticks under an
  immediate scheduler). A writer mid-`sqlite3_step` holds the connection mutex
  and its change-hook observer calls `request_upload()`, which takes the pacer
  mutex — the two orders deadlock whenever a checkpoint heartbeat coincides
  with a commit. The pacer now releases its mutex around all DB work.
- **Reconnect backoff no longer resets on flappy opens**: `reconnect_attempts_`
  was reset on every `on_websocket_open`, so an endpoint flapping open→error
  re-armed a ~1s reconnect storm forever. The reset now fires on close/error and
  only when the connection was genuinely up for at least
  `sync_config::stable_connection_ms` (default 60s), so the exponential ladder
  escalates as intended.
- **Exact windowed upload counters**: progress `pending` was incremented with
  the full classified backlog before sends were windowed, so multi-window
  catch-ups re-counted the un-sent remainder every pass — `pending` ratcheted
  unboundedly and never returned to 0, permanently blocking `drain()` and any
  idle-gated maintenance. Invariant now: `pending` == in-flight
  (sent-but-unACKed), maintained at every in-flight mutation; `total` counts
  only entries actually sent. `drain()` can exit mid-backlog.
- The pacer thread starts whenever checkpointing is enabled, not only when
  coalescing is — the WAL checkpoint heartbeat no longer silently dies with
  coalescing off.
- BridgeTests macOS compile: migrated to `shared_for_lattice` and by-ref
  `push_back` after the underlying API changes.

## [0.10.3] - 2026-07-04

### Fixed
- **Windowed uploads**: `send_entries` blasted the entire backlog in one burst
  (25 × ~1 MB frames in seconds), blowing up relay backpressure until the server
  reset the connection mid-send. Sends are now windowed to 2 chunks per
  invocation — entries beyond the window stay pending (not in-flight) and the
  ACK-drain path ships the next window; the ack-timeout resend covers a lost one.
- **Reconnect after a transport error without a close event**: a connection
  reset left `is_connected_` true, so the reconnect gate refused to run and the
  synchronizer sat dead until process restart. `on_websocket_error` now marks
  the transport disconnected before scheduling the reconnect.

## [0.10.2] - 2026-07-04

### Fixed
- Linux/Docker build: the bridge header's WAL maintenance calls
  (`sqlite3_wal_checkpoint_v2`, `sqlite3_wal_autocheckpoint`, `sqlite3_exec`)
  are replaced with their exact SQL equivalents (`PRAGMA
  wal_checkpoint(TRUNCATE)`, `PRAGMA wal_autocheckpoint=N`, `PRAGMA optimize`) —
  in translation units that include `sqlite3ext.h` every `sqlite3_*` name is a
  macro over an undeclared extension pointer, breaking the build. `checkpoint()`
  keeps its busy/log/checkpointed telemetry from the pragma's result row.

## [0.10.1] - 2026-07-03

### Fixed
- Value-path (pre-FRT) migration backlink API:
  `migration_take_backlink_result` was declared FRT-pointer-only and
  `migration_lookup_backlinks` was defined only inside the FRT branch — below
  the FRT floor (iOS < 16.4) the first failed to import correctly in Swift and
  the second was a linker hole. Both now follow the dual-declaration
  convention, with value-path definitions returning an empty ref
  (`isValid() == false`) when absent. No behavior change on the FRT path.

## [0.10.0] - 2026-07-03

### Added
- **iOS 15 support — `LATTICE_HAS_FRT` floor switch**: Swift foreign-reference
  types are hard-floored at iOS 16.4 / macOS 13.3 and don't back-deploy. Below
  the floor the `*_ref` handle family now compiles as plain copyable value types
  over the same `shared_ptr`-owned state (factories return by value; the
  delegating surface is `const` so Swift holds the handles in `let`s), so the
  existing C++-interop Swift code runs on iOS 15 without a separate C backend.
  `std::format` is gated behind availability (`LATTICE_HAS_STD_FORMAT`) and the
  minimum iOS version drops to 15.
- **Schemaless (dynamic) open**: the full Swift schema (property descriptors,
  unions, constraints) is persisted into `_lattice_meta` on the DDL path and
  reconstructed on an open with no compile-time types (with a
  `sqlite_master`/PRAGMA fallback). `swift_lattice_ref.create_dynamic(config:)`
  opens read-only with no DDL; `dynamic_table_names()` /
  `dynamic_properties_for()` expose the schema to Swift. Backs the Lattice MCP
  query server, which now reads live rooms directly — no checkpoint required.
- **Union type support**: schema, storage, and bridge layer for discriminated
  union fields; union table schema evolution (rebuild on case addition); union
  values set in migration callbacks are persisted correctly (tables created
  before the migration loop, values persisted after the table rebuild).
- **IVF vector search**: sqlite-vec upgraded to v0.1.10; count-only
  nearest-query path; nearest-query CTE builder extracted.
- **`@Unique(compoundedWith:)` on link-kind fields**: link columns live in a
  separate table, so the UNIQUE index is built on shadow `<field>__link_gid`
  columns kept in sync by link-table triggers (shadow columns never ride sync).
  Adding a `@Unique` constraint over existing duplicate data auto-deduplicates
  (keeps the newest row per group) before retrying index creation, and a bare
  `@Unique` (no arguments) now generates its constraint.
- **Fresh-peer replay handshake (IPC)**: a recreated synced DB used to receive
  nothing on reconnect (the peer's sync set marked every row already-synced).
  An IPC synchronizer that has never applied a remote entry now announces a
  `replay_request` on connect, and the peer re-arms its filtered snapshot
  (reset + reconcile + upload). IPC only — never WSS.
- **Bounded teardown drain**: `drain(deadline)` runs one upload pass and waits
  until everything sent is ACKed, the connection dies, or the deadline passes;
  teardown runs it with a single 2s budget shared across all synchronizers.
  Dropping the last reference right after a write no longer cuts the in-flight
  sync entry. Definitively idle synchronizers skip the drain round-trip
  entirely.
- `find_indices()` bridge method: position-only list queries from joined SQL,
  skipping dangling links.
- Batched `generate_history()` (per-table batches in their own transactions,
  with a transient dedup index) and `cxx_error` propagation of C++ exceptions
  across the Swift bridge.
- `LATTICE_LOG_LEVEL` env var seeds the log level (0=off … 4=debug) without
  code changes.
- Comprehensive sync system documentation.

### Changed
- **No more `ANALYZE` at open.** `database::database` no longer runs `ANALYZE` on
  every read-write open — on multi-GB databases this scanned every index (seconds
  of I/O) while holding the write lock at the worst possible moment. Stats now
  refresh incrementally: `PRAGMA analysis_limit=400` is set at open and a
  best-effort `PRAGMA optimize` runs in the destructor. Long-lived processes that
  never destruct cleanly should run `PRAGMA optimize` from their own maintenance
  paths.
- **WAL bounded via `journal_size_limit`.** Read-write connections set
  `PRAGMA journal_size_limit=256MB` so successful TRUNCATE/RESTART checkpoints
  shrink the `-wal` file instead of leaving it fully allocated.
- **Busy timeout is configurable and defaults to 30s.** New
  `configuration::busy_timeout_ms` (default `kDefaultBusyTimeoutMs` = 30000,
  previously hardcoded 5000) applies to all connections of a `lattice_db`.
  Interactive apps that write on the main thread should set a small value
  (e.g. 5000). `begin_transaction` now zeroes the statement-level timeout during
  its retry loop and uses a wall-clock 30s deadline — previously each BEGIN
  attempt busy-waited the full statement timeout *and* the loop only counted its
  own sleeps, multiplying the worst-case wait far past the intended budget.
- **LatticeCache: build on-disk instances outside the cache lock.** `get_or_create`
  no longer holds `mutex_` across `swift_lattice` construction (DB open, migration,
  `ensure_swift_tables` COMMIT, sync/IPC setup). Concurrent opens of the same key now
  de-dup via a per-key in-flight `std::shared_future` instead of serializing the whole
  function, so `get_by_pointer` (the per-object materialization / `resolve()` hot path)
  and unrelated opens no longer block while another connection is opening or migrating.
  The `:memory:` path is unchanged (still constructs under the lock; each open stays a
  distinct instance).
- **Read-only opens are WAL-aware; `immutable` mode removed.** SQLite's
  `immutable=1` structurally ignores the `-wal` file, so a reader saw only the
  last checkpoint (a live DB with a 213 MB WAL read as 0 rows).
  `open_mode::read_only_immutable` is gone; read-only opens join a concurrent
  writer's WAL and see committed-but-not-yet-checkpointed rows.
- **Cascade delete overhauled**: indexed lookups (link / virtual-link / list
  tables by target) replace per-table try/catch scans, with bulk DELETE per
  cascade target; the parent DELETE and cascade cleanup commit in a single
  transaction; cascade audits are delivered to table observers in one batch.
- **Batched table observers**: `add_table_observer` callbacks now take
  `const std::vector<change_event>&`; `flush_changes` dispatches once per WAL
  flush with each table's slice, so a 3-row transaction delivers one 3-element
  batch and wire-relay consumers ship one frame per logical transaction.
- AuditLog observers fire once per row, not coalesced per batch — consumers
  that yield the specific delivered row no longer strand the rest of a
  multi-row transaction with `isSynchronized=0`.
- Upserts emit `DO NOTHING` when the `DO UPDATE SET` clause would be empty
  (previously invalid SQL), and the conflict path re-reads `globalId` from the
  write connection so link writes never reference nonexistent globalIds.
- Preserved globalIds are lowercased at ingestion (`bind_managed`): uppercase
  `UUID.uuidString` values broke case-sensitive TEXT joins through link tables
  (`@Relation` backlinks silently filtered synced rows out).
- Logging is thread-safe (mutex-protected `fprintf` + `fflush`).

### Fixed
- **Sync state collapses against the live slot registry (+ startup heal)**:
  audit entries collapse to `isSynchronized=1` once every sync channel has
  acknowledged them, but the check compared against an init-time config
  snapshot — a configured-but-never-running channel made collapse unreachable,
  orphaning `_lattice_sync_state` rows and wedging the passive pending count.
  Both mark paths now compare against the live `_lattice_replication_slots`
  registry, and `heal_collapsed_sync_state()` at open repairs existing
  databases.
- **Unshare no longer fleet-deletes**: narrowing a sync filter emitted plain
  DELETE audit entries that rode the normal upload pipeline — the server
  applied and relayed them, destroying every peer's copy. Filter-removal
  DELETEs now carry a `__lattice_filter_removal` marker and are scoped to one
  IPC hop; WSS receivers skip applying marked DELETEs but still ACK them.
- **At-least-once delivery**: a sent frame can vanish without any transport
  error. After `send_entries`, a timer waits up to 10s for the batch's ACKs and
  releases + re-enqueues any entries still in-flight, so dropped frames recover
  without waiting for a reconnect. Re-delivery is safe (applies are idempotent
  via `ON CONFLICT(globalId) DO UPDATE`).
- **IPC dialer auto-reconnect**: IPC synchronizers hard-disabled reconnection
  and stayed dead forever after a peer restart. `sync_transport::
  supports_reconnect()` now drives the behavior — dialers (with a socket path)
  redial; server-accepted fd wrappers never do.
- **Busy timeout installed before open-time pragmas**: the busy handler was
  configured after `PRAGMA journal_mode`/`cache_size` ran, so the very first
  statement of every connection had no lock protection — a concurrent open or
  in-flight writer made open throw "database is locked" instantly.
- **Close-after-use safety**: an atomic `closed_` flag on the database wrapper
  is checked at the top of each SQL op, `close()` only sets the flag
  (`sqlite3_close_v2`; the connection is freed solely in the destructor after
  sync/scheduler threads join), and the Swift write funnels early-return when
  closed — a reader on another thread can never dereference a freed handle
  (previously a logout-time `Lattice.delete()` under a live `@LatticeQuery`
  crashed). `LatticeCache::evict()` no longer erases `ptr_cache_` (use-after-
  free when delete/close raced a concurrent read).
- `dynamic_object::get_object()` on an unset to-one link returned by segfault:
  a nil link now yields an empty (unmanaged) object, and missing target tables
  in partially reconstructed schemas are null-checked.
- LatticeCache re-entrancy deadlock: SQLite's commit hook fires synchronously
  inside `swift_lattice` construction and re-entered the cache mutex via
  sibling observer notification; the mutex is now recursive.
- Conflicting-URL same-process siblings are kicked off the sync flock
  (`teardown_sync(fire_handoff: false)`) so a new opener with a different
  `wssEndpoint` can acquire sync ownership; same-URL dormants still skip
  silently.
- Cascade-clean of link and union tables on row delete: the cascade filter
  skipped every link table, so deletes left orphaned link rows whose traversal
  segfaulted on peers; union tables (no `rhs` column) get a dedicated
  post-cascade pass, and are skipped by the generic rhs cascade.
- vec0: correct table names for schema-qualified (attached) model tables; the
  vector CTE joins the per-schema model table instead of the UNION ALL view;
  IVF reconcile uses a LEFT JOIN on the `_rowids` shadow table.
- WASM/browser build: no-thread guards for the reconnect backoff loop (ran
  inline under `immediate_scheduler` and froze the tab), the ack-timeout
  resend, and vec0 reconciliation; the bridge try/catch utility is gated behind
  `__BLOCKS__` for non-blocks compilers.

## [0.9.2] - 2026-03-27

### Added
- `lattice_set_log_level()` in the C API.

### Fixed
- vec0 tables created lazily at query time are backfilled from the model table
  on creation — rows inserted before the vec0 table existed (C API / Python /
  Kotlin path) are searchable again (restores the reconciliation removed in
  0.9.1's move to init-time).

## [0.9.1] - 2026-03-26

### Added
- `rebuild_vec0()` / `vacuum_vec0()` APIs for explicit vector-index
  maintenance.
- `apply_remote` diagnostic logging for sync debugging.

### Changed
- vec0 reconciliation moved from per-query to init-time
  (`ensure_swift_tables`), filling gaps from cross-connection IPC sync writes
  without taxing every query.

### Fixed
- `has_value()` falls through to a DB check when the property isn't in the
  `properties_` map — Optional property loading works on models not passed to
  Lattice init (e.g. AuditLog queried via the ORM).
- Defensive vec0 orphan cleanup on delete handles entries left behind by
  unreliable DELETE triggers under write contention.
- `get_table_name` uses the proper accessor.

## [0.9.0] - 2026-03-16

- Re-release of 0.8.6 under a new minor version — no source changes (the tag
  points at the same commit as 0.8.6).

## [0.8.6] - 2026-03-16

### Added
- **VirtualList / VirtualLink**: polymorphic relationships via discriminated
  link tables with `rhs_type` columns; the sync receiver creates virtual link
  tables (with `rhs_type`) when the audit entry carries `rhs_type` in its
  changed fields.
- **Link table observation**: internal-table changes fire both link-table and
  parent-table observer notifications with changed field names, enabling Swift
  Observation property tracking on relationship mutations.
- Explicit IPC socket path support (cross-platform IPC between processes with
  different HOMEs).
- vec0 write-path reconciliation (`reconcile_vec0`) with hardened embedding
  triggers.
- Expanded C API surface, plus a native C++ unit-test suite (vendored
  GoogleTest + CMake build): Bridge, CascadeDelete, InstanceLifecycle,
  MultiConnection, Observation, Query, Schema, SyncUnit, and Vec0 tests.

### Changed
- Junction tables are eagerly created at startup (fixes relay/downstream
  nodes that receive link rows before ever writing one).
- `COLLATE NOCASE` on all link-table globalId queries for case-insensitive
  matching.
- List `size()` uses `load_if_needed()` for Collection conformance
  consistency.

### Fixed
- Cascade delete removes referencing link-table entries when objects are
  deleted.
- Cross-process notifications resolve internal tables to a parent UPDATE with
  property names and a parent rowId lookup.

## [0.8.5] - 2026-03-06

### Added
- `_lattice_post_cross_process_notification()` test helper for posting Darwin
  notifications from external writers.

### Fixed
- Cross-process sync progress observer not firing for AuditLog UPDATEs: when
  the sync daemon marks entries synced (`isSynchronized=1`) no new audit rows
  appear, and the cursor-based notification handler returned early — passive
  progress observers never re-queried `pending_sync_entry_count()`. A synthetic
  AuditLog UPDATE notification now fires in the empty-rows path.

## [0.8.4] - 2026-03-05

### Changed
- **Unlimited reconnect with capped exponential backoff**: the synchronizer
  used to give up after 6 attempts (~63s), permanently killing sync in
  long-lived daemons on a transient outage. `max_reconnect_attempts` now
  defaults to 0 (unlimited) with the delay capped at 60s
  (1s, 2s, 4s, 8s, 16s, 32s, 60s, 60s, …).

## [0.8.3] - 2026-03-05

- Re-release of 0.8.2 — no source changes (the tag points at the same commit
  as 0.8.2).

## [0.8.2] - 2026-03-05

### Fixed
- Deadlock in `mark_as_synced` under `immediate_scheduler`: the in-flight
  mutex was held across a synchronous `scheduler->invoke()` whose upload path
  re-locked the same non-recursive mutex; the lock is released before invoking.
- `receive_sync_data` crash: C++ exceptions are caught at the Swift boundary
  (previously `std::terminate` → SIGTRAP) and surfaced via the
  `last_receive_error()` accessor.
- Migration lookup crash when the target model has new columns: schema
  properties are filtered to columns that exist in the DB so `detach()` no
  longer SELECTs not-yet-added columns ("no such column").

## [0.8.1] - 2026-03-04

### Added
- `LATTICE_DISABLE_XPROC` env-var kill-switch for cross-process notifications.
- `backdate_replication_slots()` test helper for deterministic stale-slot
  eviction.

### Changed
- `notify_changes_batched` coalesces AuditLog table observers to fire at most
  once per batch (model table observers still fire per row).

## [0.8.0] - 2026-03-04

### Added
- **Replication slots** for slot-aware audit log compaction: `safe_compact`
  deletes only entries confirmed by all synchronizers; `force_compact`
  regenerates snapshots and resets slot cursors; stale-slot eviction with a
  configurable threshold.
- `is_sync_agent()` — file-lock-based sync ownership detection.
- Sync error and state-change callbacks (`set_on_sync_error`,
  `set_on_sync_state_change`).
- `pending_sync_entry_count()` for cross-process progress observation.
- `distinct_by` support on `count()` and `objects()`; `combinedNearestQuery`
  supports `distinctBy` for nearest results.
- C++ try/catch bridge utility.

## [0.7.0] - 2026-03-03

### Added
- **Sync Progress API**: Real-time upload/download progress tracking
  - `synchronizer::sync_progress` struct with `pending_upload`, `total_upload`, `acked`, `received` counters
  - `get_progress()` polling and `set_on_progress()` callback APIs
  - `lattice_db::get_sync_progress()` aggregates progress across all synchronizers (WSS + IPC)
  - `lattice_db::set_on_sync_progress()` callback fires on synchronizer thread
  - Swift bridge: `sync_progress_*()` polling methods and `set_on_sync_progress()` C callback
- **Owned-DB Synchronizer Architecture**: Each synchronizer owns a dedicated `lattice_db` connection
  - Constructor takes `std::unique_ptr<lattice_db>` instead of `lattice_db&`
  - Each synchronizer runs on its own `std_thread_scheduler`, isolating sync I/O from the caller's thread
  - Cross-process notifications bridge writes between parent and sync connections
  - Eliminates SQLite write contention between sync operations and application writes
- **Instance Guard System**: Safe cross-instance observer notifications
  - `instance_guard` with atomic `alive` flag and `notify_refcount` for in-flight call tracking
  - `instance_registry::for_each_alive()` replaces raw `get_instances()` — prevents use-after-free when instances are destroyed during notification
  - Destructor spins on `notify_refcount` before proceeding, ensuring in-flight `notify_change()` calls complete
- **Scheduler Resilience**
  - `std_thread_scheduler::run_loop()` catches exceptions from work items (logs and continues instead of killing the thread)
  - `scheduler::shutdown()` virtual method for orderly drain — blocks until in-flight work completes
  - Synchronizer destructor calls `scheduler_->shutdown()` to drain in-flight lambdas before member destruction
  - `is_destroyed_` atomic flag guards all scheduled lambdas against post-destruction execution
- **In-Flight Tracking**: Prevents duplicate upload of entries awaiting ACK
  - `in_flight_ids_` set with mutex tracks sent-but-unacknowledged entries
  - `query_pending_entries()` filters out in-flight entries before upload
  - ACK handler removes acknowledged entries from in-flight set
- **Upload Coalescing**: Observer-triggered uploads batched through scheduler
  - `upload_requested_` atomic flag coalesces rapid AuditLog INSERTs into a single upload cycle
  - Tail-call re-scheduling: if new entries arrive during upload, re-queues without starving other work
- **IPC Stale Socket Recovery**: Probe logic detects and cleans up sockets from crashed processes
  - `ECONNREFUSED` on probe → unlink stale socket file, retry bind as server
  - Zombie detection: connected probe polls for `POLLHUP` / `POLLIN` with `recv(MSG_PEEK)` to distinguish dead peers from live servers sending data
- **Deferred Sync Setup**: `lattice_db(config, defer_sync=true)` delays sync/IPC initialization
  - `swift_lattice` uses deferred mode so all Swift model tables are created before sync starts
- **Sync Filter Versioning**: Prevents stale filter reconciliation from rapid toggles
  - `filter_version_` atomic counter — scheduled reconcile checks version before acting
- Synchronizer destroy-during-scheduled-work race condition test (`test_synchronizer_destroy_race`)
- Lifecycle logging: `lattice_db`, `std_thread_scheduler`, and `synchronizer` log CREATED/DESTROYED with alive counts

### Changed
- **Synchronizer constructor**: Takes `std::unique_ptr<lattice_db>` (owned) instead of `lattice_db&` (borrowed)
  - Legacy single-sync path removed — all synchronizers use per-synchronizer `sync_id` state
  - `setup_observer()` and `setup_transport_handlers()` extracted as shared helpers
- **Teardown ordering**: `close()` and `~lattice_db()` follow strict phase ordering:
  1. Mark `guard_->alive = false` (prevents new notifications)
  2. Spin on `guard_->notify_refcount` (waits for in-flight notifications)
  3. Disconnect ALL synchronizers before destroying any (prevents cross-sync use-after-free in flush_changes)
  4. Unregister from instance registry
- **IPC synchronizer dedup**: `try_register_sync_key()` now covers IPC channels (not just WSS), preventing duplicate synchronizers across instances sharing the same database
- **Sync filter reconciliation**: Inserts synthetic AuditLog entries instead of sending directly, leveraging the normal upload pipeline (in-flight tracking, chunking, ACK confirmation)
- `apply_remote_changes()` and `apply_remote_changes_for()` return `std::vector<std::string>` of successfully applied global IDs (previously void)
- `build_insert_entry_from_current_row()` returns `std::optional` instead of throwing when the row is deleted
- `mark_audit_entries_synced_for()` processes in chunks of 50 to avoid holding write lock
- `on_transport_message()` dispatches apply and ACK to scheduler thread (prevents SQLite contention with IPC/NIO read thread)
- `on_websocket_open()` dispatches initial reconcile + upload to scheduler (avoids blocking IPC accept thread)
- `schedule_reconnect()` uses interruptible 50ms sleep loop (checks `is_destroyed_`) instead of a single blocking sleep
- WAL checkpoint on close changed from `TRUNCATE` to `PASSIVE` (non-blocking)
- `ANALYZE` on init uses raw `sqlite3_exec` to avoid retry-timeout on busy databases
- `_lattice_sync_state` excluded from update hook (internal table)
- `update_sync_filter()` / `clear_sync_filter()` propagate to IPC synchronizers (not just WSS)
- `LatticeRefCacheKey` includes `schema_version` — differentiates pre/post migration instances
- Cache no longer skips entries for `target_schema_version > 1` (migration is idempotent)
- `query_audit_log_for_sync()` accepts optional `sync_filter` parameter for pre-filtering at query time

### Fixed
- **IPC probe misidentifying live server as dead**: `POLLIN` set by real sync data during 50ms probe window caused the target to incorrectly become a second server. Now uses `recv(MSG_PEEK)` to distinguish EOF from real data.
- **IPC SIGPIPE crash**: `suppress_sigpipe()` applied to all IPC sockets (server, accepted client, connected client). Without `SO_NOSIGPIPE` (macOS), writing to a closed peer kills the process.
- **IPC send interleaving**: `send()` uses `send_mutex_` to prevent interleaved length-prefix frames from concurrent callers. `fd_` changed to `std::atomic<int>` for safe concurrent read/close.
- **Scheduler thread death on exception**: Any exception from a work item (e.g., `SQLITE_BUSY` after retry timeout) killed the scheduler thread silently, dropping all future work (ACKs, uploads, applies). Tests hung waiting for conditions that required the dead scheduler.
- **Infinite resend loop**: `query_audit_log_for_sync()` WHERE clause now includes `AND a.isSynchronized = 0` to prevent eagerly-cleaned entries (deleted `_lattice_sync_state` rows) from being re-queried as pending
- **Enum deserialization crash**: `getField` returns `defaultValue` instead of `fatalError` for unknown raw values (graceful handling of schema evolution)
- Hex-encoded BLOB fields from `build_insert_entry_from_current_row()` stored as `string_kind` (matching AuditLog trigger format) instead of `data_kind`
- `any_property::to_column_value()` handles hex-encoded BLOB strings stored in `data_kind` variant
- `on_transport_message()` guards against use-after-free from late NIO/IPC callbacks via `is_destroyed_` check

## [0.6.0] - 2026-02-28

### Added
- **IPC Transport**: Cross-process sync via Unix domain sockets
  - `ipc_server` — binds and listens on a channel socket
  - `ipc_socket_client` — implements `sync_transport` interface
  - Length-prefix framing over `SOCK_STREAM`
  - Channel-based naming: `resolve_ipc_socket_path()` maps channel names to platform paths
  - macOS: `~/Library/Caches/Lattice/ipc/<channel>.sock`
  - Linux: `$XDG_RUNTIME_DIR/lattice/<channel>.sock` (fallback: `/tmp/lattice-<uid>/`)
- **Per-Synchronizer Sync State**: `_lattice_sync_state` table
  - Independent sync tracking per transport via `sync_id`
  - `query_audit_log_for_sync()` — returns pending entries for a specific synchronizer
  - Backwards compatible: single-synchronizer mode still uses `isSynchronized` column
- **Cloud Relay Mode**: `sync_apply_mode::relay`
  - IPC-received entries written with `isFromRemote=1, isSynchronized=0`
  - Receiving synchronizer's own `sync_id` marked as synced (loop prevention)
  - Other synchronizers (WSS, other IPC) see entries as pending
- **Filtered Sync**: Per-table upload filtering
  - `sync_filter_entry` with table name + SQL predicate
  - `reconcile_sync_filter()` — generates initial sync set from filter
  - Applied at upload time; downloads always accepted
- `collect_all_sync_ids()` — gathers WSS + IPC sync IDs for multi-transport
- IPC integration tests (C++ test suite)

### Changed
- `websocket_client` interface renamed to `sync_transport`
- `synchronizer` now accepts `sync_transport*` instead of `websocket_client*`
- `upload_pending_changes()` uses `_lattice_sync_state` JOIN when `sync_id` is set

### Fixed
- Linux `resolve_ipc_socket_path` test assertion for Docker environments without `XDG_RUNTIME_DIR`

## [0.5.1] - 2026-02-27

### Added
- Preserved global ID support for object insertion

### Fixed
- Cache eviction crash
- Migration guard
- Attached DB vector queries

## [0.5.0] - 2026-02-26

### Added
- `@Indexed` attribute support for non-unique column indexes
