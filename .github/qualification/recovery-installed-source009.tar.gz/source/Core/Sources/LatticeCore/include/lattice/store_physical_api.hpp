#pragma once
#include <lattice_sqlite_provider/types.h>
#include <lattice_sqlite_provider/native_v1.hpp>
#include <chrono>
#include <array>
#include <cstdint>
#include <cstddef>
#include <memory>

namespace lattice {class database;}
namespace lattice::detail {
class store_physical_api;
class database_initialization_budget;
class store_deletion_operation;
struct store_physical_vfs_test_access;
class store_physical_open_original;
class store_resource_initialization_original;
// Status-only DATA retained by actual SQLite-owned policy/UDF cookies. This
// carries the SAME physical-open original, never a second debt identity. No
// Native pointer, SQL scope, cleanup, close or physical-ending grant exists.
class store_physical_policy_original final {
    friend class store_physical_api;
    friend class ::lattice::database;
    friend struct store_physical_vfs_test_access;
    void* original_=nullptr;
    std::uint64_t creator_=0;
    static store_physical_policy_original capture_(const store_physical_open_original&)noexcept;
public:
    store_physical_policy_original()noexcept;
    store_physical_policy_original(store_physical_policy_original&&)noexcept;
    store_physical_policy_original& operator=(store_physical_policy_original&&)noexcept;
    ~store_physical_policy_original()noexcept;
    store_physical_policy_original(const store_physical_policy_original&)=delete;
    store_physical_policy_original& operator=(const store_physical_policy_original&)=delete;
    bool observer_policy_unsettled()const noexcept;
    void note_observer_policy_unsettled()noexcept;
};
// One actual open's owning DATA identity. Issued by its actual producer before
// Native open; the actual return binds the comparison before publication/SQL. It owns no Native pointer
// or callback and remains provenance after close; it never adopts a later
// connection merely because its allocator recycled the same sqlite3* value.
class store_physical_open_original final {
    friend class database_initialization_budget;
    friend class store_resource_initialization_original;
    friend class store_physical_api;
    friend class ::lattice::database;
    friend class store_deletion_operation;
    friend struct store_physical_vfs_test_access;
    const void* provider_instance_=nullptr; // fixed outer image before any opaque producer dereference
    void* original_=nullptr;
    void* provider_legacy_=nullptr; // genuine stable nonresource Native producer; never a physical grant
    lattice_sqlite3541_connection* actual_=nullptr; // comparison DATA only, never dereferenced
    std::uint64_t creator_=0;
    bool bound_=false,legacy_=false,native_retired_=false;
    // A separate closed target producer, never normal Host/SH/policy custody.
    // Its existing database_scope/custom VFS/exclusive ledger owns ending.
    bool exclusive_target_=false,exclusive_open_attempted_=false;
    bool issue_exclusive_target_(std::uint64_t captured_creator)noexcept;
    int open_exclusive_target_(const char*,lattice_sqlite3541_connection**,int,const char*,
        std::chrono::steady_clock::time_point original_end)noexcept;
    bool retain_initialization_budget_(const std::shared_ptr<database_initialization_budget>&)noexcept;
    bool matches_open_(lattice_sqlite3541_connection*)const noexcept;
    sqlite_provider::v1::connection_ref native_ref_(lattice_sqlite3541_connection*)const;
    bool seal_and_wait_(std::chrono::steady_clock::time_point)const noexcept;
public:
    store_physical_open_original()noexcept;
    store_physical_open_original(store_physical_open_original&&)noexcept;
    store_physical_open_original& operator=(store_physical_open_original&&)noexcept;
    ~store_physical_open_original()noexcept;
    store_physical_open_original(const store_physical_open_original&)=delete;
    store_physical_open_original& operator=(const store_physical_open_original&)=delete;
    // Denial-only VM policy DATA. Missing/foreign original is never healthy.
    // This debt does not rewrite physical-close facts or block cleanup.
    bool observer_policy_unsettled()const noexcept;
    void note_observer_policy_unsettled()noexcept;
};
// Internal lexical Native-caller ending pin. Fixed DATA only, no allocation,
// SQLite pointer ownership, user callback, SQL grant or public SDK lease.
// It must be declared before the actual Native-lock holder, so its ending
// follows that holder's real release. C API scopes remain separate and nested.
class store_physical_native_scope final {
    friend class store_physical_api;
    friend class store_physical_cleanup_scope;
    std::array<void*,64> originals_{};
    store_physical_native_scope* previous_=nullptr;
    static thread_local store_physical_native_scope* current_;
    bool registered_=false;
    std::size_t count_=0;
    std::uint64_t creator_=0,entered_mask_=0;
    bool entered_=true,cleanup_only_=false;
    store_physical_native_scope()noexcept=default;
public:
    explicit store_physical_native_scope(lattice_sqlite3541_connection*)noexcept;
    // Internal actual-wrapper route; captures only its already-bound original.
    explicit store_physical_native_scope(const ::lattice::database&)noexcept;
    store_physical_native_scope(const store_physical_open_original&,lattice_sqlite3541_connection* actual_comparison)noexcept;
    store_physical_native_scope(const store_physical_open_original*,lattice_sqlite3541_connection* actual_comparison)noexcept;
    ~store_physical_native_scope()noexcept;
    store_physical_native_scope(const store_physical_native_scope&)=delete;
    store_physical_native_scope& operator=(const store_physical_native_scope&)=delete;
    bool entered()const noexcept{return entered_;}
    void reset()noexcept;
};
// Closed cleanup ending custody only. It survives exact callback-slot removal,
// mutex release and close return after admission is sealed. It NEVER lends a
// continuation grant to a nested/public SQL entry. Captured immutable originals
// remain creator fenced; no address lookup or policy-DATA conversion occurs.
class store_physical_cleanup_scope final {
    store_physical_native_scope held_;
public:
    explicit store_physical_cleanup_scope(const ::lattice::database&)noexcept;
    store_physical_cleanup_scope(const store_physical_open_original&,lattice_sqlite3541_connection* actual_comparison)noexcept;
    store_physical_cleanup_scope(const store_physical_cleanup_scope&)=delete;
    store_physical_cleanup_scope& operator=(const store_physical_cleanup_scope&)=delete;
    bool entered()const noexcept{return held_.entered();}
    void reset()noexcept{held_.reset();}
};
// Return ONLY an already-owned Native mutex from its actual immutable open
// original. No acquire/SQL/close authority is issued. Callers must keep that
// exact owner and its lexical Native frame alive before entry through return.
// Inherited/retired originals abandon this POD guard without Native access.
class store_physical_mutex_return final {
    const store_physical_open_original* original_=nullptr;
    lattice_sqlite3541_mutex* mutex_=nullptr;
public:
    store_physical_mutex_return(const ::lattice::database&,lattice_sqlite3541_mutex*)noexcept;
    store_physical_mutex_return(const store_physical_open_original&,lattice_sqlite3541_mutex*)noexcept;
    ~store_physical_mutex_return()noexcept;
    store_physical_mutex_return(const store_physical_mutex_return&)=delete;
    store_physical_mutex_return& operator=(const store_physical_mutex_return&)=delete;
    void reset()noexcept;
};
// Actual raw Native adapters are source-private in Core. Public Native escape
// uses provider-bound v1 objects; no external raw-object adoption route.

}
