#pragma once
#ifdef __cplusplus
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <limits>
#include <memory>
#include <mutex>
#include <new>
#include <stdexcept>
#include <thread>
#include <unistd.h>

namespace lattice {
class database;
class lattice_db;
namespace detail {
// Exact Core lifetime DATA, shared by the existing BEGIN original and its
// ending lease. Ending this cell never rolls back or lends a successor turn.
struct core_thread_lifetime_v2 { std::atomic<bool> alive{true}; };
}

// Versioned Lockable API. No OS mutex is retained across caller work or a Core
// transaction. A short metadata leaf protects lexical depths and one exact
// Core ending component. The old independently lockable raw mutex is not kept.
class store_write_gate_v2 final {
    friend class database;
    friend class lattice_db;
    friend struct store_write_gate_v2_test_access; // fixed DATA observation only
    static std::uint64_t process_() noexcept { return static_cast<std::uint64_t>(::getpid()); }
    struct thread_key { std::uint64_t creator=0,sequence=0; };
    static std::uint64_t thread_key_() {
        static std::atomic<std::uint64_t> next{1};
        static thread_local thread_key key;
        const auto creator=process_();
        if(key.creator!=creator)key={}; // fixed child DATA; no inherited control
        if(!key.sequence) {
            auto value=next.load(std::memory_order_relaxed);
            for(;;) {
                if(value==0||value==UINT64_MAX)throw std::overflow_error("store gate thread identity exhausted");
                if(next.compare_exchange_weak(value,value+1,std::memory_order_relaxed))break;
            }
            key={creator,value};
        }
        return key.sequence;
    }
    // Intrusive fixed DATA: actual sizeof is debited before its only allocation
    // by database's closed pre-BEGIN producer. No shared-control size estimate.
    class ending_lease final {
        friend class database;
        friend class store_write_gate_v2;
        const std::uint64_t creator_;
        const void* const original_;
        const std::uint64_t thread_;
        std::atomic<std::uint64_t> refs_{1},serial_{0};
        std::atomic<bool> attempted_{false},unissued_{false},ended_{false};
        union { std::shared_ptr<const detail::core_thread_lifetime_v2> lifetime_; };
        bool lifetime_present_=false;
        ending_lease(std::uint64_t creator,const void* original,std::uint64_t thread,
            const std::shared_ptr<const detail::core_thread_lifetime_v2>& lifetime) noexcept
            :creator_(creator),original_(original),thread_(thread) {
            if(creator_==process_()) {
                new(&lifetime_)std::shared_ptr<const detail::core_thread_lifetime_v2>(lifetime);
                lifetime_present_=true;
            }
        }
        ~ending_lease()noexcept {
            if(creator_==process_()&&lifetime_present_)lifetime_.~shared_ptr();
        }
        bool retain_()noexcept {
            if(creator_!=process_())return false;
            auto refs=refs_.load(std::memory_order_relaxed);
            do {if(!refs||refs==UINT64_MAX)return false;}
            while(!refs_.compare_exchange_weak(refs,refs+1,std::memory_order_relaxed));
            return true;
        }
        void release_()noexcept {
            if(creator_==process_()&&refs_.fetch_sub(1,std::memory_order_acq_rel)==1)delete this;
        }
        bool abandoned_()const noexcept {
            return creator_==process_()&&lifetime_present_&&lifetime_&&
                !lifetime_->alive.load(std::memory_order_acquire)&&
                !ended_.load(std::memory_order_acquire);
        }
    };
    struct state {
        std::mutex mutex;
        std::condition_variable changed;
        std::uint64_t owner=0,depth=0,waiting=0;
        ending_lease* component=nullptr;
        bool cleanup=false;
    };
    const std::uint64_t creator_=process_();
    // One fixed compiled DATA issuer per actual gate. Caller/header copies in
    // another library image cannot substitute an independent counter/TLS key.
    std::uint64_t (*const key_issuer_)()=&thread_key_;
    union { state state_; };
    void require_creator_()const {
        if(creator_!=process_())throw std::runtime_error("store gate belongs to another process");
    }
    bool available_(std::uint64_t thread)const noexcept {
        return !state_.cleanup&&(!state_.owner||state_.owner==thread)&&
            !(state_.component&&state_.component->abandoned_());
    }
    void enter_(std::uint64_t thread) {
        if(state_.depth==UINT64_MAX)throw std::overflow_error("store gate recursion exhausted");
        state_.owner=thread;++state_.depth;
    }
    bool reserve_(ending_lease* lease) {
        require_creator_();
        if(!lease||lease->creator_!=creator_||lease->thread_!=key_issuer_())return false;
        std::lock_guard lock(state_.mutex);
        if(state_.component||state_.cleanup||state_.owner!=lease->thread_||!state_.depth||!lease->retain_())return false;
        --state_.depth;state_.component=lease; // move ONE lexical unit to pending BEGIN
        return true;
    }
    bool cancel_unissued_(ending_lease* lease)noexcept {
        if(creator_!=process_()||!lease||lease->creator_!=creator_)return false;
        ending_lease* retired=nullptr;
        try {
            std::lock_guard lock(state_.mutex);
            if(state_.component!=lease||state_.cleanup||lease->serial_.load(std::memory_order_acquire)||
               (lease->attempted_.load(std::memory_order_acquire)&&!lease->unissued_.load(std::memory_order_acquire))||
               state_.depth==UINT64_MAX)return false;
            ++state_.depth;retired=state_.component;state_.component=nullptr;
        }catch(...){return false;}
        state_.changed.notify_all();retired->release_();return true;
    }
    bool begin_cleanup_(ending_lease* lease)noexcept {
        if(creator_!=process_()||!lease||lease->creator_!=creator_)return false;
        try {
            std::unique_lock lock(state_.mutex,std::try_to_lock);
            if(!lock||state_.component!=lease||state_.cleanup||state_.depth||!lease->abandoned_()||
               !lease->serial_.load(std::memory_order_acquire))return false;
            state_.cleanup=true;return true;
        }catch(...){return false;}
    }
    void end_cleanup_(ending_lease* lease)noexcept {
        if(creator_!=process_())return;
        try {std::lock_guard lock(state_.mutex);if(state_.component==lease)state_.cleanup=false;}
        catch(...){return;} // retained debt, never invent an available gate
        state_.changed.notify_all();
    }
    bool retire_(ending_lease* lease)noexcept {
        if(creator_!=process_()||!lease||lease->creator_!=creator_||!lease->ended_.load(std::memory_order_acquire))return false;
        ending_lease* retired=nullptr;
        try {
            std::lock_guard lock(state_.mutex);
            if(state_.component!=lease)return false;
            retired=state_.component;state_.component=nullptr;state_.cleanup=false;
            if(!state_.depth)state_.owner=0;
        }catch(...){return false;}
        state_.changed.notify_all();retired->release_();return true;
    }
public:
    store_write_gate_v2() { new(&state_)state; }
    ~store_write_gate_v2()noexcept {
        if(creator_!=process_())return; // no inherited mutex, condition or DATA control access
        auto* component=state_.component;
        state_.~state();
        // Unknown ending retains the fixed DATA liability. Destruction is not
        // a cleanup success and cannot free another actual transaction's lease.
        if(component&&component->ended_.load(std::memory_order_acquire))component->release_();
    }
    store_write_gate_v2(const store_write_gate_v2&)=delete;
    store_write_gate_v2& operator=(const store_write_gate_v2&)=delete;
    void lock() {
        require_creator_();const auto thread=key_issuer_();
        std::unique_lock lock(state_.mutex);
        for(;;) {
            if(available_(thread)){enter_(thread);return;}
            if(state_.component&&state_.component->abandoned_())
                throw std::runtime_error("store gate abandoned Core transaction requires owner rollback");
            // Lifetime exit publishes DATA only; it deliberately performs no
            // rollback/release and need not touch this gate. A bounded recheck
            // observes that transition even for an already sleeping waiter.
            if(state_.waiting==UINT64_MAX)throw std::overflow_error("store gate wait census exhausted");
            ++state_.waiting;
            try{state_.changed.wait_for(lock,std::chrono::milliseconds(5));}
            catch(...){--state_.waiting;throw;}
            --state_.waiting;
        }
    }
    bool try_lock() {
        require_creator_();const auto thread=key_issuer_();
        std::unique_lock lock(state_.mutex,std::try_to_lock);
        if(!lock||!available_(thread))return false;
        enter_(thread);return true;
    }
    template<class Rep,class Period> bool try_lock_for(const std::chrono::duration<Rep,Period>& duration) {
        return try_lock_until(std::chrono::steady_clock::now()+duration);
    }
    template<class Clock,class Duration> bool try_lock_until(const std::chrono::time_point<Clock,Duration>& end) {
        require_creator_();const auto thread=key_issuer_();
        std::unique_lock lock(state_.mutex,std::defer_lock);
        // The timed contract also covers this short metadata admission; never
        // turn a finite try into an unbounded metadata-mutex wait.
        while(!lock.try_lock()) {
            if(Clock::now()>=end)return false;
            std::this_thread::yield();
        }
        while(!available_(thread)) {
            if(state_.component&&state_.component->abandoned_())return false;
            // Recheck abandonment on the same bounded interval, while the
            // caller's original absolute deadline remains the final bound.
            if(state_.waiting==UINT64_MAX)throw std::overflow_error("store gate wait census exhausted");
            ++state_.waiting;
            try {
                const auto recheck=Clock::now()+std::chrono::milliseconds(5);
                if(recheck<end)state_.changed.wait_until(lock,recheck);
                else state_.changed.wait_until(lock,end);
            }catch(...){--state_.waiting;throw;}
            --state_.waiting;
            if(Clock::now()>=end&&!available_(thread))return false;
        }
        enter_(thread);return true;
    }
    void unlock()noexcept {
        if(creator_!=process_())return;
        try {
            const auto thread=key_issuer_();std::lock_guard lock(state_.mutex);
            if(state_.owner!=thread||!state_.depth)return; // no foreign/dead-thread unlock
            if(!--state_.depth&&!state_.component)state_.owner=0;
        }catch(...){return;} // preserve custody on metadata failure
        state_.changed.notify_all();
    }
};
}
#endif // __cplusplus
