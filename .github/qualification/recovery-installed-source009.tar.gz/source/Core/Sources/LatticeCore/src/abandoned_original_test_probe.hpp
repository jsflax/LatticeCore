#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
#include <unistd.h>
namespace lattice::detail::abandoned_original_test_probe {
enum class phase { original_proved, fixed_vm_bound, step_returned, ending_observed };
struct event {
    phase at;std::uintptr_t writer,original,native;std::uint64_t serial;
    bool lifetime_closed,current,ended;int native_result;
};
struct record { std::array<event,8> events{};std::size_t count=0;bool overflow=false; };
struct scope final {
    const std::uint64_t creator=static_cast<std::uint64_t>(::getpid());
    record* const output;scope* const previous;
    static inline thread_local scope* current=nullptr;
    explicit scope(record& value)noexcept:output(&value),previous(current){current=this;}
    ~scope()noexcept {current=creator==static_cast<std::uint64_t>(::getpid())?previous:nullptr;}
    scope(const scope&)=delete;
};
inline void observe(event value)noexcept {
    auto* actual=scope::current;
    if(!actual||actual->creator!=static_cast<std::uint64_t>(::getpid()))return;
    auto& out=*actual->output;
    if(out.count==out.events.size()){out.overflow=true;return;}
    out.events[out.count++]=value;
}
}
