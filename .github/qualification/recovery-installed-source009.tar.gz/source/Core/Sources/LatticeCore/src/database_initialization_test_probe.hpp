#pragma once
namespace lattice { class database; }
namespace lattice::detail {
class database_initialization_budget;
struct database_initialization_test_probe {
    // Passive DATA only: no callback, admission, Native access or permission.
    static inline thread_local unsigned* read_admission_attempts=nullptr;
    enum class allocation_stage {none,request,transaction,episode,bootstrap_record,bootstrap_control,bootstrap_handoff};
    static inline thread_local allocation_stage fail_once=allocation_stage::none;
    static bool consume(allocation_stage expected)noexcept {
        if(fail_once!=expected)return false;
        fail_once=allocation_stage::none;return true;
    }
    struct continuous_guard_observation {
        const void* capsule=nullptr;const void* guard=nullptr;const void* creation_original=nullptr;
        const database_initialization_budget* account=nullptr;
    };
    // Nil-default fixed observation/cut after actual EX adoption. It cannot
    // return a guard/account/Original, issue SQL, or turn active into fresh.
    static inline thread_local void(*after_continuous_catalog_guard)(const continuous_guard_observation&)=nullptr;
    // Nil-default continuation cut only; no account/Native/SQL authority.
    static inline thread_local void(*after_normal_data_credit)()=nullptr;
    // Observe a REAL pending physical return before its existing global drain.
    // Tests may end closed DATA custody; this grants no Native/SQL admission.
    static inline thread_local void(*before_physical_return_drain)()noexcept=nullptr;
    static inline thread_local void(*before_normal_resource_account)(const database*,const database_initialization_budget*)=nullptr;
    static inline thread_local void(*after_pending)(database&)=nullptr;
    static inline thread_local void(*after_functions)(database&)=nullptr;
};
}
