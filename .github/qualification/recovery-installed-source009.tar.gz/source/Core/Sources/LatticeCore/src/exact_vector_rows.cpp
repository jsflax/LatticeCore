#include "provider_native_internal.hpp"
#include <lattice/exact_vector_rows.hpp>

namespace lattice::detail {
std::vector<database::row_t> exact_vector_rows_access::collect(
    database& db, const exact_vector_rows_plan& plan) {
    if (db.is_closed() || !db.internal_handle()) throw db_error("exact row connection is closed");
    if (plan.sql.find('\0') != std::string::npos ||
        plan.sql.size() >= static_cast<size_t>(std::numeric_limits<int>::max()) ||
        plan.bindings.size() > static_cast<size_t>(std::numeric_limits<int>::max()))
        throw std::invalid_argument("exact row statement bounds");
    lattice_sqlite3541_stmt* statement = nullptr;
    struct finalize {
        lattice_sqlite3541_stmt*& value;
        ~finalize() { if (value) ::lattice::detail::store_physical_finalize(value); }
    } cleanup{statement};
    const char* tail = nullptr;
    database::record_statement();
    if (::lattice::detail::store_physical_prepare_v2(db.internal_handle(), plan.sql.c_str(), -1, &statement, &tail) != LATTICE_SQLITE3541_OK)
        throw db_error(lattice_sqlite3541_errmsg(db.internal_handle()));
    while (tail && *tail && std::isspace(static_cast<unsigned char>(*tail))) ++tail;
    if (!statement || (tail && *tail) || !lattice_sqlite3541_stmt_readonly(statement) ||
        lattice_sqlite3541_bind_parameter_count(statement) != static_cast<int>(plan.bindings.size()))
        throw db_error("exact row query requires one readonly statement and matching bindings");
    for (size_t i = 0; i < plan.bindings.size(); ++i) {
        const int index = static_cast<int>(i + 1);
        if (lattice_sqlite3541_bind_parameter_name(statement, index))
            throw db_error("exact row query requires anonymous positional bindings");
        const int result = std::visit([&](const auto& value) -> int {
            using T = std::decay_t<decltype(value)>;
            if constexpr (std::is_same_v<T, std::nullptr_t>) return lattice_sqlite3541_bind_null(statement, index);
            else if constexpr (std::is_same_v<T, int64_t>) return lattice_sqlite3541_bind_int64(statement, index, value);
            else if constexpr (std::is_same_v<T, double>) return lattice_sqlite3541_bind_double(statement, index, value);
            else if constexpr (std::is_same_v<T, std::string>)
                return lattice_sqlite3541_bind_text64(statement, index, value.data(), value.size(), LATTICE_SQLITE3541_TRANSIENT, LATTICE_SQLITE3541_UTF8);
            else return value.empty() ? lattice_sqlite3541_bind_zeroblob(statement, index, 0) :
                lattice_sqlite3541_bind_blob64(statement, index, value.data(), value.size(), LATTICE_SQLITE3541_TRANSIENT);
        }, plan.bindings[i]);
        if (result != LATTICE_SQLITE3541_OK) throw db_error("exact row parameter binding failed");
    }
    std::vector<std::string> columns;
    std::set<std::string> names;
    for (int i = 0; i < lattice_sqlite3541_column_count(statement); ++i) {
        const char* name = lattice_sqlite3541_column_name(statement, i);
        if (!name || !names.insert(exact_vector_fold_identifier(name)).second)
            throw db_error("exact row duplicate or unavailable column name");
        columns.emplace_back(name);
    }
    std::vector<database::row_t> rows;
    int result;
    while ((result = ::lattice::detail::store_physical_step(statement)) == LATTICE_SQLITE3541_ROW) {
        database::row_t row;
        for (int i = 0; i < static_cast<int>(columns.size()); ++i) {
            column_value_t value;
            switch (lattice_sqlite3541_column_type(statement, i)) {
                case LATTICE_SQLITE3541_INTEGER: value = static_cast<int64_t>(lattice_sqlite3541_column_int64(statement, i)); break;
                case LATTICE_SQLITE3541_FLOAT: value = lattice_sqlite3541_column_double(statement, i); break;
                case LATTICE_SQLITE3541_TEXT: {
                    const auto* text = reinterpret_cast<const char*>(lattice_sqlite3541_column_text(statement, i));
                    if (!text) throw db_error("exact row text allocation failed");
                    const int length = lattice_sqlite3541_column_bytes(statement, i);
                    if (!length && lattice_sqlite3541_errcode(db.internal_handle()) == LATTICE_SQLITE3541_NOMEM)
                        throw db_error("exact row text size allocation failed");
                    value = std::string(text, length); break;
                }
                case LATTICE_SQLITE3541_BLOB: {
                    const auto* blob = static_cast<const uint8_t*>(lattice_sqlite3541_column_blob(statement, i));
                    // SQLite requires this check BEFORE column_bytes (or any
                    // other SQLite call). NULL can be an OOM, not an empty BLOB.
                    if (!blob && lattice_sqlite3541_errcode(db.internal_handle()) == LATTICE_SQLITE3541_NOMEM)
                        throw db_error("exact row blob allocation failed");
                    const int length = lattice_sqlite3541_column_bytes(statement, i);
                    if (!length && lattice_sqlite3541_errcode(db.internal_handle()) == LATTICE_SQLITE3541_NOMEM)
                        throw db_error("exact row blob size allocation failed");
                    if (length && !blob) throw db_error("exact row blob allocation failed");
                    value = length ? std::vector<uint8_t>(blob, blob + length) : std::vector<uint8_t>{}; break;
                }
                default: value = nullptr; break;
            }
            row.emplace(columns[static_cast<size_t>(i)], std::move(value));
        }
        rows.push_back(std::move(row));
    }
    if (result != LATTICE_SQLITE3541_DONE) throw db_error(lattice_sqlite3541_errmsg(db.internal_handle()));
    return rows;
}
}
