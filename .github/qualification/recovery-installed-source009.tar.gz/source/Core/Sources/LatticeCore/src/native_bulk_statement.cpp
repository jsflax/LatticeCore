#include "provider_native_internal.hpp"
#include <lattice/db.hpp>
namespace lattice {
int database::bulk_native_statement::prepare_(const char* sql) {
    return detail::store_physical_prepare_v2(owner_.internal_handle(),sql,-1,&value_,nullptr);
}
int database::bulk_native_statement::bind_text_(int index,const char* text) {
    return lattice_sqlite3541_bind_text(value_,index,text,-1,LATTICE_SQLITE3541_TRANSIENT);
}
int database::bulk_native_statement::bind_null_(int index) {return lattice_sqlite3541_bind_null(value_,index);}
int database::bulk_native_statement::column_type_(int column)const {return lattice_sqlite3541_column_type(value_,column);}
std::int64_t database::bulk_native_statement::column_int64_(int column)const {return lattice_sqlite3541_column_int64(value_,column);}
const unsigned char* database::bulk_native_statement::column_text_(int column)const {return lattice_sqlite3541_column_text(value_,column);}
int database::bulk_native_statement::column_bytes_(int column)const {return lattice_sqlite3541_column_bytes(value_,column);}
int database::bulk_native_statement::reset_() {return detail::store_physical_reset(value_);}
int database::bulk_native_statement::clear_bindings_() {return detail::store_physical_clear_bindings(value_);}
int database::bulk_native_statement::finalize_() {
    const int result=detail::store_physical_finalize(value_);value_=nullptr;return result;
}
const char* database::native_error_()const noexcept {return lattice_sqlite3541_errmsg(internal_handle());}
std::int64_t database::native_last_insert_id_()const noexcept {return lattice_sqlite3541_last_insert_rowid(internal_handle());}
}
