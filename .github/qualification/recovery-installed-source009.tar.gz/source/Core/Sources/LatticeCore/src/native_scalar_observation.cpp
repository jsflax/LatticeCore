#include "provider_native_internal.hpp"
#include <lattice/db.hpp>
namespace lattice {
int database::native_changes_()const noexcept {return lattice_sqlite3541_changes(internal_handle());}
bool database::native_write_transaction_current_()const noexcept {
    const auto* comparison=internal_handle();
    return comparison&&!lattice_sqlite3541_get_autocommit(db_)&&
        lattice_sqlite3541_txn_state(db_,"main")==LATTICE_SQLITE3541_TXN_WRITE;
}
}
