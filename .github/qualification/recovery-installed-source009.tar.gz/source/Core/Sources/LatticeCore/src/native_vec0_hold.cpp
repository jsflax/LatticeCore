#include "provider_native_internal.hpp"
#include <lattice/lattice.hpp>

namespace lattice {
lattice_db::vec0_sqlite_hold::vec0_sqlite_hold(database& owner)
            : physical_call(owner),mutex(physical_call.entered()?lattice_sqlite3541_db_mutex(owner.internal_handle()):nullptr) {
            if(!physical_call.entered())throw db_error("resource Native caller original unavailable");
            if (!mutex) throw db_error("vec0 maintenance requires a SQLite mutex");
            lattice_sqlite3541_mutex_enter(mutex);
        }
lattice_db::vec0_sqlite_hold::~vec0_sqlite_hold() noexcept { lattice_sqlite3541_mutex_leave(mutex); }
}
