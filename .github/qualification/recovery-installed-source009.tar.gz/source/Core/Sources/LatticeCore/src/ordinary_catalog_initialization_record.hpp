#pragma once
#include "ordinary_storage_catalog_digest.hpp"
#include <array>
#include <cstdint>
#include <exception>
#include <limits>
#include <string_view>
#include <span>

namespace lattice::detail {
static_assert(std::numeric_limits<unsigned char>::digits==8,"catalog initialization wire requires eight-bit bytes");
// Closed fixed DATA. These records never issue an original, account, fresh
// classification, SQL purpose, known-COMMIT receipt or runtime completion.
enum class ordinary_catalog_initialization_record_kind:std::uint8_t {reservation=1,intent=2,complete=3,enrollment_intent=4,enrollment_complete=5};
struct ordinary_catalog_initialization_file_id final {
    std::uint64_t device=0,inode=0;
    bool operator==(const ordinary_catalog_initialization_file_id&)const noexcept=default;
};
struct ordinary_catalog_initialization_record_v2 final {
    ordinary_catalog_initialization_record_kind kind=ordinary_catalog_initialization_record_kind::reservation;
    std::array<char,64> epoch{};std::uint16_t epoch_size=0;
    std::array<char,255> member{};std::uint16_t member_size=0;std::uint8_t role=0;
    // Installation, logical root, generation, control, member directory,
    // entry lock, physical lock, MAIN, logical stub, initialization lock.
    std::array<ordinary_catalog_initialization_file_id,10> identity{};
    std::array<unsigned char,32> installation_sha256{},root_sha256{};
    ordinary_storage_catalog_digest_v1 catalog{};
    std::uint32_t storage_epoch=0;std::uint64_t target_version=0;
    ordinary_storage_catalog_mode_v1 storage_mode=ordinary_storage_catalog_mode_v1::local;
    // Intent binds exact reservation bytes; complete binds exact intent bytes.
    std::array<unsigned char,32> predecessor_sha256{};std::uint32_t committed_schema_cookie=0;
    bool operator==(const ordinary_catalog_initialization_record_v2&)const noexcept=default;
};
class ordinary_catalog_initialization_record_error final:public std::exception {
public:const char* what()const noexcept override{return "catalog initialization record is unavailable or noncanonical";}
};
namespace ordinary_catalog_initialization_record_detail {
[[noreturn]] inline void refuse(){throw ordinary_catalog_initialization_record_error{};}
inline constexpr std::array<unsigned char,16> magic{{'L','A','T','T','I','C','E','-','I','N','I','T','-','V','2',0}};
// Fixed-width big-endian integers and zero-padded text; no ABI padding or JSON.
inline constexpr std::size_t wire_size=16+1+2+64+2+255+1+10*16+32+32+32+4+8+1+32+4;
using wire=std::array<unsigned char,wire_size>;
template<class T,std::size_t N> inline bool zero(const std::array<T,N>& value)noexcept {
    for(const auto one:value)if(one!=T{})return false;return true;
}
template<std::size_t N> inline void text_shape(const std::array<char,N>& value,std::size_t size) {
    if(!size||size>N)refuse();
    for(std::size_t i=0;i<size;++i)if(value[i]=='\0')refuse();
    for(std::size_t i=size;i<N;++i)if(value[i]!='\0')refuse();
}
inline void shape(const ordinary_catalog_initialization_record_v2& value) {
    text_shape(value.epoch,value.epoch_size);text_shape(value.member,value.member_size);
    const std::string_view name(value.member.data(),value.member_size);
    if(name=="."||name==".."||name.find('/')!=std::string_view::npos||value.role>=64)refuse();
    for(const auto& one:value.identity)if(!one.inode)refuse();
    using kind=ordinary_catalog_initialization_record_kind;
    switch(value.kind) {
    case kind::reservation:
        if(!zero(value.catalog.bytes)||value.storage_epoch||value.target_version||
           value.storage_mode!=ordinary_storage_catalog_mode_v1::local||
           !zero(value.predecessor_sha256)||value.committed_schema_cookie)refuse();break;
    case kind::intent:case kind::complete:
        if(value.storage_epoch!=8||!value.target_version||
           value.target_version>static_cast<std::uint64_t>(std::numeric_limits<std::int64_t>::max())||
           (value.storage_mode!=ordinary_storage_catalog_mode_v1::local&&
            value.storage_mode!=ordinary_storage_catalog_mode_v1::synchronized))refuse();
        if(value.kind==kind::intent&&value.committed_schema_cookie)refuse();break;
    case kind::enrollment_intent:case kind::enrollment_complete:
        if(value.storage_epoch!=8||!value.target_version||value.target_version>INT32_MAX||
           value.storage_mode!=ordinary_storage_catalog_mode_v1::synchronized||zero(value.catalog.bytes)||
           zero(value.predecessor_sha256)||(value.kind==kind::enrollment_intent&&value.committed_schema_cookie))refuse();break;
    default:refuse();
    }
}
struct writer final {
    wire output{};std::size_t at=0;
    void number(std::uint64_t value,std::size_t width)noexcept {
        for(std::size_t n=0;n<width;++n)output[at++]=static_cast<unsigned char>(value>>(8*(width-1-n)));
    }
    template<class T,std::size_t N> void bytes(const std::array<T,N>& value)noexcept {
        for(const auto one:value)output[at++]=static_cast<unsigned char>(one);
    }
};
struct reader final {
    std::span<const unsigned char> input;std::size_t at=0;
    std::uint64_t number(std::size_t width)noexcept {
        std::uint64_t value=0;for(std::size_t n=0;n<width;++n)value=(value<<8)|input[at++];return value;
    }
    template<class T,std::size_t N> void bytes(std::array<T,N>& value)noexcept {
        for(auto& one:value)one=static_cast<T>(input[at++]);
    }
};
}
using ordinary_catalog_initialization_wire_v2=ordinary_catalog_initialization_record_detail::wire;
inline ordinary_catalog_initialization_wire_v2 ordinary_catalog_initialization_encode_v2(
    const ordinary_catalog_initialization_record_v2& value) {
    using namespace ordinary_catalog_initialization_record_detail;shape(value);writer out;
    out.bytes(magic);out.number(static_cast<std::uint8_t>(value.kind),1);
    out.number(value.epoch_size,2);out.bytes(value.epoch);out.number(value.member_size,2);out.bytes(value.member);
    out.number(value.role,1);for(const auto& one:value.identity){out.number(one.device,8);out.number(one.inode,8);}
    out.bytes(value.installation_sha256);out.bytes(value.root_sha256);out.bytes(value.catalog.bytes);
    out.number(value.storage_epoch,4);out.number(value.target_version,8);out.number(static_cast<std::uint8_t>(value.storage_mode),1);
    out.bytes(value.predecessor_sha256);out.number(value.committed_schema_cookie,4);return out.output;
}
inline ordinary_catalog_initialization_record_v2 ordinary_catalog_initialization_decode_v2(
    std::span<const unsigned char> input) {
    using namespace ordinary_catalog_initialization_record_detail;if(input.size()!=wire_size)refuse();reader in{input};std::array<unsigned char,16> prefix{};
    in.bytes(prefix);if(prefix!=magic)refuse();ordinary_catalog_initialization_record_v2 value;
    value.kind=static_cast<ordinary_catalog_initialization_record_kind>(in.number(1));
    value.epoch_size=static_cast<std::uint16_t>(in.number(2));in.bytes(value.epoch);
    value.member_size=static_cast<std::uint16_t>(in.number(2));in.bytes(value.member);value.role=static_cast<std::uint8_t>(in.number(1));
    for(auto& one:value.identity){one.device=in.number(8);one.inode=in.number(8);}
    in.bytes(value.installation_sha256);in.bytes(value.root_sha256);in.bytes(value.catalog.bytes);
    value.storage_epoch=static_cast<std::uint32_t>(in.number(4));value.target_version=in.number(8);
    value.storage_mode=static_cast<ordinary_storage_catalog_mode_v1>(in.number(1));in.bytes(value.predecessor_sha256);
    value.committed_schema_cookie=static_cast<std::uint32_t>(in.number(4));shape(value);return value;
}
inline std::array<unsigned char,32> ordinary_catalog_initialization_wire_sha256_v2(
    const ordinary_catalog_initialization_wire_v2& input)noexcept {
    ready_sha256_state hash;(void)hash.process(std::string_view(reinterpret_cast<const char*>(input.data()),input.size()));
    return hash.digest_bytes();
}
inline bool ordinary_catalog_initialization_same_member_v2(
    const ordinary_catalog_initialization_record_v2& first,const ordinary_catalog_initialization_record_v2& second)noexcept {
    return first.epoch==second.epoch&&first.epoch_size==second.epoch_size&&first.member==second.member&&
        first.member_size==second.member_size&&first.identity==second.identity&&first.role==second.role&&
        first.installation_sha256==second.installation_sha256&&first.root_sha256==second.root_sha256;
}
inline bool ordinary_catalog_initialization_chain_v2(const ordinary_catalog_initialization_record_v2& reservation,
    const ordinary_catalog_initialization_record_v2& intent,const ordinary_catalog_initialization_record_v2& complete) {
    using kind=ordinary_catalog_initialization_record_kind;
    if(reservation.kind!=kind::reservation||intent.kind!=kind::intent||complete.kind!=kind::complete)return false;
    const auto reservation_wire=ordinary_catalog_initialization_encode_v2(reservation);
    const auto intent_wire=ordinary_catalog_initialization_encode_v2(intent);
    (void)ordinary_catalog_initialization_encode_v2(complete);
    return ordinary_catalog_initialization_same_member_v2(reservation,intent)&&
        ordinary_catalog_initialization_same_member_v2(intent,complete)&&
        intent.predecessor_sha256==ordinary_catalog_initialization_wire_sha256_v2(reservation_wire)&&
        complete.predecessor_sha256==ordinary_catalog_initialization_wire_sha256_v2(intent_wire)&&
        intent.catalog==complete.catalog&&intent.storage_epoch==complete.storage_epoch&&
        intent.target_version==complete.target_version&&intent.storage_mode==complete.storage_mode;
}

// Separate enrollment provenance. Catalog ACK remains a different kind and
// cannot authorize an enrollment. The intent binds the exact catalog intent
// and immutable normalized policy digest, plus all ten actual file identities.
inline bool ordinary_catalog_enrollment_intent_v2(const ordinary_catalog_initialization_record_v2& catalog,
    const ordinary_catalog_initialization_record_v2& intent) {
    using kind=ordinary_catalog_initialization_record_kind;
    (void)ordinary_catalog_initialization_encode_v2(intent);
    return catalog.kind==kind::intent&&intent.kind==kind::enrollment_intent&&
        catalog.storage_mode==ordinary_storage_catalog_mode_v1::synchronized&&
        ordinary_catalog_initialization_same_member_v2(catalog,intent)&&
        catalog.storage_epoch==intent.storage_epoch&&catalog.target_version==intent.target_version&&
        intent.predecessor_sha256==ordinary_catalog_initialization_wire_sha256_v2(
            ordinary_catalog_initialization_encode_v2(catalog));
}
inline bool ordinary_catalog_enrollment_chain_v2(const ordinary_catalog_initialization_record_v2& catalog,
    const ordinary_catalog_initialization_record_v2& intent,const ordinary_catalog_initialization_record_v2& complete) {
    using kind=ordinary_catalog_initialization_record_kind;
    (void)ordinary_catalog_initialization_encode_v2(complete);
    return ordinary_catalog_enrollment_intent_v2(catalog,intent)&&complete.kind==kind::enrollment_complete&&
        ordinary_catalog_initialization_same_member_v2(intent,complete)&&intent.catalog==complete.catalog&&
        intent.storage_epoch==complete.storage_epoch&&intent.target_version==complete.target_version&&
        complete.storage_mode==ordinary_storage_catalog_mode_v1::synchronized&&
        complete.predecessor_sha256==ordinary_catalog_initialization_wire_sha256_v2(
            ordinary_catalog_initialization_encode_v2(intent));
}
}
