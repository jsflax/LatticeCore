#pragma once
namespace lattice::detail::ordinary_catalog_initialization_test {
// Passive stop/observation only. This cannot return an Open, account, lock,
// Native handle, COMMIT, empty/final proof or publication authority.
enum class cut : unsigned {
    reservation_file_synced,reservation_renamed,reservation_parent_synced,
    intent_file_synced,intent_renamed,intent_parent_synced,intent_bound_before_native,
    writer_guard_returned,paired_guard_borrowed,actual_native_return,resource_shared_admitted,resource_shared_ended,
    actual_full_durability,actual_empty_write,actual_full_postimage_before_commit,
    known_commit_before_ack,complete_file_synced,complete_renamed,complete_parent_synced,complete_verified,
    actual_resume_guard_wait,provider_vfs_registered,provider_preentry_unregistered,
    enrollment_intent_file_synced,enrollment_intent_renamed,enrollment_intent_parent_synced,enrollment_intent_before_native,
    enrollment_empty_verified,enrollment_full_postimage_before_commit,enrollment_known_commit_before_ack,
    enrollment_complete_file_synced,enrollment_complete_renamed,enrollment_complete_parent_synced,enrollment_complete_verified,enrollment_committed_tail,count
};
inline constexpr const char* names[]={"reservation-file-synced","reservation-renamed","reservation-parent-synced",
    "intent-file-synced","intent-renamed","intent-parent-synced","intent-bound-before-native",
    "writer-guard-returned","paired-guard-borrowed","actual-native-return","resource-shared-admitted","resource-shared-ended",
    "actual-full-durability","actual-empty-write","actual-full-postimage-before-commit",
    "known-commit-before-ack","complete-file-synced","complete-renamed","complete-parent-synced","complete-verified","actual-resume-guard-wait","provider-vfs-registered","provider-preentry-unregistered",
    "enrollment-intent-file-synced","enrollment-intent-renamed","enrollment-intent-parent-synced","enrollment-intent-before-native",
    "enrollment-empty-verified","enrollment-full-postimage-before-commit","enrollment-known-commit-before-ack",
    "enrollment-complete-file-synced","enrollment-complete-renamed","enrollment-complete-parent-synced","enrollment-complete-verified","enrollment-committed-tail"};
static_assert(sizeof(names)/sizeof(*names)==static_cast<unsigned>(cut::count));
#if defined(LATTICE_RESOURCE_DURABLE_INITIALIZATION_TESTING)
using callback_type=void(*)(cut);
inline thread_local callback_type callback=nullptr;
inline void at(cut value){if(callback)callback(value);}
#else
inline void at(cut)noexcept{}
#endif
}
