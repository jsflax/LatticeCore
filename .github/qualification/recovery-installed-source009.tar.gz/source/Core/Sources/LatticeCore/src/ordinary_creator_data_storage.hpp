#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
#include <new>
#include <stdexcept>
#include <tuple>
#include <type_traits>
#include <utility>

namespace lattice::detail {
std::uint64_t database_native_process()noexcept;
template<class> struct ordinary_creator_data_array:std::false_type{};
template<class T,std::size_t Size>struct ordinary_creator_data_array<std::array<T,Size>>:std::true_type{};
// Private destruction custody for fixed, closed DATA admission locals. The
// tuple is inline: no new/control allocation before the first actual credit.
// This supplies no account, Native, store, scope, identity or SQL permission.
// Product instantiations default-construct only empty standard DATA owners.
template<class... Values> class ordinary_creator_data_storage final {
    using fields=std::tuple<Values...>;
    const std::uint64_t creator_=database_native_process();
    alignas(fields) unsigned char bytes_[sizeof(fields)];
    fields& value_()noexcept{return *std::launder(reinterpret_cast<fields*>(bytes_));}
    template<class Value>static bool clear_value_(Value& value,std::uint64_t creator)noexcept {
        if(creator!=database_native_process())return false;
        if constexpr(ordinary_creator_data_array<Value>::value) {
            for(auto& item:value)if(!clear_value_(item,creator))return false;
        }else if constexpr(requires{value.reset();})value.reset();
        else value=Value{};
        // This fences OUR next field/tuple access. It does not certify
        // arbitrary user-deleter or standard-runtime internals during reset.
        return creator==database_native_process();
    }
    template<std::size_t Index>bool clear_()noexcept {
        if(creator_!=database_native_process())return false;
        if constexpr(Index<sizeof...(Values)) {
            if(!clear_value_(std::get<Index>(value_()),creator_))return false;
            return clear_<Index+1>();
        }else return true;
    }
public:
    ordinary_creator_data_storage()noexcept {
        static_assert((std::is_nothrow_default_constructible_v<Values>&&...));
        ::new(static_cast<void*>(bytes_))fields{};
    }
    ~ordinary_creator_data_storage()noexcept {
        if(creator_==database_native_process()&&clear_<0>())value_().~fields();
    }
    ordinary_creator_data_storage(const ordinary_creator_data_storage&)=delete;
    ordinary_creator_data_storage& operator=(const ordinary_creator_data_storage&)=delete;
    bool in_creator_process()const noexcept{return creator_==database_native_process();}
    template<std::size_t Index>auto& get() {
        if(!in_creator_process())throw std::runtime_error("inherited ordinary DATA storage");
        return std::get<Index>(value_());
    }
};
}
