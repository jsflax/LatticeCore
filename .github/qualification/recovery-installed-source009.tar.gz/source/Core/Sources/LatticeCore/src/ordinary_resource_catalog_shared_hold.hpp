#pragma once
#include <cstdint>
#include <utility>
namespace lattice::detail {
class store_resource_open;class store_physical_vfs;
// Private fixed resource-only custody, never catalog freshness/account/SQL.
// Only actual retained v2 member admission can populate this SH description;
// the genuine VFS lifetime adopts it before its fallible constructor payloads.
class store_resource_catalog_shared_hold final {
    friend class store_resource_open;friend class store_physical_vfs;
    std::uint64_t creator_=0;int description_=-1;
    store_resource_catalog_shared_hold(std::uint64_t actual,int& description)noexcept
        :creator_(actual),description_(std::exchange(description,-1)){}
public:
    store_resource_catalog_shared_hold()noexcept=default;
    store_resource_catalog_shared_hold(store_resource_catalog_shared_hold&& prior)noexcept
        :creator_(prior.creator_),description_(std::exchange(prior.description_,-1)){}
    ~store_resource_catalog_shared_hold()noexcept;
    store_resource_catalog_shared_hold(const store_resource_catalog_shared_hold&)=delete;
    store_resource_catalog_shared_hold& operator=(const store_resource_catalog_shared_hold&)=delete;
};
}
