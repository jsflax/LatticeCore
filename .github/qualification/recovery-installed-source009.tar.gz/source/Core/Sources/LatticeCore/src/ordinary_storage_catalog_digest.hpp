#pragma once
#include "canonical_ready_sha256.hpp"
#include <lattice/recovery_schema.hpp>
#include <array>
#include <cstdint>
#include <exception>
#include <limits>
#include <iterator>
#include <string_view>

namespace lattice::detail {
// Pure immutable DATA identity. Neither a digest nor its inputs issue an Open,
// account, Native original, fresh source, SQL purpose or completion receipt.
struct ordinary_storage_catalog_digest_v1 final {
    std::array<unsigned char,32> bytes{};
    bool operator==(const ordinary_storage_catalog_digest_v1&)const noexcept=default;
};
enum class ordinary_storage_catalog_mode_v1:std::uint8_t {local=0,synchronized=1};
class ordinary_storage_catalog_digest_error final:public std::exception {
public:
    const char* what()const noexcept override{return "captured storage catalog cannot be durably bound";}
};

namespace ordinary_storage_catalog_digest_detail {
[[noreturn]] inline void refuse(){throw ordinary_storage_catalog_digest_error{};}
// Exact fixed stack work, no dynamic buffer, allocation callback or retained
// borrow. The connected issuer charges this workspace on its actual account
// BEFORE construction; this pure digest helper does not manufacture an account.
struct work final {
    ready_sha256_state hash;
    std::size_t declaration_bytes=0,properties=0;
    void charge(std::size_t n) {
        if(n>recovery_owner_schema::max_bytes-declaration_bytes)refuse();
        declaration_bytes+=n;
    }
    void count(std::size_t n,std::size_t cap,std::size_t overhead) {
        bounded(n,cap);if(overhead&&n>recovery_owner_schema::max_bytes/overhead)refuse();
        charge(n*overhead);
    }
    static void bounded(std::size_t n,std::size_t cap){if(n>cap)refuse();}
    void number(std::uint64_t value)noexcept {
        std::array<char,8> encoded{};
        for(std::size_t n=0;n<encoded.size();++n)encoded[n]=static_cast<char>(value>>(56-8*n));
        (void)hash.process(std::string_view(encoded.data(),encoded.size()));
    }
    void text(std::string_view value,std::size_t field_cap=65536,bool declaration_payload=true) {
        bounded(value.size(),field_cap);
        if(declaration_payload) {
            charge(value.size());if(field_cap==65536)charge(16);
        }
        number(value.size());(void)hash.process(value);
    }
    static std::uint64_t type(column_type value) {
        switch(value){
        case column_type::integer:return 1;case column_type::real:return 2;
        case column_type::text:return 3;case column_type::blob:return 4;
        }
        refuse();
    }
    static std::uint64_t kind(property_kind value) {
        switch(value){
        case property_kind::primitive:return 1;case property_kind::link:return 2;
        case property_kind::list:return 3;case property_kind::virtual_list:return 4;
        case property_kind::virtual_link:return 5;case property_kind::union_type:return 6;
        }
        refuse();
    }
    static bool lower_hex(std::string_view value)noexcept {
        for(const char one:value)if(!((one>='0'&&one<='9')||(one>='a'&&one<='f')))return false;
        return true;
    }
    void property(const property_descriptor& p) {
        if(properties==recovery_owner_schema::max_properties)refuse();++properties;charge(128);
        text(p.name);number(type(p.type));number(kind(p.kind));
        const std::uint64_t flags=std::uint64_t(p.nullable)|(std::uint64_t(p.is_vector)<<1)|
            (std::uint64_t(p.is_geo_bounds)<<2)|(std::uint64_t(p.is_full_text)<<3)|
            (std::uint64_t(p.is_indexed)<<4)|(std::uint64_t(p.is_unique)<<5)|
            (std::uint64_t(p.is_union)<<6)|(std::uint64_t(p.no_history)<<7);
        number(flags);text(p.target_table);text(p.link_table);text(p.column_name);
        // Even unused union fields are captured inputs and cannot disappear
        // merely because is_union is false in this declaration generation.
        text(p.union_desc.union_table_name);count(p.union_desc.cases.size(),64,32);
        number(p.union_desc.cases.size());
        for(const auto& one:p.union_desc.cases) {
            text(one.case_name);count(one.values.size(),32,32);number(one.values.size());
            for(const auto& value:one.values) {
                text(value.param_name);number(type(value.type));number(value.is_link?1:0);
                text(value.link_target);
            }
        }
    }
};
}

// Version1 grammar: UTF-8 domain as length+bytes; big-endian uint64 epoch,
// positive target and actual storage mode; sorted model count; each model name,
// Swift-membership bit, ordered properties and ordered constraints; actual Swift
// production order as model ordinals; the three retained Swift metadata bytes.
// Every string is length-delimited; all vectors have a count. Names whose
// equality is required are checked rather than cloned/serialized redundantly.
inline ordinary_storage_catalog_digest_v1 ordinary_storage_catalog_sha256_v1(
    const recovery_owner_schema& catalog,std::uint32_t actual_epoch,
    std::int64_t actual_target,ordinary_storage_catalog_mode_v1 actual_mode) {
    using namespace ordinary_storage_catalog_digest_detail;
    if(!catalog.valid()||actual_epoch!=8||actual_target<=0||
       (actual_mode!=ordinary_storage_catalog_mode_v1::local&&
        actual_mode!=ordinary_storage_catalog_mode_v1::synchronized))refuse();
    work::bounded(catalog.models.size(),recovery_owner_schema::max_models);
    work::bounded(catalog.swift_models.size(),catalog.models.size());
    if(catalog.swift_constraints.size()!=catalog.swift_models.size()||
       catalog.swift_order.size()!=catalog.swift_models.size())refuse();
    const bool has_swift=!catalog.swift_models.empty();
    constexpr std::string_view fingerprint_prefix="schema_fingerprint:";
    if(has_swift) {
        if(catalog.swift_digest.size()!=64||!work::lower_hex(catalog.swift_digest)||
           catalog.swift_fingerprint.size()!=fingerprint_prefix.size()+16||
           std::string_view(catalog.swift_fingerprint).substr(0,fingerprint_prefix.size())!=fingerprint_prefix||
           !work::lower_hex(std::string_view(catalog.swift_fingerprint).substr(fingerprint_prefix.size()))||
           catalog.swift_snapshot.empty())refuse();
    }else if(!catalog.swift_digest.empty()||!catalog.swift_fingerprint.empty()||!catalog.swift_snapshot.empty())refuse();
    work out;
    out.text("lattice-storage-catalog-sha256-v1",65536,false);
    out.number(actual_epoch);out.number(static_cast<std::uint64_t>(actual_target));
    out.number(static_cast<std::uint8_t>(actual_mode));out.number(catalog.models.size());
    std::size_t swift_seen=0;
    for(const auto& [name,model]:catalog.models) {
        if(name!=model.table_name)refuse();out.text(name);
        const bool swift=catalog.swift_models.contains(name);if(swift)++swift_seen;
        out.number(swift?1:0);work::bounded(model.properties.size(),256);out.number(model.properties.size());
        for(const auto& p:model.properties)out.property(p);
        const auto constraints=catalog.swift_constraints.find(name);
        if((constraints!=catalog.swift_constraints.end())!=swift)refuse();
        if(!swift) {out.number(0);continue;}
        out.count(constraints->second.size(),64,32);out.number(constraints->second.size());
        for(const auto& constraint:constraints->second) {
            out.count(constraint.columns.size(),64,16);out.number(constraint.columns.size());
            for(const auto& column:constraint.columns)out.text(column);
            out.number(constraint.allows_upsert?1:0);
        }
    }
    if(swift_seen!=catalog.swift_models.size())refuse();
    out.number(catalog.swift_order.size());
    for(std::size_t n=0;n<catalog.swift_order.size();++n) {
        const auto& name=catalog.swift_order[n];
        if(!catalog.swift_models.contains(name))refuse();
        for(std::size_t prior=0;prior<n;++prior)if(catalog.swift_order[prior]==name)refuse();
        const auto actual=catalog.models.find(name);if(actual==catalog.models.end())refuse();
        out.number(static_cast<std::size_t>(std::distance(catalog.models.begin(),actual)));
    }
    // These two derived metadata strings have fixed real producer lengths and
    // are not charged by recovery_owner_schema's declaration-byte counter.
    out.text(catalog.swift_digest,64,false);
    out.text(catalog.swift_fingerprint,fingerprint_prefix.size()+16,false);
    out.text(catalog.swift_snapshot,recovery_owner_schema::max_bytes);
    return {out.hash.digest_bytes()};
}

inline constexpr std::size_t ordinary_storage_catalog_digest_workspace_v1=
    sizeof(ordinary_storage_catalog_digest_detail::work);
}
