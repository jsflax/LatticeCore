#include "provider_native_internal.hpp" // actual private engine before public types guard
#include "store_physical_api.hpp"
#include "../../LatticeSQLiteProvider/src/provider_core_bridge.hpp"
#include <lattice_sqlite_provider/provider.hpp>
#include "wal_callback_return.hpp"

namespace lattice::detail {
struct sqlite_provider_core_access final {
    static void invoke(unsigned source,const void* original,std::uint64_t creator,lattice_sqlite3541_connection* actual,
        sqlite_provider::v1::detail::core_native_call_kind kind,void(*work)(void*),void* borrowed) {
        using namespace sqlite_provider::v1;
        // Provider checked its actual instance before this fixed Core entry.
        // PID must precede ANY dereference of the retained actual Core original.
        if(!creator||creator!=database_native_process()||!original||!actual||!work||
           (kind!=sqlite_provider::v1::detail::core_native_call_kind::ordinary&&kind!=sqlite_provider::v1::detail::core_native_call_kind::statement_ending))
            throw error(rejection::invalid_original);
        if(source==3){
            store_physical_api::provider_legacy_call_(original,creator,actual,
                kind==sqlite_provider::v1::detail::core_native_call_kind::statement_ending,work,borrowed);
            return;
        }
        if(source!=1&&source!=2)throw error(rejection::invalid_original);
        store_physical_api::provider_native_call_(*static_cast<const store_physical_open_original*>(original),actual,
            kind==sqlite_provider::v1::detail::core_native_call_kind::statement_ending,work,borrowed);
    }
};
void store_physical_api::provider_native_call_(const store_physical_open_original& owner,
    lattice_sqlite3541_connection* actual,bool ending,void(*work)(void*),void* borrowed) {
    using namespace sqlite_provider::v1;
    if(owner.creator_!=database_native_process()||foreign_protected_()||!owner.bound_||
       !actual||owner.actual_!=actual||!work||(!ending&&owner.native_retired_))
        throw error(rejection::invalid_original);
#if !defined(__EMSCRIPTEN__) && (defined(__APPLE__) || defined(__linux__))
    // A real owned VM can end its close_v2 zombie. The immutable producer is
    // compared with the captured primary, never a later address as authority.
    // No arbitrary VM is discovered or finalized by this bridge.
    const auto capture=[&]() {
        auto held=ending?capture_(actual):capture_open_(owner,actual);
        if(held.inherited||held.value!=owner.original_)
            throw error(rejection::invalid_original);
        return held;
    };
    store_physical_native_scope native;
    native.cleanup_only_=ending;
    enter_captured_native_(capture(),native);
    if(!native.entered())throw error(rejection::invalid_original);
    api_scope returned(capture());
    if(!returned.entered())throw error(rejection::invalid_original);
    work(borrowed); // actual Native return, then API pin, then caller pin end
#else
    // Portable source3 takes its genuine separate allocation-owner path above.
    // No portable protected/resource-only producer exists to reinterpret here.
    (void)ending;(void)borrowed;
    throw error(rejection::invalid_original);
#endif
}
}
namespace lattice::sqlite_provider::v1::detail {
void core_native_call(unsigned source,const void* original,std::uint64_t creator,lattice_sqlite3541_connection* actual,
    core_native_call_kind kind,void(*work)(void*),void* borrowed) {
    struct native_work {lattice_sqlite3541_connection* actual;void(*call)(void*);void* borrowed;};
    native_work value{actual,work,borrowed};
    ::lattice::detail::sqlite_provider_core_access::invoke(source,original,creator,actual,kind,
        [](void* pointer){
            auto& issued=*static_cast<native_work*>(pointer);
            // This runs ONLY at the real admitted Core work boundary, after
            // actual Original/API/Native pins; never around earlier admission.
            ::lattice::detail::wal_callback_native_turn returned(issued.actual);
            issued.call(issued.borrowed);
        },&value);
}
}
