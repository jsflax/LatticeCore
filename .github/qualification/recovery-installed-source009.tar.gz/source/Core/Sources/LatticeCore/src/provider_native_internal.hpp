#pragma once
// SOURCE-PRIVATE: raw engine declarations never belong to installed Core or
// Swift importer headers. Every bound public Native escape uses Native-v1.
// This include MUST precede public types.h because the official header guard
// is shared by the private declaration and types-only namespace stages.
#include "../../LatticeSQLiteProvider/src/native_api.h"
#include "../../LatticeSQLiteProvider/src/provider_engine_interface.h"
#include "../../SqliteVec/src/sqlite_vec_native_api.h"

#include "store_physical_api.hpp" // source-only raw Core ending adapters
