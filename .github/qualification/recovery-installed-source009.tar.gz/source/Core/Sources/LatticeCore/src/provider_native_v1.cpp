#include "../../LatticeSQLiteProvider/src/provider_engine_interface.h"
#include "lattice_sqlite_provider/native_v1.hpp"
#include "../../LatticeSQLiteProvider/src/provider_core_bridge.hpp"
#include "wal_callback_return.hpp"
#include <type_traits>
#include <utility>
#if defined(__APPLE__) || defined(__linux__)
#include <unistd.h>
#endif
namespace lattice::sqlite_provider::v1 {
namespace {
std::uint64_t native_process()noexcept {
    return lattice_sqlite3541_provider_current_process();
}
void returned(std::uint64_t creator){
    if(!creator||creator!=native_process())throw error(rejection::inherited_original);
}
}
struct native_access final {
    template<class Function>
    static auto through_core(const connection_original& source,lattice_sqlite3541_connection* actual,
                             detail::core_native_call_kind kind,Function&& work) {
        using function_type=std::remove_reference_t<Function>;
        using result_type=std::invoke_result_t<function_type&>;
        // No heap, owning callback or retained stack pointer. Only this fixed
        // source implementation supplies the synchronous Native thunk.
        if constexpr(std::is_void_v<result_type>) {
            detail::core_native_call(source.source_,source.physical_,source.creator_,actual,kind,
                [](void* borrowed){(*static_cast<function_type*>(borrowed))();},&work);
        }else {
            result_type result{};
            struct call {function_type* work;result_type* result;} value{&work,&result};
            detail::core_native_call(source.source_,source.physical_,source.creator_,actual,kind,
                [](void* borrowed){auto& call=*static_cast<struct call*>(borrowed);*call.result=(*call.work)();},&value);
            return result;
        }
    }
    template<class Function> static auto receiving(lattice_sqlite3541_connection* actual,Function&& work) {
        ::lattice::detail::wal_callback_return returned(actual);
        using result_type=std::invoke_result_t<Function&>;
        if constexpr(std::is_void_v<result_type>){
            work();returned.finish();
        }else{
            auto result=work();returned.finish();return result;
        }
    }
    template<class Function> static auto invoke(const connection_ref& value,Function&& work) {
        const auto& source=original(value);
        auto* actual=static_cast<lattice_sqlite3541_connection*>(value.actual_);
        return receiving(actual,[&]{return through_core(source,actual,
            detail::core_native_call_kind::ordinary,std::forward<Function>(work));});
    }
    template<class Function> static auto invoke(const statement_original& value,Function&& work) {
        (void)statement(value);
        auto* actual=static_cast<lattice_sqlite3541_connection*>(value.actual_connection_);
        return receiving(actual,[&]{return through_core(*value.connection_,actual,
            detail::core_native_call_kind::ordinary,std::forward<Function>(work));});
    }
    static const connection_original& original(const connection_ref& value){
        // Fixed outer instance and PID precede dereferencing the producer.
        if(value.instance_!=lattice_sqlite3541_provider_instance()||!value.creator_||
           value.creator_!=native_process()||!lattice_sqlite3541_provider_process_current())
            throw error(rejection::foreign_instance);
        if(!value.original_)throw error(rejection::invalid_original);
        const auto& source=*value.original_;
        if(!source.borrow_current_()||source.instance_!=value.instance_||source.creator_!=value.creator_||
           source.serial_!=value.serial_||source.actual_!=value.actual_)throw error(rejection::invalid_original);
        return source;
    }
    static lattice_sqlite3541_connection* connection(const connection_ref& value){
        (void)original(value);return static_cast<lattice_sqlite3541_connection*>(value.actual_);
    }
    static lattice_sqlite3541_stmt* statement(const statement_original& value,bool ending=false){
        if(value.instance_!=lattice_sqlite3541_provider_instance()||!value.creator_||
           value.creator_!=native_process()||!lattice_sqlite3541_provider_process_current())
            throw error(rejection::foreign_instance);
        if(!value.connection_||!value.actual_||!value.actual_connection_)throw error(rejection::invalid_original);
        const auto& source=*value.connection_;
        if(source.instance_!=value.instance_||source.creator_!=value.creator_||source.serial_!=value.serial_||
           !source.attempted_)throw error(rejection::invalid_original);
        // Only the exact retained statement may finish a genuine close_v2
        // zombie. No later connection admission or pointer retargeting occurs.
        if(!ending&&(source.retired_||!source.borrow_current_()||source.actual_!=value.actual_connection_))
            throw error(rejection::invalid_original);
        if(ending&&!source.retired_&&source.actual_!=value.actual_connection_)
            throw error(rejection::invalid_original);
        return static_cast<lattice_sqlite3541_stmt*>(value.actual_);
    }
    static int prepare(const connection_ref& owner,const char* sql,int bytes,unsigned flags,
                       statement_original& destination,const char** tail,bool v3){
        auto* db=connection(owner); // Actual original before any Native call.
        if(destination.instance_||destination.actual_||destination.connection_)
            throw error(rejection::consumed_original);
        ::lattice::detail::wal_callback_return callback_return(db);
        lattice_sqlite3541_stmt* actual=nullptr;
        const int rc=through_core(original(owner),db,detail::core_native_call_kind::ordinary,[&]{
            return v3?lattice_sqlite3541_prepare_v3(db,sql,bytes,flags,&actual,tail):
                      lattice_sqlite3541_prepare_v2(db,sql,bytes,&actual,tail);
        });
        returned(owner.creator_);
        if(actual){
            destination.instance_=owner.instance_;destination.creator_=owner.creator_;
            destination.serial_=owner.serial_;destination.connection_=owner.original_;
            destination.actual_connection_=db;destination.actual_=actual;
        }
        // Preserve a genuine partial VM in the supplied output before any
        // originating observer failure can leave this C++ receiving call.
        callback_return.finish();
        return rc;
    }
    static int finish(statement_original& value){
        auto* actual=statement(value,true);const auto creator=value.creator_;
        ::lattice::detail::wal_callback_return callback_return(static_cast<lattice_sqlite3541_connection*>(value.actual_connection_));
        const int rc=through_core(*value.connection_,static_cast<lattice_sqlite3541_connection*>(value.actual_connection_),
            detail::core_native_call_kind::statement_ending,[&]{return lattice_sqlite3541_finalize(actual);});returned(creator);
        // SQLite destroys this statement even when the genuine return is its
        // earlier step error. A nonzero rc cannot authorize a second finalize.
        value.instance_=nullptr;value.creator_=0;value.serial_=0;
        value.connection_=nullptr;value.actual_connection_=nullptr;value.actual_=nullptr;
        // The VM is really destroyed even on nonzero Native rc. Consume its
        // exact identity BEFORE rethrowing any actual committed observer error.
        callback_return.finish();
        return rc;
    }
};
connection_ref::connection_ref(const connection_original& source)
    :instance_(source.instance_),creator_(source.creator_),serial_(source.serial_),original_(&source),actual_(source.actual_){
    (void)native_access::original(*this);
}
connection_ref connection_original::borrow_()const{
    if(instance_!=lattice_sqlite3541_provider_instance()||!creator_||creator_!=native_process()||
       !lattice_sqlite3541_provider_process_current())throw error(rejection::foreign_instance);
    if(!borrow_current_())throw error(rejection::invalid_original);
    return connection_ref(*this);
}
int prepare_v2(const connection_ref& c,const char* s,int n,statement_original& o,const char** t){return native_access::prepare(c,s,n,0,o,t,false);}
int prepare_v3(const connection_ref& c,const char* s,int n,unsigned f,statement_original& o,const char** t){return native_access::prepare(c,s,n,f,o,t,true);}
int finalize(statement_original& s){return native_access::finish(s);}
int step(const statement_original& s){auto* actual=native_access::statement(s);const auto creator=native_process();const auto result=native_access::invoke(s,[&]{return lattice_sqlite3541_step(actual);});returned(creator);return result;}
int reset(const statement_original& s){auto* actual=native_access::statement(s);const auto creator=native_process();const auto result=native_access::invoke(s,[&]{return lattice_sqlite3541_reset(actual);});returned(creator);return result;}
int clear_bindings(const statement_original& s){auto* actual=native_access::statement(s);const auto creator=native_process();const auto result=native_access::invoke(s,[&]{return lattice_sqlite3541_clear_bindings(actual);});returned(creator);return result;}
int bind_null(const statement_original& s,int i){auto* actual=native_access::statement(s);const auto creator=native_process();const auto result=native_access::invoke(s,[&]{return lattice_sqlite3541_bind_null(actual,i);});returned(creator);return result;}
int bind_int64(const statement_original& s,int i,std::int64_t v){auto* actual=native_access::statement(s);const auto creator=native_process();const auto result=native_access::invoke(s,[&]{return lattice_sqlite3541_bind_int64(actual,i,v);});returned(creator);return result;}
int bind_double(const statement_original& s,int i,double v){auto* actual=native_access::statement(s);const auto creator=native_process();const auto result=native_access::invoke(s,[&]{return lattice_sqlite3541_bind_double(actual,i,v);});returned(creator);return result;}
int bind_blob64(const statement_original& s,int i,const void* v,std::uint64_t n,lattice_sqlite3541_destructor_type d){auto* actual=native_access::statement(s);const auto creator=native_process();const auto result=native_access::invoke(s,[&]{return lattice_sqlite3541_bind_blob64(actual,i,v,n,d);});returned(creator);return result;}
int bind_text64(const statement_original& s,int i,const char* v,std::uint64_t n,lattice_sqlite3541_destructor_type d,unsigned char e){auto* actual=native_access::statement(s);const auto creator=native_process();const auto result=native_access::invoke(s,[&]{return lattice_sqlite3541_bind_text64(actual,i,v,n,d,e);});returned(creator);return result;}
int bind_zeroblob64(const statement_original& s,int i,std::uint64_t n){auto* actual=native_access::statement(s);const auto creator=native_process();const auto result=native_access::invoke(s,[&]{return lattice_sqlite3541_bind_zeroblob64(actual,i,n);});returned(creator);return result;}
int bind_parameter_count(const statement_original& s){auto* actual=native_access::statement(s);const auto creator=native_process();const auto result=native_access::invoke(s,[&]{return lattice_sqlite3541_bind_parameter_count(actual);});returned(creator);return result;}
const char* bind_parameter_name(const statement_original& s,int i){auto* actual=native_access::statement(s);const auto creator=native_process();const auto result=native_access::invoke(s,[&]{return lattice_sqlite3541_bind_parameter_name(actual,i);});returned(creator);return result;}
int column_count(const statement_original& s){auto* actual=native_access::statement(s);const auto creator=native_process();const auto result=native_access::invoke(s,[&]{return lattice_sqlite3541_column_count(actual);});returned(creator);return result;}
int column_type(const statement_original& s,int i){auto* actual=native_access::statement(s);const auto creator=native_process();const auto result=native_access::invoke(s,[&]{return lattice_sqlite3541_column_type(actual,i);});returned(creator);return result;}
int column_int(const statement_original& s,int i){auto* actual=native_access::statement(s);const auto creator=native_process();const auto result=native_access::invoke(s,[&]{return lattice_sqlite3541_column_int(actual,i);});returned(creator);return result;}
std::int64_t column_int64(const statement_original& s,int i){auto* actual=native_access::statement(s);const auto creator=native_process();const auto result=native_access::invoke(s,[&]{return lattice_sqlite3541_column_int64(actual,i);});returned(creator);return result;}
double column_double(const statement_original& s,int i){auto* actual=native_access::statement(s);const auto creator=native_process();const auto result=native_access::invoke(s,[&]{return lattice_sqlite3541_column_double(actual,i);});returned(creator);return result;}
const unsigned char* column_text(const statement_original& s,int i){auto* actual=native_access::statement(s);const auto creator=native_process();const auto result=native_access::invoke(s,[&]{return lattice_sqlite3541_column_text(actual,i);});returned(creator);return result;}
const void* column_blob(const statement_original& s,int i){auto* actual=native_access::statement(s);const auto creator=native_process();const auto result=native_access::invoke(s,[&]{return lattice_sqlite3541_column_blob(actual,i);});returned(creator);return result;}
int column_bytes(const statement_original& s,int i){auto* actual=native_access::statement(s);const auto creator=native_process();const auto result=native_access::invoke(s,[&]{return lattice_sqlite3541_column_bytes(actual,i);});returned(creator);return result;}
const char* column_name(const statement_original& s,int i){auto* actual=native_access::statement(s);const auto creator=native_process();const auto result=native_access::invoke(s,[&]{return lattice_sqlite3541_column_name(actual,i);});returned(creator);return result;}
int stmt_busy(const statement_original& s){auto* actual=native_access::statement(s);const auto creator=native_process();const auto result=native_access::invoke(s,[&]{return lattice_sqlite3541_stmt_busy(actual);});returned(creator);return result;}
int stmt_readonly(const statement_original& s){auto* actual=native_access::statement(s);const auto creator=native_process();const auto result=native_access::invoke(s,[&]{return lattice_sqlite3541_stmt_readonly(actual);});returned(creator);return result;}
const char* sql(const statement_original& s){auto* actual=native_access::statement(s);const auto creator=native_process();const auto result=native_access::invoke(s,[&]{return lattice_sqlite3541_sql(actual);});returned(creator);return result;}
int get_autocommit(const connection_ref& c){auto* actual=native_access::connection(c);const auto creator=native_process();const auto result=native_access::invoke(c,[&]{return lattice_sqlite3541_get_autocommit(actual);});returned(creator);return result;}
int errcode(const connection_ref& c){auto* actual=native_access::connection(c);const auto creator=native_process();const auto result=native_access::invoke(c,[&]{return lattice_sqlite3541_errcode(actual);});returned(creator);return result;}
int extended_errcode(const connection_ref& c){auto* actual=native_access::connection(c);const auto creator=native_process();const auto result=native_access::invoke(c,[&]{return lattice_sqlite3541_extended_errcode(actual);});returned(creator);return result;}
const char* errmsg(const connection_ref& c){auto* actual=native_access::connection(c);const auto creator=native_process();const auto result=native_access::invoke(c,[&]{return lattice_sqlite3541_errmsg(actual);});returned(creator);return result;}
std::int64_t changes64(const connection_ref& c){auto* actual=native_access::connection(c);const auto creator=native_process();const auto result=native_access::invoke(c,[&]{return lattice_sqlite3541_changes64(actual);});returned(creator);return result;}
std::int64_t last_insert_rowid(const connection_ref& c){auto* actual=native_access::connection(c);const auto creator=native_process();const auto result=native_access::invoke(c,[&]{return lattice_sqlite3541_last_insert_rowid(actual);});returned(creator);return result;}
void interrupt(const connection_ref& c){auto* actual=native_access::connection(c);const auto creator=native_process();native_access::invoke(c,[&]{lattice_sqlite3541_interrupt(actual);});returned(creator);}
}
