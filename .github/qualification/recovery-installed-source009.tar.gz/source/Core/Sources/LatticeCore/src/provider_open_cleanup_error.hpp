#pragma once
#include "ordinary_creator_data_storage.hpp"
#include <exception>
#include <utility>
namespace lattice::detail {
// Actual first open error + distinct actual registration-cleanup debt. Neither
// this carrier nor a missing Native pointer establishes ending or permission.
class provider_open_cleanup_error final:public std::exception {
    ordinary_creator_data_storage<std::exception_ptr,std::exception_ptr> errors_;
    const bool actual_rc_present_;
    const int actual_rc_;
public:
    provider_open_cleanup_error(std::exception_ptr primary,std::exception_ptr cleanup,bool has_rc=false,int actual_rc=0)noexcept
        :actual_rc_present_(has_rc),actual_rc_(actual_rc) {
        errors_.get<0>()=std::move(primary);errors_.get<1>()=std::move(cleanup);
    }
    const char* what()const noexcept override{return "private provider open failed with actual registration cleanup debt";}
    std::exception_ptr primary_error()const {
        if(!errors_.in_creator_process())return {};
        return const_cast<provider_open_cleanup_error*>(this)->errors_.get<0>();
    }
    std::exception_ptr cleanup_error()const {
        if(!errors_.in_creator_process())return {};
        return const_cast<provider_open_cleanup_error*>(this)->errors_.get<1>();
    }
    bool has_actual_cleanup_code()const noexcept{return actual_rc_present_;}
    int actual_cleanup_code()const noexcept{return actual_rc_;}
};
}
