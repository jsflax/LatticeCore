#pragma once
#include <lattice/ordinary_context.hpp>
#include "canonical_writer_adapter.hpp"
#include <atomic>
#include <chrono>
#include <mutex>

namespace lattice { class swift_lattice_ref; }
namespace lattice::detail {
namespace authenticated_ready_maintenance_test_observation {
// Passive scheduling probe only. It cannot create a setup/admission, supply
// lifecycle facts, change time or bypass the actual owned transaction.
struct probe {const lattice_db* owner=nullptr;std::function<void(const char*)> observed;};
std::shared_ptr<const probe> exchange(std::shared_ptr<const probe>);
// Passive copies only, including when no service has ever been launched.
// Neither map absence nor these counters is physical-ending authority.
struct retirement_observation {
    bool available=false,worker_exited=false,caller_is_worker=false;
    uint64_t launches=0,requested=0,settled=0,boundaries=0;
    size_t active_removal_originals=0;
    size_t matching_registrations=0;
};
retirement_observation retirement(const instance_guard*) noexcept;
}
namespace authenticated_ready_control_test_observation {
enum class operation : int32_t { unobserved,describe,prepare,resume,read,discard,inspect,predecessor,unknown };
enum class point { entered,control_parsed,deadline_reserved,expiration_returned,prepare_returned,resume_returned,lease_copied,finished,count };
// Test-only bounded copies from the actual retained capture exception. No
// exception/owner is retained and no diagnostic participates in admission.
enum class capture_exception_kind : uint8_t { unobserved,none,db_error,std_exception,non_std_exception };
struct capture_failure {
    capture_exception_kind kind=capture_exception_kind::unobserved;
    std::array<char,512> message{};
    uint16_t bytes=0;
    bool truncated=false,null_message=false;
};
inline capture_failure copy_capture_failure(const std::exception_ptr& original) noexcept {
    capture_failure out;
    if(!original){out.kind=capture_exception_kind::none;return out;}
    const auto copy=[&](capture_exception_kind kind,const char* text) noexcept {
        out.kind=kind;if(!text){out.null_message=true;return;}
        size_t n=0;for(;n+1<out.message.size()&&text[n];++n)out.message[n]=text[n];
        out.bytes=static_cast<uint16_t>(n);out.truncated=text[n]!=0;
    };
    try {std::rethrow_exception(original);}
    catch(const db_error& error){copy(capture_exception_kind::db_error,error.what());}
    catch(const std::exception& error){copy(capture_exception_kind::std_exception,error.what());}
    catch(...){out.kind=capture_exception_kind::non_std_exception;}
    return out;
}
struct observation : canonical_ready_control_observation::stages<static_cast<size_t>(point::count)> {
    operation op=operation::unobserved;
    capture_failure capture_failure_copy;
    // Copied only after native UUID validation; no untrusted/arbitrary string.
    std::array<char,37> request_id{};
    // Authenticated epoch milliseconds, distinct from retention-session time.
    int64_t clock_ms=-1,deadline_ms=-1,duration_ms=-1;
    canonical_ready_control_observation::settlement expiration,preparation,publication;
    bool capture_error=false,requires_full_request=false,lease_available=false;
    // Passive, fixed copies only after the actual non-lifecycle discard returns.
    // No exception pointer, owner, wire data or admission is retained here.
    bool discard_observed=false;
    int64_t logical_sequence=-1;
    canonical_ready_control_observation::settlement discard;
    capture_failure discard_primary,discard_cleanup;
};
inline void copy_discard(observation& out,const recovery_install_result& result) noexcept {
    out.discard=canonical_ready_control_observation::copy(result);
    out.discard_primary=copy_capture_failure(result.primary_error);
    out.discard_cleanup=copy_capture_failure(result.cleanup_error);
    out.discard_observed=true;
}
inline thread_local observation* current=nullptr;
inline void mark(point p) noexcept {if(auto* value=current)value->mark(static_cast<size_t>(p));}
}
struct authenticated_ready_budget;
struct authenticated_ready_fence;
// Payload-free source-wide charge. This is capacity, never authority.
class authenticated_ready_charge {
    friend class authenticated_session_fence;
    friend class authenticated_relay_setup;
    std::shared_ptr<authenticated_ready_budget> budget_;
    uint64_t input_=0,charged_=0;
    std::atomic<bool> consumed_{false};
    authenticated_ready_charge()=default;
public:
    ~authenticated_ready_charge();
};
// Payload-free shared stop state. Only the real setup can authorize it. Close
// and kicks may stop it from any thread without entering SQL or waiting.
class authenticated_session_fence {
    friend class authenticated_relay_setup;
    friend class authenticated_relay_operation;
    std::atomic<bool> stopped_{false},authorized_{false};
    std::atomic<int64_t> deadline_{0};
    mutable std::mutex mutex_;
    size_t active_=0;
    std::shared_ptr<authenticated_ready_budget> ready_budget_;
    std::shared_ptr<instance_guard> owner_guard_;
    std::shared_ptr<const std::atomic<bool>> active_guard_;
    authenticated_session_fence()=default;
public:
    static int64_t now() noexcept;
    bool live()const noexcept;
    bool stopped()const noexcept;
    bool drained()const noexcept;
    void stop()noexcept;
    std::shared_ptr<authenticated_ready_charge> reserve_ready(uint64_t input_bytes)const;
};
// Payload-free counted handoff. A result retains it through SDK publication;
// destruction settles exactly one admission without running SQL or callbacks.
class authenticated_relay_operation {
    friend class authenticated_relay_setup;
    std::shared_ptr<authenticated_session_fence> fence_;
    std::shared_ptr<authenticated_ready_charge> charge_;
    std::shared_ptr<authenticated_ready_fence> ready_;
    explicit authenticated_relay_operation(std::shared_ptr<authenticated_session_fence>);
public:
    ~authenticated_relay_operation();
    bool publishable()const noexcept;
};
struct authenticated_relay_result {
    // 1 completed with actual IDs/bookkeeping, 2 retired. Exceptions retain
    // uncertainty; the bridge reports 4 rather than claiming effect absence.
    int32_t status=0;
    std::vector<std::string> applied;
    std::shared_ptr<authenticated_relay_operation> operation;
};
struct authenticated_ready_result {
    // 0 not a control, 1 typed control response, 2 retired. Exceptions retain
    // uncertainty; no control result enters ordinary ACK/NACK/fan-out.
    int32_t status=0;
    std::string wire;
    std::shared_ptr<authenticated_relay_operation> operation;
    std::string request_id;
};
struct authenticated_lifecycle_adoption_result {
    bool pending_quiescence=false;
    canonical_ready_adoption_result adoption;
};
struct authenticated_mounted_source;
class authenticated_relay_setup {
    friend class ::lattice::swift_lattice_ref;
    friend struct authenticated_ready_test_access;
    static thread_local const std::function<void()>* ready_before_owned_test_hook_;
    static thread_local const std::function<void()>* admin_before_open_test_hook_;
    // Passive friend-only observation; cannot inject work or skip validation.
    static thread_local uint64_t* setup_registry_entries_test_counter_;
    struct source_file_administration;
    static std::unique_ptr<source_file_administration> open_administrative_file(const std::string&,
        recovery_owner_schema,int64_t,int,ordinary_context context = {});
    struct state;
    std::shared_ptr<state> state_;
    explicit authenticated_relay_setup(std::shared_ptr<state>);
    // Bridge-private creation retains the actual ref impl_. It creates an
    // UNAUTHORIZED setup, never an admission from caller claims.
    static std::shared_ptr<authenticated_relay_setup> open(std::shared_ptr<lattice_db>,
        const std::string& source_policy,const std::string& connection,
        void*,int32_t(*)(void*),void(*)(void*));
    static std::shared_ptr<authenticated_relay_setup> open_automatic(std::shared_ptr<lattice_db>,
        const std::string&,const std::string&,void*,int32_t(*)(void*),int32_t(*)(void*),void(*)(void*),bool&);
    static std::shared_ptr<authenticated_relay_setup> open_impl(std::shared_ptr<lattice_db>,
        const std::string&,const std::string&,void*,int32_t(*)(void*),void(*)(void*),int32_t(*)(void*),bool*);
    // Explicit administration of the real resolved mount owner, never an
    // issuer. False is only pre-SQL quiescence contention; exceptions do not
    // imply durable absence and ordinary open never invokes this transition.
    static bool migrate_receipt_coverage_file(const std::string& path, recovery_owner_schema catalog,
        int64_t schema_version,int busy_timeout_ms,const std::string& prior,const std::string& next);
    static authenticated_lifecycle_adoption_result adopt_lifecycle_file(const std::string&,recovery_owner_schema,
        int64_t,int,const std::string& prior,const std::string& next);
    static bool migrate_receipt_coverage(std::shared_ptr<lattice_db>,
        const std::string& prior_mount_policy,const std::string& next_mount_policy);
public:
    authenticated_relay_setup(const authenticated_relay_setup&)=delete;
    ~authenticated_relay_setup();
    std::shared_ptr<authenticated_session_fence> stop_token()const noexcept;
    std::string descriptor()const;
    bool finish_authorization(const std::string& exact_application_outcome);
    authenticated_relay_result receive(const std::string&);
    authenticated_ready_result ready(const std::string&,const std::shared_ptr<authenticated_ready_charge>&);
    void close()noexcept;
    static constexpr bool receiver_source_authority=false;
    static constexpr bool automatic_recovery=false;
};
}
