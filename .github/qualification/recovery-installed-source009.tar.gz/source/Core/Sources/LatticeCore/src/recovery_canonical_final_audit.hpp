#pragma once
#include "recovery_obligation_bootstrap_statement.hpp"
#include "ordinary_schema_projection.hpp"
#include "recovery_producer_continuity.hpp"
#include <initializer_list>
#include <limits>
#include <string_view>
#include <vector>
#include <cstdint>

namespace lattice::detail {
// Closed implementation seam. Its Reader is constructible only by the actual
// pending Open/account owner, and its audit requires that same sealed snapshot.
struct scoped_recovery_limits;
struct recovery_canonical_final_audit final {
    friend class recovery_request_store;
    friend class canonical_range_staging;
    friend class receive_install_store;
    friend struct recovery_witness_access;
    friend class recovery_receiver_controller;
private:
    struct column {const char* name;column_type type;bool nullable;};
    static void table_(const recovery_obligation_bootstrap_reader&,ordinary_schema_projection&,
        std::string_view,std::string_view,std::initializer_list<column>,std::initializer_list<std::string_view> = {});
    static void append_domains_(const recovery_obligation_bootstrap_reader&,ordinary_schema_projection&);
    static void audit_domains_(recovery_obligation_bootstrap_reader&,const scoped_recovery_limits&);
    static void claim_rows_(recovery_obligation_bootstrap_reader&,const std::vector<database::row_t>&);
public:
    static void append_projection_(const recovery_continuous_policy&,
        const recovery_obligation_bootstrap_reader&,ordinary_schema_projection&);
    static void audit_(lattice_db&,database&,recovery_obligation_bootstrap_reader&,
        const recovery_continuous_policy&,std::int64_t phase,std::int64_t barrier,std::int64_t attempt);
    static void audit_core_receivers_(recovery_obligation_bootstrap_reader&,
        const recovery_continuous_policy&,std::int64_t phase,std::int64_t attempt);
};
}
