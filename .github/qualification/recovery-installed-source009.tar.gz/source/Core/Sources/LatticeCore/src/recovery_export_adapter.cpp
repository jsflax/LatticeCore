#include "provider_native_internal.hpp"
#include <lattice/store_physical_api.hpp>
#include "recovery_export_adapter.hpp"
#include "recovery_unknown_reconciliation.hpp"
#include "recovery_receiver_source.hpp"
#include "recovery_upload_json.hpp"
#include <cmath>
#include <algorithm>
#include <array>
#include <functional>
#include <utility>
#include <iomanip>
#include <limits>
#include <locale>
#include <sstream>

namespace lattice::detail {
namespace recovery_export_test_hooks {
thread_local void (*before_claim_commit)()=nullptr;
thread_local void (*after_claim_commit)()=nullptr;
thread_local void (*after_contribution_claim)(size_t)=nullptr;
thread_local void (*automatic_handoff_observed)(const transport_message&)=nullptr;
}
namespace {
[[noreturn]] void refuse(const char* message){throw db_error(message);}
struct export_capacity_error : db_error {using db_error::db_error;};
bool automatic_export_deferred(const recovery_install_result& result,bool* busy) {
    if(result.deferred==recovery_install_deferred::none)return false;
    if(!busy||result.state!=recovery_install_state::refused||result.primary_error||result.cleanup_error||
       result.postcommit_error||result.notification_error||result.unexpected_commit_observed)
        refuse("automatic export invalid deferred settlement");
    *busy=true;return true;
}
struct statement {
    lattice_sqlite3541_stmt* p=nullptr;
    statement(lattice_sqlite3541_connection* db,const std::string& sql){
        database::record_statement();const int rc=::lattice::detail::store_physical_prepare_v2(db,sql.c_str(),-1,&p,nullptr);
        if(rc!=LATTICE_SQLITE3541_OK||!p||!lattice_sqlite3541_stmt_readonly(p)){::lattice::detail::store_physical_finalize(p);p=nullptr;refuse("export bounded read preparation failed");}
    }
    ~statement(){::lattice::detail::store_physical_finalize(p);}
    statement(const statement&)=delete;
    void integer(int at,int64_t value){if(lattice_sqlite3541_bind_int64(p,at,value)!=LATTICE_SQLITE3541_OK)refuse("export integer binding failed");}
    void text(int at,const std::string& value){
        if(value.size()>static_cast<size_t>(std::numeric_limits<int>::max())||
           lattice_sqlite3541_bind_text(p,at,value.data(),static_cast<int>(value.size()),LATTICE_SQLITE3541_STATIC)!=LATTICE_SQLITE3541_OK)refuse("export text binding failed");
    }
    bool next(){const int rc=::lattice::detail::store_physical_step(p);if(rc==LATTICE_SQLITE3541_ROW)return true;if(rc==LATTICE_SQLITE3541_DONE)return false;refuse("export bounded read failed");}
};
struct budget {
    const recovery_export_limits& limits;size_t used=0;
    void charge(size_t n){if(n>limits.field_bytes||n>limits.raw_bytes-used)throw export_capacity_error("export raw byte budget exceeded before copy");used+=n;}
};
int64_t integer(statement& s,int at){if(lattice_sqlite3541_column_type(s.p,at)!=LATTICE_SQLITE3541_INTEGER)refuse("export expected INTEGER");return lattice_sqlite3541_column_int64(s.p,at);}
std::string text(statement& s,int at,budget& b){
    if(lattice_sqlite3541_column_type(s.p,at)!=LATTICE_SQLITE3541_TEXT)refuse("export expected TEXT");
    const int n=lattice_sqlite3541_column_bytes(s.p,at);if(n<0)refuse("export invalid text length");b.charge(static_cast<size_t>(n));
    const auto* p=lattice_sqlite3541_column_text(s.p,at);if(!p)refuse("export unavailable text");return {reinterpret_cast<const char*>(p),static_cast<size_t>(n)};
}
column_value_t scalar(statement& s,int at,budget& b){
    switch(lattice_sqlite3541_column_type(s.p,at)){
    case LATTICE_SQLITE3541_NULL:b.charge(0);return nullptr;
    case LATTICE_SQLITE3541_INTEGER:b.charge(8);return static_cast<int64_t>(lattice_sqlite3541_column_int64(s.p,at));
    case LATTICE_SQLITE3541_FLOAT:{b.charge(8);const double v=lattice_sqlite3541_column_double(s.p,at);if(!std::isfinite(v))refuse("export nonfinite scalar");return v;}
    case LATTICE_SQLITE3541_TEXT:return text(s,at,b);
    case LATTICE_SQLITE3541_BLOB:{const int n=lattice_sqlite3541_column_bytes(s.p,at);if(n<0)refuse("export invalid blob length");b.charge(static_cast<size_t>(n));if(!n)return std::vector<uint8_t>{};
        const auto* p=static_cast<const uint8_t*>(lattice_sqlite3541_column_blob(s.p,at));if(!p)refuse("export unavailable blob");return std::vector<uint8_t>(p,p+n);}
    default:refuse("export unsupported scalar");
    }
}
std::string quote_identifier(const std::string& name){
    if(name.empty()||name.size()>64)refuse("export invalid admitted identifier");
    for(unsigned char c:name)if(!((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='_'))refuse("export invalid admitted identifier");
    return "\""+name+"\"";
}
void limits_ok(const recovery_export_limits& l,size_t count,const std::vector<int64_t>& in_flight){
    if(!l.entries||l.entries>1000||!count||count>l.entries||in_flight.size()>2000||
       !l.field_bytes||l.field_bytes>1048576||l.raw_bytes<l.field_bytes||l.raw_bytes>4194304||
       l.wire_bytes<16||l.wire_bytes>8388608||!l.coverage_candidates||l.coverage_candidates>4096)refuse("export independent limits exceeded");
    for(const auto id:in_flight)if(id<=0)refuse("export synthetic in-flight original unsupported");
}
struct raw_audit {
    audit_log_entry entry;std::string fields,names;
    column_value_t persisted_timestamp;
};
std::string wire_timestamp(const column_value_t& value,budget& b){
    // Real generated AuditLog rows use numeric epoch seconds. The wire field
    // remains text, including older textual originals, but conversion must
    // neither discard fractional seconds nor invent a replacement timestamp.
    if(const auto* legacy=std::get_if<std::string>(&value))return *legacy;
    std::string encoded;
    if(const auto* seconds=std::get_if<int64_t>(&value))encoded=std::to_string(*seconds);
    else if(const auto* seconds=std::get_if<double>(&value)){
        std::ostringstream stream;stream.imbue(std::locale::classic());
        stream<<std::setprecision(std::numeric_limits<double>::max_digits10)<<*seconds;
        if(!stream)refuse("export timestamp encoding failed");encoded=stream.str();
    }else refuse("export timestamp is not numeric or text");
    b.charge(encoded.size());return encoded;
}
raw_audit read_audit(lattice_sqlite3541_connection* db,int64_t id,budget& b){
    statement s(db,"SELECT id,globalId,tableName,operation,rowId,globalRowId,changedFields,changedFieldsNames,timestamp,isFromRemote,isSynchronized,synthesized FROM main.AuditLog WHERE id=? LIMIT 2");s.integer(1,id);
    if(!s.next())refuse("export original disappeared");raw_audit r;auto& e=r.entry;
    e.id=integer(s,0);e.global_id=text(s,1,b);e.table_name=text(s,2,b);e.operation=text(s,3,b);e.row_id=integer(s,4);e.global_row_id=text(s,5,b);
    r.fields=text(s,6,b);r.names=text(s,7,b);r.persisted_timestamp=scalar(s,8,b);
    e.timestamp=wire_timestamp(r.persisted_timestamp,b);
    const auto remote=integer(s,9),synced=integer(s,10),synthesized=integer(s,11);
    if(e.id!=id||id<=0||e.global_id.size()!=36||e.global_row_id.size()!=36||e.table_name.empty()||
       (e.operation!="INSERT"&&e.operation!="UPDATE"&&e.operation!="DELETE")||e.row_id<0||remote!=0||synthesized!=0||(synced!=0&&synced!=1))
        refuse("export requires local persisted original shape");
    e.is_synchronized=synced!=0;
    if(s.next())refuse("export ambiguous original");return r;
}
bool same_original(const raw_audit& a,const raw_audit& b){
    const auto& x=a.entry;const auto& y=b.entry;
    return x.id==y.id&&x.global_id==y.global_id&&x.table_name==y.table_name&&x.operation==y.operation&&x.row_id==y.row_id&&
        x.global_row_id==y.global_row_id&&x.timestamp==y.timestamp&&a.persisted_timestamp==b.persisted_timestamp&&
        x.is_synchronized==y.is_synchronized&&a.fields==b.fields&&a.names==b.names;
}
bool has_column(const recovery_local_export_table& table,const std::string& name){
    if(table.regular_link)return name=="lhs"||name=="rhs";
    for(const auto& c:table.columns)if(c.first==name)return true;
    return false;
}
void decode_generated(lattice_sqlite3541_connection* db,raw_audit& row,const recovery_local_export_table& table,budget& b,
    bool retained_later_delete=false,const std::function<bool()>& absent_row_proof={},
    const std::function<void(audit_log_entry&)>& capture_identity={},bool materialize=true){
    auto& e=row.entry;
    {statement valid(db,"SELECT json_valid(?1),json_valid(?2),CASE WHEN json_valid(?1) THEN json_type(?1) END,CASE WHEN json_valid(?2) THEN json_type(?2) END");
     valid.text(1,row.fields);valid.text(2,row.names);
     if(!valid.next()||integer(valid,0)!=1||integer(valid,1)!=1||text(valid,2,b)!="object"||text(valid,3,b)!="array")refuse("export malformed generated JSON");}
    std::set<std::string> keys,changed;
    {statement fields(db,"SELECT key,type,atom FROM json_each(?) LIMIT 33");fields.text(1,row.fields);
     while(fields.next()){
        if(keys.size()>=32)refuse("export generated field count exceeded");const auto key=text(fields,0,b);const auto type=text(fields,1,b);
        if(!has_column(table,key)||!keys.insert(key).second||type=="object"||type=="array"||type=="true"||type=="false")refuse("export unsupported or duplicate generated field");
        e.changed_fields.emplace(key,any_property::from_column_value(scalar(fields,2,b)));
     }}
    {statement names(db,"SELECT type,atom FROM json_each(?) LIMIT 33");names.text(1,row.names);size_t count=0;
     while(names.next()){
        if(++count>32)refuse("export generated name count exceeded");const auto type=text(names,0,b);if(type=="null")continue;
        if(type!="text")refuse("export generated name is not text");const auto name=text(names,1,b);
        if(!keys.count(name)||!changed.insert(name).second)refuse("export missing or duplicate generated name");e.changed_fields_names.push_back(name);
     }}
    if(table.regular_link&&e.operation=="UPDATE")refuse("export unsupported link update");
    if(capture_identity)capture_identity(e);
    if(!materialize)return;
    if(e.operation=="UPDATE")for(const auto& column:table.no_history){
        if(!changed.count(column))continue;
        statement current(db,"SELECT "+quote_identifier(column)+" FROM main."+quote_identifier(table.name)+" WHERE globalId=? LIMIT 2");current.text(1,e.global_row_id);
        if(!current.next()){
            if(!retained_later_delete&&(!absent_row_proof||!absent_row_proof()))refuse("export NoHistory current row is absent");
            // Only the wire projection changes. The original names/fields and
            // generated stamp remain intact and are verified again precommit.
            e.changed_fields.erase(column);
            e.changed_fields_names.erase(std::remove(e.changed_fields_names.begin(),e.changed_fields_names.end(),column),e.changed_fields_names.end());
            continue;
        }
        e.changed_fields[column]=any_property::from_column_value(scalar(current,0,b));
        if(current.next())refuse("export NoHistory target is ambiguous");
    }
}
size_t wire_bound(const audit_log_entry& e,size_t cap){
    size_t n=512;auto add=[&](size_t bytes,size_t multiplier=1){if(n>cap||bytes>(cap-n)/multiplier)throw export_capacity_error("export wire budget exceeded before serialization");n+=bytes*multiplier;};
    for(const auto* s:{&e.global_id,&e.table_name,&e.operation,&e.global_row_id,&e.timestamp})add(s->size(),6);
    for(const auto& name:e.changed_fields_names){add(name.size(),6);add(4);}
    for(const auto& [name,p]:e.changed_fields){add(name.size(),6);add(80);
        if(const auto* s=std::get_if<std::string>(&p.value))add(s->size(),6);
        else if(const auto* bytes=std::get_if<std::vector<uint8_t>>(&p.value))add(bytes->size(),2);
    }
    if(e.original_identity){add(128);add(e.original_identity->digest.size());for(const auto& n:e.original_identity->changed_fields_names){add(n.size(),6);add(4);}}
    if(n>cap)refuse("export wire budget exceeded before serialization");return n;
}
void check_scopes(const recovery_local_export_inventory& inventory,const std::vector<recovery_local_export_scope>& expected){
    if(inventory.scopes.size()!=expected.size())refuse("export scope inventory changed");
    for(size_t i=0;i<expected.size();++i){const auto& a=inventory.scopes[i];const auto& b=expected[i];
        if(a.contribution.address!=b.contribution.address||a.contribution.profile!=b.contribution.profile||
           a.contribution.mode!=recovery_obligation_mode::recording||a.program_digest!=b.program_digest||a.program_revision!=b.program_revision)
            refuse("export contribution generation or program changed");
    }
}
void check_claims(recovery_obligation_store& journal,const std::vector<recovery_obligation_export_ticket>& claims,const std::vector<audit_log_entry>& entries){
    for(const auto& claim:claims)for(const auto& id:claim.canonical_original_ids){
        const auto found=journal.find(claim.address,id);if(!found||!found->first_export_claim||found->stage!=recovery_obligation_stage::open)refuse("export final claim disappeared");
        const audit_log_entry* actual=nullptr;for(const auto& e:entries)if(e.id==found->record.audit_id){actual=&e;break;}
        if(!actual||actual->global_id!=found->record.original_id||actual->table_name!=found->record.table||actual->global_row_id!=found->record.target_id)
            refuse("export final claimed identity changed");
    }
}
std::string small_text(statement& s,int at,size_t limit){
    if(lattice_sqlite3541_column_type(s.p,at)!=LATTICE_SQLITE3541_TEXT)refuse("export coverage expected TEXT");
    const int n=lattice_sqlite3541_column_bytes(s.p,at);
    if(n<0||static_cast<size_t>(n)>limit)refuse("export coverage text exceeds bound before copy");
    const auto* value=lattice_sqlite3541_column_text(s.p,at);
    if(!value)refuse("export coverage unavailable text");
    return {reinterpret_cast<const char*>(value),static_cast<size_t>(n)};
}
std::string compact_index_sql(std::string sql){
    std::string result;result.reserve(sql.size());
    for(unsigned char c:sql){
        if(c==' '||c=='\t'||c=='\n'||c=='\r')continue;
        result+=static_cast<char>(c>='A'&&c<='Z'?c-'A'+'a':c);
    }
    return result;
}
void coverage_indexes(lattice_sqlite3541_connection* db){
    for(const auto& index:std::array<std::pair<const char*,const char*>,2>{{
        {"idx_sync_state_pending","CREATE INDEX idx_sync_state_pending ON _lattice_sync_state(sync_id, is_synchronized) WHERE is_synchronized = 0"},
        {"idx_audit_log_pending_sync","CREATE INDEX idx_audit_log_pending_sync ON AuditLog(isSynchronized) WHERE isSynchronized = 0"}}}){
        statement query(db,"SELECT sql FROM main.sqlite_schema WHERE type='index' AND name=? LIMIT 2");
        const std::string name(index.first);query.text(1,name);
        if(!query.next())refuse("export coverage required pending index differs");
        const auto actual=compact_index_sql(small_text(query,0,512));const auto expected=compact_index_sql(index.second);
        const auto guarded=std::string("createindexifnotexists")+expected.substr(sizeof("createindex")-1);
        if((actual!=expected&&actual!=guarded)||query.next())
            refuse("export coverage required pending index differs");
    }
}
// This is an addressed stamp check, not a repeated full profile/manifest read.
// Full schema/profile audit and exclusive metadata custody remain prerequisites.
std::array<int64_t,20> coverage_stamp(lattice_sqlite3541_connection* db,const recovery_local_export_inventory& inventory,
    const recovery_local_export_scope& scope,const recovery_obligation_entry& entry){
    statement query(db,"SELECT t.incarnation,t.program_revision,t.audit_id,t.record_sequence,t.generation,t.scope_revision,"
        "t.base_scopes,t.base_records,t.base_bytes,t.base_incarnation,t.base_export,t.producer_profiles,t.producer_stamps,t.producer_bytes,t.bytes,"
        "g.incarnation,g.export_sequence,u.stamps,u.bytes,u.profiles "
        "FROM main._lattice_obligation_producer_stamp t CROSS JOIN main._lattice_obligation_store g CROSS JOIN main._lattice_obligation_producer_store u "
        "WHERE t.channel=CAST(? AS BLOB) AND t.original=CAST(? AS BLOB) AND g.id=1 AND u.id=1 LIMIT 2");
    query.text(1,scope.contribution.address.channel);query.text(2,entry.canonical_original_id);
    if(!query.next())refuse("export coverage pending original lacks generated stamp");
    std::array<int64_t,20> value{};
    for(size_t i=0;i<value.size();++i)value[i]=integer(query,static_cast<int>(i));
    if(query.next())refuse("export coverage ambiguous generated stamp");
    const auto& ol=inventory.limits.obligations;const auto& pl=inventory.limits.producers;
    const auto& address=scope.contribution.address;
    const int64_t stamp_bytes=15*8+36+static_cast<int64_t>(address.channel.size());
    const int64_t entry_bytes=8*8+static_cast<int64_t>(address.channel.size()+entry.record.original_id.size()+
        entry.record.table.size()+entry.record.target_id.size()+entry.canonical_original_id.size()+entry.canonical_target_id.size());
    if(value[0]!=address.incarnation||value[1]!=scope.program_revision||value[2]!=entry.record.audit_id||value[3]!=entry.sequence||
       value[4]<=0||value[4]>address.generation||value[5]<=0||value[5]>scope.contribution.revision||
       value[6]<=0||value[6]>ol.scopes||value[7]<=0||value[7]>ol.records||value[8]<entry_bytes||value[8]>ol.encoded_bytes||
       value[9]<address.incarnation||value[9]>value[15]||value[10]<0||value[10]>value[16]||
       value[11]<=0||value[11]>pl.profiles||value[12]<=0||value[12]>pl.stamps||value[13]<stamp_bytes||value[13]>pl.encoded_bytes||
       value[14]!=stamp_bytes||value[17]<1||value[17]>pl.stamps||value[18]<stamp_bytes||value[18]>pl.encoded_bytes||
       value[19]!=static_cast<int64_t>(inventory.scopes.size()))
        refuse("export coverage generated stamp contradicts current obligation");
    return value;
}
std::vector<int64_t> covered_pending(lattice_sqlite3541_connection* db,const std::string& channel,
    const recovery_local_export_inventory& inventory,recovery_obligation_store& journal,size_t cap){
    coverage_indexes(db);
    std::vector<int64_t> explicit_ids,global_ids;
    const auto collect=[&](statement& query,std::vector<int64_t>& ids){
        while(query.next()){
            // Count raw candidates BEFORE joins/state exclusions. LIMIT on a
            // missing-entry anti-join would not bound the work it skips.
            if(ids.size()==cap)refuse("protected export coverage budget exceeded");
            const auto id=integer(query,0);if(id<=0)refuse("export coverage invalid audit identity");ids.push_back(id);
        }
    };
    if(inventory.continuous) {
        // A complete continuous lineage has generated stamps for its selected
        // contributions since first write. Bound the raw journal candidates
        // before route-state exclusions; unrelated local-only rows coexist.
        statement query(db,"SELECT audit_id FROM main._lattice_obligation_entry WHERE stage=0 ORDER BY audit_id LIMIT ?");
        query.integer(1,static_cast<int64_t>(cap+1));collect(query,global_ids);
        std::sort(global_ids.begin(),global_ids.end());global_ids.erase(std::unique(global_ids.begin(),global_ids.end()),global_ids.end());
    } else {
    {statement query(db,"SELECT CASE WHEN typeof(audit_entry_id)='integer' THEN audit_entry_id END "
        "FROM main._lattice_sync_state INDEXED BY idx_sync_state_pending WHERE sync_id=? AND is_synchronized=0 LIMIT ?");
     query.text(1,channel);query.integer(2,static_cast<int64_t>(cap+1));collect(query,explicit_ids);}
    {statement query(db,"SELECT id FROM main.AuditLog INDEXED BY idx_audit_log_pending_sync WHERE isSynchronized=0 LIMIT ?");
     query.integer(1,static_cast<int64_t>(cap+1));collect(query,global_ids);}
    }
    std::set<int64_t> pending(explicit_ids.begin(),explicit_ids.end());
    for(const auto id:global_ids){
        statement state(db,"SELECT is_synchronized FROM main._lattice_sync_state WHERE audit_entry_id=? AND sync_id=? LIMIT 2");
        state.integer(1,id);state.text(2,channel);
        if(!state.next()){pending.insert(id);continue;}
        const auto value=integer(state,0);if((value!=0&&value!=1)||state.next())refuse("export coverage invalid channel state");
        // Explicit zero is already in stream A; one resolves this route.
        if(value==0){if(inventory.continuous)pending.insert(id);else if(!pending.count(id))refuse("export coverage explicit pending inventory changed");}
    }
    std::map<std::string,std::vector<size_t>> tables;
    for(size_t i=0;i<inventory.scopes.size();++i)for(const auto& table:inventory.scopes[i].tables) {
        auto& matches=tables[table.name];if(!matches.empty()&&!inventory.continuous)refuse("export coverage ambiguous admitted table");matches.push_back(i);
    }
    for(const auto id:pending){
        statement audit(db,"SELECT id,globalId,tableName,globalRowId,rowId,isFromRemote,synthesized,isSynchronized "
            "FROM main.AuditLog WHERE id=? LIMIT 2");audit.integer(1,id);
        if(!audit.next())refuse("export coverage pending audit disappeared");
        const auto actual_id=integer(audit,0);const auto original=small_text(audit,1,36);
        const auto table=small_text(audit,2,64);const auto target=small_text(audit,3,36);
        const auto row_id=integer(audit,4),remote=integer(audit,5),synthetic=integer(audit,6),synchronized=integer(audit,7);
        if(actual_id!=id||original.size()!=36||target.size()!=36||row_id<0||remote!=0||synthetic!=0||
           (synchronized!=0&&synchronized!=1)||audit.next())refuse("export coverage unsupported pending original");
        const auto found=tables.find(table);if(found==tables.end())refuse("export coverage pending original has no admitted contribution");
        for(const auto index:found->second){const auto& scope=inventory.scopes[index];const auto entry=journal.find(scope.contribution.address,original);
        if(!entry||entry->record.audit_id!=id||entry->record.original_id!=original||entry->record.table!=table||
           entry->record.target_id!=target||entry->record.origin!=recovery_obligation_origin::local_candidate||
           entry->stage!=recovery_obligation_stage::open)
            refuse("export coverage pending original lacks current open obligation");
        coverage_stamp(db,inventory,scope,*entry);}
    }
    return {pending.begin(),pending.end()};
}
// Actual continuous routes have exclusive generated coverage from enrollment.
// Unlike qualification's full pending-body audit, they may select a finite
// page and validate just that page's originals/stamps under the owned frame.
// The scan/sort input is still bounded by the entire admitted journal cap,
// including duplicate contributions, settled rows and ACKed open obligations.
std::vector<int64_t> continuous_pending_page(lattice_sqlite3541_connection* db,const std::string& channel,
    const recovery_local_export_inventory& inventory,recovery_obligation_store& journal,
    size_t count,const std::vector<int64_t>& in_flight){
    const auto cap=inventory.limits.obligations.records;
    if(!inventory.continuous||cap<=0||cap>100000)refuse("continuous export requires bounded admitted journal");
    const auto usage=journal.usage();
    // Before ORDER BY can sort, prove its full input cardinality against the
    // protected stored counter. This copies one scalar, never journal bodies.
    {statement total(db,"SELECT COUNT(*) FROM (SELECT 1 FROM main._lattice_obligation_entry LIMIT ?)");
     total.integer(1,cap+1);
     if(!total.next())refuse("continuous export journal count unavailable");
     const auto records=integer(total,0);
     if(records<0||records>cap||records!=usage.records||total.next())refuse("continuous export journal count contradicts admitted cap");}
    coverage_indexes(db);
    const std::set<int64_t> sending(in_flight.begin(),in_flight.end());
    statement query(db,"SELECT audit_id FROM main._lattice_obligation_entry WHERE stage=0 ORDER BY audit_id LIMIT ?");
    query.integer(1,cap+1);
    std::vector<int64_t> selected;int64_t previous=0,scanned=0;
    while(query.next()){
        if(++scanned>cap)refuse("continuous export raw scan exceeded admitted journal");
        const auto id=integer(query,0);if(id<=0||id<previous)refuse("continuous export invalid ordered original");
        if(id==previous)continue;previous=id;
        if(sending.count(id))continue;
        statement state(db,"SELECT is_synchronized FROM main._lattice_sync_state WHERE audit_entry_id=? AND sync_id=? LIMIT 2");
        state.integer(1,id);state.text(2,channel);
        if(state.next()){
            const auto value=integer(state,0);
            if((value!=0&&value!=1)||state.next())refuse("continuous export invalid channel state");
            if(value==1)continue; // Route ACK excludes delivery, never settles Q.
        }
        selected.push_back(id);if(selected.size()==count)break;
    }
    return selected;
}
// Unlike pending coverage, this selector does not exclude any addressed row.
// The integer PK range + LIMIT bounds materialization to the requested page;
// larger retained history is paged, not silently treated as unsupported/empty.
std::vector<int64_t> history_page(lattice_sqlite3541_connection* db,int64_t after,size_t count){
    statement query(db,"SELECT id FROM main.AuditLog WHERE id>? ORDER BY id LIMIT ?");
    query.integer(1,after);query.integer(2,static_cast<int64_t>(count));
    std::vector<int64_t> ids;int64_t previous=after;
    while(query.next()){
        const auto id=integer(query,0);
        if(ids.size()==count||id<=previous)refuse("export history invalid ordered identity");
        ids.push_back(id);previous=id;
    }
    return ids;
}
void history_original(lattice_sqlite3541_connection* db,const recovery_local_export_inventory& inventory,
    const recovery_local_export_scope& scope,recovery_obligation_store& journal,const audit_log_entry& row){
    // find() checks normalized UUID identity and the actual persisted original;
    // comparisons preserve its exact AuditLog spelling/body rather than rewrite.
    const auto entry=journal.find(scope.contribution.address,row.global_id);
    if(!entry||entry->record.audit_id!=row.id||entry->record.original_id!=row.global_id||
       entry->record.table!=row.table_name||entry->record.target_id!=row.global_row_id||
       entry->record.origin!=recovery_obligation_origin::local_candidate||entry->stage!=recovery_obligation_stage::open)
        refuse("export history original lacks current open obligation");
    coverage_stamp(db,inventory,scope,*entry);
}
// Metadata only: the complete scan is bounded by the already admitted journal,
// and retained keys by the finite selected page. Unrelated AuditLog payloads
// are never decoded or copied. This index is built at most once, lazily after
// an actual NoHistory row read proves absence on a negotiated continuous route.
class continuous_delete_index {
    using target=std::pair<std::string,std::string>;
    bool loaded_=false;
    std::map<target,int64_t> latest_;
public:
    int64_t later(lattice_sqlite3541_connection* db,const recovery_local_export_inventory& inventory,
        recovery_obligation_store& journal,const std::vector<int64_t>& selected,const audit_log_entry& update){
        if(!loaded_){
            const auto cap=inventory.limits.obligations.records;
            if(!inventory.continuous||cap<=0||cap>100000||selected.size()>1000)
                refuse("continuous delete proof lacks bounded admitted journal");
            const auto usage=journal.usage();
            statement total(db,"SELECT COUNT(*) FROM (SELECT 1 FROM main._lattice_obligation_entry LIMIT ?)");total.integer(1,cap+1);
            if(!total.next())refuse("continuous delete proof count unavailable");
            const auto records=integer(total,0);
            if(records<0||records>cap||records!=usage.records||total.next())refuse("continuous delete proof journal count differs");
            for(const auto id:selected){
                statement row(db,"SELECT tableName,globalRowId FROM main.AuditLog WHERE id=? LIMIT 2");row.integer(1,id);
                if(!row.next())refuse("continuous delete proof selected original disappeared");
                target key{small_text(row,0,64),small_text(row,1,36)};
                if(key.first.empty()||key.second.size()!=36||row.next())refuse("continuous delete proof selected target differs");
                latest_.emplace(std::move(key),0);
            }
            statement candidates(db,"SELECT e.audit_id,a.tableName,a.globalRowId,a.operation FROM "
                "(SELECT audit_id FROM main._lattice_obligation_entry WHERE stage=0 LIMIT ?) e "
                "LEFT JOIN main.AuditLog a ON a.id=e.audit_id");candidates.integer(1,cap+1);
            int64_t scanned=0;
            while(candidates.next()){
                if(++scanned>records)refuse("continuous delete proof raw inventory exceeded");
                const auto id=integer(candidates,0);
                target key{small_text(candidates,1,64),small_text(candidates,2,36)};
                const auto operation=small_text(candidates,3,6);
                if(id<=0||key.first.empty()||key.second.size()!=36)refuse("continuous delete proof invalid metadata");
                const auto found=latest_.find(key);
                if(operation=="DELETE"&&found!=latest_.end())found->second=std::max(found->second,id);
            }
            loaded_=true;
        }
        const auto found=latest_.find({update.table_name,update.global_row_id});
        return found!=latest_.end()&&found->second>update.id?found->second:0;
    }
};
struct continuous_delete_witness {
    raw_audit original;
    struct contribution {size_t index;recovery_obligation_entry entry;std::array<int64_t,15> stamp;};
    std::vector<contribution> contributions;
};
} // namespace

std::map<std::string,std::string> recovery_export_adapter::frozen_original_identities(std::shared_ptr<lattice_db> owner,
    const verified_unsent_set& proof,const recovery_receipt_binding& binding,const std::string& schema) {
    binding.validate();recovery_continuous_producer::verify_for_owned_write(proof);
    if(!owner)refuse("frozen original identity requires actual owner");auto* writer=recovery_writer_access::active_writer(*owner);
    if(!writer)refuse("frozen original identity requires actual owned WRITE");
    const auto inventory=recovery_local_producer_adapter::export_inventory_for_owned_write(owner);
    if(!inventory.continuous||inventory.scopes.size()!=proof.frozen_journals().size())refuse("frozen original identity producer inventory differs");
    auto* db=recovery_writer_access::active_handle(*owner,*writer);
    std::map<std::string,recovery_obligation_record> originals;
    for(const auto& scope:proof.frozen_journals())for(const auto& entry:scope.entries){
        if(!originals.count(entry.canonical_original_id)&&originals.size()>=8192)refuse("frozen original identity union bound");
        const auto [at,added]=originals.emplace(entry.canonical_original_id,entry.record);
        if(!added&&at->second!=entry.record)refuse("frozen shared original identity differs");
    }
    std::map<std::string,std::string> result;
    for(const auto& [id,record]:originals) {
        recovery_export_limits limits;budget raw{limits};auto row=read_audit(db,record.audit_id,raw);
        if(row.entry.global_id!=record.original_id||row.entry.table_name!=record.table||row.entry.global_row_id!=record.target_id)refuse("frozen original audit differs from verified journal");
        const recovery_local_export_table* table=nullptr;
        for(const auto& scope:inventory.scopes)for(const auto& t:scope.tables)if(t.name==record.table){
            if(table&&(table->columns!=t.columns||table->no_history!=t.no_history||table->regular_link!=t.regular_link))refuse("frozen original schema contribution differs");table=&t;}
        if(!table)refuse("frozen original schema unavailable");
        std::unordered_map<std::string,column_type> columns(table->columns.begin(),table->columns.end());
        if(table->regular_link){columns.emplace("lhs",column_type::text);columns.emplace("rhs",column_type::text);}
        decode_generated(db,row,*table,raw,false,{},[&](audit_log_entry& entry){
            result.emplace(id,make_original_identity(entry,columns,table->no_history,schema,binding.producer).digest);
        },false);
    }
    recovery_continuous_producer::verify_for_owned_write(proof);return result;
}

committed_export_frame::committed_export_frame(committed_export_frame&& other) noexcept {
    *this=std::move(other);
}
committed_export_frame& committed_export_frame::operator=(committed_export_frame&& other) noexcept {
    if(this==&other)return *this;
    continuous_work_=std::move(other.continuous_work_);
    upload_view_=std::move(other.upload_view_);
    reconciliation_=std::move(other.reconciliation_);
    owner_=std::move(other.owner_);claims_=std::move(other.claims_);scopes_=std::move(other.scopes_);
    restricted_first_claims_=std::move(other.restricted_first_claims_);
    limits_=other.limits_;entries_=std::move(other.entries_);message_=std::move(other.message_);
    physical_generation_=std::exchange(other.physical_generation_,0);
    consumed_=std::exchange(other.consumed_,true);
    return *this;
}

void recovery_export_adapter::require_committed(const recovery_install_result& result){
    if(result.state==recovery_install_state::committed)return;
    if(result.primary_error)std::rethrow_exception(result.primary_error);
    refuse("export owned operation did not commit");
}
bool recovery_export_adapter::protected_store(std::shared_ptr<lattice_db> owner){
    return recovery_local_producer_adapter::export_protection_required(std::move(owner));
}
std::optional<bool> recovery_export_adapter::try_protected_store(std::shared_ptr<lattice_db> owner){
    try{return recovery_local_producer_adapter::export_protection_required(std::move(owner));}
    catch(const export_discovery_busy&){return std::nullopt;}
}
std::optional<bool> recovery_export_adapter::try_automatic_protected_store(std::shared_ptr<lattice_db> owner){
    return recovery_local_producer_adapter::try_automatic_export_protection(std::move(owner));
}
std::optional<recovery_export_preparation> recovery_export_adapter::prepare_for_route(std::shared_ptr<lattice_db> owner,
    const std::shared_ptr<recovery_continuous_route>& route,const std::string& channel,uint64_t generation,size_t count,
    const std::vector<int64_t>& in_flight,bool filtered,bool* discovery_busy,std::shared_ptr<const receiver_upload_view> upload_view){
    if(upload_view){if(!upload_view->current())refuse("negotiated export source revoked before selection");count=std::min(count,upload_view->entries_);}
    auto work=recovery_continuous_producer::admit_work(route,owner,generation);
    bool busy=false;auto prepared=prepare(std::move(owner),channel,generation,count,in_flight,filtered,{},std::nullopt,discovery_busy?&busy:nullptr,false,std::move(work),std::move(upload_view),{},discovery_busy!=nullptr);
    if(busy){*discovery_busy=true;return std::nullopt;}return prepared;
}
recovery_export_preparation recovery_export_adapter::prepare_reconciliation(std::shared_ptr<lattice_db> owner,
    std::shared_ptr<recovery_continuous_work> work,std::shared_ptr<recovery_reconciliation_export> grant,
    uint64_t generation,std::shared_ptr<const receiver_upload_view> upload,bool* busy,
    const std::shared_ptr<recovery_reconciliation_operation>& operation) {
    if(!owner||!work||!grant||grant->descriptor_->owner()!=owner||grant->descriptor_->phase()!=4||
       !upload||!upload->current()||grant->requested_.empty()||grant->requested_.size()>1000||
       grant->requested_.size()!=grant->originals_.size()||!grant->selected_.empty()||!operation||operation->descriptor_!=grant->descriptor_)
        refuse("restricted export lacks exact current window");
    const auto count=std::min(grant->requested_.size(),upload->entries_);
    const auto channel=grant->address_.channel;
    return prepare(std::move(owner),channel,generation,count,{},false,{},std::nullopt,busy,false,
        std::move(work),std::move(upload),std::move(grant),busy!=nullptr,operation);
}
std::optional<recovery_export_preparation> recovery_export_adapter::try_prepare_pending(std::shared_ptr<lattice_db> owner,
    const std::string& sync_id,uint64_t generation,size_t count,const std::vector<int64_t>& in_flight,
    bool filtered,const recovery_export_limits& limits){
    bool busy=false;
    auto prepared=prepare(std::move(owner),sync_id,generation,count,in_flight,filtered,limits,std::nullopt,&busy);
    if(busy)return std::nullopt;
    return prepared;
}
recovery_export_preparation recovery_export_adapter::prepare_pending(std::shared_ptr<lattice_db> owner,const std::string& sync_id,
    uint64_t generation,size_t count,const std::vector<int64_t>& in_flight,bool filtered,const recovery_export_limits& limits){
    return prepare(std::move(owner),sync_id,generation,count,in_flight,filtered,limits,std::nullopt);
}
recovery_export_preparation recovery_export_adapter::prepare_history_page(std::shared_ptr<lattice_db> owner,
    uint64_t generation,int64_t after,size_t count,const recovery_export_limits& limits){
    if(after<0)refuse("export history cursor must be a resolved nonnegative PK");
    return prepare(std::move(owner),{},generation,count,{},false,limits,after);
}
recovery_export_preparation recovery_export_adapter::prepare_retained_page(std::shared_ptr<lattice_db> owner,
    uint64_t generation,int64_t after,size_t count,const recovery_export_limits& limits){
    if(after<0)refuse("export retained cursor must be a resolved nonnegative PK");
    return prepare(std::move(owner),{},generation,count,{},false,limits,after,nullptr,true);
}
recovery_export_preparation recovery_export_adapter::prepare(std::shared_ptr<lattice_db> owner,const std::string& sync_id,
    uint64_t generation,size_t count,const std::vector<int64_t>& in_flight,bool filtered,const recovery_export_limits& limits,
    std::optional<int64_t> history_after,bool* discovery_busy,bool retained_delete_page,std::shared_ptr<recovery_continuous_work> work,
    std::shared_ptr<const receiver_upload_view> upload_view,std::shared_ptr<recovery_reconciliation_export> reconciliation,bool automatic,
    const std::shared_ptr<recovery_reconciliation_operation>& operation){
    recovery_export_preparation output;
    // Catch only this first no-effect classifier. A busy exception arising
    // later from reentrant work must never replay a claim or mutation stage.
    try {
        if(automatic) {
            const auto protection=try_automatic_protected_store(owner);
            if(!protection){if(!discovery_busy)refuse("automatic export requires retained busy output");*discovery_busy=true;return output;}
            if(!*protection)return output;
        }else if(!recovery_local_producer_adapter::export_protection_required(owner))return output;
    }
    catch(const export_discovery_busy&){
        if(!discovery_busy)throw;
        *discovery_busy=true;return output;
    }
    committed_export_frame frame;frame.owner_=owner;frame.physical_generation_=generation;frame.continuous_work_=std::move(work);frame.upload_view_=std::move(upload_view);frame.reconciliation_=std::move(reconciliation);
    const auto owned_body=[&](database& writer){
        if(frame.upload_view_&&!frame.upload_view_->current())refuse("negotiated export source revoked before owned selection");
        auto inventory=recovery_local_producer_adapter::export_inventory_for_owned_write(owner);if(inventory.scopes.empty())return;
        limits_ok(limits,count,in_flight);if(!history_after&&(sync_id.empty()||sync_id.size()>4096))refuse("export invalid route channel");
        output.protected_store=true;if(filtered)refuse("protected export refuses legacy filter synthesis");
        for(const auto& scope:inventory.scopes)if(scope.contribution.mode!=recovery_obligation_mode::recording)refuse("protected export contribution is frozen or installed");
        frame.scopes_=inventory.scopes;frame.limits_=inventory.limits;
        auto* db=recovery_writer_access::active_handle(*owner,writer);
        recovery_obligation_store journal(owner,inventory.limits.obligations,inventory.limits.installations);
        if(frame.reconciliation_)operation->verify(writer);
        const bool continuous_page=inventory.continuous&&static_cast<bool>(frame.continuous_work_);
        if(frame.upload_view_&&(!continuous_page||history_after||retained_delete_page))refuse("negotiated export requires actual continuous pending route");
        const auto restricted_ids=[&](size_t maximum){
            const auto& grant=frame.reconciliation_;
            if(!grant||!continuous_page||!frame.upload_view_||history_after||retained_delete_page||
               maximum>grant->requested_.size()||maximum>count)refuse("restricted export window mode differs");
            const auto scope=std::find_if(inventory.scopes.begin(),inventory.scopes.end(),[&](const auto& item){return item.contribution.address==grant->address_;});
            if(scope==inventory.scopes.end())refuse("restricted export contribution changed");
            std::vector<int64_t> selected;selected.reserve(maximum);
            for(size_t n=0;n<maximum;++n){
                auto expected=grant->requested_[n];const auto actual=journal.find(grant->address_,grant->originals_[n]);
                if(!actual)refuse("restricted export retained original disappeared");
                if(!expected.first_export_claim)expected.first_export_claim=actual->first_export_claim;
                if(*actual!=expected||actual->stage!=recovery_obligation_stage::open||actual->acknowledged||
                   actual->canonical_original_id!=grant->originals_[n])refuse("restricted export retained original or receipt changed");
                if(!selected.empty()&&selected.back()>=actual->record.audit_id)refuse("restricted export original order changed");
                coverage_stamp(db,inventory,*scope,*actual);selected.push_back(actual->record.audit_id);
            }
            return selected;
        };
        std::vector<int64_t> pending,ids;
        if(frame.reconciliation_)ids=restricted_ids(count);
        else if(history_after)ids=history_page(db,*history_after,count);
        else if(continuous_page)ids=continuous_pending_page(db,sync_id,inventory,journal,count,in_flight);
        else {
            pending=covered_pending(db,sync_id,inventory,journal,limits.coverage_candidates);
            const std::set<int64_t> sending(in_flight.begin(),in_flight.end());
            for(const auto id:pending)if(!sending.count(id)){ids.push_back(id);if(ids.size()==count)break;}
        }
        budget raw{limits};std::vector<raw_audit> originals;std::vector<std::vector<std::string>> by_scope(inventory.scopes.size());
        // Validate the entire finite page's provenance before any later row
        // can justify an earlier UPDATE projection. No caller-provided flag,
        // operation text alone or unselected DELETE is generated evidence.
        std::vector<const recovery_local_export_table*> tables;
        std::vector<std::vector<size_t>> scope_indexes;
        continuous_delete_index delete_index;
        std::map<int64_t,continuous_delete_witness> delete_witnesses;
        std::vector<int64_t> selected_delete_witnesses;
        std::string encoded="{\"auditLog\":[";
        if(frame.upload_view_) {
            std::vector<int64_t> selected;
            recovery_upload_json::prefix prefix({frame.upload_view_->entries_,frame.upload_view_->wire_,
                frame.upload_view_->scalar_,frame.upload_view_->nodes_,frame.upload_view_->depth_,frame.upload_view_->deletes_});
            // Process only the fitting ordered prefix. A later local byte cap
            // cannot consume the earlier prefix's opportunity to progress.
            // Parse each new member in its actual envelope/depth once, then
            // recheck the complete immutable envelope before creating claims.
            for(const auto id:ids) {
                std::string reason;
                try {
                    auto row=read_audit(db,id,raw);const recovery_local_export_table* table=nullptr;std::vector<size_t> matches;
                    for(size_t i=0;i<inventory.scopes.size();++i)for(const auto& t:inventory.scopes[i].tables)if(t.name==row.entry.table_name){
                        if(table&&(table->columns!=t.columns||table->no_history!=t.no_history||table->regular_link!=t.regular_link))refuse("export ambiguous contribution table");
                        table=&t;matches.push_back(i);
                    }
                    if(!table)refuse("export original has no admitted whole-model contribution");
                    for(const auto i:matches)history_original(db,inventory,inventory.scopes[i],journal,row.entry);
                    int64_t witness_id=0;
                    const auto prove_absence=[&]{
                        if(witness_id)return true;
                        const auto later=delete_index.later(db,inventory,journal,ids,row.entry);
                        if(!later)return false;
                        if(!delete_witnesses.count(later)){
                            continuous_delete_witness witness;witness.original=read_audit(db,later,raw);
                            const auto& original=witness.original.entry;
                            if(original.id<=row.entry.id||original.operation!="DELETE"||
                               original.table_name!=row.entry.table_name||original.global_row_id!=row.entry.global_row_id)
                                refuse("continuous delete proof original differs from selected target");
                            for(const auto i:matches){
                                const auto& scope=inventory.scopes[i];history_original(db,inventory,scope,journal,original);
                                const auto entry=journal.find(scope.contribution.address,original.global_id);
                                if(!entry)refuse("continuous delete proof contribution disappeared");
                                const auto stamp=coverage_stamp(db,inventory,scope,*entry);
                                continuous_delete_witness::contribution part{i,*entry,{}};
                                std::copy_n(stamp.begin(),part.stamp.size(),part.stamp.begin());witness.contributions.push_back(std::move(part));
                            }
                            // Validate the full generated original, not merely
                            // its operation label. It is evidence only: no
                            // claim, frame member or delivery state is added.
                            decode_generated(db,witness.original,*table,raw);
                            delete_witnesses.emplace(later,std::move(witness));
                        }
                        witness_id=later;return true;
                    };
                    const auto identity=[&](audit_log_entry& entry){
                        if(!frame.upload_view_->receipt_binding_)return;
                        std::unordered_map<std::string,column_type> columns(table->columns.begin(),table->columns.end());
                        if(table->regular_link){columns.emplace("lhs",column_type::text);columns.emplace("rhs",column_type::text);}
                        entry.original_identity=make_original_identity(entry,columns,table->no_history,frame.upload_view_->schema_digest_,frame.upload_view_->receipt_binding_->producer);
                        raw.charge(original_identity_bytes(*entry.original_identity));
                    };
                    decode_generated(db,row,*table,raw,false,prove_absence,identity);wire_bound(row.entry,limits.wire_bytes);
                    const auto json=row.entry.to_json();
                    if(prefix.append(json,row.entry.operation=="DELETE",reason)) {
                        selected.push_back(id);
                        for(const auto i:matches)by_scope[i].push_back(row.entry.global_id);
                        frame.entries_.push_back(row.entry);tables.push_back(table);scope_indexes.push_back(std::move(matches));originals.push_back(std::move(row));
                        selected_delete_witnesses.push_back(witness_id);
                        continue;
                    }
                }catch(const export_capacity_error& error){reason=error.what();}
                if(frame.entries_.empty())output.blocked_original="negotiated upload original PK "+std::to_string(id)+" cannot fit: "+reason;
                break;
            }
            encoded=std::move(prefix).release_open();
            ids=std::move(selected);
        } else {
        for(const auto id:ids){auto row=read_audit(db,id,raw);const recovery_local_export_table* table=nullptr;std::vector<size_t> matches;
            for(size_t i=0;i<inventory.scopes.size();++i)for(const auto& t:inventory.scopes[i].tables)if(t.name==row.entry.table_name){
                if(table&&(!inventory.continuous||table->columns!=t.columns||table->no_history!=t.no_history||table->regular_link!=t.regular_link))refuse("export ambiguous contribution table");
                table=&t;matches.push_back(i);
            }
            if(!table)refuse("export original has no admitted whole-model contribution");
            if(history_after||continuous_page)for(const auto i:matches)history_original(db,inventory,inventory.scopes[i],journal,row.entry);
            tables.push_back(table);scope_indexes.push_back(std::move(matches));originals.push_back(std::move(row));
        }
        }
        const auto later_delete=[&](size_t index){
            if(!retained_delete_page)return false;
            const auto& current=originals[index].entry;
            if(current.operation!="UPDATE")return false;
            for(size_t next=index+1;next<originals.size();++next){const auto& candidate=originals[next].entry;
                if(candidate.operation=="DELETE"&&candidate.id>current.id&&candidate.table_name==current.table_name&&
                   candidate.global_row_id==current.global_row_id)return true;
            }
            return false;
        };
        if(!frame.upload_view_){
        for(size_t i=0;i<originals.size();++i){auto& row=originals[i];
            decode_generated(db,row,*tables[i],raw,later_delete(i));wire_bound(row.entry,limits.wire_bytes-encoded.size()-2);
            const auto json=row.entry.to_json();if(json.size()+3>limits.wire_bytes-encoded.size())refuse("export encoded frame exceeds budget");
            if(!frame.entries_.empty())encoded+=',';encoded+=json;for(const auto index:scope_indexes[i])by_scope[index].push_back(row.entry.global_id);frame.entries_.push_back(row.entry);
        }
        }
        if(frame.upload_view_&&!frame.upload_view_->current())refuse("negotiated export source revoked before claims");
        encoded+="]}";if(frame.entries_.empty())return;
        if(frame.upload_view_){
            const auto deletes=std::count_if(frame.entries_.begin(),frame.entries_.end(),
                [](const auto& entry){return entry.operation=="DELETE";});
            std::string reason;
            if(!frame.upload_view_->fits(encoded,frame.entries_.size(),deletes,reason))
                refuse("negotiated export final envelope exceeds bounds");
        }
        std::vector<std::pair<recovery_obligation_address,recovery_obligation_entry>> expected_entries;
        std::vector<recovery_obligation_scope> expected_scopes;
        for(size_t i=0;i<by_scope.size();++i)if(!by_scope[i].empty()){
            const auto& address=inventory.scopes[i].contribution.address;
            std::vector<recovery_obligation_entry> before_claim;
            if(frame.reconciliation_)for(const auto& id:by_scope[i]){
                const auto entry=journal.find(address,id);if(!entry)refuse("restricted pre-claim original missing");
                before_claim.push_back(*entry);
            }
            frame.claims_.push_back(journal.claim_export(address,by_scope[i]));
            if(frame.reconciliation_){
                const auto& ticket=frame.claims_.back();
                if(ticket.canonical_original_ids.size()!=before_claim.size())refuse("restricted claim member count changed");
                std::vector<int64_t> first_claims;first_claims.reserve(before_claim.size());
                for(size_t n=0;n<before_claim.size();++n){auto expected=std::move(before_claim[n]);
                    if(expected.canonical_original_id!=ticket.canonical_original_ids[n])refuse("restricted claim member order changed");
                    if(!expected.first_export_claim)expected.first_export_claim=ticket.sequence;
                    if(journal.find(address,expected.canonical_original_id)!=std::optional<recovery_obligation_entry>{expected})
                        refuse("restricted claim changed validated preimage");
                    first_claims.push_back(*expected.first_export_claim);expected_entries.emplace_back(address,std::move(expected));
                }
                frame.restricted_first_claims_.push_back(std::move(first_claims));
                operation->claimed(ticket);
            }else for(const auto& id:by_scope[i]){const auto entry=journal.find(address,id);if(!entry)refuse("export claimed original missing");expected_entries.emplace_back(address,*entry);}
            const auto scope=journal.read(address.channel);if(!scope)refuse("export claimed scope missing");expected_scopes.push_back(*scope);
            if(recovery_export_test_hooks::after_contribution_claim)recovery_export_test_hooks::after_contribution_claim(i);
        }
        if(recovery_export_test_hooks::before_claim_commit)recovery_export_test_hooks::before_claim_commit();
        const auto final_inventory=recovery_local_producer_adapter::export_inventory_for_owned_write(owner);
        check_scopes(final_inventory,frame.scopes_);check_claims(journal,frame.claims_,frame.entries_);
        for(const auto& [address,expected]:expected_entries)if(journal.find(address,expected.record.original_id)!=std::optional<recovery_obligation_entry>(expected))refuse("export cross-contribution final entry changed");
        for(const auto& expected:expected_scopes)if(journal.read(expected.address.channel)!=std::optional<recovery_obligation_scope>(expected))refuse("export cross-contribution final scope changed");
        budget verify{limits};
        // Revalidate only witnesses used by the fitting prefix. A selected D
        // may have gained its own claim in this transaction; every other D
        // entry and each immutable producer stamp must remain byte-equivalent.
        std::set<int64_t> checked_delete_witnesses;
        for(const auto id:selected_delete_witnesses)if(id&&checked_delete_witnesses.insert(id).second){
            const auto& witness=delete_witnesses.at(id);auto actual=read_audit(db,id,verify);
            if(!same_original(witness.original,actual))refuse("continuous delete proof original changed after claims");
            for(const auto& part:witness.contributions){
                const auto& scope=final_inventory.scopes.at(part.index);
                history_original(db,final_inventory,scope,journal,actual.entry);
                auto expected=part.entry;
                for(const auto& claim:frame.claims_)if(claim.address==scope.contribution.address&&
                    std::find(claim.canonical_original_ids.begin(),claim.canonical_original_ids.end(),expected.canonical_original_id)!=claim.canonical_original_ids.end()){
                    if(!expected.first_export_claim)expected.first_export_claim=claim.sequence;
                }
                const auto entry=journal.find(scope.contribution.address,actual.entry.global_id);
                if(!entry||*entry!=expected)refuse("continuous delete proof contribution changed after claims");
                const auto stamp=coverage_stamp(db,final_inventory,scope,*entry);
                if(!std::equal(part.stamp.begin(),part.stamp.end(),stamp.begin()))refuse("continuous delete proof stamp changed after claims");
            }
        }
        for(size_t i=0;i<originals.size();++i){const auto& before=originals[i];auto after=read_audit(db,before.entry.id,verify);
            if(!same_original(before,after))refuse("export original changed after claims");
            if(retained_delete_page||frame.upload_view_){
                // Recheck both actual row absence/value and exact projection
                // after reentrant claim hooks; read errors never prove absence.
                const bool continuous_absence=frame.upload_view_&&selected_delete_witnesses.at(i)!=0;
                const auto identity=[&](audit_log_entry& entry){
                    if(!frame.upload_view_||!frame.upload_view_->receipt_binding_)return;
                    const auto& table=*tables[i];std::unordered_map<std::string,column_type> columns(table.columns.begin(),table.columns.end());
                    if(table.regular_link){columns.emplace("lhs",column_type::text);columns.emplace("rhs",column_type::text);}
                    entry.original_identity=make_original_identity(entry,columns,table.no_history,frame.upload_view_->schema_digest_,frame.upload_view_->receipt_binding_->producer);
                    verify.charge(original_identity_bytes(*entry.original_identity));
                };
                decode_generated(db,after,*tables[i],verify,later_delete(i)||continuous_absence,{},identity);
                const auto& projected=frame.entries_[i];
                if(after.entry.original_identity!=projected.original_identity)refuse("export immutable original identity changed after claims");
                if(after.entry.changed_fields_names!=projected.changed_fields_names||after.entry.changed_fields.size()!=projected.changed_fields.size())
                    refuse("export retained projection changed after claims");
                for(const auto& [name,value]:after.entry.changed_fields){const auto found=projected.changed_fields.find(name);
                    if(found==projected.changed_fields.end()||found->second.kind!=value.kind||found->second.value!=value.value)
                        refuse("export retained projection changed after claims");
                }
            }
        }
        if(frame.reconciliation_){
            if(restricted_ids(ids.size())!=ids)refuse("restricted export exact selected prefix changed during claims");
            for(const auto& scope:final_inventory.scopes)for(const auto& table:scope.tables)
                for(const auto& entry:frame.entries_)if(entry.table_name==table.name)
                    history_original(db,final_inventory,scope,journal,entry);
            frame.reconciliation_->selected_.assign(frame.reconciliation_->originals_.begin(),
                frame.reconciliation_->originals_.begin()+ids.size());
        }else if(history_after){
            if(history_page(db,*history_after,count)!=ids)refuse("export history page changed during claims");
            for(const auto& scope:final_inventory.scopes)for(const auto& table:scope.tables)
                for(const auto& entry:frame.entries_)if(entry.table_name==table.name)
                    history_original(db,final_inventory,scope,journal,entry);
        }else if(continuous_page){
            if(continuous_pending_page(db,sync_id,final_inventory,journal,frame.upload_view_?ids.size():count,in_flight)!=ids)
                refuse("continuous export selected page changed during claims");
            for(const auto& scope:final_inventory.scopes)for(const auto& table:scope.tables)
                for(const auto& entry:frame.entries_)if(entry.table_name==table.name)
                    history_original(db,final_inventory,scope,journal,entry);
        }else if(covered_pending(db,sync_id,final_inventory,journal,limits.coverage_candidates)!=pending)
            refuse("export coverage pending inventory changed during claims");
        frame.message_=transport_message::from_binary({encoded.begin(),encoded.end()});
        if(frame.upload_view_&&!frame.upload_view_->current())refuse("negotiated export source revoked during claims");
        if(frame.reconciliation_)operation->verify(writer,true);
    };
    const auto result=frame.reconciliation_
        ?recovery_continuous_producer::reconciliation_export_owned(owner,frame.continuous_work_,frame.reconciliation_->originals_,owned_body,discovery_busy,automatic,
            [operation]{operation->publish();})
        :recovery_continuous_producer::export_owned(owner,frame.continuous_work_,owned_body,discovery_busy,automatic);
    if(automatic&&automatic_export_deferred(result,discovery_busy))return output;
    if(discovery_busy&&*discovery_busy)return output;
    if(operation)operation->require_settled(result);else require_committed(result);
    if(!frame.entries_.empty()){
        if(recovery_export_test_hooks::after_claim_commit)recovery_export_test_hooks::after_claim_commit();
        if(frame.upload_view_&&!frame.upload_view_->current())refuse("negotiated export source revoked after committed claims");
        output.frame=std::move(frame);
    }
    return output;
}
void recovery_export_adapter::acknowledge_legacy(std::shared_ptr<lattice_db> owner,const std::string& channel,const std::vector<std::string>& ids){
    require_committed(acknowledge_legacy_impl(std::move(owner),channel,ids,false));
}
bool recovery_export_adapter::try_acknowledge_legacy(std::shared_ptr<lattice_db> owner,const std::string& channel,const std::vector<std::string>& ids){
    const auto result=acknowledge_legacy_impl(std::move(owner),channel,ids,true);bool busy=false;
    if(automatic_export_deferred(result,&busy))return false;
    require_committed(result);return true;
}
recovery_install_result recovery_export_adapter::acknowledge_legacy_impl(std::shared_ptr<lattice_db> owner,const std::string& channel,const std::vector<std::string>& ids,bool automatic){
    if(channel.empty()||channel.size()>4096||ids.size()>2000)refuse("export legacy ACK bounds exceeded");
    return recovery_writer_access::install_impl(owner,[&](database& writer){
        const auto inventory=recovery_local_producer_adapter::export_inventory_for_owned_write(owner);
        if(inventory.scopes.empty())refuse("export legacy ACK lost protected inventory");
        recovery_obligation_store journal(owner,inventory.limits.obligations,inventory.limits.installations);
        const bool enabled=inventory.continuous&&recovery_continuous_producer::shared_install_domains(*owner);
        const auto target=std::find_if(inventory.scopes.begin(),inventory.scopes.end(),[&](const auto& scope){return scope.contribution.address.channel==channel;});
        if(enabled&&target==inventory.scopes.end())refuse("enabled legacy ACK channel is not admitted");
        if(!enabled)for(const auto& scope:inventory.scopes)if(scope.contribution.mode!=recovery_obligation_mode::recording)refuse("export legacy ACK belongs to frozen generation");
        std::set<std::string> unique;
        for(const auto& id:ids){
            if(id.size()!=36||!unique.insert(id).second)refuse("export legacy ACK invalid or duplicate original");
            std::optional<recovery_obligation_entry> entry;
            std::vector<std::pair<recovery_obligation_address,recovery_obligation_entry>> unchanged;
            if(enabled){
                // A delayed physical delivery ACK is orthogonal to the current
                // canonical phase. It may observe frozen, installed or resumed
                // journals, including an already settled retained original.
                entry=journal.find(target->contribution.address,id);
                if(!entry||!entry->first_export_claim||entry->record.origin!=recovery_obligation_origin::local_candidate)
                    refuse("enabled legacy ACK has no retained channel claim");
                for(const auto& scope:inventory.scopes){
                    const auto found=journal.find(scope.contribution.address,id);
                    const bool covers=std::any_of(scope.tables.begin(),scope.tables.end(),[&](const auto& table){return table.name==entry->record.table;});
                    if(covers&&!found)refuse("enabled legacy ACK lost shared original");
                    if(found){
                        if(!found->first_export_claim||found->record!=entry->record||found->canonical_original_id!=entry->canonical_original_id||
                           found->canonical_target_id!=entry->canonical_target_id)refuse("enabled legacy ACK shared claim identity differs");
                        unchanged.emplace_back(scope.contribution.address,*found);
                    }
                }
            }else{
                for(const auto& scope:inventory.scopes){const auto found=journal.find(scope.contribution.address,id);if(found){
                    if(entry&&(!inventory.continuous||entry->record!=found->record))refuse("export ambiguous ACK contribution");
                    if(inventory.continuous&&!found->first_export_claim)refuse("continuous ACK has unclaimed shared contribution");entry=found;
                }}
                if(!entry||!entry->first_export_claim||entry->stage!=recovery_obligation_stage::open)refuse("export legacy ACK has no retained claimed original");
            }
            writer.execute("INSERT INTO main._lattice_sync_state(audit_entry_id,sync_id,is_synchronized) VALUES(?,?,1) ON CONFLICT(audit_entry_id,sync_id) DO UPDATE SET is_synchronized=1",{entry->record.audit_id,channel});
            const auto rows=writer.query("SELECT 1 AS ok FROM main._lattice_sync_state WHERE audit_entry_id=? AND sync_id=? AND typeof(is_synchronized)='integer' AND is_synchronized=1 LIMIT 2",{entry->record.audit_id,channel});
            if(rows.size()!=1)refuse("export legacy ACK bookkeeping was ignored");
            for(const auto& [address,before]:unchanged)if(journal.find(address,id)!=std::optional<recovery_obligation_entry>{before})
                refuse("enabled legacy ACK changed canonical entry");
        }
        if(enabled)for(const auto& scope:inventory.scopes)
            if(journal.read(scope.contribution.address.channel)!=std::optional<recovery_obligation_scope>{scope.contribution})
                refuse("enabled legacy ACK changed canonical scope");
    },{},{},nullptr,automatic);
}
void recovery_export_adapter::validate_server_limits(const recovery_export_limits& limits){limits_ok(limits,limits.entries,{});}
void recovery_export_adapter::revalidate_claimed_frame(const committed_export_frame& frame,bool* busy,bool automatic,
    const std::shared_ptr<recovery_reconciliation_operation>& operation){
    const auto owned_body=[&](database& writer){
        if(frame.reconciliation_){if(!operation)refuse("restricted handoff lacks continuity operation");operation->verify(writer);}
        check_scopes(recovery_local_producer_adapter::export_inventory_for_owned_write(frame.owner_),frame.scopes_);
        recovery_obligation_store journal(frame.owner_,frame.limits_.obligations,frame.limits_.installations);check_claims(journal,frame.claims_,frame.entries_);
        if(frame.reconciliation_){const auto& grant=*frame.reconciliation_;
            if(grant.selected_.empty()||grant.selected_.size()!=frame.entries_.size()||grant.selected_.size()>grant.originals_.size()||
               !std::equal(grant.selected_.begin(),grant.selected_.end(),grant.originals_.begin()))
                refuse("restricted handoff selected prefix differs");
            if(frame.restricted_first_claims_.size()!=frame.claims_.size())refuse("restricted handoff claim witness count differs");
            size_t issued=frame.claims_.size();
            for(size_t i=0;i<frame.claims_.size();++i){const auto& claim=frame.claims_[i];const auto& first=frame.restricted_first_claims_[i];
                if(first.size()!=claim.canonical_original_ids.size())refuse("restricted handoff claim witness members differ");
                for(size_t n=0;n<first.size();++n){const auto entry=journal.find(claim.address,claim.canonical_original_ids[n]);
                    if(first[n]<=0||!entry||entry->first_export_claim!=std::optional<int64_t>{first[n]})
                        refuse("restricted handoff validated first claim changed");}
                if(claim.address==grant.address_){
                    if(issued!=frame.claims_.size())refuse("restricted handoff has duplicate contribution claim");issued=i;
                }
            }
            if(issued==frame.claims_.size())refuse("restricted handoff lacks exact contribution claim");
            const auto& issued_ids=frame.claims_[issued].canonical_original_ids;
            for(size_t n=0;n<grant.selected_.size();++n){const auto actual=journal.find(grant.address_,grant.selected_[n]);auto expected=grant.requested_[n];
                if(!actual)refuse("restricted handoff original disappeared");
                const auto member=std::find(issued_ids.begin(),issued_ids.end(),grant.selected_[n]);
                if(member==issued_ids.end())refuse("restricted handoff original lacks issued claim");
                const auto first=frame.restricted_first_claims_[issued][static_cast<size_t>(member-issued_ids.begin())];
                if(expected.first_export_claim&&*expected.first_export_claim!=first)refuse("restricted handoff descriptor first claim differs");
                expected.first_export_claim=first;
                if(*actual!=expected||frame.entries_[n].id!=actual->record.audit_id||frame.entries_[n].global_id!=actual->record.original_id)
                    refuse("restricted handoff retained original changed");}
        }
    };
    const auto result=frame.reconciliation_
        ?recovery_continuous_producer::reconciliation_export_owned(frame.owner_,frame.continuous_work_,frame.reconciliation_->selected_,owned_body,busy,automatic)
        :recovery_continuous_producer::export_owned(frame.owner_,frame.continuous_work_,owned_body,busy,automatic);
    if(automatic&&automatic_export_deferred(result,busy))return;
    if(busy&&*busy)return;
    if(operation)operation->require_settled(result);else recovery_export_adapter::require_committed(result);
}
recovery_export_route::recovery_export_route(std::shared_ptr<sync_transport> transport,std::shared_ptr<sync_callback_lifetime> lifetime):transport_(std::move(transport)),lifetime_(std::move(lifetime)){}
#ifndef __EMSCRIPTEN__
void recovery_export_route::install_configured_retirement(sync_retirement_lane::reservation reservation){
    std::lock_guard<std::mutex> lock(mutex_);
    if(retired_||retirement_||protected_)refuse("configured native reservation already published");
    retirement_.emplace(std::move(reservation));retirement_->publish();configured_reservation_=true;
}
#endif
void recovery_export_route::prepare_protected(uint64_t generation){
#ifdef __EMSCRIPTEN__
    refuse("protected export retirement is not available in the browser graph");
#else
    if(!lifetime_->can_begin_protected(generation))refuse("protected export requires a fresh physical endpoint");
    {std::lock_guard<std::mutex> lock(mutex_);
        if(configured_reservation_){
            if(retired_||protected_||!retirement_)refuse("configured protected route already published or retired");
            lifetime_->begin_connect(generation,true);protected_=true;return;
        }
    }
    // Worker launch and capacity reservation happen before any route/handler
    // publication. The reserved slot owns the transport throughout callbacks.
    auto reservation=sync_retirement_lane::instance()->reserve(transport_,lifetime_);
    std::lock_guard<std::mutex> lock(mutex_);
    if(retired_||retirement_)refuse("protected export route already published or retired");
    lifetime_->begin_connect(generation,true);
    retirement_.emplace(std::move(reservation));retirement_->publish();protected_=true;
#endif
}
bool recovery_export_route::retire_protected(std::thread pacer)noexcept{
#ifndef __EMSCRIPTEN__
    std::optional<sync_retirement_lane::reservation> reservation;
    {std::lock_guard<std::mutex> lock(mutex_);if(!retirement_){if(pacer.joinable())std::terminate();return protected_;}open_=false;retired_=true;reservation.emplace(std::move(*retirement_));retirement_.reset();}
    lifetime_->end_protected_attempt();reservation->retire(std::move(pacer));return true;
#else
    return false;
#endif
}
void recovery_export_route::publish(uint64_t generation,bool open) noexcept{std::lock_guard<std::mutex> lock(mutex_);if(!retired_){generation_=generation;open_=open;}}
void recovery_export_route::retire() noexcept{if(retire_protected())return;std::lock_guard<std::mutex> lock(mutex_);retired_=true;open_=false;}
bool recovery_export_route::current(uint64_t generation) noexcept{std::lock_guard<std::mutex> lock(mutex_);return !retired_&&open_&&generation_==generation&&lifetime_->current(generation);}
size_t committed_export_frame::retained_metadata_bytes(size_t cap)const noexcept {
    size_t bytes=sizeof(*this);
    const auto add=[&](size_t n,size_t width=1){if(bytes>cap||n>(cap-bytes)/width)bytes=cap+1;else bytes+=n*width;};
    const auto text=[&](const std::string& value){add(value.capacity());add(1);};
    if(reconciliation_)add(reconciliation_->retained_bytes(cap));
    add(message_.data.capacity());add(claims_.capacity(),sizeof(recovery_obligation_export_ticket));
    add(restricted_first_claims_.capacity(),sizeof(std::vector<int64_t>));
    for(const auto& first:restricted_first_claims_)add(first.capacity(),sizeof(int64_t));
    for(const auto& claim:claims_){text(claim.address.channel);add(claim.canonical_original_ids.capacity(),sizeof(std::string));for(const auto& id:claim.canonical_original_ids)text(id);}
    add(scopes_.capacity(),sizeof(recovery_local_export_scope));
    for(const auto& scope:scopes_){
        const auto& c=scope.contribution;const auto& b=c.profile.binding;
        for(const auto* value:{&b.channel,&b.authority,&b.source,&b.epoch,&b.scope,&b.schema,&c.profile.profile_digest,&c.profile.receipt_namespace,&c.address.channel,&c.installed_manifest,&scope.program_digest})text(*value);
        add(scope.tables.capacity(),sizeof(recovery_local_export_table));
        for(const auto& table:scope.tables){text(table.name);add(table.columns.capacity(),sizeof(decltype(table.columns)::value_type));
            for(const auto& column:table.columns)text(column.first);
            add(table.no_history.size(),sizeof(std::string)+4*sizeof(void*));for(const auto& name:table.no_history)text(name);}
    }
    return bytes;
}
bool recovery_export_route::handoff(committed_export_frame frame){return handoff_impl(frame,nullptr);}
std::optional<bool> recovery_export_route::try_handoff(committed_export_frame& frame){
    bool busy=false;const bool sent=handoff_impl(frame,&busy);
    if(busy)return std::nullopt;return sent;
}
std::optional<bool> recovery_export_route::try_handoff_automatic(committed_export_frame& frame){
    bool busy=false;const bool sent=handoff_impl(frame,&busy,true);
    if(busy)return std::nullopt;return sent;
}
bool recovery_export_route::handoff_impl(committed_export_frame& frame,bool* busy,bool automatic){
    if(frame.consumed_||!frame.owner_||frame.entries_.empty()||frame.claims_.empty())refuse("export permit already consumed or missing custody");
    if(!current(frame.physical_generation_)||frame.owner_->is_closed()){frame.consumed_=true;return false;}
    // A superseded descriptor must be disposable even when the owned writer
    // remains BUSY. The later owned check still validates all current claims.
    if(frame.reconciliation_&&!recovery_continuous_producer::reconciliation_work_current(frame.continuous_work_,frame.owner_)){
        frame.consumed_=true;return false;
    }
    std::shared_ptr<recovery_reconciliation_operation> operation;
    if(frame.reconciliation_){
        const auto worker=frame.reconciliation_->worker_.lock();
        if(!worker)refuse("restricted handoff continuity worker expired");
        operation=worker->begin_operation(false);
        if(!operation){if(busy){*busy=true;return false;}refuse("restricted handoff continuity operation pending");}
    }
    try {
        if(automatic&&recovery_export_test_hooks::automatic_handoff_observed)
            recovery_export_test_hooks::automatic_handoff_observed(frame.message_);
        recovery_export_adapter::revalidate_claimed_frame(frame,busy,automatic,operation);
        if(busy&&*busy)return false;
        frame.consumed_=true;
        if(frame.owner_->is_closed()||!lifetime_->protected_current(frame.physical_generation_))return false;
        std::shared_ptr<sync_transport> transport;
        {std::lock_guard<std::mutex> lock(mutex_);if(retired_||!open_||generation_!=frame.physical_generation_)return false;transport=transport_;}
        if(operation)operation->require_live();
        bool sent=false;
        if(frame.upload_view_) {
            const auto platform=std::dynamic_pointer_cast<owned_platform_sync_transport>(transport);
            sent=platform&&frame.upload_view_->send(*platform,frame.message_);
        }else {
            if(frame.reconciliation_)refuse("restricted handoff lacks current negotiated source");
            transport->send(frame.message_);sent=true;
        }
        if(frame.reconciliation_){
            // Counted custody spans the entire real handoff. Only after it is
            // released may a completed cursor permit the next owned refreeze.
            frame.continuous_work_.reset();
            if(sent)frame.reconciliation_->did_handoff();
        }
        return sent;
    }catch(...){if(operation)operation->fail(std::current_exception());frame.consumed_=true;throw;}
}
} // namespace lattice::detail
