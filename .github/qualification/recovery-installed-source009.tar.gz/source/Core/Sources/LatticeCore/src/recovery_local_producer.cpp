#include "provider_native_internal.hpp"
#include <lattice/store_physical_api.hpp>
#include "store_physical_api.hpp"
#include "database_sql_dispatcher.hpp"
#include "ordinary_cohort_attachment.hpp"
#include "recovery_local_producer.hpp"
#include "recovery_obligation_bootstrap_statement.hpp"
#include "recovery_resume_commit_publication.hpp"
#include "recovery_admission_test_probe.hpp"
#include "recovery_producer_continuity.hpp"
#include "ordinary_catalog_initialization_test_probe.hpp"
#include "observer_delivery_startup_test_probe.hpp"
#include "ordinary_schema_projection.hpp"
#include "ordinary_resource_normal_startup.hpp"
#include "observer_delivery_initialization_plan.hpp"
#include "ordinary_initialization_storage.hpp"
#include "ordinary_creator_data_storage.hpp"
#include "recovery_canonical_final_audit.hpp"
#include <cstddef>
#include <new>
#include <thread>
#include "recovery_receiver_controller.hpp"
#ifndef __EMSCRIPTEN__
#include "controller_store_ending.hpp"
#include <lattice/native_retirement_storage.hpp>
#endif
#include "recovery_request_store.hpp"
#ifndef __EMSCRIPTEN__
#include "configured_recovery_connection.hpp"
#include "ordinary_managed_wss_owner.hpp"
#endif
#include <filesystem>
#include <limits>
#if defined(__APPLE__) || defined(__linux__)
#include <sys/file.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#endif
#include "vendor/picosha2/picosha2.h"
#include <array>
#include <algorithm>
#include <cerrno>
#include <cstring>
#include <map>
#include <set>
#include <utility>

namespace lattice::detail {
using bootstrap_kind=recovery_obligation_bootstrap_statement::kind;
namespace recovery_local_producer_test_hooks {
thread_local const authorizer_fault* fault=nullptr;
thread_local void (*after_inventory)()=nullptr;
// Production-null observation at the exact already-validated upgrade WRITE.
// Tests may install the existing restricting authorizer fault for this owner.
thread_local void (*before_count_program_upgrade)(const lattice_db*)=nullptr;
}
namespace {
using blob=std::vector<uint8_t>;
constexpr size_t max_models=16, max_relations=32, max_columns=32, max_sql=262144;
constexpr size_t max_manifest=1048576, max_receipt=65536, max_existing=4096;
// Independent discovery ceilings, never populated from stored limits. This
// private slice refuses larger enrolled profiles instead of unbounded opening.
constexpr recovery_obligation_producer_discovery_limits discovery_caps{
    {16,100000,4096,67108864},{16,4096,1048576},{16,100000,4096,1048576,67108864}};
constexpr const char* template_version="lattice-local-original-v1/uuid-nocase/schema-v1";
constexpr const char* swift_template_version="lattice-local-original-v1/uuid-nocase/swift-owner-schema-v1";
[[noreturn]] void refuse(const char* s) { throw db_error(s); }
bool identifier(const std::string& s) {
    if(s.empty() || s.size()>64 || (s[0]>='0'&&s[0]<='9')) return false;
    for(unsigned char c:s) if(!((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='_')) return false;
    return true;
}
std::string literal(const std::string& s) {
    static constexpr char h[]="0123456789abcdef"; std::string out="X'";
    for(unsigned char c:s) {out+=h[c>>4];out+=h[c&15];} return out+"'";
}
int64_t integer(const database::row_t& r,const char* n) {
    const auto i=r.find(n); if(i==r.end()||!std::holds_alternative<int64_t>(i->second)) refuse("local producer invalid integer descriptor");
    return std::get<int64_t>(i->second);
}
std::string text(const database::row_t& r,const char* n) {
    const auto i=r.find(n); if(i==r.end()||!std::holds_alternative<std::string>(i->second)) refuse("local producer invalid bounded descriptor");
    return std::get<std::string>(i->second);
}
bool uuid(const unsigned char* p,int n,char* out) noexcept {
    if(!p||n!=36) return false;
    for(int i=0;i<36;++i) {
        unsigned char c=p[i];
        if(i==8||i==13||i==18||i==23) {if(c!='-')return false;}
        else {if(c>='A'&&c<='F')c+=32;if(!((c>='a'&&c<='f')||(c>='0'&&c<='9')))return false;}
        out[i]=static_cast<char>(c);
    }
    return true;
}
void uuid_sql(lattice_sqlite3541_context* c,int n,lattice_sqlite3541_value** v) noexcept {
    char result[36];
    if(n!=1 || lattice_sqlite3541_value_type(v[0])!=LATTICE_SQLITE3541_TEXT || lattice_sqlite3541_value_bytes(v[0])!=36 ||
       !uuid(lattice_sqlite3541_value_text(v[0]),36,result)) {lattice_sqlite3541_result_null(c);return;}
    lattice_sqlite3541_result_blob(c,result,36,LATTICE_SQLITE3541_TRANSIENT);
}
void append(blob& to,const void* bytes,size_t count) {
    if(to.size()>max_manifest || count>max_manifest-to.size())refuse("local producer manifest budget exceeded");
    if(count) {const auto* p=static_cast<const uint8_t*>(bytes);to.insert(to.end(),p,p+count);}
}
void number(blob& to,uint64_t n) {
    uint8_t b[8];for(int i=7;i>=0;--i){b[i]=static_cast<uint8_t>(n);n>>=8;}append(to,b,8);
}
void field(blob& to,const std::string& s) {number(to,s.size());append(to,s.data(),s.size());}
void field(blob& to,const blob& s) {number(to,s.size());append(to,s.data(),s.size());}
struct reader {
    const blob& bytes; size_t at=0;
    uint64_t number() {
        if(at>bytes.size() || 8>bytes.size()-at)refuse("local producer truncated manifest");
        uint64_t out=0;for(int i=0;i<8;++i)out=(out<<8)|bytes[at++];return out;
    }
    std::string field(size_t limit) {
        auto n=number();if(n>limit || n>bytes.size()-at)refuse("local producer invalid manifest field");
        std::string out(reinterpret_cast<const char*>(bytes.data()+at),static_cast<size_t>(n));at+=n;return out;
    }
};
recovery_local_producer_grant grant_from(const recovery_obligation_producer_profile& p) {
    if(p.grant_manifest.size()>max_manifest)refuse("local producer oversized stored grant");
    reader in{p.grant_manifest};
    const auto version=in.field(128);
    if(version==swift_template_version) {
        if(in.field(64).size()!=64)refuse("local producer invalid owner declaration digest");
    } else if(version!=template_version)refuse("local producer unsupported template revision");
    auto receipt=in.field(max_receipt); if(receipt.empty())refuse("local producer missing incoming grant claim");
    recovery_local_producer_grant out;out.address={p.contribution.binding.channel,p.contribution_incarnation,0};
    out.incoming_grant_receipt={receipt.begin(),receipt.end()};
    auto count=in.number();if(!count||count>max_models)refuse("local producer model inventory bound");
    for(size_t i=0;i<count;++i)out.models.push_back(in.field(64));
    // Remaining descriptors are regenerated from the same registered/durable
    // schema and compared as complete bytes, not trusted as parser authority.
    return out;
}
std::string normalize_sql(std::string s) {
    const std::string prefix="CREATE TRIGGER IF NOT EXISTS ";
    if(s.compare(0,prefix.size(),prefix)==0)s.replace(0,prefix.size(),"CREATE TRIGGER ");
    return s;
}
std::string program_name(const std::string& sql) {
    auto s=normalize_sql(sql);const std::string prefix="CREATE TRIGGER ";
    if(s.compare(0,prefix.size(),prefix)!=0)refuse("local producer unexpected generator program");
    auto e=s.find(' ',prefix.size());if(e==std::string::npos)refuse("local producer malformed program name");
    return s.substr(prefix.size(),e-prefix.size());
}
using programs=std::map<std::string,std::string>;
programs actual_programs(database& db,const std::string& table,recovery_obligation_bootstrap_reader* initialization=nullptr) {
    const auto budget=(initialization?initialization->query_(bootstrap_kind::trigger_budget,{table}):db.query("SELECT COUNT(*) AS n,COALESCE(SUM(length(CAST(name AS BLOB))+length(CAST(sql AS BLOB))),0) AS bytes FROM (SELECT name,sql FROM main.sqlite_master WHERE type='trigger' AND tbl_name=? LIMIT 17)",{table}));
    if(integer(budget.at(0),"n")>16||integer(budget.at(0),"bytes")>static_cast<int64_t>(max_manifest))refuse("local producer trigger bytes exceed allocation bound");
    const auto rows=(initialization?initialization->query_(bootstrap_kind::trigger_programs,{table}):db.query("SELECT CASE WHEN length(CAST(name AS BLOB))<=128 THEN name END AS name,CASE WHEN length(CAST(sql AS BLOB))<=262144 THEN sql END AS sql FROM main.sqlite_master WHERE type='trigger' AND tbl_name=? LIMIT 17",{table}));
    if(rows.size()>16)refuse("local producer trigger inventory bound");
    programs out;for(const auto& r:rows)out.emplace(text(r,"name"),normalize_sql(text(r,"sql")));
    if(initialization)initialization->strip_complete_meter_(table,out);
    return out;
}
programs retention_programs() {
    // SQL-only guards protect connections opened before enrollment too. No
    // connection UDF or sync-disabled setting can bypass retained originals.
    const std::string predicate=" WHEN EXISTS(SELECT 1 FROM _lattice_obligation_producer_profile LIMIT 1) BEGIN SELECT RAISE(ABORT,'local producer durable audit retention fence'); END";
    const std::string remove="_lattice_local_producer_AuditLog_DELETE";
    const std::string update="_lattice_local_producer_AuditLog_UPDATE";
    const std::string insert="_lattice_local_producer_AuditLog_INSERT";
    std::string unchanged;
    for(const char* column:{"id","globalId","tableName","operation","rowId","globalRowId","changedFields","changedFieldsNames","isFromRemote","timestamp","synthesized"}) {
        if(!unchanged.empty())unchanged+=" AND ";
        const std::string name(column);
        // BINARY overrides globalId's NOCASE collation and compares full TEXT
        // lengths, including NUL. typeof prevents equal-value type changes.
        unchanged+="(typeof(OLD."+name+")=typeof(NEW."+name+") AND OLD."+name+" IS NEW."+name+" COLLATE BINARY)";
    }
    return {{remove,"CREATE TRIGGER "+remove+" BEFORE DELETE ON AuditLog"+predicate},
        {insert,"CREATE TRIGGER "+insert+" BEFORE INSERT ON AuditLog WHEN EXISTS(SELECT 1 FROM _lattice_obligation_producer_profile LIMIT 1) AND (EXISTS(SELECT 1 FROM AuditLog WHERE id=NEW.id) OR EXISTS(SELECT 1 FROM AuditLog WHERE globalId=NEW.globalId)) BEGIN SELECT RAISE(ABORT,'local producer durable audit retention fence'); END"},
        {update,"CREATE TRIGGER "+update+" BEFORE UPDATE ON AuditLog WHEN EXISTS(SELECT 1 FROM _lattice_obligation_producer_profile LIMIT 1) AND NOT ("+unchanged+") BEGIN SELECT RAISE(ABORT,'local producer durable audit retention fence'); END"}};
}
// This reads only fixed schema names and EXISTS, never stored payload bytes.
// Call under the actual writer transaction for maintenance mutation admission.
bool durable_producer_present(database& db,recovery_obligation_bootstrap_reader* initialization=nullptr) {
    const auto family=(initialization?initialization->query_(bootstrap_kind::family,{}):db.query("SELECT name FROM main.sqlite_schema WHERE name IN ('_lattice_obligation_producer_store','_lattice_obligation_producer_profile','_lattice_obligation_producer_stamp') LIMIT 4"));
    if(family.empty())return false;
    if(family.size()!=3)refuse("local producer incomplete durable family");
    return !(initialization?initialization->query_(bootstrap_kind::producer_present,{}):db.query("SELECT 1 FROM main._lattice_obligation_producer_profile LIMIT 1")).empty();
}
// Read-only discovery deliberately avoids database::query(): its settled drain
// may deliver the very legacy notification whose callback is asking this
// question. All returned values below are scalars or exact, bounded schema
// literals; no stored manifest, row payload, or unbounded metadata is copied.
struct discovery_statement {
    lattice_sqlite3541_stmt* value=nullptr;
    explicit discovery_statement(lattice_sqlite3541_connection* db,const char* sql) {
        database::record_statement();
        if(::lattice::detail::store_physical_prepare_v2(db,sql,-1,&value,nullptr)!=LATTICE_SQLITE3541_OK) {
            ::lattice::detail::store_physical_finalize(value);value=nullptr;
            refuse("export discovery could not prepare read-only metadata");
        }
        if(!value||!lattice_sqlite3541_stmt_readonly(value)) {
            ::lattice::detail::store_physical_finalize(value);value=nullptr;
            refuse("export discovery requires read-only metadata statements");
        }
    }
    ~discovery_statement(){::lattice::detail::store_physical_finalize(value);}
    discovery_statement(const discovery_statement&)=delete;
    discovery_statement& operator=(const discovery_statement&)=delete;
    bool row() {
        const int rc=::lattice::detail::store_physical_step(value);
        if(rc==LATTICE_SQLITE3541_ROW)return true;
        if(rc!=LATTICE_SQLITE3541_DONE)refuse("export discovery could not read current metadata");
        return false;
    }
    bool text_is(int column,const char* expected) const {
        if(lattice_sqlite3541_column_type(value,column)!=LATTICE_SQLITE3541_TEXT)return false;
        const auto size=std::strlen(expected);
        if(lattice_sqlite3541_column_bytes(value,column)!=static_cast<int>(size))return false;
        const auto* bytes=lattice_sqlite3541_column_text(value,column);
        return bytes&&std::memcmp(bytes,expected,size)==0;
    }
    int64_t number(int column) const {
        if(lattice_sqlite3541_column_type(value,column)!=LATTICE_SQLITE3541_INTEGER)
            refuse("export discovery has malformed integer metadata");
        return lattice_sqlite3541_column_int64(value,column);
    }
};
// This classifier recognizes exactly producer storage v1, without obtaining a
// storage writer capability. Keep these bounded read-only definitions equal to
// recovery_obligation_store.cpp's producer_definitions (SQLite omits main.).
constexpr std::pair<const char*,const char*> discovery_definitions[]={
 {"_lattice_obligation_producer_store","CREATE TABLE _lattice_obligation_producer_store(id INTEGER PRIMARY KEY,version INTEGER NOT NULL,max_profiles INTEGER NOT NULL,max_stamps INTEGER NOT NULL,max_field INTEGER NOT NULL,max_manifest INTEGER NOT NULL,max_bytes INTEGER NOT NULL,profiles INTEGER NOT NULL,stamps INTEGER NOT NULL,bytes INTEGER NOT NULL) WITHOUT ROWID"},
 {"_lattice_obligation_producer_profile","CREATE TABLE _lattice_obligation_producer_profile(channel BLOB PRIMARY KEY,incarnation INTEGER NOT NULL UNIQUE,program_revision INTEGER NOT NULL,program_digest BLOB NOT NULL,manifest BLOB NOT NULL,bytes INTEGER NOT NULL) WITHOUT ROWID"},
 {"_lattice_obligation_producer_stamp","CREATE TABLE _lattice_obligation_producer_stamp(channel BLOB NOT NULL,original BLOB NOT NULL,incarnation INTEGER NOT NULL,program_revision INTEGER NOT NULL,audit_id INTEGER NOT NULL,record_sequence INTEGER NOT NULL UNIQUE,generation INTEGER NOT NULL,scope_revision INTEGER NOT NULL,base_scopes INTEGER NOT NULL,base_records INTEGER NOT NULL,base_bytes INTEGER NOT NULL,base_incarnation INTEGER NOT NULL,base_export INTEGER NOT NULL,producer_profiles INTEGER NOT NULL,producer_stamps INTEGER NOT NULL,producer_bytes INTEGER NOT NULL,bytes INTEGER NOT NULL,PRIMARY KEY(channel,original),UNIQUE(channel,audit_id)) WITHOUT ROWID"}
};
bool discovery_family_present(lattice_sqlite3541_connection* db,bool admitted_profiles) {
    discovery_statement family(db,"SELECT type,name,sql FROM main.sqlite_schema WHERE name IN ('_lattice_obligation_producer_store','_lattice_obligation_producer_profile','_lattice_obligation_producer_stamp') LIMIT 4");
    unsigned seen=0;
    while(family.row()) {
        unsigned match=0;
        for(unsigned i=0;i<3;++i)if(family.text_is(1,discovery_definitions[i].first)) {
            match=1u<<i;
            if(!family.text_is(0,"table")||!family.text_is(2,discovery_definitions[i].second))
                refuse("export discovery producer schema differs");
            break;
        }
        if(!match||(seen&match))refuse("export discovery duplicate or unknown producer schema");
        seen|=match;
    }
    if(!seen) {
        if(admitted_profiles)refuse("export admitted producer family disappeared");
        return false;
    }
    if(seen!=7)refuse("export discovery incomplete durable producer family");
    discovery_statement config(db,"SELECT id,version,max_profiles,max_stamps,max_field,max_manifest,max_bytes,profiles,stamps,bytes FROM main._lattice_obligation_producer_store LIMIT 2");
    if(!config.row())refuse("export discovery missing producer metadata");
    std::array<int64_t,10> values{};
    for(int i=0;i<10;++i)values[i]=config.number(i);
    if(config.row()||values[0]!=1||values[1]!=1)
        refuse("export discovery unsupported producer metadata");
    const auto& cap=discovery_caps.producers;
    if(values[2]<0||values[2]>cap.profiles||values[3]<0||values[3]>cap.stamps||
       values[4]<=0||values[4]>cap.field_bytes||values[5]<0||values[5]>cap.manifest_bytes||
       values[6]<0||values[6]>cap.encoded_bytes||values[7]<0||values[7]>values[2]||
       values[8]<0||values[8]>values[3]||values[9]<0||values[9]>values[6])
        refuse("export discovery producer limits or counters are invalid");
    discovery_statement profiles(db,"SELECT COUNT(*) FROM (SELECT 1 FROM main._lattice_obligation_producer_profile LIMIT 17)");
    if(!profiles.row())refuse("export discovery missing profile count");
    const auto count=profiles.number(0);
    if(profiles.row()||count!=values[7]||count>cap.profiles)
        refuse("export discovery producer profile count differs");
    if(count)return true; // Classification only; strict preparation rereads admission.
    if(admitted_profiles)refuse("export admitted producer profiles disappeared");
    discovery_statement stamps(db,"SELECT 1 FROM main._lattice_obligation_producer_stamp LIMIT 1");
    if(values[8]!=0||values[9]!=0||stamps.row())
        refuse("export discovery dormant producer family is not empty");
    return false;
}
void validate_retention_programs(database& db,bool required,recovery_obligation_bootstrap_reader* initialization=nullptr) {
    const auto actual=actual_programs(db,"AuditLog",initialization);
    if(actual.empty()&&!required)return;
    if(actual!=retention_programs())refuse("local producer durable audit retention program mismatch");
}
std::string require(const std::string& condition) {
    return " SELECT CASE WHEN ("+condition+") THEN 1 ELSE RAISE(ABORT,'local producer phase/program refused') END;";
}
bool equal_blob(lattice_sqlite3541_value* value,const std::string& expected) noexcept {
    return lattice_sqlite3541_value_type(value)==LATTICE_SQLITE3541_BLOB && lattice_sqlite3541_value_bytes(value)==static_cast<int>(expected.size()) &&
        (!expected.size() || (lattice_sqlite3541_value_blob(value) && std::memcmp(lattice_sqlite3541_value_blob(value),expected.data(),expected.size())==0));
}
void validate_limits(const recovery_obligation_producer_discovery_limits& x) {
    const auto fit=[](int64_t n,int64_t cap){return n>0&&n<=cap;};
    if(!fit(x.obligations.scopes,discovery_caps.obligations.scopes)||!fit(x.obligations.records,discovery_caps.obligations.records)||
       !fit(x.obligations.field_bytes,discovery_caps.obligations.field_bytes)||!fit(x.obligations.encoded_bytes,discovery_caps.obligations.encoded_bytes)||
       !fit(x.installations.channels,discovery_caps.installations.channels)||!fit(x.installations.field_bytes,discovery_caps.installations.field_bytes)||
       !fit(x.installations.encoded_bytes,discovery_caps.installations.encoded_bytes)||
       !fit(x.producers.profiles,discovery_caps.producers.profiles)||!fit(x.producers.stamps,discovery_caps.producers.stamps)||
       !fit(x.producers.field_bytes,discovery_caps.producers.field_bytes)||!fit(x.producers.manifest_bytes,discovery_caps.producers.manifest_bytes)||
       !fit(x.producers.encoded_bytes,discovery_caps.producers.encoded_bytes))refuse("local producer explicit limits exceed independent discovery caps");
}
bool same_ascii(const char* a,const char* b) noexcept {
    if(!a||!b)return false;
    for(;*a&&*b;++a,++b) {unsigned char x=*a,y=*b;if(x>='A'&&x<='Z')x+=32;if(y>='A'&&y<='Z')y+=32;if(x!=y)return false;}
    return *a==*b;
}
struct table_plan {
    std::string name,ddl; bool link=false;
    std::vector<std::pair<std::string,column_type>> columns;
    std::set<std::string> no_history;
    programs ordinary, enrolled;
};
}

struct recovery_local_producer_adapter::descriptor {
    blob manifest; std::string digest;
    std::map<std::string,table_plan> tables;
};
struct recovery_local_producer_adapter::management {
    const std::uint64_t creator=database_native_process();
    lattice_sqlite3541_connection* connection; management* previous;
    explicit management(lattice_sqlite3541_connection* c):connection(c),previous(management_){management_=this;}
    ~management(){management_=creator==database_native_process()?previous:nullptr;}
};
thread_local recovery_local_producer_adapter::management* recovery_local_producer_adapter::management_=nullptr;
#include "recovery_producer_continuity_state.inc"

struct recovery_local_producer_adapter::context {
    struct profile {recovery_obligation_producer_profile stored; descriptor schema;};
    lattice_sqlite3541_connection* connection=nullptr; lattice_db* owner=nullptr; // identity, never lifetime ownership
    std::shared_ptr<instance_guard> lifetime;
    recovery_obligation_producer_discovery_limits admitted_limits{};
    // Revocation is monotonic. Settlement only changes configuration status,
    // never writes true over a concurrent close/raw-escape revocation.
    std::shared_ptr<std::atomic<bool>> active=std::make_shared<std::atomic<bool>>(true);
    std::atomic<int> status{0}; // 0 pending, 1 committed, 2 rolled back
    bool final_role_registered=false; // set only by actual complete registration-return producer
    bool final_role_pending=false; // exact unpublished role, activates only after actual final COMMIT
    struct final_key final {};
    context()=default;
    explicit context(final_key):active(std::allocate_shared<std::atomic<bool>>(
        ordinary_initialization_allocator<std::atomic<bool>>{},true)) {}
    std::shared_ptr<context> previous;
    std::vector<profile> profiles;
    std::shared_ptr<recovery_continuous_admission> continuous;
    // Determined only by exact WHOLE generated-bundle comparison in bootstrap.
    // This private spelling never grants write, receipt, or source authority.
    bool legacy_distinct_count_programs=false;
    bool matches_complete_programs(database& db,recovery_obligation_bootstrap_reader* initialization=nullptr)const {
        std::set<std::string> checked;
        for(const auto& p:profiles)for(const auto& [name,t]:p.schema.tables)
            if(checked.insert(name).second&&actual_programs(db,name,initialization)!=t.enrolled)return false;
        return true;
    }
    const context* effective() const noexcept {
        const auto state=status.load(std::memory_order_acquire);
        if(state==2)return previous ? previous->effective() : nullptr;
        return this;
    }
    static void guard(lattice_sqlite3541_context* sql,int n,lattice_sqlite3541_value** v) noexcept {
        auto& root=**static_cast<std::shared_ptr<context>*>(lattice_sqlite3541_user_data(sql));
        const auto* effective=root.effective();
        if(!effective || effective->status.load(std::memory_order_acquire)!=1){lattice_sqlite3541_result_int(sql,0);return;}
        const auto& c=*effective;
        bool ok=n==6 && lattice_sqlite3541_context_db_handle(sql)==c.connection &&
            lattice_sqlite3541_value_type(v[1])==LATTICE_SQLITE3541_INTEGER && lattice_sqlite3541_value_type(v[2])==LATTICE_SQLITE3541_INTEGER && lattice_sqlite3541_value_type(v[5])==LATTICE_SQLITE3541_INTEGER;
        const auto phase=ok?lattice_sqlite3541_value_int64(v[5]):0;
        const bool install=ok&&recovery_writer_access::active_install_for(c.owner,c.connection);
        if(c.continuous) {
            if(phase==1)ok=ok&&c.continuous->state->dml_open.load(std::memory_order_acquire);
            else if(phase==2)ok=ok&&continuous_install_owned(*c.continuous);
            else ok=false;
        }
        ok=ok&&((phase==1 && !install && root.active->load(std::memory_order_acquire) && c.active->load(std::memory_order_acquire) && c.lifetime->alive.load(std::memory_order_acquire)) ||
                (phase==2 && install));
        bool found=false;
        for(const auto& p:c.profiles) {
            if(!ok || !equal_blob(v[0],p.stored.contribution.binding.channel) ||
               lattice_sqlite3541_value_int64(v[1])!=p.stored.contribution_incarnation || lattice_sqlite3541_value_int64(v[2])!=p.stored.program_revision ||
               !equal_blob(v[3],p.stored.program_digest))continue;
            for(const auto& pair:p.schema.tables)if(equal_blob(v[4],pair.first)){found=true;break;}
            if(found)break;
        }
        lattice_sqlite3541_result_int(sql,found?1:0);
    }
    static void continuous_guard(lattice_sqlite3541_context* sql,int n,lattice_sqlite3541_value**) noexcept {
        auto& root=**static_cast<std::shared_ptr<context>*>(lattice_sqlite3541_user_data(sql));
        const auto* c=root.effective();
        const bool ok=n==0&&c&&c->continuous&&lattice_sqlite3541_context_db_handle(sql)==c->connection&&continuous_owned(*c->continuous);
        lattice_sqlite3541_result_int(sql,ok?1:0);
    }
    static int authorize(void* raw,int action,const char* one,const char* two,const char* schema,const char* origin) noexcept {
        auto& root=*static_cast<context*>(raw);
        const auto normal=[&]() noexcept -> int {
        for(auto* m=management_;m;m=m->previous)if(m->connection==root.connection)return LATTICE_SQLITE3541_OK;
        const auto* effective=root.effective();
        if(!effective || effective->profiles.empty())return LATTICE_SQLITE3541_OK;
        const auto& c=*effective;
        if(c.continuous && !continuous_authorize(*c.continuous,action,one,two,origin))return LATTICE_SQLITE3541_DENY;
        switch(action) {
        case LATTICE_SQLITE3541_ATTACH:case LATTICE_SQLITE3541_DETACH:case LATTICE_SQLITE3541_ALTER_TABLE:
        case LATTICE_SQLITE3541_CREATE_TABLE:case LATTICE_SQLITE3541_CREATE_TEMP_TABLE:case LATTICE_SQLITE3541_CREATE_TRIGGER:case LATTICE_SQLITE3541_CREATE_TEMP_TRIGGER:
        case LATTICE_SQLITE3541_DROP_TABLE:case LATTICE_SQLITE3541_DROP_TEMP_TABLE:case LATTICE_SQLITE3541_DROP_TRIGGER:case LATTICE_SQLITE3541_DROP_TEMP_TRIGGER:
        case LATTICE_SQLITE3541_CREATE_INDEX:case LATTICE_SQLITE3541_DROP_INDEX:case LATTICE_SQLITE3541_CREATE_TEMP_INDEX:case LATTICE_SQLITE3541_DROP_TEMP_INDEX:
        case LATTICE_SQLITE3541_CREATE_VIEW:case LATTICE_SQLITE3541_DROP_VIEW:case LATTICE_SQLITE3541_CREATE_TEMP_VIEW:case LATTICE_SQLITE3541_DROP_TEMP_VIEW:
        case LATTICE_SQLITE3541_CREATE_VTABLE:case LATTICE_SQLITE3541_DROP_VTABLE: return LATTICE_SQLITE3541_DENY;
        default:break;
        }
        if(action==LATTICE_SQLITE3541_PRAGMA && two && (same_ascii(one,"recursive_triggers")||same_ascii(one,"writable_schema")||same_ascii(one,"schema_version")))return LATTICE_SQLITE3541_DENY;
        // Retention/reset integration is not active. Preserve original bodies
        // conservatively across ALL channels instead of losing a pinned body
        // and discovering the damage during a later recovery read.
        if(one && same_ascii(one,"AuditLog") && (action==LATTICE_SQLITE3541_DELETE ||
           (action==LATTICE_SQLITE3541_UPDATE && !same_ascii(two,"isSynchronized"))))return LATTICE_SQLITE3541_DENY;
        if(one && action==LATTICE_SQLITE3541_DELETE && (same_ascii(one,"_lattice_sync_state") ||
           same_ascii(one,"_lattice_sync_set")||same_ascii(one,"_lattice_replication_slots")))return LATTICE_SQLITE3541_DENY;
        if(one && action==LATTICE_SQLITE3541_UPDATE && same_ascii(one,"_lattice_replication_slots") &&
           (same_ascii(two,"confirmed_audit_id")||same_ascii(two,"upload_floor"))&&
           !(c.continuous&&continuous_install_owned(*c.continuous)))return LATTICE_SQLITE3541_DENY;
        if((action==LATTICE_SQLITE3541_INSERT||action==LATTICE_SQLITE3541_UPDATE||action==LATTICE_SQLITE3541_DELETE) && one &&
           std::strncmp(one,"_lattice_obligation_producer_",sizeof("_lattice_obligation_producer_")-1)==0) {
            if(!schema||std::strcmp(schema,"main")||!origin)return LATTICE_SQLITE3541_DENY;
            if(std::strcmp(one,"_lattice_obligation_producer_profile")==0)return LATTICE_SQLITE3541_DENY;
            for(const auto& p:c.profiles)for(const auto& t:p.schema.tables)
                for(const auto& program:t.second.ordinary)if(program.first==origin)return LATTICE_SQLITE3541_OK;
            return LATTICE_SQLITE3541_DENY;
        }
        return LATTICE_SQLITE3541_OK;
        };
        const int admission=normal();
        if(admission!=LATTICE_SQLITE3541_OK)return admission;
        const auto* fault=recovery_local_producer_test_hooks::fault;
        if(fault && fault->owner==root.owner && fault->restrict_action) {
            const int value=fault->restrict_action(action,one,two,origin);
            if(value==LATTICE_SQLITE3541_DENY||value==LATTICE_SQLITE3541_IGNORE)return value;
        }
        return LATTICE_SQLITE3541_OK;
    }
};

std::shared_ptr<database> recovery_local_producer_adapter::retained_writer_for_test(lattice_db& owner) {
    std::lock_guard<std::mutex> lock(owner.connection_ownership_mutex_);return owner.db_;
}
recovery_local_producer_adapter::descriptor recovery_local_producer_adapter::describe(
    lattice_db& owner,database& db,const recovery_local_producer_grant& grant,bool initial_inventory,recovery_obligation_bootstrap_reader* initialization) {
    const auto& catalog=owner.recovery_schemas_;
    if(!catalog.valid())refuse("local producer owner schema catalog outside bounds or ambiguous");
    if(grant.models.empty()||grant.models.size()>max_models||grant.incoming_grant_receipt.empty()||grant.incoming_grant_receipt.size()>max_receipt)
        refuse("local producer requires bounded explicit whole-model incoming grant");
    for(const auto& name:grant.models)if(!identifier(name)||name[0]=='_')refuse("local producer unsupported model identifier");
    const std::set<std::string> models(grant.models.begin(),grant.models.end());
    if(models.size()!=grant.models.size())refuse("local producer duplicate model grant");
    descriptor d;
    field(d.manifest,std::string(catalog.swift_digest.empty()?template_version:swift_template_version));
    if(!catalog.swift_digest.empty())field(d.manifest,catalog.swift_digest);
    field(d.manifest,grant.incoming_grant_receipt);number(d.manifest,models.size());
    for(const auto& name:models) {
        if(!identifier(name)||name[0]=='_')refuse("local producer unsupported model identifier");field(d.manifest,name);
        const auto* schema=catalog.find(name);
        if(!schema || schema->properties.empty() || schema->properties.size()>max_columns)refuse("local producer unknown/oversized complete schema");
        table_plan t;t.name=name;
        for(const auto& p:schema->properties) {
            if(!identifier(p.name)||p.is_vector||p.is_geo_bounds||p.is_full_text||p.is_union||
               (!p.column_name.empty()&&p.column_name!=p.name)||
               (p.kind!=property_kind::primitive&&p.kind!=property_kind::link&&p.kind!=property_kind::list))
                refuse("local producer unsupported complete schema property");
            const bool swift=catalog.swift_models.count(name);
            const bool physical=swift?p.kind==property_kind::primitive:p.kind!=property_kind::list;
            if(physical)t.columns.emplace_back(p.name,p.type);
            if(p.no_history&&(!swift||physical))t.no_history.insert(p.name);
        }
        if(t.columns.empty())refuse("local producer model has no generated audit program");
        d.tables.emplace(name,std::move(t));
    }
    for(const auto& [schema_name,s]:catalog.models)for(const auto& p:s.properties) {
        if(p.kind!=property_kind::link&&p.kind!=property_kind::list)continue;
        if(!models.count(s.table_name)&&!models.count(p.target_table))continue;
        if(p.is_geo_bounds||p.target_table.empty()||!models.count(s.table_name)||!models.count(p.target_table))
            refuse("local producer incomplete regular-link incoming/outgoing closure");
        table_plan t;t.name="_"+s.table_name+"_"+p.target_table+"_"+p.name;t.link=true;
        if(!identifier(t.name))refuse("local producer oversized relation");d.tables.emplace(t.name,std::move(t));
    }
    if(d.tables.size()>max_relations)refuse("local producer physical relation budget");
    // Fixed retention-program bytes participate in the descriptor digest;
    // their trigger names/definitions are independently checked at admission.
    for(const auto& [name,sql]:retention_programs()){field(d.manifest,name);field(d.manifest,sql);}
    size_t existing=0;
    for(auto& [name,t]:d.tables) {
        auto ddl=(initialization?initialization->query_(bootstrap_kind::model_definition,{name}):db.query("SELECT CASE WHEN length(CAST(sql AS BLOB))<=262144 THEN sql END AS sql FROM main.sqlite_master WHERE type='table' AND name=?",{name}));
        if(ddl.size()!=1)refuse("local producer missing durable model/link relation");t.ddl=text(ddl[0],"sql");
        if(t.ddl.find("globalId TEXT UNIQUE COLLATE NOCASE")==std::string::npos || t.ddl.find("CREATE VIRTUAL")!=std::string::npos || t.ddl.find("WITHOUT ROWID")!=std::string::npos)
            refuse("local producer unsupported durable UUID relation");
        const auto columns=(initialization?initialization->query_(bootstrap_kind::model_columns,{name}):db.query("SELECT CASE WHEN length(CAST(name AS BLOB))<=64 THEN name END AS name,CASE WHEN length(CAST(type AS BLOB))<=16 THEN type END AS type,CASE WHEN typeof(hidden)='integer' THEN hidden END AS hidden FROM pragma_table_xinfo(?) ORDER BY cid LIMIT 35",{name}));
        if(columns.size()>34)refuse("local producer durable column count");
        std::map<std::string,std::string> actual,want;
        for(const auto& c:columns) {if(integer(c,"hidden")!=0)refuse("local producer hidden/generated columns");actual.emplace(text(c,"name"),text(c,"type"));}
        if(t.link)want={{"lhs","TEXT"},{"rhs","TEXT"},{"globalId","TEXT"}};
        else {
            want={{"id","INTEGER"},{"globalId","TEXT"}};
            for(const auto& [column,type]:t.columns)want.emplace(column,type==column_type::integer?"INTEGER":type==column_type::real?"REAL":type==column_type::blob?"BLOB":"TEXT");
        }
        if(actual!=want)refuse("local producer durable/registered schema disagreement");
        if(catalog.swift_models.count(name)) {
            // SwiftSchema is unordered. Installed generated SQL follows the
            // physical creation order; a later process may enumerate the same
            // declaration differently. Set agreement above precedes this use.
            std::vector<std::pair<std::string,column_type>> ordered;
            for(const auto& c:columns) {
                const auto column=text(c,"name");
                for(const auto& declared:t.columns)if(declared.first==column){ordered.push_back(declared);break;}
            }
            if(ordered.size()!=t.columns.size())refuse("local producer incomplete physical column order");
            t.columns=std::move(ordered);
        }
        // Only first enrollment scans the bounded initial identity inventory.
        // Admitted programs guard later UUID writes. Reconstructing their exact
        // schema/program descriptor must not add a lower row-growth ceiling.
        // Arbitrary external/raw schema or UDF tampering is unsupported.
        if(initial_inventory) {
            const auto rows=db.query("SELECT CASE WHEN typeof(globalId)='text' AND length(CAST(globalId AS BLOB))=36 THEN globalId END AS gid FROM main."+name+" LIMIT "+std::to_string(max_existing-existing+1));
            if(rows.size()>max_existing-existing)refuse("local producer initial UUID inventory bound");existing+=rows.size();
            for(const auto& row:rows) {auto id=text(row,"gid");char out[36];if(!uuid(reinterpret_cast<const unsigned char*>(id.data()),id.size(),out))refuse("local producer non-UUID existing identity");}
        }
        std::vector<std::string> sql;
        if(t.link)owner.create_link_table_triggers(name,{},&sql);
        else owner.create_model_table_triggers(name,t.columns,t.no_history,{},&sql);
        for(const auto& s:sql)t.ordinary.emplace(program_name(s),normalize_sql(s));
        field(d.manifest,name);number(d.manifest,t.link?1:0);field(d.manifest,t.ddl);
        for(const auto& [n,s]:t.ordinary){field(d.manifest,n);field(d.manifest,s);}
        const auto index_budget=(initialization?initialization->query_(bootstrap_kind::index_budget,{name}):db.query("SELECT COUNT(*) AS n,COALESCE(SUM(length(CAST(name AS BLOB))+COALESCE(length(CAST(sql AS BLOB)),0)),0) AS bytes FROM (SELECT name,sql FROM main.sqlite_master WHERE type='index' AND tbl_name=? LIMIT 33)",{name}));
        if(integer(index_budget.at(0),"n")>32||integer(index_budget.at(0),"bytes")>static_cast<int64_t>(max_manifest-d.manifest.size()))refuse("local producer index bytes exceed allocation bound");
        const auto indexes=(initialization?initialization->query_(bootstrap_kind::indexes,{name}):db.query("SELECT CASE WHEN length(CAST(name AS BLOB))<=128 THEN name END AS name,CASE WHEN sql IS NULL THEN '' WHEN length(CAST(sql AS BLOB))<=262144 THEN sql END AS sql FROM main.sqlite_master WHERE type='index' AND tbl_name=? ORDER BY name LIMIT 33",{name}));
        if(indexes.size()>32)refuse("local producer index inventory bound");number(d.manifest,indexes.size());
        for(const auto& i:indexes){field(d.manifest,text(i,"name"));field(d.manifest,text(i,"sql"));}
    }
    d.digest=picosha2::hash256_hex_string(d.manifest);return d;
}

void recovery_local_producer_adapter::validate_custody(lattice_db& owner,database& writer,recovery_obligation_bootstrap_reader* initialization) {
    if(owner.config_.read_only||(!owner.recovery_continuous_ && owner.config_.is_sync_enabled())||owner.config_.is_ipc_enabled()||owner.config_.audit_retention_seconds!=0)
        refuse("local producer qualification refuses legacy transports/automatic retention/read-only owner");
    if(writer.raw_handle_escaped_.load(std::memory_order_acquire))refuse("local producer raw handle escaped; engine hook custody unavailable");
    if(writer.canonical_callback_custody_ || (initialization?!initialization->query_(bootstrap_kind::canonical_coverage,{std::string("_lattice_canonical_coverage")}).empty():writer.table_exists("_lattice_canonical_coverage")))
        refuse("local producer source-canonical coattachment is unqualified");
    const auto dbs=(initialization?initialization->query_(bootstrap_kind::databases,{}):writer.query("SELECT name FROM pragma_database_list LIMIT 3"));
    if(dbs.size()>2)refuse("local producer attached databases are unqualified");
    for(const auto& r:dbs)if(text(r,"name")!="main"&&text(r,"name")!="temp")refuse("local producer attached databases are unqualified");
    if(!(initialization?initialization->query_(bootstrap_kind::temporary_presence,{}):writer.query("SELECT 1 FROM temp.sqlite_master LIMIT 1")).empty())refuse("local producer temporary schema is unqualified");
    validate_retention_programs(writer,durable_producer_present(writer,initialization),initialization);
    if(!(initialization?initialization->query_(bootstrap_kind::metadata_triggers,{}):writer.query("SELECT 1 FROM main.sqlite_master WHERE type='trigger' AND substr(tbl_name,1,20)='_lattice_obligation_' LIMIT 1")).empty())
        refuse("local producer obligation metadata triggers are unqualified");
}
void recovery_local_producer_adapter::register_context(database& writer,const std::shared_ptr<context>& c) {
    if(writer.delivery_startup_&&c&&c->continuous) {
        writer.require_creator_();const auto creator=database_native_process();auto& open=*writer.delivery_startup_;
        open.require_work_current_(writer);
        if(c->connection!=writer.db_||!c->owner||c->owner->recovery_continuous_!=c->continuous||c->final_role_registered)
            refuse("checked producer registration lost its actual same role/context");
        ordinary_initialization_storage_scope storage(&open,&writer,&observer_delivery_open_startup::debit_initialization_storage_);
        ordinary_creator_data_storage<std::unique_ptr<std::shared_ptr<context>>,std::unique_ptr<std::shared_ptr<context>>> custody;
        auto& continuity=custody.get<0>();auto& producer=custody.get<1>();
        open.claim_workspace_(writer,sizeof(std::shared_ptr<context>));continuity=std::make_unique<std::shared_ptr<context>>(c);
        if(creator!=database_native_process())refuse("inherited producer continuity userdata allocation");
        open.claim_workspace_(writer,sizeof(std::shared_ptr<context>));producer=std::make_unique<std::shared_ptr<context>>(c);
        if(creator!=database_native_process())refuse("inherited producer guard userdata allocation");
        database::catalog_native_admission_ leaf(writer);open.require_work_current_(writer);
        store_physical_api::registration_scope registration(writer,open,4);
        const auto destroy=[](void* p){delete static_cast<std::shared_ptr<context>*>(p);};
        // Each actual v2 call consumes its own userdata on success or failure;
        // the closed wrapper also consumes genuine same-creator preentry refusal.
        int rc=registration.function_(0,"lattice_recovery_continuity_owned_v1",0,LATTICE_SQLITE3541_UTF8,
            continuity.release(),context::continuous_guard,destroy);
        if(creator!=database_native_process())refuse("inherited producer continuity Native return");
        if(rc!=LATTICE_SQLITE3541_OK)refuse("checked continuous guard registration failed");
        rc=registration.function_(1,"lattice_recovery_producer_guard_v1",6,LATTICE_SQLITE3541_UTF8,
            producer.release(),context::guard,destroy);
        if(creator!=database_native_process())refuse("inherited producer guard Native return");
        if(rc!=LATTICE_SQLITE3541_OK)refuse("checked local producer guard registration failed");
        rc=registration.function_(2,"lattice_recovery_producer_uuid_v1",1,LATTICE_SQLITE3541_UTF8|LATTICE_SQLITE3541_DETERMINISTIC,
            nullptr,uuid_sql,nullptr);
        if(creator!=database_native_process())refuse("inherited producer UUID Native return");
        if(rc!=LATTICE_SQLITE3541_OK)refuse("checked local producer UUID registration failed");
        std::atomic_store(&writer.local_producer_callback_custody_,std::static_pointer_cast<void>(c));
        std::atomic_store(&writer.local_producer_write_allowed_,c->active);
        rc=registration.authorizer_(context::authorize,c.get());
        if(creator!=database_native_process())refuse("inherited producer authorizer Native return");
        if(rc!=LATTICE_SQLITE3541_OK)refuse("checked local producer authorizer registration failed");
        registration.finish_();
        if(creator!=database_native_process())refuse("inherited producer complete registration return");
        store_physical_api::require_producer_registrations_(writer,open,context::authorize,c.get());
        c->final_role_registered=true;return;
    }
    if(c->continuous) {
        auto* continuous_held=new std::shared_ptr<context>(c);
        if(::lattice::detail::store_physical_create_function_v2(c->connection,"lattice_recovery_continuity_owned_v1",0,LATTICE_SQLITE3541_UTF8,continuous_held,context::continuous_guard,nullptr,nullptr,
            [](void* p){delete static_cast<std::shared_ptr<context>*>(p);})!=LATTICE_SQLITE3541_OK)refuse("continuous guard registration failed");
    }
    auto* held=new std::shared_ptr<context>(c);
    if(::lattice::detail::store_physical_create_function_v2(c->connection,"lattice_recovery_producer_guard_v1",6,LATTICE_SQLITE3541_UTF8,held,context::guard,nullptr,nullptr,
        [](void* p){delete static_cast<std::shared_ptr<context>*>(p);})!=LATTICE_SQLITE3541_OK)refuse("local producer guard registration failed");
    if(::lattice::detail::store_physical_create_function_v2(c->connection,"lattice_recovery_producer_uuid_v1",1,LATTICE_SQLITE3541_UTF8|LATTICE_SQLITE3541_DETERMINISTIC,nullptr,uuid_sql,nullptr,nullptr,nullptr)!=LATTICE_SQLITE3541_OK)
        refuse("local producer UUID registration failed");
    // Authorizer userdata has the same physical lifetime as the registered UDF;
    // database close/replacement revokes admission before releasing its copy.
    std::atomic_store(&writer.local_producer_callback_custody_,std::static_pointer_cast<void>(c));
    std::atomic_store(&writer.local_producer_write_allowed_,c->active);
    if(writer.set_sql_authorizer_(database_authorizer_slot::local_producer,context::authorize,c.get())!=LATTICE_SQLITE3541_OK)refuse("local producer authorizer registration failed");
    c->final_role_registered=true;
}

void recovery_local_producer_adapter::compile_programs(lattice_db& owner,descriptor& d,
    const recovery_obligation_producer_program& program) {
    const auto& p=program.profile();size_t generated=0;
    for(auto& [name,t]:d.tables) {
        const auto tail=program.emit_tail(name,t.link,max_sql);
        if(tail.size()>max_sql)refuse("local producer tail exceeds independent SQL budget");
        for(const auto& entry:t.ordinary)if(entry.second.size()>max_sql-tail.size())refuse("local producer complete program bound");
        std::vector<std::string> emitted;
        if(t.link)owner.create_link_table_triggers(name,tail,&emitted);
        else owner.create_model_table_triggers(name,t.columns,t.no_history,tail,&emitted);
        const auto guard=[&](int phase) {
            return "lattice_recovery_producer_guard_v1("+literal(p.contribution.binding.channel)+","+
                std::to_string(p.contribution_incarnation)+","+std::to_string(p.program_revision)+","+
                literal(p.program_digest)+","+literal(name)+","+std::to_string(phase)+")=1";
        };
        for(const auto* operation:{"INSERT","UPDATE","DELETE"}) {
            const std::string op(operation), key=op=="DELETE"?"OLD.globalId":"NEW.globalId";
            std::string check="((sync_disabled()=0 AND "+guard(1)+") OR (sync_disabled()=1 AND "+guard(2)+"))";
            check+=" AND lattice_recovery_producer_uuid_v1("+key+") IS NOT NULL";
            if(op=="UPDATE") {
                check+=" AND CAST(OLD.globalId AS BLOB) IS CAST(NEW.globalId AS BLOB)";
                if(t.link)check+=" AND ("+guard(2)+" OR (OLD.lhs IS NEW.lhs AND OLD.rhs IS NEW.rhs))";
                else check+=" AND OLD.id IS NEW.id";
            }
            emitted.push_back("CREATE TRIGGER _lattice_local_producer_"+name+"_"+op+" BEFORE "+op+" ON "+name+" BEGIN"+require(check)+" END");
        }
        for(auto& sql:emitted) {
            if(sql.size()>max_sql || generated>max_manifest || sql.size()>max_manifest-generated)refuse("local producer generated program aggregate bound");
            generated+=sql.size();const auto name=program_name(sql);t.enrolled.emplace(name,normalize_sql(std::move(sql)));
        }
    }
}

recovery_install_result recovery_local_producer_adapter::enroll_for_qualification(
    std::shared_ptr<lattice_db> owner,const recovery_local_producer_grant& grant,
    const recovery_obligation_producer_discovery_limits& limits) {
    std::shared_ptr<context> candidate;
    auto result=recovery_writer_access::install_impl(owner,[&](database& db) {
        if(owner->recovery_continuous_)refuse("continuous producer cannot use qualification enrollment or retirement");
        validate_limits(limits);validate_custody(*owner,db);
        management changing(db.internal_handle());
        auto prior=std::static_pointer_cast<context>(std::atomic_load(&db.local_producer_callback_custody_));
        while(prior && prior->status.load(std::memory_order_acquire)==2)prior=prior->previous;
        candidate=std::make_shared<context>();candidate->connection=db.internal_handle();candidate->owner=owner.get();candidate->lifetime=owner->guard_;candidate->previous=prior;candidate->admitted_limits=limits;
        recovery_obligation_store obligations(owner,limits.obligations,limits.installations);
        obligations.audit();const auto scope=obligations.read(grant.address.channel);
        if(!scope || scope->address!=grant.address)refuse("local producer stale or unbound contribution address");
        recovery_obligation_producer_store storage(owner,limits.obligations,limits.installations,limits.producers);
        storage.initialize();
        auto schema=describe(*owner,db,grant,true);
        recovery_obligation_producer_profile profile{scope->profile,scope->address.incarnation,1,schema.digest,schema.manifest};
        const auto existing=storage.profiles();
        for(const auto& p:existing) {
            if(p.contribution.binding.channel==profile.contribution.binding.channel)refuse("local producer contribution already enrolled");
            auto old=describe(*owner,db,grant_from(p),false);
            if(old.manifest!=p.grant_manifest||old.digest!=p.program_digest||p.program_revision!=1)refuse("local producer changed existing grant/schema");
            compile_programs(*owner,old,recovery_obligation_producer_store::compile(p,limits.obligations,limits.producers));
            for(const auto& [name,t]:old.tables) {
                if(schema.tables.count(name))refuse("local producer overlapping whole-model contribution grants");
                if(actual_programs(db,name)!=t.enrolled)refuse("local producer changed existing generated program");
            }
            candidate->profiles.push_back({p,std::move(old)});
        }
        for(const auto& [name,t]:schema.tables)if(actual_programs(db,name)!=t.ordinary)refuse("local producer missing/extra/non-generated pre-enrollment trigger");
        const auto program=storage.enroll(profile);
        compile_programs(*owner,schema,program);
        candidate->profiles.push_back({profile,std::move(schema)});
        // Non-writing guards installed before persistent programs. Pending
        // configuration cannot authorize effects until the owned COMMIT.
        register_context(db,candidate);
        db.execute("PRAGMA recursive_triggers=ON");
        if(integer(db.query("PRAGMA recursive_triggers").at(0),"recursive_triggers")!=1)refuse("local producer REPLACE qualification requires recursive triggers");
        if(actual_programs(db,"AuditLog").empty())for(const auto& [name,sql]:retention_programs())db.execute(sql);
        validate_retention_programs(db,true);
        for(const auto& [name,t]:candidate->profiles.back().schema.tables) {
            for(const auto& old:t.ordinary)db.execute("DROP TRIGGER "+old.first);
            for(const auto& installed:t.enrolled)db.execute(installed.second);
        }
        owner->store_recovery_fingerprints();
    },[&] {
        // Monotonic revocation flag is untouched. A concurrent logical close
        // still fences phase 1; pre-admitted phase 2 uses its retained frame.
        candidate->status.store(1,std::memory_order_release);candidate->previous.reset();
    });
    if(candidate && result.state!=recovery_install_state::committed)candidate->status.store(2,std::memory_order_release);
    return result;
}

recovery_install_result recovery_local_producer_adapter::retire_for_qualification(
    std::shared_ptr<lattice_db> owner,const recovery_obligation_address& address,
    const recovery_obligation_producer_discovery_limits& limits) {
    std::shared_ptr<context> candidate;
    auto result=recovery_writer_access::install_impl(owner,[&](database& db) {
        if(owner->recovery_continuous_)refuse("continuous producer cannot use qualification enrollment or retirement");
        validate_limits(limits);validate_custody(*owner,db);management changing(db.internal_handle());
        auto prior=std::static_pointer_cast<context>(std::atomic_load(&db.local_producer_callback_custody_));
        while(prior && prior->status.load(std::memory_order_acquire)==2)prior=prior->previous;
        if(!prior || prior->status.load(std::memory_order_acquire)!=1)refuse("local producer retirement requires admitted connection");
        candidate=std::make_shared<context>();candidate->connection=db.internal_handle();candidate->owner=owner.get();candidate->lifetime=owner->guard_;candidate->previous=prior;candidate->admitted_limits=limits;
        const context::profile* removed=nullptr;
        for(const auto& p:prior->profiles) {
            for(const auto& [name,t]:p.schema.tables)if(actual_programs(db,name)!=t.enrolled)refuse("local producer retirement program mismatch");
            if(p.stored.contribution.binding.channel==address.channel)removed=&p;
            else candidate->profiles.push_back(p);
        }
        if(!removed||removed->stored.contribution_incarnation!=address.incarnation)refuse("local producer retirement incarnation mismatch");
        recovery_obligation_producer_store storage(owner,limits.obligations,limits.installations,limits.producers);
        storage.retire_contribution(address,removed->stored);
        register_context(db,candidate);
        for(const auto& [name,t]:removed->schema.tables) {
            for(const auto& installed:t.enrolled)db.execute("DROP TRIGGER "+installed.first);
            for(const auto& ordinary:t.ordinary)db.execute(ordinary.second);
        }
        owner->store_recovery_fingerprints();
    },[&]{candidate->status.store(1,std::memory_order_release);candidate->previous.reset();});
    if(candidate && result.state!=recovery_install_state::committed)candidate->status.store(2,std::memory_order_release);
    return result;
}

std::shared_ptr<recovery_local_producer_adapter::context> recovery_local_producer_adapter::bootstrap(
    lattice_db& owner,const std::shared_ptr<database>& writer) {
    if(owner.recovery_continuous_&&owner.recovery_continuous_->owner==&owner&&
       owner.recovery_continuous_->state&&owner.recovery_continuous_->state->initialized) {
        // A published continuous replacement is proved by the actual common
        // final transaction below, including all canonical families. Do not
        // enter the old constructor-only bootstrap or borrow a normal BEGIN.
        if(!writer||!writer->delivery_startup_||
           writer->delivery_startup_->continuous_final_owner_(*writer)!=&owner)
            refuse("continuous replacement lacks its actual source1 final role");
        return {}; // final supplier binds its exact pending role before proof
    }
    // Set before any bootstrap metadata read: even a refused read can make
    // SQLite's optional close-time optimize decide to ANALYZE. A refusal must
    // leave the durable schema/cookie intact for the original valid owner.
    // Only success restores the prior policy; an earlier refusal stays fenced.
    const bool prior_suppression=writer && writer->suppress_destructor_optimize_;
    if(writer)writer->suppress_destructor_optimize_=true;
    if(!writer)refuse("local producer bootstrap requires retained physical connection");
    auto initialization=recovery_obligation_bootstrap_reader::create_(*writer,discovery_caps,
        recovery_continuous_producer::shared_install_domains(owner));
    std::shared_ptr<context> c;
    recovery_obligation_producer_store::bootstrap_profiles(writer,discovery_caps,
        [&](database& view,const recovery_obligation_producer_inventory& inventory) {
            if(!inventory.initialized)return;
            // Storage-only initialization can predate first enrollment. Empty
            // families allow absent guards or the exact retained dormant bundle;
            // partial/replaced programs always refuse, active profiles need all.
            validate_retention_programs(view,!inventory.profiles.empty(),initialization.get());
            if(inventory.profiles.empty())return;
            validate_custody(owner,view,initialization.get());
            const bool continuous=(initialization?!initialization->query_(bootstrap_kind::continuous_presence,{std::string(continuous_table)}).empty():view.table_exists(continuous_table));
            if(continuous&&initialization&&(!owner.delivery_startup_||
               !recovery_continuous_producer::pending_startup_matches_(owner,*owner.delivery_startup_)))
                refuse("ordinary initialization cannot adopt continuous producer custody");
            if(continuous!=static_cast<bool>(owner.recovery_continuous_))refuse("continuous lineage requires actual retained factory; no legacy adoption");
            if(continuous)continuous_verify_row(view,*owner.recovery_continuous_->state,false,initialization.get());
            if(recovery_local_producer_test_hooks::after_inventory)recovery_local_producer_test_hooks::after_inventory();
            c=std::make_shared<context>();c->connection=view.internal_handle();c->owner=&owner;c->lifetime=owner.guard_;
            c->admitted_limits={inventory.stored_obligation_limits,inventory.stored_installation_limits,inventory.stored_producer_limits};
            c->continuous=owner.recovery_continuous_;
            std::set<std::string> relations;
            for(const auto& p:inventory.profiles) {
                auto d=describe(owner,view,grant_from(p),false,initialization.get());
                if(p.program_revision!=(continuous?(continuous_receiver_enabled(*c->continuous->state)?3:2):1)||d.manifest!=p.grant_manifest||d.digest!=p.program_digest)refuse("local producer bootstrap descriptor/program revision mismatch");
                if(!continuous)compile_programs(owner,d,recovery_obligation_producer_store::compile(p,inventory.stored_obligation_limits,inventory.stored_producer_limits));
                if(!continuous)for(const auto& [name,t]:d.tables) {
                    if(!relations.insert(name).second)refuse("local producer bootstrap overlapping grants");
                    if(actual_programs(view,name,initialization.get())!=t.enrolled)refuse("local producer bootstrap generated program mismatch");
                }
                c->profiles.push_back({p,std::move(d)});
            }
            if(continuous) {
                compile_continuous(owner,*c);
                if(!c->matches_complete_programs(view,initialization.get())) {
                    if(!continuous_receiver_enabled(*c->continuous->state))refuse("continuous complete generated program differs");
                    // One complete historical bundle is the only alternative.
                    // Never select old/new programs separately by trigger or table.
                    c->legacy_distinct_count_programs=true;
                    compile_continuous(owner,*c);
                    if(!c->matches_complete_programs(view,initialization.get()))refuse("continuous complete generated program differs");
                }
            }
        },recovery_continuous_producer::shared_install_domains(owner),initialization.get());
    if(!c) {
        writer->suppress_destructor_optimize_=prior_suppression;
        return {};
    }
    // Inventory, descriptor and exact trigger bytes were read in ONE owned
    // snapshot. A later sibling retirement is still a separate lifetime event;
    // final owned profile discovery rereads storage and refuses stale custody.
    database::maintenance_scope maintenance(*writer);
    register_context(*writer,c);
    {management changing(c->connection);if(initialization)initialization->registration_enable_();else writer->execute("PRAGMA recursive_triggers=ON");}
    if(integer((initialization?initialization->registration_getter_():writer->query("PRAGMA recursive_triggers")).at(0),"recursive_triggers")!=1)refuse("local producer recursive-trigger setup failed");
    writer->suppress_destructor_optimize_=prior_suppression;
    return c;
}

#include "recovery_producer_continuity.inc"
#include "recovery_continuous_final_proof.inc"

void recovery_local_producer_adapter::publish(lattice_db& owner,database& db) noexcept {
    auto c=std::static_pointer_cast<context>(std::atomic_load(&db.local_producer_callback_custody_));
    if(!c)return;
    const auto* hook=db.lattice_update_hook_context_.get();
    if(c->owner==&owner && c->connection==db.internal_handle() && hook && hook->owner==&owner && hook->connection==c->connection &&
       owner.guard_->alive.load(std::memory_order_acquire) && !db.raw_handle_escaped_.load(std::memory_order_acquire))
        c->status.store(1,std::memory_order_release);
    else c->active->store(false,std::memory_order_release);
}
bool prepare_recovery_local_producer(lattice_db& owner,const std::shared_ptr<database>& writer) {
    return static_cast<bool>(recovery_local_producer_adapter::bootstrap(owner,writer));
}
void publish_recovery_local_producer(lattice_db& owner,database& writer) noexcept {
    recovery_local_producer_adapter::publish(owner,writer);
}
bool preserve_recovery_local_producer_relation(database& db,const std::string& name) {
    const auto c=std::static_pointer_cast<recovery_local_producer_adapter::context>(std::atomic_load(&db.local_producer_callback_custody_));
    if(!c)return false;
    const auto* effective=c->effective();if(!effective)return false;
    for(const auto& p:effective->profiles)if(p.schema.tables.count(name)) {
        if(!c->active->load(std::memory_order_acquire))refuse("local producer relation admission revoked");
        return true;
    }
    return false;
}
void require_recovery_local_producer_maintenance_absent(database& db) {
    const auto c=std::static_pointer_cast<recovery_local_producer_adapter::context>(std::atomic_load(&db.local_producer_callback_custody_));
    const auto* effective=c?c->effective():nullptr;
    if((effective && !effective->profiles.empty())||durable_producer_present(db))refuse("local producer retention/history/reset integration is not active");
}
std::vector<recovery_obligation_producer_profile> recovery_local_producer_adapter::profiles_for_owned_write(
    std::shared_ptr<lattice_db> owner,const recovery_obligation_producer_discovery_limits& limits) {
    validate_limits(limits);
    if(!owner)refuse("local producer discovery requires retained owner");
    auto* writer=recovery_writer_access::active_writer(*owner);
    if(!writer)refuse("local producer discovery requires actual owned WRITE");
    const auto c=std::static_pointer_cast<context>(std::atomic_load(&writer->local_producer_callback_custody_));
    // An owner may have opened BEFORE a sibling enrolled. Missing local
    // callback custody is not proof of durable profile absence.
    const auto family=writer->query("SELECT name FROM main.sqlite_schema WHERE name IN ('_lattice_obligation_producer_store','_lattice_obligation_producer_profile','_lattice_obligation_producer_stamp') LIMIT 4");
    if(family.empty()) {
        if(c && c->effective() && !c->effective()->profiles.empty())refuse("local producer admitted family disappeared");
        return {};
    }
    if(family.size()!=3)refuse("local producer discovery found incomplete durable family");
    recovery_obligation_producer_store storage(owner,limits.obligations,limits.installations,limits.producers);
    auto stored=storage.profiles();
    if(!c) {
        if(!stored.empty())refuse("local producer durable profiles lack physical admission");
        return {};
    }
    const auto* effective=c->effective();
    if(!effective || effective->status.load(std::memory_order_acquire)!=1 || !c->active->load(std::memory_order_acquire) ||
       effective->owner!=owner.get()||effective->connection!=writer->internal_handle()||owner->is_closed()||
       writer->raw_handle_escaped_.load(std::memory_order_acquire))refuse("local producer discovery lacks current physical admission");
    if(stored.size()!=effective->profiles.size())refuse("local producer stored/admitted inventory mismatch");
    for(const auto& p:stored) {
        bool found=false;for(const auto& admitted:effective->profiles)if(p==admitted.stored){found=true;break;}
        if(!found)refuse("local producer stored/admitted profile mismatch");
    }
    return stored;
}
bool recovery_local_producer_adapter::export_protection_required(std::shared_ptr<lattice_db> owner) {
    return *export_protection_impl(std::move(owner),false);
}
std::optional<bool> recovery_local_producer_adapter::try_automatic_export_protection(std::shared_ptr<lattice_db> owner) {
    return export_protection_impl(std::move(owner),true);
}
std::optional<bool> recovery_local_producer_adapter::export_protection_impl(std::shared_ptr<lattice_db> owner,bool automatic) {
    if(!owner)refuse("export discovery requires a retained owner");
    std::shared_ptr<database> writer;
    {
        std::lock_guard<std::mutex> lock(owner->connection_ownership_mutex_);
        if(owner->closed_.load())refuse("export discovery owner is closed");
        writer=owner->db_;
    }
    if(!writer)refuse("export discovery has no published writer");
    store_physical_native_scope physical_call(*writer);
    if(!physical_call.entered())refuse("resource Native caller original unavailable");
    auto* db=writer->internal_handle();auto* mutex=db?lattice_sqlite3541_db_mutex(db):nullptr;
#ifndef __EMSCRIPTEN__
    if(!mutex)refuse("export discovery requires a serialized connection");
#endif
    const auto validate_deferred_owner=[&] {
        // No SQLite calls on a busy mutex; this is retained owner identity,
        // never authority to use an unvalidated snapshot or writer.
        std::lock_guard<std::mutex> lock(owner->connection_ownership_mutex_);
        if(owner->closed_.load()||owner->db_!=writer||writer->is_closed())
            refuse("export discovery admission invalidated");
        const auto allowed=std::atomic_load(&writer->local_producer_write_allowed_);
        if(allowed&&!allowed->load(std::memory_order_acquire))refuse("export discovery admission revoked");
    };
    const auto probe=lattice_sqlite3541_mutex_try(mutex);
    if(probe==LATTICE_SQLITE3541_BUSY) {
        if(!automatic)throw export_discovery_busy();
        validate_deferred_owner();return std::nullopt;
    }
    if(probe!=LATTICE_SQLITE3541_OK)refuse("export discovery writer mutex failed");
    struct unlock {lattice_sqlite3541_mutex* mutex;~unlock(){lattice_sqlite3541_mutex_leave(mutex);}} release{mutex};
    const auto validate_owner=[&] {
        const auto* hook=writer->lattice_update_hook_context_.get();
        std::lock_guard<std::mutex> lock(owner->connection_ownership_mutex_);
        if(!db||writer->is_closed()||owner->closed_.load()||owner->db_!=writer||
           !hook||hook->owner!=owner.get()||hook->connection!=db||
           writer->channel_reset_unsettled_.load(std::memory_order_acquire)||
           database::update_hook_scope::active_for(db))
            refuse("export discovery captured writer is unavailable");
    };
    validate_owner();
    // A preexisting read snapshot may predate sibling enrollment. Only an
    // idle connection or the actual current owned WRITE can classify absence.
    const bool idle=lattice_sqlite3541_get_autocommit(db)!=0&&lattice_sqlite3541_txn_state(db,"main")==LATTICE_SQLITE3541_TXN_NONE;
    const bool owned_write=!idle&&lattice_sqlite3541_txn_state(db,"main")==LATTICE_SQLITE3541_TXN_WRITE&&
        recovery_writer_access::active_writer(*owner)==writer.get();
    if(automatic&&!owned_write) {
        // A busy SELECT without a main read transaction still needs provenance;
        // so does same-thread query/callback reentry even when main is idle.
        const auto admission=database::maintenance_scope::controller_classify_locked(*writer, &owner->txn_owner_thread_);
        if(admission==database::maintenance_scope::admission::engine_read_busy ||
           admission==database::maintenance_scope::admission::core_write_busy) {
            validate_deferred_owner();return std::nullopt;
        }
    }else if(!idle&&!owned_write)
        refuse("export discovery requires a fresh view or actual owned WRITE");
    const auto root=std::static_pointer_cast<context>(std::atomic_load(&writer->local_producer_callback_custody_));
    const auto* admitted=root?root->effective():nullptr;
    const bool has_admitted=admitted&&!admitted->profiles.empty();
    // Leave this VM at ROW until every dependent metadata read has finished.
    // It pins one fresh main snapshot without beginning/settling a transaction
    // or entering the notification-draining database query funnel.
    discovery_statement anchor(db,"SELECT 1 FROM main.sqlite_schema LIMIT 1");
    const bool schema_present=anchor.row();
    if(!schema_present&&has_admitted)refuse("export admitted producer schema disappeared");
    const bool result=schema_present&&discovery_family_present(db,has_admitted);
    validate_owner();
    return result;
}
recovery_local_export_inventory recovery_local_producer_adapter::export_inventory_for_owned_write(std::shared_ptr<lattice_db> owner) {
    if(!owner)refuse("export inventory requires retained owner");
    auto* writer=recovery_writer_access::active_writer(*owner);
    if(!writer)refuse("export inventory requires actual owned WRITE");
    const auto context_root=std::static_pointer_cast<context>(std::atomic_load(&writer->local_producer_callback_custody_));
    const auto* admitted=context_root?context_root->effective():nullptr;
    const auto family=writer->query("SELECT name FROM main.sqlite_schema WHERE name IN ('_lattice_obligation_producer_store','_lattice_obligation_producer_profile','_lattice_obligation_producer_stamp') LIMIT 4");
    if(family.empty()) {
        if(admitted&&!admitted->profiles.empty())refuse("export admitted producer family disappeared");
        return {};
    }
    if(family.size()!=3)refuse("export incomplete durable producer family");
    const auto count=writer->query("SELECT COUNT(*) AS n FROM (SELECT 1 FROM main._lattice_obligation_producer_profile LIMIT 17)");
    const auto n=integer(count.at(0),"n");
    if(n<0||n>16)refuse("export producer inventory bound");
    if(n==0 && (!admitted||admitted->profiles.empty()))return {};
    if(!admitted || admitted->status.load(std::memory_order_acquire)!=1 ||
       !context_root->active->load(std::memory_order_acquire)||!admitted->active->load(std::memory_order_acquire)||
       !admitted->lifetime->alive.load(std::memory_order_acquire)||owner->is_closed()||
       admitted->owner!=owner.get()||admitted->connection!=writer->internal_handle()||
       writer->raw_handle_escaped_.load(std::memory_order_acquire)||static_cast<size_t>(n)!=admitted->profiles.size())
        refuse("export producer inventory lacks current physical admission");
    validate_limits(admitted->admitted_limits);
    recovery_local_export_inventory result;result.limits=admitted->admitted_limits;result.continuous=static_cast<bool>(admitted->continuous);
    recovery_obligation_store journal(owner,result.limits.obligations,result.limits.installations);
    for(const auto& profile:admitted->profiles) {
        const auto& p=profile.stored;
        // Full manifest/program validation belongs to enrollment/bootstrap.
        // Engine-owned profile mutation is forbidden while admitted. This hot
        // addressed check deliberately neither copies nor compares its bytes.
        const auto rows=writer->query("SELECT 1 AS ok FROM main._lattice_obligation_producer_profile WHERE channel=? AND typeof(channel)='blob' AND typeof(incarnation)='integer' AND incarnation=? AND typeof(program_revision)='integer' AND program_revision=? AND typeof(program_digest)='blob' AND program_digest=? AND typeof(manifest)='blob' AND length(manifest)=? LIMIT 2",
            {blob(p.contribution.binding.channel.begin(),p.contribution.binding.channel.end()),p.contribution_incarnation,p.program_revision,
             blob(p.program_digest.begin(),p.program_digest.end()),static_cast<int64_t>(p.grant_manifest.size())});
        const auto scope=journal.read(p.contribution.binding.channel);
        if(rows.size()!=1||!scope||scope->profile!=p.contribution||scope->address.incarnation!=p.contribution_incarnation)
            refuse("export durable producer binding changed");
        recovery_local_export_scope item;item.contribution=*scope;item.program_revision=p.program_revision;item.program_digest=p.program_digest;
        for(const auto& [name,table]:profile.schema.tables)
            item.tables.push_back({name,table.columns,table.no_history,table.link});
        result.scopes.push_back(std::move(item));
    }
    return result;
}
} // namespace lattice::detail

namespace lattice {
std::shared_ptr<detail::configured_managed_handlers> lattice_db::configured_listener_cell(){
    require_creator_process();
#ifndef __EMSCRIPTEN__
    if(is_closed())throw db_error("application listener registration is retired");
    detail::native_retirement_storage<std::shared_ptr<detail::configured_managed_handlers>,std::shared_ptr<detail::configured_managed_handlers>> held;
    auto& current=held.get<0>();auto& candidate=held.get<1>();
    current=std::atomic_load(&managed_wss_handlers_);if(current)return std::move(current);
    candidate=std::make_shared<detail::configured_managed_handlers>();
    if(detail::configured_recovery_test_hooks::before_listener_publication)
        detail::configured_recovery_test_hooks::before_listener_publication();
    if(!owns_creator_process())return {};
    {std::lock_guard<std::mutex> lock(managed_wss_mutex_);
        if(is_closed())throw db_error("application listener registration is retired");
        current=std::atomic_load(&managed_wss_handlers_);
        if(!current){std::atomic_store(&managed_wss_handlers_,candidate);current=candidate;}
    }
    return std::move(current);
#else
    return {};
#endif
}
bool lattice_db::remember_configured_state(const synchronizer::on_state_change_handler& handler){
    require_creator_process();
#ifndef __EMSCRIPTEN__
    detail::native_retirement_storage<std::shared_ptr<const synchronizer::on_state_change_handler>,std::shared_ptr<detail::configured_managed_handlers>> held;
    held.get<0>()=std::make_shared<const synchronizer::on_state_change_handler>(handler);
    if(!owns_creator_process())return false;
    held.get<1>()=configured_listener_cell();
    if(!owns_creator_process()||!held.get<1>())return false;
    const bool published=held.get<1>()->publish_state(std::move(held.get<0>()));
    if(!owns_creator_process())return false;
    return published;
#else
    return !is_closed();
#endif
}
bool lattice_db::remember_configured_error(const synchronizer::on_error_handler& handler){
    require_creator_process();
#ifndef __EMSCRIPTEN__
    detail::native_retirement_storage<std::shared_ptr<const synchronizer::on_error_handler>,std::shared_ptr<detail::configured_managed_handlers>> held;
    held.get<0>()=std::make_shared<const synchronizer::on_error_handler>(handler);
    if(!owns_creator_process())return false;
    held.get<1>()=configured_listener_cell();
    if(!owns_creator_process()||!held.get<1>())return false;
    const bool published=held.get<1>()->publish_error(std::move(held.get<0>()));
    if(!owns_creator_process())return false;
    return published;
#else
    return !is_closed();
#endif
}
bool lattice_db::remember_configured_progress(const synchronizer::on_progress_handler& handler){
    require_creator_process();
#ifndef __EMSCRIPTEN__
    detail::native_retirement_storage<std::shared_ptr<const synchronizer::on_progress_handler>,std::shared_ptr<detail::configured_managed_handlers>> held;
    held.get<0>()=std::make_shared<const synchronizer::on_progress_handler>(handler);
    if(!owns_creator_process())return false;
    held.get<1>()=configured_listener_cell();
    if(!owns_creator_process()||!held.get<1>())return false;
    const bool published=held.get<1>()->publish_progress(std::move(held.get<0>()));
    if(!owns_creator_process())return false;
    return published;
#else
    return !is_closed();
#endif
}
void lattice_db::begin_configured_listener_retirement(){
    require_creator_process();
#ifndef __EMSCRIPTEN__
    detail::native_retirement_storage<std::shared_ptr<detail::configured_managed_handlers>> held;
    {std::lock_guard<std::mutex> lock(managed_wss_mutex_);held.get<0>()=std::atomic_load(&managed_wss_handlers_);}
    if(held.get<0>())held.get<0>()->retire_publication();
#endif
}
bool lattice_db::retire_configured_listener_targets(){
    require_creator_process();
#ifndef __EMSCRIPTEN__
    if(detail::configured_recovery_test_hooks::before_listener_retirement_preparation)
        detail::configured_recovery_test_hooks::before_listener_retirement_preparation();
    require_creator_process(); // Actual hook can throw or fork before preparation.
#endif
    detail::native_retirement_storage<synchronizer::on_state_change_handler,synchronizer::on_error_handler,
        synchronizer::on_progress_handler,std::shared_ptr<detail::configured_managed_handlers>,
        std::shared_ptr<detail::configured_recovery_connection>> held;
    {std::lock_guard<std::mutex> lock(managed_wss_mutex_);
        if(!is_closed())return false;
        held.get<0>().swap(on_sync_state_change_);held.get<1>().swap(on_sync_error_);held.get<2>().swap(on_sync_progress_);
    }
    if(!held.release<0>()||!held.release<1>()||!held.release<2>())return false;
#ifndef __EMSCRIPTEN__
    held.get<4>()=configured_connection();if(held.get<4>()&&!held.get<4>()->cleanup_complete())return false;
    held.get<3>()=std::atomic_load(&managed_wss_handlers_);
    const bool disposed=!held.get<3>()||held.get<3>()->dispose_retired();
    if(!owns_creator_process())return false;
    return disposed;
#else
    return true;
#endif
}
bool lattice_db::finish_configured_listener_retirement(){
    require_creator_process();
    const bool disposed=retire_configured_listener_targets();
    if(!owns_creator_process())return false;
#ifndef __EMSCRIPTEN__
    detail::native_retirement_storage<std::shared_ptr<const detail::ordinary_managed_owner_release>> held;
    {std::lock_guard<std::mutex> lock(managed_wss_mutex_);held.get<0>()=managed_wss_start_release_;}
    if(held.get<0>()){
        if(!held.get<0>()->start_fields_destroyed())return false;
        if(const auto error=held.get<0>()->start_cleanup_error())std::rethrow_exception(error);
    }
#endif
    return disposed;
}
std::shared_ptr<detail::configured_recovery_connection> lattice_db::configured_connection()const noexcept{
    if(!owns_creator_process())return {};
#ifndef __EMSCRIPTEN__
    {std::lock_guard<std::mutex> lock(managed_wss_mutex_);if(managed_wss_connection_)return managed_wss_connection_;}
    const auto admission=recovery_continuous_;if(!admission)return {};
    std::lock_guard<std::mutex> lock(admission->configured_mutex);return admission->configured;
#else
    return {};
#endif
}
bool lattice_db::configured_sync_present()const noexcept{return bool(configured_connection());}
#ifndef __EMSCRIPTEN__
bool lattice_db::configured_sync_connected()const{const auto owner=configured_connection();return owner&&owner->connected();}
void lattice_db::configured_sync_now(){if(auto owner=configured_connection())owner->sync_now();}
void lattice_db::configured_sync_upload(){if(auto owner=configured_connection())owner->trigger_upload();}
void lattice_db::configured_sync_connect(){if(auto owner=configured_connection())owner->connect();}
void lattice_db::configured_sync_disconnect(){if(auto owner=configured_connection())owner->disconnect();}
void lattice_db::configured_sync_state(std::function<void(bool)> handler){
    require_creator_process();
    detail::native_retirement_storage<std::shared_ptr<detail::configured_recovery_connection>,synchronizer::on_state_change_handler> retained;
    retained.get<1>().swap(handler);retained.get<0>()=configured_connection();
    if(retained.get<0>())retained.get<0>()->set_state(std::move(retained.get<1>()));
}
void lattice_db::configured_sync_error(std::function<void(const std::string&)> handler){
    require_creator_process();
    detail::native_retirement_storage<std::shared_ptr<detail::configured_recovery_connection>,synchronizer::on_error_handler> retained;
    retained.get<1>().swap(handler);retained.get<0>()=configured_connection();
    if(retained.get<0>())retained.get<0>()->set_error(std::move(retained.get<1>()));
}
void lattice_db::configured_sync_progress(synchronizer::on_progress_handler handler){
    require_creator_process();
    detail::native_retirement_storage<std::shared_ptr<detail::configured_recovery_connection>,synchronizer::on_progress_handler> retained;
    retained.get<1>().swap(handler);retained.get<0>()=configured_connection();
    if(retained.get<0>())retained.get<0>()->set_progress(std::move(retained.get<1>()));
}
synchronizer::sync_progress lattice_db::configured_sync_progress()const{if(auto owner=configured_connection())return owner->progress();return {};}
lattice_close_result lattice_db::configured_sync_close(std::chrono::steady_clock::time_point deadline)noexcept{if(auto owner=configured_connection())return owner->close(deadline);return {};}
#else
bool lattice_db::configured_sync_connected()const{return false;}
void lattice_db::configured_sync_now(){}
void lattice_db::configured_sync_upload(){}
void lattice_db::configured_sync_connect(){}
void lattice_db::configured_sync_disconnect(){}
void lattice_db::configured_sync_state(std::function<void(bool)>){ }
void lattice_db::configured_sync_error(std::function<void(const std::string&)>){ }
void lattice_db::configured_sync_progress(synchronizer::on_progress_handler){ }
synchronizer::sync_progress lattice_db::configured_sync_progress()const{return {};}
lattice_close_result lattice_db::configured_sync_close(std::chrono::steady_clock::time_point)noexcept{return {};}
#endif
}
