#pragma once
#include "recovery_local_producer.hpp"
#include <array>

namespace lattice { class swift_lattice_ref; }
namespace lattice::detail {
class recovery_receiver_controller;
class recovery_receiver_route;
class recovery_reconciliation_descriptor;
struct recovery_reconciliation_cohort;
class receiver_source_binding;
class sync_callback_lifetime;
enum class recovery_continuous_receiver_profile : int64_t { disabled=0, full_canonical_v2=2 };
// Private opt-in storage/route policy. These spellings do not authenticate a
// source or namespace. The actual accepted application/TLS issuer is separate.
struct recovery_continuous_contribution {
    recovery_obligation_profile profile;
    std::vector<std::string> models;
    std::vector<uint8_t> incoming_grant_claim;
};
struct recovery_continuous_route_policy {
    std::string sync_id, endpoint;
    bool operator==(const recovery_continuous_route_policy&) const = default;
};
struct recovery_continuous_policy {
    std::vector<recovery_continuous_contribution> contributions;
    std::vector<recovery_continuous_route_policy> routes;
    recovery_obligation_producer_discovery_limits limits{};
    // Counts are admission caps, not a queue or a promise to buffer writes.
    size_t owners=0, physical_routes=0, operations=0, frozen_entries=0;
    uint64_t frozen_bytes=0;
    recovery_continuous_receiver_profile receiver=recovery_continuous_receiver_profile::disabled;
};
class recovery_continuous_producer;
class observer_delivery_initialization_plan;
class observer_delivery_initialization_meter;
class observer_delivery_initialization_sql;
class observer_delivery_initialization_preimage;
class observer_delivery_startup;
class observer_delivery_open_startup;
struct recovery_continuous_startup_test_access;
class recovery_obligation_bootstrap_reader;
class recovery_obligation_bootstrap_statement;
struct ordinary_schema_projection;
class store_resource_continuous_startup;
class recovery_continuous_route;
class recovery_continuous_work;
struct recovery_continuous_admission;
struct recovery_continuous_state;
class verified_unsent_set {
    friend class recovery_continuous_producer;
    std::shared_ptr<lattice_db> owner_;
    std::weak_ptr<lattice_db> controller_owner_;
    std::weak_ptr<recovery_continuous_state> state_;
    int64_t incarnation_=0,barrier_=0;
    std::vector<recovery_obligation_snapshot> journals_;
    std::string policy_digest_;
    std::vector<std::string> originals_;
    verified_unsent_set()=default;
public:
    verified_unsent_set(const verified_unsent_set&)=default;
    verified_unsent_set(verified_unsent_set&&) noexcept=default;
    verified_unsent_set& operator=(const verified_unsent_set&)=default;
    verified_unsent_set& operator=(verified_unsent_set&&) noexcept=default;
    // Read-only local provenance. Neither these rows nor this object's
    // existence authorize source receipts, an install, ACK, or a remote peer.
    const std::vector<recovery_obligation_snapshot>& frozen_journals()const noexcept{return journals_;}
    const std::vector<std::string>& canonical_originals()const noexcept{return originals_;}
};
class recovery_continuous_barrier {
    friend class recovery_continuous_producer;
    std::shared_ptr<lattice_db> owner_;
    std::weak_ptr<recovery_continuous_state> state_;
    int64_t incarnation_=0,barrier_=0,attempt_=0;
    recovery_continuous_barrier()=default;
public:
    recovery_continuous_barrier(const recovery_continuous_barrier&)=default;
};
struct recovery_continuous_open_result {
    recovery_install_result settlement;
    std::shared_ptr<lattice_db> owner;
    // Actual later owner close failure is distinct from the install's first
    // rollback cleanup error. With no prior cleanup it also occupies that
    // existing compatibility slot; both references then describe ONE error.
    std::exception_ptr owner_close_error;
};
struct recovery_continuous_quiescence {
    recovery_install_result settlement;
    bool waiting=false;
    std::optional<recovery_continuous_barrier> barrier;
    std::optional<verified_unsent_set> unsent;
};
// Internal counted cells are constructed only at the actual native WSS route
// and retained through preparation/handoff. Destruction settles local work; it
// never clears durable claims or establishes remote cancellation.
class recovery_continuous_work {
    friend class recovery_continuous_producer;
    std::shared_ptr<recovery_continuous_state> state_;
    std::shared_ptr<lattice_db> owner_;
    uint64_t route_=0, physical_=0;
    int64_t incarnation_=0;
    std::shared_ptr<const recovery_reconciliation_descriptor> reconciliation_;
    std::shared_ptr<recovery_continuous_route> restricted_route_;
    recovery_continuous_work()=default;
public:
    ~recovery_continuous_work();
    recovery_continuous_work(const recovery_continuous_work&)=delete;
    recovery_continuous_work& operator=(const recovery_continuous_work&)=delete;
};
class recovery_continuous_route {
    friend class recovery_continuous_producer;
    friend struct configured_attempt;
    std::shared_ptr<recovery_continuous_state> state_;
    std::weak_ptr<lattice_db> owner_;
    uint64_t route_=0;
    int64_t incarnation_=0;
    std::function<void()> configured_unregistered_;
    recovery_continuous_route()=default;
public:
    ~recovery_continuous_route();
    recovery_continuous_route(const recovery_continuous_route&)=delete;
    recovery_continuous_route& operator=(const recovery_continuous_route&)=delete;
};
class controller_store_ending;
class store_deletion_operation;
class recovery_continuous_producer {
    friend class observer_delivery_startup;
    friend class store_resource_initialization_original;
    friend class observer_delivery_open_startup;
    friend class observer_delivery_initialization_plan;
    static void execute_final_meter_(const observer_delivery_open_startup&,database&,
        const observer_delivery_initialization_plan&,const observer_delivery_initialization_meter&,
        std::size_t,const observer_delivery_initialization_sql&);
    static void prepare_final_role_(const observer_delivery_open_startup&,database&);
    static void complete_final_role_(const observer_delivery_open_startup&,database&);
    static void require_final_role_registration_(const observer_delivery_open_startup&,database&);
    static const void* prepare_replacement_writer_final_(lattice_db&,database&,database&);
    static void require_replacement_writer_final_(lattice_db&,database&,database&,const void*);
    static void publish_replacement_writer_final_(lattice_db&,database&)noexcept;
    static void append_final_projection_(const observer_delivery_open_startup&,database&,ordinary_schema_projection&);
    static void require_final_state_(const observer_delivery_open_startup&,database&,
        const std::shared_ptr<const observer_delivery_initialization_preimage>&);
    // Journal supplier owns this definition. Catalog completion is insufficient.
    friend class recovery_obligation_bootstrap_reader;
    friend class recovery_obligation_bootstrap_statement;
    friend struct recovery_continuous_startup_test_access;
    friend class store_deletion_operation;
#ifndef __EMSCRIPTEN__
    static controller_store_ending retire_controller_for_deletion(const std::shared_ptr<lattice_db>&);
#endif
    friend class ::lattice::swift_lattice_ref;
    friend struct recovery_continuous_admission;
    // Closed recipe: only native and Swift retained-owner factories construct it.
    // Captures immutable declarations, never an owner or application callback.
    struct owner_recipe {
        std::function<std::shared_ptr<lattice_db>(const configuration&,const std::shared_ptr<recovery_continuous_admission>&)> construct;
        std::function<void(const std::shared_ptr<lattice_db>&)> publish_pointer;
    };
    static recovery_continuous_open_result open_owned(const configuration&,const recovery_continuous_policy&,
        std::shared_ptr<const owner_recipe>);
    friend class recovery_local_producer_adapter;
    friend class recovery_export_adapter;
    friend class recovery_export_route;
    friend class recovery_server_export_endpoint;
    friend class ::lattice::lattice_db;
    friend class ::lattice::database;
    friend class ::lattice::synchronizer_base;
    friend class recovery_receiver_controller;
    friend class recovery_receiver_route;
    friend class recovery_unknown_reconciliation;
    friend class receive_install_store;
    friend class recovery_obligation_store;
    friend class recovery_obligation_producer_store;
    friend std::shared_ptr<database> open_continuous_writer(const configuration&,const std::shared_ptr<recovery_continuous_admission>&,const std::shared_ptr<observer_delivery_startup>&,const recovery_owner_schema&);
    friend void require_continuous_legacy_export_absent(database&);
    friend void require_continuous_raw_handle_absent(database&);
    friend std::shared_ptr<observer_delivery_startup> select_continuous_startup(
        const configuration&,const recovery_owner_schema&,const std::shared_ptr<recovery_continuous_admission>&);
    static std::shared_ptr<observer_delivery_startup> select_startup_(
        const configuration&,const recovery_owner_schema&,const std::shared_ptr<recovery_continuous_admission>&);
    static std::shared_ptr<recovery_continuous_admission> acquire_(const configuration&,
        const recovery_continuous_policy&,store_resource_continuous_startup,std::chrono::steady_clock::time_point);
    static void classify_open(database&,bool private_admission,bool writable);
    static std::shared_ptr<database> open_writer(const configuration&,
        const std::shared_ptr<recovery_continuous_admission>&,
        const std::shared_ptr<observer_delivery_startup>&,const recovery_owner_schema&);
    // Denial-only exact custody check at the actual post-open owner bind.
    static bool pending_startup_matches_(const lattice_db&,const observer_delivery_startup&)noexcept;
    // Borrow the SAME actual writer source before real Native return/adoption;
    // no facade, SQL, fresh-catalog or resource receipt is synthesized.
    static const store_resource_continuous_startup& pending_resource_startup_(
        const recovery_continuous_admission*,const observer_delivery_startup&,
        const observer_delivery_open_startup&);
    // Genuine pre-enrollment origin, issued by the retained container creator.
    // Null means existing/noncontinuous; malformed actual custody throws.
    static const recovery_continuous_admission* pending_fresh_catalog_original_(
        const lattice_db&,database&,const observer_delivery_startup&);
    friend class observer_delivery_open_startup;
    static bool enrollment_startup_matches_(const lattice_db&,const observer_delivery_startup&)noexcept;
    // DATA-only binding to the actual retained enrollment. The issuer derives
    // discovery caps/domain from that same admission; callers supply no grant.
    static const recovery_continuous_admission* enrollment_reader_binding_(
        const lattice_db&,const database&,recovery_obligation_producer_discovery_limits* =nullptr,bool* =nullptr)noexcept;
    static bool enrollment_reader_fresh_(const lattice_db&,const database&,const recovery_continuous_admission*)noexcept;
    // Distinct journal-bound resume, never a new fresh classification or cap.
    static bool enrollment_reader_resume_(const lattice_db&,const database&,const recovery_continuous_admission*);
    static std::array<unsigned char,32> enrollment_policy_digest_(const recovery_continuous_admission*,
        const observer_delivery_open_startup&,database&);
    // Denial-only seam for the separately generated exact final corpus proof.
    static void require_enrollment_final_(const lattice_db&,const database&,const observer_delivery_open_startup&);
    static const receive_install_binding& enrollment_receiver_binding_(const lattice_db&,const database&,
        const recovery_continuous_admission*,std::size_t);
    // Actual pre-enrollment producer controls, never caller SQL or a model-row
    // grant. Fixed entries retain this same actual pending Open and budget.
    static void initialize_connection_durability_(database&);
    static bool fresh_schema_present_(database&);
    static void append_initialization_projection_(ordinary_schema_projection&,
        const recovery_obligation_bootstrap_reader&);
    static void verify_initializing_lineage_(database&,recovery_continuous_state&);
    static std::shared_ptr<recovery_continuous_route> admit_route(
        std::shared_ptr<lattice_db>,const sync_config&,bool injected);
    static std::shared_ptr<recovery_continuous_work> admit_work(
        const std::shared_ptr<recovery_continuous_route>&,std::shared_ptr<lattice_db>,uint64_t);
    static void verify_work(const std::shared_ptr<recovery_continuous_work>&,lattice_db&,database&);
    static std::shared_ptr<recovery_continuous_work> admit_reconciliation_work(
        const std::shared_ptr<const recovery_reconciliation_descriptor>&,
        const std::shared_ptr<recovery_continuous_route>&,std::shared_ptr<lattice_db>,uint64_t physical);
    static recovery_install_result reconciliation_export_owned(std::shared_ptr<lattice_db>,
        const std::shared_ptr<recovery_continuous_work>&,const std::vector<std::string>& ordered_originals,
        const std::function<void(database&)>&,bool* admission_busy=nullptr,bool automatic=false,
        const std::function<void()>& after_committed_unlock={});
    // Optional busy output is set only before entering the owned body.
    static recovery_install_result export_owned(std::shared_ptr<lattice_db>,
        const std::shared_ptr<recovery_continuous_work>&,const std::function<void(database&)>&,
        bool* initial_admission_busy = nullptr,bool automatic=false);
    static void setup_configured_route(lattice_db&);
    static bool attached(const lattice_db&) noexcept;
    static bool shared_install_domains(const lattice_db&)noexcept;
    static void require_no_continuous_export(database&);
    static void require_no_continuous_route(lattice_db&);
    static recovery_install_result enroll(std::shared_ptr<lattice_db>);
    static std::shared_ptr<recovery_receiver_route> attach_receiver(
        const std::shared_ptr<recovery_continuous_route>&,std::shared_ptr<lattice_db>,
        const std::shared_ptr<receiver_source_binding>&,const std::shared_ptr<owned_platform_sync_transport>&,
        const std::shared_ptr<scheduler>&,const std::shared_ptr<sync_callback_lifetime>&);
    enum class cohort_admission { available, retained };
    static cohort_admission controller_cohort(const recovery_receiver_controller&,
        const std::shared_ptr<lattice_db>&,
        const std::shared_ptr<recovery_reconciliation_descriptor>& candidate = {});
    static bool reconciliation_work_current(const std::shared_ptr<recovery_continuous_work>&,
        const std::shared_ptr<lattice_db>&);
    static recovery_install_result controller_owned(const recovery_receiver_controller&,
        std::shared_ptr<lattice_db>,const std::function<void(database&)>&,bool controller_try=false);
    static recovery_continuous_quiescence begin_impl(std::shared_ptr<lattice_db>,int64_t,bool controller_try);
    static recovery_continuous_quiescence inspect_impl(std::shared_ptr<lattice_db>,bool controller_try);
    static recovery_continuous_quiescence finish_impl(const recovery_continuous_barrier&,bool controller_try);
    static void controller_park_proof(verified_unsent_set&);
    static int64_t controller_next_attempt_owned(std::shared_ptr<lattice_db>);
    static const recovery_owner_schema& controller_catalog(const lattice_db&)noexcept;
    static void controller_installed_owned(const recovery_receiver_controller&,
        const verified_unsent_set&);
    static void controller_resume_owned(const recovery_receiver_controller&,
        std::shared_ptr<lattice_db>,int64_t barrier,int64_t attempt);
    // Called only after the real receiver controller has terminal-fenced
    // every source Q and canceled the exact complete local frozen cohort.
    static void controller_restart_terminal_owned(const recovery_receiver_controller&,std::shared_ptr<lattice_db>,
        int64_t physical_incarnation,int64_t barrier,int64_t attempt);
    static void controller_transition_reconcile_owned(const recovery_receiver_controller&,std::shared_ptr<lattice_db>,
        int64_t phase,int64_t barrier,int64_t attempt,int64_t next_phase,int64_t next_barrier,int64_t next_attempt);
    static void controller_publish_reconcile(const recovery_receiver_controller&,std::shared_ptr<lattice_db>,int64_t barrier,int64_t attempt);
    static void controller_publish_resume(const recovery_receiver_controller&,
        std::shared_ptr<lattice_db>,int64_t barrier,int64_t attempt);
public:
    // Actual retained unpublished-owner factory. No borrowed/no-op shared
    // owner may turn constructor setup into the owned enrollment transaction.
    static recovery_continuous_open_result open(const configuration&,const recovery_continuous_policy&);
    static recovery_continuous_quiescence begin(std::shared_ptr<lattice_db>,int64_t logical_attempt);
    // Nonblocking: waiting means admitted work still exists. Caller resumes
    // on its existing scheduler; no wait under SQLite/registry/owner locks.
    static recovery_continuous_quiescence finish(const recovery_continuous_barrier&);
    // Authoritative same-generation inspection, including restart with an
    // already closed durable barrier. Does not reopen admission.
    static recovery_continuous_quiescence inspect(std::shared_ptr<lattice_db>);
    static recovery_install_result cancel(const recovery_continuous_barrier&);
    // Revalidate actual frozen Q, producer stamps, continuous coverage and
    // physical lifetime under the same owned WRITE as a future consumer.
    static void verify_for_owned_write(const verified_unsent_set&);
    // Producer primitives alone grant neither source authority nor recovery.
    // The explicit receiver profile activates only through the real controller.
    static constexpr bool source_authentication_capability=false;
    static constexpr bool automatic_recovery_capability=false;
};
// Read-only/constructor guards. Absence never grants a capability.
void require_continuous_path_unowned(const std::string&);
void require_continuous_legacy_export_absent(database&);
void require_continuous_raw_handle_absent(database&);
} // namespace lattice::detail
