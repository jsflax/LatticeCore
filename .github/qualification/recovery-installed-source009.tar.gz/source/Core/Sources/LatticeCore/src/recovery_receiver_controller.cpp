#include "recovery_receiver_controller.hpp"
#include "recovery_cohort_progress_observation.hpp"
#include "recovery_unknown_reconciliation.hpp"
#include "recovery_export_adapter.hpp"
#include "recovery_receipt_json.hpp"
#include "recovery_request_store.hpp"
#include "recovery_writer_access.hpp"
#include "recovery_predecessor_wire.hpp"
#include "canonical_writer_adapter.hpp"
#include "recovery_witness.hpp"
#include "sync_callback_lifetime.hpp"
#include "recovery_controller_executor.hpp"
#include "controller_store_ending.hpp"
#include <lattice/native_retirement_storage.hpp>
#include "vendor/picosha2/picosha2.h"
#include <lattice/lattice.hpp>
#include <nlohmann/json.hpp>
#include <algorithm>
#include <array>
#include <charconv>
#include <chrono>
#include <set>
#if defined(__APPLE__) || defined(__linux__)
#include <unistd.h>
#endif

namespace lattice::detail {
#ifndef __EMSCRIPTEN__
thread_local recovery_controller_executor::state* recovery_controller_executor::current_ = nullptr;
#endif
namespace {
namespace cr=canonical_range;
using json=nlohmann::json;
constexpr size_t pending_bytes=16777216;
constexpr unsigned admission_retry_attempts=32;
constexpr int64_t admission_retry_window_ms=5000,admission_retry_tick_ms=100;
[[noreturn]] void refuse(const char* reason){throw db_error(reason);}
// Actual returned no-effect admission kind retained only for the existing
// private controller test probe; no retry, grant or public diagnostic channel.
class controller_admission_wait final {
public:
    recovery_install_deferred reason;
    explicit controller_admission_wait(recovery_install_deferred actual)noexcept:reason(actual){}
};
const char* deferred_observation_label(recovery_install_deferred actual)noexcept {
    switch(actual){
        case recovery_install_deferred::connection_mutex:return "admission-deferred-connection-mutex";
        case recovery_install_deferred::engine_read:return "admission-deferred-engine-read";
        case recovery_install_deferred::store_gate:return "admission-deferred-store-gate";
        case recovery_install_deferred::core_write:return "admission-deferred-core-write";
        case recovery_install_deferred::schema_registry:return "admission-deferred-schema-registry";
        case recovery_install_deferred::none:return "admission-deferred-none-unexpected";
    }
    return "admission-deferred-unknown";
}
// Only the two exact disposal-generation guards create this primary marker.
// A primary class alone never grants SQL replay or proves no source effect.
class controller_generation_changed final : public db_error {
public:
    const uint64_t revision;
    controller_generation_changed(uint64_t expected,const char* reason):db_error(reason),revision(expected){}
};
class controller_stale_turn_cancelled final : public db_error {
public:
    const uint64_t revision;
    controller_stale_turn_cancelled(uint64_t expected,const char* reason):db_error(reason),revision(expected){}
};
class controller_generation_unsettled final : public db_error {
public:
    // Preserve every actual outcome/error, including secondary failures, in
    // the fatal exception rather than promoting its primary marker to retry.
    const recovery_install_result settlement;
    controller_generation_unsettled(const controller_generation_changed& primary,const recovery_install_result& result)
        :db_error(primary.what()),settlement(result){}
};
// A failed completed-disposal SQL turn retains the real primary and full
// settlement. It is neither a fresh-demand retry nor a delivery wait. Keep
// older generic install-failure drain behavior outside this narrow operation.
class controller_disposal_refused final : public db_error {
    static std::string reason(const std::exception_ptr& error) {
        try {if(error)std::rethrow_exception(error);}
        catch(const std::exception& value){
            const char* text=value.what();size_t size=0;while(text&&size<2048&&text[size])++size;
            return text?std::string(text,size):std::string("controller completed disposal failed");
        }
        catch(...){}
        return "controller completed disposal failed";
    }
public:
    const std::exception_ptr primary;
    const recovery_install_result settlement;
    controller_disposal_refused(std::exception_ptr error,const recovery_install_result& result)
        :db_error(reason(error)),primary(std::move(error)),settlement(result){}
};
std::uint64_t controller_process()noexcept {
#if defined(__APPLE__) || defined(__linux__)
    return static_cast<std::uint64_t>(::getpid());
#else
    return 1; // Other targets retain existing admission; no added PID check.
#endif
}
class delivery_retry_wait final : public db_error {
public:
    delivery_retry_wait():db_error("controller UNKNOWN persisted after one restricted pass; new external source/request generation or actual delivery timeout required"){}
};
void require(bool value,const char* reason){if(!value)refuse(reason);}
int64_t now(){return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();}
json parse(const std::string& raw,size_t cap) {
    require(!raw.empty()&&raw.size()<=cap,"controller frame byte capacity");
    size_t nodes=0;std::vector<std::set<std::string>> keys;
    return json::parse(raw,[&](int depth,json::parse_event_t event,json& value){
        require(depth>=0&&depth<=20&&++nodes<=262144,"controller frame structure capacity");
        if(value.is_string())require(value.get_ref<const std::string&>().size()<=4194304,"controller scalar capacity");
        if(event==json::parse_event_t::object_start)keys.emplace_back();
        if(event==json::parse_event_t::key)require(!keys.empty()&&keys.back().insert(value.get<std::string>()).second,"controller duplicate member");
        if(event==json::parse_event_t::object_end)keys.pop_back();return true;
    });
}
void members(const json& value,std::initializer_list<const char*> required,std::initializer_list<const char*> optional={}) {
    require(value.is_object(),"controller control object required");std::set<std::string> allowed;
    for(const auto* key:required){require(value.contains(key),"controller required control member missing");allowed.insert(key);}
    for(const auto* key:optional)allowed.insert(key);
    for(const auto& item:value.items())require(allowed.count(item.key()),"controller unknown control member");
}
bool repeated_description(const json& value) {
    return value.is_object()&&value.contains("kind")&&value.at("kind")=="recoveryReady"&&
        value.contains("operation")&&value.at("operation")=="describe";
}
void settlement_shape(const json& value) {
    members(value,{"state","unexpectedCommitObserved","primaryError","cleanupError","postcommitError","notificationError"});
    require(value.at("state").is_string(),"controller settlement state type");const auto state=value.at("state").get<std::string>();
    require(state=="refused"||state=="rolledBack"||state=="committed"||state=="unsettled"||state=="ownershipLost"||state=="unknown","controller settlement state unknown");
    for(const auto* key:{"unexpectedCommitObserved","primaryError","cleanupError","postcommitError","notificationError"})require(value.at(key).is_boolean(),"controller settlement flag type");
}
int64_t integer(const database::row_t& row,const char* key) {
    const auto it=row.find(key);require(it!=row.end()&&std::holds_alternative<int64_t>(it->second),"controller durable integer unavailable");return std::get<int64_t>(it->second);
}
uint64_t decimal(const json& row,const char* key,uint64_t minimum=1) {
    const auto& value=row.at(key);require(value.is_string(),"controller normalized decimal required");
    const auto& text=value.get_ref<const std::string&>();require(!text.empty()&&text.size()<=19,"controller decimal capacity");
    uint64_t n=0;const auto parsed=std::from_chars(text.data(),text.data()+text.size(),n);
    require(parsed.ec==std::errc{}&&parsed.ptr==text.data()+text.size()&&n>=minimum&&n<=uint64_t(INT64_MAX)&&std::to_string(n)==text,"controller invalid decimal");return n;
}
std::string source_context(const json& description) {
    json value;for(const auto* key:{"source","incomingScope","peer","channel","profile","upload"})value[key]=description.at(key);
    if(description.contains("receiptBinding"))value["receiptBinding"]=description.at("receiptBinding");
    auto raw=value.dump();require(raw.size()<=recovery_request_store::context_bytes,"controller source context capacity");return raw;
}
std::string domain(const json& description) {
    auto value=json{{"source",description.at("source")},{"incomingScope",description.at("incomingScope")}};
    // Receipt enrollment changes how an original is proved, not which rows
    // this exact canonical authority/catalog replaces. Keep that enrollment
    // in source_context and separately require one binding across the cohort.
    auto& source=value["source"];for(const auto* key:{"receiptNamespace","coverageID","coverageRevision","descriptorDigest","receiptCoverage"})source.erase(key);
    return picosha2::hash256_hex_string(value.dump());
}
cr::source_binding source_binding(const recovery_obligation_profile& profile) {
    const auto& b=profile.binding;return {b.authority,b.source,b.epoch,b.scope,b.schema};
}
bool terminal_profile(const json& description) {
    const auto& p=description.at("profile");
    if(!predecessor_wire::lifecycle_name(p))return false;
    require(p.contains("orphanResumeGraceMilliseconds")&&p.at("orphanResumeGraceMilliseconds").is_number_integer(),"controller terminal profile grace missing");
    const auto grace=p.at("orphanResumeGraceMilliseconds").get<int64_t>();
    require(grace>0&&grace<=3600000,"controller terminal profile grace invalid");return true;
}
json predecessor_profile(const recovery_request_row& row,const json& description) {
    auto old=parse(row.source_context,recovery_request_store::context_bytes);
    require(old.dump()==row.source_context,"controller prior context encoding differs");
    const auto prior=old.at("profile");const auto current=source_context(description);
    old["profile"]=description.at("profile");require(old.dump()==current,"controller predecessor non-profile context changed");
    predecessor_wire::pair(prior,description.at("profile"),description.contains("receiptBinding"));return prior;
}
template<class Proof,class Route,class View> bool compatible_context(const recovery_request_row& row,const json& description,
    const Proof& proof,const Route& route,const View& view,uint64_t revision,int64_t physical,int64_t phase,int64_t barrier,int64_t attempt,
    const cr::limits& caps) {
    const auto current=source_context(description);if(row.source_context==current)return true;
    (void)predecessor_profile(row,description);
    if(!proof||proof->route.lock()!=route||proof->view.value!=view.value||proof->controller_revision!=revision||
        proof->physical!=physical||proof->phase!=phase||proof->barrier!=barrier||proof->attempt!=attempt||
        proof->journal!=row.journal||proof->row_barrier!=row.barrier||proof->row_sequence!=row.sequence||proof->row_revision!=row.journal_revision||
        proof->domain!=row.domain||proof->old_context!=picosha2::hash256_hex_string(row.source_context)||proof->current_context!=picosha2::hash256_hex_string(current))return false;
    const auto q=cr::decode(row.request_frame,caps);
    return q.logical==proof->logical&&std::get<cr::request>(q.body).request_digest==proof->request_digest;
}
void predecessor_reply_shape(const json& value) {
    members(value,{"kind","version","operation","requestID","routeGeneration","settlement","leaseAvailable"},{"predecessor"});
    settlement_shape(value.at("settlement"));
    require(value.at("kind")=="recoveryReady"&&value.at("version").is_number_integer()&&value.at("version")==1&&value.at("operation")=="predecessor"&&
        value.at("requestID").is_string()&&value.at("requestID").get_ref<const std::string&>().size()==36&&canonical_writer_adapter::uuid_key(value.at("requestID").get<std::string>())==value.at("requestID").get_ref<const std::string&>()&&
        value.at("leaseAvailable").is_boolean()&&value.at("leaseAvailable")==false,"controller predecessor envelope differs");
    (void)decimal(value,"routeGeneration");if(!value.contains("predecessor"))return;
    require(value.at("settlement").at("state")=="committed","controller predecessor without known source COMMIT");
    const auto& body=value.at("predecessor");
    members(body,{"version","transitionID","transitionDigest","beforeProfileDigest","afterProfileDigest","sourceIdentityDigest","disposition",
        "requestDigest","attemptID","sequence","namespaceID","replicaID","receiverIncarnation","channelIncarnation","channel"});
    require(body.dump().size()<=predecessor_wire::body_bytes&&body.at("version").is_number_integer()&&body.at("version")==1&&
        body.at("disposition")=="preserveCompleted","controller predecessor body/version differs");
    for(const auto* key:{"transitionDigest","beforeProfileDigest","afterProfileDigest","sourceIdentityDigest","requestDigest"}){
        require(body.at(key).is_string(),"controller predecessor digest type");const auto& s=body.at(key).get_ref<const std::string&>();
        require(s.size()==64&&std::all_of(s.begin(),s.end(),[](char c){return (c>='0'&&c<='9')||(c>='a'&&c<='f');}),"controller predecessor digest bound");}
    for(const auto* key:{"transitionID","attemptID","receiverIncarnation","channelIncarnation"}){
        require(body.at(key).is_string(),"controller predecessor UUID type");const auto s=body.at(key).get<std::string>();
        require(s.size()==36&&canonical_writer_adapter::uuid_key(s)==s,"controller predecessor UUID differs");}
    for(const auto* key:{"namespaceID","replicaID","channel"})require(body.at(key).is_string()&&!body.at(key).get_ref<const std::string&>().empty()&&
        body.at(key).get_ref<const std::string&>().size()<=256&&body.at(key).get_ref<const std::string&>().find('\0')==std::string::npos,"controller predecessor binding text differs");
    (void)decimal(body,"sequence");
}
void late_predecessor_shape(const json& value,const json& description) {
    predecessor_reply_shape(value);require(terminal_profile(description)&&value.at("routeGeneration")==description.at("routeGeneration"),"controller late predecessor route differs");
    if(!value.contains("predecessor"))return;
    const auto& body=value.at("predecessor");const auto& peer=description.at("peer");
    require(body.at("afterProfileDigest")==predecessor_wire::profile_digest(description.at("profile"))&&
        body.at("namespaceID")==description.at("source").at("receiptNamespace")&&body.at("replicaID")==peer.at("replicaID")&&
        body.at("receiverIncarnation")==peer.at("receiverIncarnation")&&body.at("channelIncarnation")==peer.at("channelIncarnation")&&
        body.at("channel")==description.at("channel"),"controller late predecessor authenticated binding differs");
}
void lifecycle_reply_shape(const json& value) {
    members(value,{"kind","version","operation","requestID","routeGeneration","settlement","leaseAvailable"},{"lifecycle"});
    settlement_shape(value.at("settlement"));
    require(value.at("kind")=="recoveryReady"&&value.at("version").is_number_integer()&&value.at("version")==1&&
        (value.at("operation")=="inspect"||value.at("operation")=="discard")&&value.at("requestID").is_string()&&
        !value.at("requestID").get_ref<const std::string&>().empty()&&value.at("requestID").get_ref<const std::string&>().size()<=128&&value.at("requestID").get_ref<const std::string&>().find('\0')==std::string::npos&&
        value.at("leaseAvailable").is_boolean()&&value.at("leaseAvailable")==false,"controller lifecycle envelope shape differs");
    (void)decimal(value,"routeGeneration");
    if(!value.contains("lifecycle"))return;
    require(value.at("settlement").at("state")=="committed","controller lifecycle body without known source COMMIT");
    const auto& body=value.at("lifecycle");
    members(body,{"state","requestDigest","attemptID","sequence","bindingHighWater","namespaceID","replicaID","receiverIncarnation","channelIncarnation","channel"});
    for(const auto* key:{"state","requestDigest","attemptID","namespaceID","replicaID","receiverIncarnation","channelIncarnation","channel"})
        require(body.at(key).is_string()&&!body.at(key).get_ref<const std::string&>().empty()&&body.at(key).get_ref<const std::string&>().size()<=256&&body.at(key).get_ref<const std::string&>().find('\0')==std::string::npos,
            "controller lifecycle bounded text differs");
    const auto& digest=body.at("requestDigest").get_ref<const std::string&>();
    require(digest.size()==64&&std::all_of(digest.begin(),digest.end(),[](char c){return (c>='0'&&c<='9')||(c>='a'&&c<='f');}),"controller lifecycle digest shape differs");
    for(const auto* key:{"attemptID","receiverIncarnation","channelIncarnation"})
        require(canonical_writer_adapter::uuid_key(body.at(key).get<std::string>())==body.at(key).get_ref<const std::string&>(),"controller lifecycle canonical UUID differs");
    const auto seq=decimal(body,"sequence"),high=decimal(body,"bindingHighWater",0);const auto status=body.at("state").get<std::string>();
    require((status=="available"||status=="terminal"||status=="unstarted")&&(status=="unstarted"?high<seq:high==seq)&&
        (value.at("operation")!="discard"||status=="terminal"),"controller lifecycle status/high-water shape differs");
}
void original_discard_reply_shape(const json& value,const json& description) {
    members(value,{"kind","version","operation","requestID","routeGeneration","settlement","leaseAvailable"});
    settlement_shape(value.at("settlement"));
    require(value.at("kind")=="recoveryReady"&&value.at("version").is_number_integer()&&value.at("version")==1&&
        value.at("operation")=="discard"&&value.at("requestID").is_string()&&value.at("requestID").get_ref<const std::string&>().size()==36&&
        canonical_writer_adapter::uuid_key(value.at("requestID").get<std::string>())==value.at("requestID").get_ref<const std::string&>()&&
        value.at("routeGeneration")==description.at("routeGeneration")&&value.at("leaseAvailable").is_boolean()&&value.at("leaseAvailable")==false,
        "controller original discard envelope differs");
    (void)decimal(value,"routeGeneration");
}
// Late lifecycle traffic can only be disposed, never published as proof.
void late_lifecycle_shape(const json& value,const json& description) {
    lifecycle_reply_shape(value);
    require(terminal_profile(description)&&value.at("routeGeneration")==description.at("routeGeneration"),
        "controller late lifecycle physical route differs");
    if(!value.contains("lifecycle"))return; // legal body-absent late failure
    const auto& body=value.at("lifecycle");const auto& peer=description.at("peer");
    require(body.at("namespaceID")==description.at("source").at("receiptNamespace")&&
        body.at("replicaID")==peer.at("replicaID")&&body.at("receiverIncarnation")==peer.at("receiverIncarnation")&&
        body.at("channelIncarnation")==peer.at("channelIncarnation")&&body.at("channel")==description.at("channel"),
        "controller late lifecycle authenticated binding differs");
}
bool canceled_predecessor(const recovery_request_row& row,const recovery_obligation_scope& scope,
    const receive_install_snapshot& receiver,const cr::request& q,int64_t phase,int64_t barrier,int64_t attempt) {
    if((phase!=1&&phase!=2)||barrier<=1||attempt<=1||row.barrier!=barrier-1||row.sequence!=attempt-1||
       row.journal.generation>INT64_MAX-phase||row.journal_revision>INT64_MAX-phase||
       scope.address.incarnation!=row.journal.incarnation||scope.address.generation!=row.journal.generation+phase||
       scope.revision!=row.journal_revision+phase||scope.last_attempt!=(phase==1?row.sequence:attempt)||
       scope.mode!=(phase==1?recovery_obligation_mode::recording:recovery_obligation_mode::frozen)||
       scope.freeze_revision!=(phase==1?row.journal_revision:scope.revision)||receiver.active||
       receiver.binding!=scope.profile.binding||receiver.last_sequence!=row.sequence||
       (receiver.last_installed&&receiver.last_installed->sequence>=row.sequence)||
       receiver.revision!=scope.installed_revision||uint64_t(receiver.revision)!=q.expected.revision)return false;
    const cr::frontier baseline{receiver.frontier.kind==receive_frontier_kind::position?cr::frontier_kind::position:
        receiver.frontier.kind==receive_frontier_kind::beginning_null?cr::frontier_kind::beginning_null:cr::frontier_kind::uninitialized,
        receiver.frontier.position?std::optional<uint64_t>{static_cast<uint64_t>(*receiver.frontier.position)}:std::nullopt};
    if(baseline!=q.expected.base)return false;
    return scope.installed_sequence==0?!receiver.last_installed&&receiver.frontier==receive_install_frontier{}:
        receiver.last_installed&&receiver.last_installed->sequence==scope.installed_sequence&&
        receiver.last_installed->head==scope.installed_head&&receiver.last_installed->manifest_digest==scope.installed_manifest&&
        receiver.frontier==receive_install_frontier{receive_frontier_kind::position,scope.installed_head};
}
void known(const recovery_install_result& result) {
    if(result.deferred!=recovery_install_deferred::none) {
        require(result.state==recovery_install_state::refused&&!result.primary_error&&!result.cleanup_error&&
            !result.postcommit_error&&!result.notification_error&&!result.unexpected_commit_observed,
            "controller invalid no-effect admission outcome");
        throw controller_admission_wait{result.deferred};
    }
    if(result.state!=recovery_install_state::committed){
        if(result.primary_error)try{std::rethrow_exception(result.primary_error);}
        catch(const controller_generation_changed& primary){
            if(result.state==recovery_install_state::rolled_back&&!result.cleanup_error&&!result.postcommit_error&&
                !result.notification_error&&!result.unexpected_commit_observed)
                throw controller_stale_turn_cancelled(primary.revision,primary.what());
            throw controller_generation_unsettled(primary,result);
        }
        refuse("controller transaction outcome unavailable; gate remains closed");
    }
    // Postcommit notification failure cannot roll back or justify model replay.
    // The next actual owned inspection observes the committed durable phase.
}
canonical_scoped_contract contract(const json& description,const recovery_continuous_contribution& contribution,const recovery_owner_schema& catalog) {
    require(catalog.valid()&&catalog.swift_digest.size()==64,"controller actual Swift catalog unavailable");
    const auto& source=description.at("source");const auto& binding=contribution.profile.binding;
    require(description.at("channel")==binding.channel&&source.at("authority")==binding.authority&&source.at("sourceID")==binding.source&&
        source.at("epoch")==binding.epoch&&source.at("scopeDigest")==binding.scope&&source.at("schemaDigest")==binding.schema&&
        source.at("receiptNamespace")==contribution.profile.receipt_namespace&&source.at("schemaDigest")==catalog.swift_digest,
        "controller source differs from enrolled contribution or actual catalog");
    const auto& incoming=description.at("incomingScope");
    const std::string claimed(contribution.incoming_grant_claim.begin(),contribution.incoming_grant_claim.end());
    require(parse(claimed,65536)==incoming,"controller actual incoming authorization differs from enrolled claim");
    require(incoming.at("catalogDigest")==catalog.swift_digest,"controller incoming catalog differs");
    canonical_scoped_contract result;const std::set<std::string> all{"INSERT","UPDATE","DELETE"};
    const auto operations=[&](const json& value){std::set<std::string> mask;for(const auto& op:value.at("incomingOperations"))mask.insert(op.get<std::string>());require(mask==all,"controller full replacement operation scope incomplete");};
    for(const auto& model:incoming.at("models")){operations(model);const auto name=model.at("table").get<std::string>();require(catalog.find(name)&&catalog.swift_models.count(name),"controller incoming model not actual Swift declaration");result.model_tables.push_back(name);}
    auto actual=result.model_tables,expected=contribution.models;std::sort(actual.begin(),actual.end());std::sort(expected.begin(),expected.end());require(actual==expected,"controller model contribution coverage differs");
    for(const auto& relation:incoming.at("relations")){operations(relation);result.relations.push_back({relation.at("table"),relation.at("lhsModel"),relation.at("rhsModel")});}
    for(const auto& link:incoming.at("scopedLinkTables"))result.scoped_link_tables.push_back(link.get<std::string>());
    // Relation spelling/column closure is independently checked against the
    // same actual SQLite catalog by the installer before model effects.
    return result;
}
cr::wire_limits negotiate(const json& description,const cr::limits& local) {
    const auto& remote=description.at("profile").at("wire");auto value=local.maximum;
    value.frame_bytes=std::min(value.frame_bytes,decimal(remote,"frame_bytes"));value.payload_bytes=std::min(value.payload_bytes,decimal(remote,"payload_bytes"));
    value.items_per_page=std::min(value.items_per_page,decimal(remote,"items_per_page"));value.content_pages=std::min(value.content_pages,decimal(remote,"content_pages"));
    value.content_identities=std::min(value.content_identities,decimal(remote,"content_identities"));value.content_bytes=std::min(value.content_bytes,decimal(remote,"content_bytes"));
    value.receipt_pages=std::min(value.receipt_pages,decimal(remote,"receipt_pages"));value.receipts=std::min(value.receipts,decimal(remote,"receipts"));value.receipt_bytes=std::min(value.receipt_bytes,decimal(remote,"receipt_bytes"));return value;
}
}
struct recovery_receiver_route::state {
    std::weak_ptr<lattice_db> owner;
    std::shared_ptr<recovery_continuous_route> continuous;
    std::shared_ptr<receiver_source_binding> source;
    std::shared_ptr<owned_platform_sync_transport> transport;
    std::shared_ptr<scheduler> dispatch;
    std::shared_ptr<sync_callback_lifetime> lifetime;
    std::atomic<bool> retired{false},blocked{true};
    std::function<void()> resumed,renew,reconcile;
    std::shared_ptr<const std::function<void()>> wake_notifications;
    bool notifications_bound=false;
    std::mutex notification_mutex;
    unsigned notification_kinds=0;
    uint64_t notification_generation=0;
    uint64_t notification_serial=0,notification_queued=0;
    std::exception_ptr notification_error;
    std::atomic<bool> renewal_requested{false};
    // Set only by worker validation of the actual current orphan profile.
    // Coordinator mutex guards this weak record; it cannot retain old sources.
    std::weak_ptr<const receiver_source_binding::record> late_control_view;
    // Original-profile late discard is admitted only after this worker issued
    // a completed-predecessor disposal on the exact current physical view.
    std::weak_ptr<const receiver_source_binding::record> issued_discard_view;
    // Current selected-cohort membership, replaced as one set under the
    // controller mutex. Historical observation is not current membership.
    // The worker-only observed map is never read by drain callers.
    std::weak_ptr<const receiver_source_binding::record> checked_selected_view;
    std::function<void(const std::exception_ptr&)> error;
};
struct recovery_receiver_controller::state {
    const std::uint64_t creator=controller_process();
    const recovery_continuous_policy policy;
    const canonical_scoped_limits caps;
    std::shared_ptr<const test_probe> probe;
#ifndef __EMSCRIPTEN__
    std::unique_ptr<recovery_controller_executor> executor;
#endif
    std::mutex mutex;
    std::vector<std::weak_ptr<recovery_receiver_route>> routes;
    bool scheduled=false,running=false,demand=true,idle=false,deferred_external_request=false;
    bool deletion_retired=false; // only explicit Core deletion retirement
    // One coalesced actual wake, not a new external revision or SQL permit.
    // A wake arriving after a running turn's final inbox check must survive
    // until that turn (or reconciliation reservation) really releases it.
    bool wake_pending=false;
    const void* scheduled_token=nullptr; // identity only, never dereferenced
    void wake_released(recovery_receiver_controller&)noexcept;
    const recovery_reconciliation_reservation* reconciliation_reservation=nullptr;
    uint64_t revision=1,external_revision=1,reconciled_external_revision=0;
    uint64_t delivery_retry_revision=0,reconciled_delivery_retry_revision=0;
    bool awaiting_delivery_retry=false;
    std::exception_ptr failure;
    // One episode, driven by the existing native 100ms receiver tick. A wake
    // does not extend either the original deadline or the attempt allowance.
    struct admission_episode {
        uint64_t revision=0;
        unsigned attempts=0;
        int64_t deadline=0,next_due=0;
    } admission_wait;
    // A deferred real install is a milestone, not permission for a preliminary
    // phase/audit unit to release its denial. Every access is under mutex.
    struct install_target_id {
        uint64_t revision=0;
        int64_t physical=0,barrier=0,attempt=0;
        const verified_unsent_set* frozen=nullptr;
        bool operator==(const install_target_id&)const=default;
    };
    struct install_target {install_target_id id;std::shared_ptr<const verified_unsent_set> frozen;};
    struct install_target_delete {
        uint64_t creator;
        install_target_delete()noexcept:creator(controller_process()){}
        explicit install_target_delete(uint64_t original)noexcept:creator(original){}
        void operator()(install_target* target)const noexcept {
            // The controller capsule is creator-fenced too. Detached retired
            // custody must likewise abandon before an inherited proof release.
            if(creator==controller_process())delete target;
        }
    };
    using install_target_ptr=std::unique_ptr<install_target,install_target_delete>;
    install_target_ptr admission_install{nullptr,install_target_delete{creator}};
    // Exact physical denial cell; the controller mutex never
    // destroys its retained writer. It spans only the original retry episode.
    recovery_writer_access::controller_admission_intent admission_intent;
    bool admission_intent_revoked=false; // coordinator leaf; never refreshes admission_wait
    std::shared_ptr<const verified_unsent_set> frozen;
    std::shared_ptr<const recovery_reconciliation_descriptor> reconciliation;
    int64_t frozen_attempt=0,frozen_barrier=0;
    bool framing_committed=false;
    // Reservations outlive the outstanding pointer when a callback or worker
    // still owns bytes. Only reservations run under mutex; atomic releases
    // happen after payload destruction and never need the coordinator leaf.
    struct inbox_budget {
        const uint64_t creator=controller_process();
        std::atomic<size_t> bytes{0},slots{0};
        std::atomic<bool> capacity_wait{false};
        // Bound once under the coordinator leaf before the first actual route
        // publication. Weak DATA cannot keep a controller/Native owner alive.
        std::weak_ptr<recovery_receiver_controller> controller;
        bool controller_bound=false;
    };
    struct charge {
        const uint64_t creator;
        std::shared_ptr<inbox_budget> budget;
        size_t bytes=0;bool slot=false,charged=false;
        // Required promotion custody exists before any charge publication. A
        // child abandons this entire heap object before inherited last release.
        std::shared_ptr<recovery_receiver_controller> wake_owner;
        std::shared_ptr<recovery_receiver_route> wake_route;
        std::exception_ptr wake_error;
        std::array<std::weak_ptr<recovery_receiver_route>,128> wake_routes{};
        explicit charge(std::shared_ptr<inbox_budget> value):creator(value->creator),budget(std::move(value)){}
        static void destroy(charge*)noexcept;
        void shrink(size_t actual){require(actual<=bytes,"controller reservation exceeded");budget->bytes.fetch_sub(bytes-actual);bytes=actual;}
    };
    std::shared_ptr<inbox_budget> budget=std::make_shared<inbox_budget>();
    std::shared_ptr<charge> reserve_locked(size_t bytes,bool slot) {
        require(budget->creator==controller_process(),"controller credit belongs to another process");
        if(bytes>pending_bytes-budget->bytes.load()||(slot&&budget->slots.load()>=2))return {};
        // A failed shared_ptr control allocation destroys an UNCHARGED empty
        // object; it must not consume another wait bit or run a wake under leaf.
        auto result=std::shared_ptr<charge>(new charge(budget),charge::destroy);
        require(budget->creator==controller_process(),"controller credit changed process during allocation");
        result->bytes=bytes;result->slot=slot;
        budget->bytes.fetch_add(bytes);if(slot)budget->slots.fetch_add(1);
        result->charged=true;return result;
    }
    struct reply {
        std::shared_ptr<charge> reservation; // destroyed after bytes
        std::string bytes;
        uint64_t order=0;
        std::weak_ptr<recovery_receiver_route> late_route;
        receiver_source_binding::recovery_view late_view;
        bool ready=false; // published under mutex, bytes immutable thereafter
    };
    struct disposal_key {
        int64_t physical=0,phase=2,barrier=0,attempt=0;uint64_t revision=0;
        recovery_obligation_address journal,frozen_journal;
        int64_t row_barrier=0,row_sequence=0,row_revision=0,row_route=0,frozen_revision=0;
        cr::attempt logical;
        std::string request_digest,request_hash,manifest_hash,old_context,old_domain,current_context,cohort;
        receive_install_snapshot receiver;
        bool installed=false;
        bool operator==(const disposal_key&)const=default;
    };
    struct disposal {
        std::weak_ptr<recovery_receiver_route> route;
        receiver_source_binding::recovery_view view;
        disposal_key key;
    };
    // Worker-only compact receipts, at most one per configured contribution.
    // Callbacks revoke route/view/revision authority without touching this map.
    std::map<std::string,disposal> disposals;
    struct pending {
        std::shared_ptr<charge> reservation; // destroyed after request/inbox
        std::weak_ptr<recovery_receiver_route> route;
        receiver_source_binding::recovery_view view;
        // Identity, request bytes and deadline are immutable after publication.
        std::string request_id,operation,request_bytes;
        int64_t deadline=0;
        uint64_t index=0,next_order=0;
        bool terminal_inbox=false;
        std::optional<disposal> completed_disposal;
        int64_t proof_physical=0,proof_phase=0,proof_barrier=0,proof_attempt=0;
        uint64_t proof_revision=0;
        std::array<std::shared_ptr<reply>,2> inbox;
    };
    std::shared_ptr<pending> outstanding;
    // Separate pointer inventory, SAME two-slot/16MiB global reservations.
    std::array<std::shared_ptr<reply>,2> late_inbox;
    uint64_t late_order=0;
    struct lease {
        std::weak_ptr<recovery_receiver_route> route;
        receiver_source_binding::recovery_view view;
        std::string id,request_digest,attempt_id;
        uint64_t sequence=0,frames=0;int64_t deadline=0;
    };
    // Ephemeral authority only: each result belongs to the current actual
    // physical source view and full Q. Reopen reacquires it from the source.
    struct lifecycle {
        std::weak_ptr<recovery_receiver_route> route;
        receiver_source_binding::recovery_view view;
        canonical_range::attempt attempt;
        std::string request_digest,state;
    };
    std::map<std::string,lifecycle> lifecycles;
    std::map<std::string,std::shared_ptr<const recovery_reconciliation_descriptor::predecessor>> predecessors;
    std::set<std::string> inspect_required;
    bool terminal_rearm=false;
    int64_t terminal_successor_attempt=0; // observation only; never authority
    std::map<std::string,lease> leases;
    std::map<std::string,receiver_source_binding::recovery_view> observed;
    explicit state(const recovery_continuous_policy& p):policy(p),caps(recovery_receiver_controller::limits(p)){}
};
// One result owns the successful admission until known-COMMIT publication or
// abandonment. SQL bodies and owner destruction never run under the leaf.
// Every published charge is retained beyond coordinator-leaf pointer removal:
// receive owns its local reply/pending, turn owns front/pending, and retire/error
// paths move originals to off-leaf custody. Reservation is the FIRST field of
// reply/pending, so payload bytes, inbox and view destruction precede this call.
void recovery_receiver_controller::state::charge::destroy(charge* value)noexcept {
    if(!value||value->creator!=controller_process())return;
    const auto current=[&]{return value->creator==controller_process();};
    if(value->charged){
        value->budget->bytes.fetch_sub(value->bytes);
        if(value->slot)value->budget->slots.fetch_sub(1);
        // Publication BEFORE the waiter's zero check pairs with this actual
        // last-release zero check. No polling, timer or new retry allowance.
        if(value->budget->bytes.load()==0&&value->budget->slots.load()==0&&
           value->budget->capacity_wait.exchange(false)){
            value->wake_owner=value->budget->controller.lock();
            if(value->wake_owner&&current())try{
                auto& runtime=*value->wake_owner->state_;
                bool live=false;
                {std::lock_guard lock(runtime.mutex);
                    live=!runtime.deletion_retired&&!runtime.failure;
                    if(live){runtime.wake_pending=true;std::copy(runtime.routes.begin(),runtime.routes.end(),value->wake_routes.begin());}}
                if(live)for(const auto& route:value->wake_routes){
                    value->wake_route=route.lock();
                    if(value->wake_route&&!value->wake_route->state_->retired.load()){
                        try{value->wake_owner->wake(value->wake_route);}
                        catch(...){
                            if(!current())return;
                            value->wake_error=std::current_exception();
                            value->wake_owner->scheduling_failed(value->wake_error);
                        }
                        if(!current())return;
                        // Retirement can win inside wake's initial check. Do
                        // not consume the only capacity event for a dead route
                        // while an actual registered sibling could carry it.
                        if(!value->wake_route->state_->retired.load())break;
                    }
                    value->wake_route.reset();if(!current())return;
                }
            }
            catch(...){
                if(!current())return;
                value->wake_error=std::current_exception();
                value->wake_owner->scheduling_failed(value->wake_error);
            }
        }
    }
    if(!current())return;
    value->wake_error={};if(!current())return;
    value->wake_route.reset();if(!current())return;
    value->wake_owner.reset();if(!current())return;
    for(auto& route:value->wake_routes){route.reset();if(!current())return;}
    delete value; // no Native-bearing promotion/callback remains in its fields
}

struct recovery_reconciliation_reservation {
    std::shared_ptr<recovery_receiver_controller> controller;
    std::shared_ptr<lattice_db> owner;
    bool active=false;
    void release()noexcept {
        std::shared_ptr<const recovery_reconciliation_descriptor> retired;
        bool ended=false;
        if(active){auto& runtime=*controller->state_;{
            std::lock_guard lock(runtime.mutex);
            if(runtime.reconciliation_reservation==this){runtime.reconciliation_reservation=nullptr;runtime.running=false;ended=true;
                // Admission reserves room for publication plus this one
                // coalesced actual external event. Internal wakes never set it.
                if(runtime.deferred_external_request){runtime.deferred_external_request=false;++runtime.revision;++runtime.external_revision;
                    runtime.demand=true;runtime.failure={};runtime.awaiting_delivery_retry=false;retired=std::move(runtime.reconciliation);}}
            active=false;}}
        retired.reset(); // release old payload owners before any next turn
        if(ended)controller->state_->wake_released(*controller);
    }
    ~recovery_reconciliation_reservation(){release();}
};
canonical_scoped_limits recovery_receiver_controller::limits(const recovery_continuous_policy& policy) {
    canonical_scoped_limits result;
    result.obligations=policy.limits.obligations;result.install.installations=policy.limits.installations;
    result.install.capture={8192,32768,16,256,4096,4194304,65536,536870912};
    result.install.channels=16;result.install.members=262144;result.install.metadata_bytes=33554432;
    result.install.targets=32768;result.install.receipts=8192;result.install.fields=4194304;result.install.field_bytes=65536;result.install.logical_bytes=536870912;
    result.codec={{4194304,16384,64,512,16384,33554432,256,8192,8388608},16,262144,32768,8192,8192,2097152,4194304,3600000,{16384,64,256,4096,16384}};
    result.staging={16,8192,262144,536870912,4096,131072,134217728,805306368};return result;
}
std::mutex recovery_receiver_controller::test_mutex_;
std::shared_ptr<const recovery_receiver_controller::test_probe> recovery_receiver_controller::test_probe_;
std::shared_ptr<const recovery_receiver_controller::worker_observer> recovery_receiver_controller::test_worker_observer_;
recovery_receiver_controller::recovery_receiver_controller(const recovery_continuous_policy& policy,
    const std::shared_ptr<controller_worker_original>& original):state_(std::make_unique<state>(policy)){
#ifndef __EMSCRIPTEN__
    // Reserve actual ending capacity and launch before this controller can be
    // published into a producer or accept any route/wake.
    auto staged=std::make_unique<recovery_controller_executor>();
    if(!original)throw db_error("controller worker lacks preconstruction ending custody");
    // Before any constructor callback or producer publication. If retaining
    // DATA fails, the reserved producer original remains honestly unavailable.
    original->bind(staged->retain_ending());
#endif
    std::shared_ptr<const worker_observer> worker_observed;
    {std::lock_guard lock(test_mutex_);state_->probe=test_probe_;worker_observed=test_worker_observer_;}
#ifndef __EMSCRIPTEN__
    state_->executor=std::move(staged);
    if(worker_observed)(*worker_observed)(*state_->executor); // Actual constructor observation, off test/producer leaves.
#endif
}
void recovery_receiver_controller::retire_for_deletion(){
    if(state_->creator!=controller_process())throw db_error("controller deletion belongs to another process");
    native_retirement_storage<std::shared_ptr<database_retirement_state>,
        std::shared_ptr<database>,state::install_target_ptr> retired; // before effects
    if(!retired.in_creator_process()||state_->creator!=controller_process())
        throw db_error("controller deletion changed process during ending admission");
    {
        std::lock_guard lock(state_->mutex);
        state_->deletion_retired=true;state_->wake_pending=false;
        state_->admission_intent_revoked=true;
        retired.get<2>()=std::move(state_->admission_install);
        if(!state_->running){
            auto actual=state_->admission_intent.retire();
            retired.get<0>()=std::move(actual.retirement);retired.get<1>()=std::move(actual.writer);
            state_->admission_wait={};
        }
    }
    // Each arbitrary final release is off leaf and followed by a creator
    // check before another payload or state access. A child abandons the
    // entire remaining heap graph rather than unwinding automatic owners.
    if(!retired.release<0>()||!retired.release<1>()||!retired.release<2>())
        throw db_error("controller deletion changed process during retained ending");
#ifndef __EMSCRIPTEN__
    // Cancel only unexecuted slots; actual executing work must return before
    // its original worker and reserved reaper can establish a real join.
    state_->executor->retire();
#endif
}
recovery_receiver_controller::~recovery_receiver_controller(){
    // Abandon the entire inherited process capsule before worker/thread,
    // callback/shared ownership or leaf destruction in a fork child.
    if(state_&&state_->creator!=controller_process())(void)state_.release();
}
void recovery_receiver_controller::initialize_owned(std::shared_ptr<lattice_db> owner,const recovery_continuous_policy& policy) {
    const auto caps=limits(policy);recovery_request_store requests(owner);requests.initialize();
    canonical_range_staging stage(owner,caps.install.installations,caps.codec,caps.staging);stage.initialize();
    initialize_canonical_domains_owned(owner,caps.install,true);
    (void)bump_recovery_witness(*owner);
}
void recovery_receiver_controller::validate_reopen_owned(std::shared_ptr<lattice_db> owner,const recovery_continuous_policy& policy,int64_t phase,int64_t barrier,int64_t attempt) {
    const auto caps=limits(policy);recovery_request_store requests(owner);requests.migrate_existing();
    initialize_canonical_domains_owned(owner,caps.install,false);
    require(read_recovery_witness(*recovery_writer_access::active_writer(*owner)).has_value(),"controller witness missing on reopen");
    canonical_range_staging stages(owner,caps.install.installations,caps.codec,caps.staging);stages.audit();
    recovery_obligation_store journals(owner,caps.obligations,caps.install.installations);journals.audit();
    receive_install_store receiver(owner,caps.install.installations);receiver.audit();
    const auto count=recovery_writer_access::active_writer(*owner)->query("SELECT COUNT(*) AS n FROM (SELECT DISTINCT original FROM main._lattice_obligation_entry WHERE stage<>2 ORDER BY original LIMIT 8193)");
    require(count.size()==1&&integer(count[0],"n")<=8192,"controller reopened unresolved-original capacity differs");
    std::set<std::string> allowed;
    for(const auto& c:policy.contributions){allowed.insert(c.profile.binding.channel);const auto scope=journals.read(c.profile.binding.channel);const auto actual=receiver.read(c.profile.binding.channel);
        require(scope&&scope->profile==c.profile&&actual&&actual->binding==c.profile.binding,"controller reopened contribution binding differs");
        require(phase==0||phase==1||phase==4?scope->mode==recovery_obligation_mode::recording:
            phase==2?scope->mode==recovery_obligation_mode::frozen:phase==3&&scope->mode==recovery_obligation_mode::installed,
            "controller reopened journal phase differs");
        const auto framing=requests.read(c.profile.binding.channel);
        if(framing){
            const auto decoded=cr::decode(framing->request_frame,caps.codec);const auto* q=std::get_if<cr::request>(&decoded.body);
            require(q&&decoded.logical.channel==c.profile.binding.channel&&decoded.logical.sequence==uint64_t(framing->sequence)&&q->source==source_binding(c.profile),"controller reopened Q differs");
            if(phase==4)require(framing->receipt_decisions=="0"||(q->receipts.size()<=recovery_request_store::decision_entries&&framing->receipt_decisions.size()==65+2*q->receipts.size()&&!framing->receipt_decisions.empty()&&framing->receipt_decisions[0]=='1'),
                "controller reopened canceled receipt decisions missing or count differs");
            if(!framing->manifest_frame.empty()){
                const auto m=cr::decode(framing->manifest_frame,caps.codec);require(m.logical==decoded.logical&&std::holds_alternative<cr::manifest>(m.body),"controller reopened manifest framing differs");
                const auto described=describe_canonical_range(decoded.logical,*q,std::get<cr::manifest>(m.body),caps.codec,framing->route);
                require(described.installation_binding==c.profile.binding,"controller reopened manifest binding differs");
                if(phase==0||phase==3||(phase==1&&actual->last_installed==std::optional<receive_install_identity>{described.installation_identity})){require(actual->last_installed==std::optional<receive_install_identity>{described.installation_identity}&&scope->installed_manifest==described.installation_identity.manifest_digest&&
                    scope->installed_revision==actual->revision,"controller reopened installed framing differs");
                    require(!actual->active&&actual->last_sequence==framing->sequence&&
                        (phase!=1||(framing->sequence==attempt-1&&scope->last_attempt==framing->sequence)),"controller prior installed request is not the exact barrier predecessor");}
            }else require((phase==2&&framing->sequence==attempt&&framing->barrier==barrier&&framing->journal==scope->address&&framing->journal_revision==scope->revision)||
                canceled_predecessor(*framing,*scope,*actual,*q,phase,barrier,attempt),"controller manifestless Q lacks exact current or canceled predecessor");
            if(framing->manifest_frame.empty()&&(phase==1||phase==2)&&framing->sequence==attempt-1)
                require(canceled_predecessor(*framing,*scope,*actual,*q,phase,barrier,attempt),"controller reopened canceled predecessor differs");
            if(phase==1)require(framing->sequence==attempt-1&&actual->last_sequence==framing->sequence&&!actual->active,
                "controller preparing phase lacks its exact prior receiver sequence");
            if(phase==4||(phase==1&&framing->sequence<attempt&&(!actual->last_installed||actual->last_installed->sequence<framing->sequence)))require(framing->sequence==attempt-1&&framing->barrier+1>framing->barrier&&
                scope->last_attempt==framing->sequence&&scope->address.incarnation==framing->journal.incarnation&&scope->address.generation==framing->journal.generation+1&&
                scope->revision>=framing->journal_revision+1&&!actual->active&&actual->last_sequence==framing->sequence&&
                (!actual->last_installed||actual->last_installed->sequence<framing->sequence),"controller reopened reconciliation differs from exact canceled attempt");
        }else require(!actual->last_installed&&phase!=3,"controller missing installed framing");
        if(phase==2||phase==3)require(scope->last_attempt==attempt,"controller reopened attempt differs");
        if(phase==3)require(framing&&framing->sequence==attempt&&!framing->manifest_frame.empty(),"controller installed phase lacks complete framing");
    }
    for(const auto& channel:requests.channels())require(allowed.count(channel),"controller unknown durable request channel");
}
std::shared_ptr<recovery_receiver_route> recovery_receiver_controller::attach(std::shared_ptr<lattice_db> owner,const std::shared_ptr<recovery_continuous_route>& continuous,
    const std::shared_ptr<receiver_source_binding>& source,const std::shared_ptr<owned_platform_sync_transport>& transport,
    const std::shared_ptr<scheduler>& scheduler,const std::shared_ptr<sync_callback_lifetime>& lifetime) {
    auto route_state=std::make_shared<recovery_receiver_route::state>();route_state->owner=owner;route_state->continuous=continuous;route_state->source=source;route_state->transport=transport;route_state->dispatch=scheduler;route_state->lifetime=lifetime;
    auto route=std::shared_ptr<recovery_receiver_route>(new recovery_receiver_route(shared_from_this(),std::move(route_state)));
    {std::lock_guard lock(state_->mutex);require(!state_->deletion_retired,"controller deletion retired route admission");
        if(!state_->budget->controller_bound){state_->budget->controller=weak_from_this();state_->budget->controller_bound=true;}
        auto& all=state_->routes;all.erase(std::remove_if(all.begin(),all.end(),[](const auto& value){return value.expired();}),all.end());
        require(all.size()<state_->policy.physical_routes,"controller physical route capacity");all.push_back(route);}
    return route;
}
recovery_receiver_route::recovery_receiver_route(std::shared_ptr<recovery_receiver_controller> controller,std::shared_ptr<state> state):state_(std::move(state)),controller_(std::move(controller)){}
recovery_receiver_route::~recovery_receiver_route(){state_->retired.store(true,std::memory_order_release);controller_->retire(this);}
void recovery_receiver_controller::retire(recovery_receiver_route*)noexcept {
    if(state_->creator!=controller_process())return;
    recovery_writer_access::controller_admission_intent::retired_custody retired_writer;
    state::install_target_ptr retired_install;
    std::shared_ptr<state::pending> released;
    std::array<std::shared_ptr<state::reply>,2> retired;
    {std::lock_guard lock(state_->mutex);
        state_->admission_intent_revoked=true;
        retired_install=std::move(state_->admission_install);
        if(!state_->running){retired_writer=state_->admission_intent.retire();state_->admission_intent_revoked=false;}
        if(state_->outstanding&&state_->outstanding->route.expired())released=std::move(state_->outstanding);
        for(size_t i=0;i<retired.size();++i)if(state_->late_inbox[i]&&state_->late_inbox[i]->late_route.expired())
            retired[i]=std::move(state_->late_inbox[i]);}
#ifndef __EMSCRIPTEN__
    state_->executor->cancel_retry();
#endif
    // In-flight callbacks/worker retain their charges until actual disposal.
    // Durable barrier/Q survives; a later actual route can continue it.
}
void recovery_receiver_route::wake(){if(!state_->retired.load(std::memory_order_acquire))controller_->wake(shared_from_this());}
void recovery_receiver_route::notifications(std::function<void()> resumed,std::function<void()> renew,std::function<void(const std::exception_ptr&)> error,std::function<void()> reconcile,std::function<void()> wake_notifications){
    require(static_cast<bool>(wake_notifications),"controller requires its actual pacer notification wake");
    // Existing controllers may observe this registration before the new sync
    // constructor reaches callback binding. Stage allocation/captures off leaf,
    // then publish immutable callbacks once; readers only copy a shared holder.
    const auto wake=std::make_shared<const std::function<void()>>(std::move(wake_notifications));
    bool bound=false,pending=false;
    {std::lock_guard lock(state_->notification_mutex);
        if(!state_->notifications_bound){
            state_->resumed=std::move(resumed);state_->renew=std::move(renew);state_->error=std::move(error);state_->reconcile=std::move(reconcile);
            state_->wake_notifications=wake;state_->notifications_bound=true;bound=true;
            pending=state_->notification_kinds!=0;
        }}
    require(bound,"controller notification callbacks already bound");
    if(pending)(*wake)(); // earlier retained DATA, off leaf; no user scheduler
}
void recovery_receiver_route::request(){request_impl(nullptr,nullptr);}
void recovery_receiver_route::legacy_delivery_acknowledged(){
    if(!creator_current())throw db_error("controller ACK belongs to another process");
    // Prepare fenced weak-original custody before reading inherited bindings.
    // This capsule grants no Native/source permission and owns no database.
    native_retirement_storage<std::weak_ptr<recovery_receiver_route>,
        std::weak_ptr<recovery_receiver_controller>> identity;
    if(!identity.in_creator_process()||!creator_current())return;
    identity.get<0>()=weak_from_this();identity.get<1>()=controller_;
    request_impl(&identity.get<0>(),&identity.get<1>());
}
void recovery_receiver_route::request_impl(const std::weak_ptr<recovery_receiver_route>* legacy_origin,
    const std::weak_ptr<recovery_receiver_controller>* actual_controller){
    if(!creator_current())throw db_error("controller request belongs to another process");
    recovery_writer_access::controller_admission_intent::retired_custody retired_writer;
    recovery_receiver_controller::state::install_target_ptr retired_install;
    std::shared_ptr<const recovery_reconciliation_descriptor> retired;
    bool preserve_pass=false;
    {std::lock_guard lock(controller_->state_->mutex);auto& state=*controller_->state_;
        if(legacy_origin){
            if(state_->retired.load())return;
            const auto& current=state.reconciliation;
            const auto same=[](const auto& x,const auto& y)noexcept{return !x.owner_before(y)&&!y.owner_before(x);};
            if(current&&current->phase_==4&&current->controller_revision_==state.revision&&
                current->external_revision_==state.external_revision&&actual_controller&&
                same(current->controller_,*actual_controller)&&same(current->owner_,state_->owner)){
                size_t matched=0;
                for(const auto& part:current->contributions_)
                    if(same(part.route,*legacy_origin)&&part.source==state_->source)++matched;
                preserve_pass=matched==1;
            }
        }
        // Even an entirely handed-off pass must finish its actual refreeze
        // publication. ACKs do not reset that cursor or become external demand.
        if(!preserve_pass){
        require(state.revision!=UINT64_MAX&&state.external_revision!=UINT64_MAX,"controller demand revision exhausted");
        if(state.reconciliation_reservation)state.deferred_external_request=true;
        else {++state.revision;++state.external_revision;state.demand=true;state.failure={};state.awaiting_delivery_retry=false;retired=std::move(state.reconciliation);
            state.admission_intent_revoked=true;
            retired_install=std::move(state.admission_install);
            if(!state.running){retired_writer=state.admission_intent.retire();state.admission_intent_revoked=false;}}}}
    if(preserve_pass){wake();return;} // normal worker/handoff still verify the actual source/view
    retired_writer.reset();retired.reset();
#ifndef __EMSCRIPTEN__
    controller_->state_->executor->cancel_retry();
#endif
    wake();
}
std::function<void()> recovery_receiver_route::delivery_timeout_retry(const committed_export_frame& frame,uint64_t physical) {
    if(!frame.reconciliation_)return {};
    const auto& grant=*frame.reconciliation_;const auto& descriptor=grant.descriptor_;
    require(descriptor&&descriptor->phase_==4&&!frame.consumed_&&!frame.entries_.empty()&&frame.physical_generation_==physical&&
        frame.owner_==state_->owner.lock(),"delivery retry lacks actual restricted frame");
    require(grant.contribution_<descriptor->contributions_.size(),"delivery retry contribution missing");
    const auto& part=descriptor->contributions_[grant.contribution_];
    require(part.route.lock().get()==this&&part.source==state_->source,"delivery retry frame route differs");
    // An obsolete parked frame must reach the actual handoff's stale disposal
    // path. It cannot issue a retry event, but staleness is not a new error.
    if(state_->retired.load()||!state_->lifetime->current(physical)||!part.source->recovery_live(part.view))return {};
    {
        std::lock_guard lock(controller_->state_->mutex);const auto& runtime=*controller_->state_;
        if(runtime.reconciliation!=descriptor||runtime.revision!=descriptor->controller_revision_||
            runtime.external_revision!=descriptor->external_revision_)return {};
    }
    // No descriptor/cohort/database/transport retention in the ACK worker.
    // The actual send registration separately fences which IDs may expire.
    return [weak=weak_from_this(),record=std::weak_ptr<const receiver_source_binding::record>(part.view.value),
        physical,external=descriptor->external_revision_,retry=descriptor->delivery_retry_revision_] {
        const auto route=weak.lock();const auto current=record.lock();
        if(!route||!current||route->state_->retired.load()||!route->state_->lifetime->current(physical))return;
        const receiver_source_binding::recovery_view view{current};
        if(!route->state_->source->recovery_live(view))return;
        {
            std::lock_guard lock(route->controller_->state_->mutex);auto& runtime=*route->controller_->state_;
            if(runtime.external_revision!=external||runtime.delivery_retry_revision!=retry)return;
            require(runtime.delivery_retry_revision!=UINT64_MAX,"controller delivery retry revision exhausted");
            ++runtime.delivery_retry_revision;runtime.demand=true;
            // This event never replaces a live descriptor or changes its
            // ordinary revision, including during known-COMMIT publication.
            // A timeout preceding fresh UNKNOWN remains pending in the counter.
            if(runtime.awaiting_delivery_retry){runtime.failure={};runtime.awaiting_delivery_retry=false;}
        }
        const auto probe=route->controller_->state_->probe;
        if(probe&&probe->owner==route->state_->owner.lock().get()&&probe->observed)
            probe->observed("delivery-retry-admitted");
        route->wake();
    };
}
bool recovery_receiver_route::blocks_ordinary()const noexcept{return state_->blocked.load(std::memory_order_acquire);}
bool recovery_receiver_route::creator_current()const noexcept{return controller_->state_->creator==controller_process();}
std::exception_ptr recovery_receiver_route::checked_disposal_failure(uint64_t lifecycle)const {
    // No inherited leaf, and no failure from a live but deselected physical
    // wrapper or from a new route not yet selected by the actual controller.
    if(!creator_current()||state_->retired.load()||!state_->lifetime->current(lifecycle))return {};
    const auto view=state_->source->recovery_current();if(!view)return {};
    std::exception_ptr error;
    {std::lock_guard lock(controller_->state_->mutex);const auto& runtime=*controller_->state_;
        if(state_->retired.load()||runtime.awaiting_delivery_retry)return {};
        if(state_->checked_selected_view.lock()!=view->value)return {};
        error=runtime.failure;
    }
    // Typed disposition comes only from the real controller SQL settlement;
    // notification strings and caller flags cannot turn pending into failed.
    try {if(error)std::rethrow_exception(error);else return {};}
    catch(const controller_generation_unsettled&){}
    catch(const controller_disposal_refused&){}
    catch(...){return {};}
    if(state_->retired.load()||!state_->lifetime->current(lifecycle)||!state_->source->recovery_live(*view))return {};
    {std::lock_guard lock(controller_->state_->mutex);const auto& runtime=*controller_->state_;
        if(state_->retired.load()||runtime.awaiting_delivery_retry||runtime.failure!=error||
           state_->checked_selected_view.lock()!=view->value)return {};
    }
    return error;
}
void recovery_receiver_controller::dropped_turn(const void* scheduled_token)noexcept {
    std::lock_guard lock(state_->mutex);
    if(state_->scheduled_token!=scheduled_token)return;
    state_->scheduled_token=nullptr;state_->scheduled=false;state_->wake_pending=true;
    // A failed/dropped dispatch does not spin or renew a deadline. A later
    // actual event may try again; no scheduled flag may remain stranded.
}
void recovery_receiver_controller::wake(const std::shared_ptr<recovery_receiver_route>& route) {
    if(state_->creator!=controller_process()||route->state_->retired.load())return;
    {std::lock_guard lock(state_->mutex);
        if(state_->deletion_retired)return;
        if(state_->running){state_->wake_pending=true;return;}
        if(state_->scheduled)return;}
    struct scheduled {
        std::shared_ptr<recovery_receiver_controller> owner;
        std::atomic<bool> armed{false},invoked{false};
        ~scheduled(){if(armed.load()&&!invoked.load())owner->dropped_turn(this);}
    };
    // Allocate before scheduled publication. Failure here leaves the next real
    // wake eligible; neither a token allocation nor its absence is authority.
    const auto probe=state_->probe;
    std::shared_ptr<void> allocation_scope;
    if(probe&&probe->owner==route->state_->owner.lock().get()&&probe->scope)
        allocation_scope=probe->scope("schedule-token-before-allocation");
    auto held=std::make_shared<scheduled>();held->owner=shared_from_this();
    {std::lock_guard lock(state_->mutex);
        if(state_->deletion_retired)return;
        if(state_->running){state_->wake_pending=true;return;}
        if(state_->scheduled)return;
        state_->scheduled=true;state_->scheduled_token=held.get();held->armed.store(true);}
    try {
#ifndef __EMSCRIPTEN__
        state_->executor->invoke([held]{if(held->invoked.exchange(true))return;held->owner->turn();});
#else
        route->state_->dispatch->invoke([held]{if(held->invoked.exchange(true))return;held->owner->turn();});
#endif
    }
    catch(...){if(!held->invoked.exchange(true))dropped_turn(held.get());throw;}
}
void recovery_receiver_route::post(notification kind,std::exception_ptr failure) {
    if(!creator_current()||state_->retired.load())return;
    const auto generation=state_->lifetime->dispatch_generation();
    if(!state_->lifetime->current(generation))return;
    std::exception_ptr retired;
    std::shared_ptr<const std::function<void()>> wake;
    {std::lock_guard lock(state_->notification_mutex);
        if(state_->notification_generation!=generation){
            retired=std::move(state_->notification_error);state_->notification_kinds=0;state_->notification_generation=generation;}
        state_->notification_kinds|=static_cast<unsigned>(kind);
        if(failure&&!state_->notification_error)state_->notification_error=std::move(failure);
        wake=state_->wake_notifications;
    }
    // Closed native metadata wake only. The private controller lane never
    // invokes an original scheduler that is allowed to execute user work inline.
    if(wake)(*wake)();
}
void recovery_receiver_route::drain_notifications(){
    if(!creator_current()||state_->retired.load())return;
    // One original-scheduler handoff per route, independent of notification
    // arrival/tick count. A blocked original worker cannot accumulate hints.
    {std::lock_guard lock(state_->notification_mutex);
        if(!state_->notifications_bound||state_->notification_queued||!state_->notification_kinds)return;}
    struct handoff {
        struct payload {
            std::shared_ptr<recovery_receiver_route::state> metadata;
            std::shared_ptr<recovery_receiver_route> route;
            uint64_t serial=0,generation=0;unsigned kinds=0;
            std::atomic<bool> invoked{false};std::exception_ptr error;
        };
        const uint64_t creator=controller_process();payload* held=nullptr;
        explicit handoff(std::shared_ptr<recovery_receiver_route> route)
            :held(new payload{route->state_,std::move(route)}){}
        bool current()const noexcept{return creator==controller_process();}
        ~handoff(){
            // Arbitrary callback/capture ending may occur on another process.
            // Abandon the whole Native-bearing capsule before inherited leaves
            // or shared/callback release. The outer wrapper owns only DATA.
            if(!current()){held=nullptr;return;}
            auto* ended=held;held=nullptr;if(!ended)return;
            ended->error={};if(!current())return;
            ended->route.reset();if(!current())return;
            // Keep the exact identity reserved through actual user callback
            // AND captured route/error final release, not callback entry.
            if(ended->serial){std::lock_guard lock(ended->metadata->notification_mutex);
                if(ended->metadata->notification_queued==ended->serial)ended->metadata->notification_queued=0;}
            delete ended; // all remaining closed DATA release is off leaf
        }
    };
    auto pending=std::make_shared<handoff>(shared_from_this());
    bool exhausted=false;
    {std::lock_guard lock(state_->notification_mutex);
        if(!state_->notifications_bound||state_->notification_queued||!state_->notification_kinds)return;
        exhausted=state_->notification_serial==UINT64_MAX;
        if(!exhausted){pending->held->serial=++state_->notification_serial;state_->notification_queued=pending->held->serial;}}
    require(!exhausted,"controller notification serial exhausted"); // exception construction off leaf
    try{state_->dispatch->invoke([pending]{
        if(!pending->current())return;
        auto& actual=*pending->held;if(actual.invoked.exchange(true))return;
        const auto& held=actual.route;
        {std::lock_guard lock(actual.metadata->notification_mutex);
            if(actual.metadata->notification_queued!=actual.serial)return;
            actual.kinds=actual.metadata->notification_kinds;actual.metadata->notification_kinds=0;
            actual.generation=actual.metadata->notification_generation;actual.error=std::move(actual.metadata->notification_error);}
        if(held->state_->retired.load()||!held->state_->lifetime->current(actual.generation))return;
        for(const auto kind:{notification::renew,notification::resumed,notification::reconcile,notification::error}){
            if(!(actual.kinds&static_cast<unsigned>(kind)))continue;
            if(!pending->current()||held->state_->retired.load()||!held->state_->lifetime->current(actual.generation))return;
            try{switch(kind){
                case notification::resumed:if(held->state_->resumed)held->state_->resumed();break;
                case notification::renew:if(held->state_->renew)held->state_->renew();break;
                case notification::reconcile:if(held->state_->reconcile)held->state_->reconcile();break;
                case notification::error:if(held->state_->error)held->state_->error(actual.error);break;
            }}catch(...){if(!pending->current())return;if(kind!=notification::error)held->controller_->scheduling_failed(std::current_exception());}
        }
    });}catch(...){
        if(!creator_current())return;
        // A throwing scheduler may already have retained/invoked its payload.
        // Only actual last capture release retires this handoff identity; this
        // catch cannot clear it or allow overlapping work on a custom scheduler.
        controller_->scheduling_failed(std::current_exception());
    }
}
void recovery_receiver_controller::scheduling_failed(std::exception_ptr error)noexcept {
    if(state_->creator!=controller_process())return;
    recovery_writer_access::controller_admission_intent::retired_custody retired;
    state::install_target_ptr retired_install;
    std::array<std::weak_ptr<recovery_receiver_route>,128> routes;
    {std::lock_guard lock(state_->mutex);
        if(!state_->failure)state_->failure=error;
        retired_install=std::move(state_->admission_install);
        if(!state_->running){retired=state_->admission_intent.retire();state_->admission_wait={};}
        else state_->admission_intent_revoked=true;
        std::copy(state_->routes.begin(),state_->routes.end(),routes.begin());}
    retired.reset();
#ifndef __EMSCRIPTEN__
    state_->executor->cancel_retry();
#endif
    for(const auto& weak:routes)if(auto route=weak.lock())try{route->post(recovery_receiver_route::notification::error,error);}catch(...){}
}
void recovery_receiver_controller::arm_admission_retry(int64_t due) {
#ifndef __EMSCRIPTEN__
    auto weak=weak_from_this();
    state_->executor->retry_at(std::chrono::steady_clock::time_point(std::chrono::milliseconds(due)),[weak]{
        const auto controller=weak.lock();if(!controller||controller->state_->creator!=controller_process())return;
        std::array<std::weak_ptr<recovery_receiver_route>,128> routes;
        {std::lock_guard lock(controller->state_->mutex);
            std::copy(controller->state_->routes.begin(),controller->state_->routes.end(),routes.begin());}
        for(const auto& entry:routes)if(auto route=entry.lock())if(!route->state_->retired.load()){
            try{controller->wake(route);}catch(...){controller->scheduling_failed(std::current_exception());}return;
        }
    });
#else
    (void)due; // Continuous browser routes already refuse before construction.
#endif
}
void recovery_receiver_controller::state::wake_released(recovery_receiver_controller& controller)noexcept {
    // Custom schedulers may invoke inline. Nested settlement keeps demand
    // pending for this outer constant-stack drain, never another recursive turn.
    static thread_local bool handing_off=false;
    if(handing_off)return;
    struct handoff_scope {bool& active;explicit handoff_scope(bool& v):active(v){active=true;}~handoff_scope(){active=false;}} hold(handing_off);
    for(unsigned quantum=0;quantum<8;++quantum){
        // physical_routes is validated <=128. Copy only registered weak
        // identities under the leaf, not source owners or callback work.
        std::array<std::weak_ptr<recovery_receiver_route>,128> next;
        {std::lock_guard lock(mutex);
            if(deletion_retired||running||scheduled||!wake_pending)return;
            wake_pending=false;std::copy(routes.begin(),routes.end(),next.begin());}
        bool handed_off=false;
        for(const auto& weak:next)if(auto route=weak.lock()){
            if(route->state_->retired.load())continue;
            try{controller.wake(route);}catch(...){
                // The event was removed from the pending bit before this
                // attempt. Even allocation before token publication can fail.
                // Retain it, without recursive retry or a renewed deadline.
                {std::lock_guard lock(mutex);wake_pending=true;}
                try{if(probe&&probe->owner==route->state_->owner.lock().get()&&probe->observed)
                    probe->observed("wake-handoff-failed-pending");}catch(...){}
                return;
            }
            // A racing retirement cannot select an inherited source. Another
            // actual live registration may carry the coalesced wake instead.
            if(!route->state_->retired.load()){handed_off=true;break;}
        }
        if(!handed_off)return;
        // An asynchronous dispatch leaves scheduled/running set, so the next
        // check returns. An inline dispatch may have received one real event.
    }
    // Any demand beyond this fixed quantum remains pending. Only another real
    // event (including the unchanged native pacer) may continue it; no busy
    // loop, new timer, deadline renewal, SQL permit or source authority exists.
}
bool recovery_receiver_route::receive(const platform_transport_callbacks& endpoint,uint64_t lifecycle,const transport_message& message) {
    const std::string_view raw(reinterpret_cast<const char*>(message.data.data()),message.data.size());
    if(!reserved_recovery_source_frame(raw))return false;
    auto& coordinator=*controller_->state_;
    std::shared_ptr<recovery_receiver_controller::state::pending> pending;
    {std::lock_guard lock(coordinator.mutex);pending=coordinator.outstanding;}
    if(!pending) {
        receiver_source_binding::recovery_view view;
        {std::lock_guard lock(coordinator.mutex);view.value=state_->late_control_view.lock();}
        // Initial/renewed describe still belongs to the original verifier.
        // This lane admits only an already worker-verified physical record.
        if(!view.value||!state_->source->recovery_matches(view,endpoint,lifecycle))return false;
        try {
            require(message.data.size()<=recovery_request_store::frame_bytes,"controller late response byte capacity");
            auto reply=std::make_shared<recovery_receiver_controller::state::reply>();
            reply->late_route=shared_from_this();reply->late_view=view;
            size_t slot=0;
            {std::lock_guard lock(coordinator.mutex);
                // Publication and late admission share this leaf. If a new
                // request won the race, retain its ordinary correlation path.
                pending=coordinator.outstanding;
                if(!pending){
                    while(slot<coordinator.late_inbox.size()&&coordinator.late_inbox[slot])++slot;
                    require(slot<coordinator.late_inbox.size(),"controller bounded late response inbox full");
                    require(coordinator.late_order!=UINT64_MAX,"controller late response order exhausted");
                    reply->reservation=coordinator.reserve_locked(message.data.size(),true);
                    require(reply->reservation!=nullptr,"controller retained late response capacity");
                    reply->order=++coordinator.late_order;coordinator.late_inbox[slot]=reply;}}
            if(!pending){
                try {reply->bytes.assign(raw);}
                catch(...){
                    {std::lock_guard lock(coordinator.mutex);if(coordinator.late_inbox[slot]==reply)coordinator.late_inbox[slot].reset();}
                    throw;
                }
                const bool live=state_->source->recovery_live(view);
                {std::lock_guard lock(coordinator.mutex);
                    if(coordinator.late_inbox[slot]!=reply)return true;
                    if(!live||state_->retired.load()||state_->late_control_view.lock()!=view.value)coordinator.late_inbox[slot].reset();
                    else reply->ready=true;}
                wake();return true;
            }
        }catch(...){
            const auto failure=std::current_exception();
            // Preserve source.receive's exact-view revocation on newly
            // intercepted late admission failures, after every leaf unwinds.
            bool invalidated=false;
            try {invalidated=state_->source->recovery_live(view)&&state_->source->invalidate(view.value);}
            catch(...){std::rethrow_exception(failure);}
            if(invalidated)std::rethrow_exception(failure);
            return true; // a retired/replaced view cannot revoke its successor
        }
    }
    if(pending->route.lock().get()!=this||!state_->source->recovery_matches(pending->view,endpoint,lifecycle))return true;
    require(message.data.size()<=recovery_request_store::frame_bytes,"controller pending response byte capacity");
    auto reply=std::make_shared<recovery_receiver_controller::state::reply>();
    size_t slot=0;
    {std::lock_guard lock(coordinator.mutex);if(coordinator.outstanding!=pending)return true;
        const size_t limit=pending->terminal_inbox?2:1;
        while(slot<limit&&pending->inbox[slot])++slot;
        require(slot<limit,"controller bounded response inbox full");
        require(pending->next_order!=UINT64_MAX,"controller response order exhausted");
        reply->reservation=coordinator.reserve_locked(message.data.size(),true);
        require(reply->reservation!=nullptr,"controller retained response capacity");
        reply->order=++pending->next_order;pending->inbox[slot]=reply;}
    try {reply->bytes.assign(raw);}
    catch(...){
        // The local reference retains its charge beyond the leaf on failure.
        {std::lock_guard lock(coordinator.mutex);if(pending->inbox[slot]==reply)pending->inbox[slot].reset();}
        throw;
    }
    {std::lock_guard lock(coordinator.mutex);if(coordinator.outstanding!=pending)return true;
        reply->ready=true;}
    // Copies only actual successful publication, before the existing wake.
    // No grant, source lookup, SQL or callback executes under the leaf.
    const auto probe=coordinator.probe;
    if(probe&&probe->owner==state_->owner.lock().get()&&probe->observed)
        probe->observed("physical-reply-ready-before-wake");
    wake();
    if(probe&&probe->owner==state_->owner.lock().get()&&probe->observed)
        probe->observed("physical-reply-wake-returned");
    return true;
}
void recovery_receiver_controller::turn() {
    auto& runtime=*state_;
    {std::lock_guard lock(runtime.mutex);runtime.scheduled=false;runtime.scheduled_token=nullptr;
        if(runtime.deletion_retired)return;
        if(runtime.running){runtime.wake_pending=true;return;}
        runtime.running=true;runtime.wake_pending=false;}
    // Existing private restriction/observation seam only. Its holder precedes
    // settlement so the observed turn includes settlement's inline successors.
    std::shared_ptr<void> turn_scope;
    std::optional<recovery_writer_access::controller_admission_intent::turn> intent_turn;
    using notification=recovery_receiver_route::notification;
    struct settlement {recovery_receiver_controller& controller;recovery_receiver_controller::state& value;std::function<void()> after;
        struct notice {const recovery_receiver_route* identity=nullptr;std::weak_ptr<recovery_receiver_route> route;unsigned kinds=0;std::exception_ptr error;};
        std::array<notice,128> notices{};size_t notice_count=0;
        void notify(const std::shared_ptr<recovery_receiver_route>& route,notification kind,std::exception_ptr error={}){
            size_t slot=0;while(slot<notice_count&&notices[slot].identity!=route.get())++slot;
            require(slot<notices.size(),"controller notification route capacity");
            auto& item=notices[slot];if(slot==notice_count){++notice_count;item.identity=route.get();item.route=route;}
            item.kinds|=static_cast<unsigned>(kind);if(error&&!item.error)item.error=std::move(error);
        }
        // Admission-retry composition consumes this flag. Merely disposing a
        // late frame (or waiting for its copy) is not recovery progress and
        // must not reset an already-running admission deadline/allowance.
        bool keep_admission_wait=false;
        ~settlement(){
            recovery_writer_access::controller_admission_intent::retired_custody retired_writer;
            state::install_target_ptr retired_install;
            bool cancel_retry=false,episode_exhausted=false;int64_t retry_due=0;
            {std::lock_guard lock(value.mutex);
                // Retire the exact old hint before publishing !running. A
                // concurrent wake must not let this destructor erase a new
                // turn's intent; final writer release stays off the leaf.
                const bool revoked=value.deletion_retired||value.admission_intent_revoked||
                    (value.admission_install&&value.admission_install->id.revision!=value.revision);
                const auto stamp=now();
                episode_exhausted=value.admission_install&&!revoked&&
                    (stamp>=value.admission_wait.deadline||
                     (value.admission_wait.attempts>=admission_retry_attempts&&stamp>=value.admission_wait.next_due));
                const bool keep=(keep_admission_wait||bool(value.admission_install))&&!revoked&&!episode_exhausted;
                if(!keep){
                    value.admission_wait={};retired_install=std::move(value.admission_install);
                    retired_writer=value.admission_intent.retire();cancel_retry=true;
                }else if(value.admission_install){
                    // A consumed timer/quantum boundary cannot strand a target
                    // behind the original route FIFO. Preserve future due time;
                    // otherwise use one fixed tick within the original episode.
                    if(value.admission_wait.next_due<=stamp)
                        value.admission_wait.next_due=std::min(value.admission_wait.deadline,stamp+admission_retry_tick_ms);
                    retry_due=value.admission_wait.next_due;
                }
                value.admission_intent_revoked=false;
                value.running=false;
            }
            retired_writer.reset();retired_install.reset(); // no final proof/writer decrement on the coordinator leaf
#ifndef __EMSCRIPTEN__
            if(cancel_retry)value.executor->cancel_retry();
#endif
            if(episode_exhausted){
                try{controller.scheduling_failed(std::make_exception_ptr(db_error("controller admission retry budget exhausted; gate remains closed")));}
                catch(...){controller.scheduling_failed(std::current_exception());}
            }else if(retry_due){
                try{controller.arm_admission_retry(retry_due);}
                catch(...){controller.scheduling_failed(std::current_exception());}
            }
            if(after)try{after();}catch(...){controller.scheduling_failed(std::current_exception());}
            // This is after the real turn relinquishes its denial cell and
            // running flag. Inline custom route schedulers cannot occupy the
            // private controller lane before its required install can retire.
            for(size_t n=0;n<notice_count;++n)if(auto route=notices[n].route.lock())
                for(const auto kind:{notification::renew,notification::resumed,notification::reconcile,notification::error})
                    if(notices[n].kinds&static_cast<unsigned>(kind))
                        try{route->post(kind,notices[n].error);}catch(...){controller.scheduling_failed(std::current_exception());}
            value.wake_released(controller);
        }} settle{*this,runtime,{}};
    std::weak_ptr<lattice_db> observed_owner;
    int64_t admission_deadline=now()+admission_retry_window_ms;
    uint64_t admission_revision=0;
    std::optional<state::install_target_id> attempted_install;
    try {
        // Capture failure remains in the existing retained failure/settlement
        // path. The optional holder still outlives settlement and its tails.
        intent_turn.emplace(runtime.admission_intent);
        // Drain before idle/failure/cohort/source-count returns: even a dead
        // route's payload must leave the shared byte/slot budget. No SQL or
        // lifecycle proof publication is permitted in this bounded lane.
        for(unsigned quantum=0;quantum<2;++quantum) {
            std::shared_ptr<state::reply> front;
            {std::lock_guard lock(runtime.mutex);
                for(const auto& reply:runtime.late_inbox)if(reply&&(!front||reply->order<front->order))front=reply;
                if(!front)break;
                settle.keep_admission_wait=true;
                if(!front->ready)return;}
            auto route=front->late_route.lock();
            if(route&&!route->state_->retired.load()&&route->state_->source->recovery_live(front->late_view)) {
                observed_owner=route->state_->owner;
                try {
                    const auto description=parse(route->state_->source->recovery_description(front->late_view),65536);
                    const auto late=parse(front->bytes,recovery_request_store::frame_bytes);
                    // This inbox owns an already-described physical view. Keep
                    // the original verifier's refusal and exact-view revocation
                    // when a second describe is intercepted by this lane.
                    require(!repeated_description(late),"receiver source unsolicited, repeated or expired recovery frame");
                    if(terminal_profile(description)) {
                        if(late.value("operation",std::string{})=="predecessor")late_predecessor_shape(late,description);
                        else late_lifecycle_shape(late,description);
                    } else {
                        {std::lock_guard lock(runtime.mutex);require(route->state_->issued_discard_view.lock()==front->late_view.value,"controller unsolicited original late discard");}
                        original_discard_reply_shape(late,description);
                    }
                }catch(...){
                    const auto failure=std::current_exception();
                    if(runtime.probe&&runtime.probe->owner==route->state_->owner.lock().get()&&runtime.probe->observed)
                        runtime.probe->observed("late-lifecycle-validation-rejected");
                    // Idle routes may already permit ordinary export. Revoke
                    // exactly this current source before reporting its error;
                    // replacement/retirement must not poison another view.
                    bool invalidated=false;
                    try {invalidated=route->state_->source->recovery_live(front->late_view)&&
                        route->state_->source->invalidate(front->late_view.value);}
                    catch(...){std::rethrow_exception(failure);}
                    if(invalidated)std::rethrow_exception(failure);
                }
                // Shape and actual binding permit disposal only. The route
                // may retire during parsing; neither case creates authority.
                if(route->state_->source->recovery_live(front->late_view)&&runtime.probe&&
                    runtime.probe->owner==route->state_->owner.lock().get()&&runtime.probe->observed)
                    runtime.probe->observed("late-lifecycle-discarded");
            }
            if(route&&!route->state_->source->recovery_live(front->late_view)&&runtime.probe&&
                runtime.probe->owner==route->state_->owner.lock().get()&&runtime.probe->observed)
                runtime.probe->observed("late-lifecycle-retired-disposed");
            {std::lock_guard lock(runtime.mutex);for(auto& reply:runtime.late_inbox)if(reply==front)reply.reset();}
        }
        {std::lock_guard lock(runtime.mutex);
            if(std::any_of(runtime.late_inbox.begin(),runtime.late_inbox.end(),[](const auto& reply){return bool(reply);})) {
                settle.keep_admission_wait=true;return;
            }}
        uint64_t current_revision;{std::lock_guard lock(runtime.mutex);current_revision=runtime.revision;}
        for(auto at=runtime.disposals.begin();at!=runtime.disposals.end();) {
            auto route=at->second.route.lock();
            if(at->second.key.revision!=current_revision||!route||route->state_->retired.load()||!route->state_->source->recovery_live(at->second.view))at=runtime.disposals.erase(at);
            else ++at;
        }
        struct connected {
            std::shared_ptr<recovery_receiver_route> route;
            receiver_source_binding::recovery_view view;
            json description;
            canonical_scoped_contract scope;
        };
        std::vector<std::shared_ptr<recovery_receiver_route>> routes;
        {std::lock_guard lock(runtime.mutex);for(const auto& weak:runtime.routes)if(auto route=weak.lock())routes.push_back(std::move(route));}
        std::map<std::string,connected> connected_routes;
        for(const auto& route:routes) {
            if(route->state_->retired.load())continue;
            auto owner=route->state_->owner.lock();if(!owner||owner->is_closed())continue;
            const auto view=route->state_->source->recovery_current();if(!view) {
                if(route->state_->source->recovery_expired()&&!route->state_->renewal_requested.exchange(true)&&route->state_->renew)settle.notify(route,notification::renew);
                continue;
            }
            route->state_->renewal_requested.store(false);
            auto description=parse(route->state_->source->recovery_description(*view),65536);
            const auto channel=description.at("channel").get<std::string>();
            auto contribution=std::find_if(runtime.policy.contributions.begin(),runtime.policy.contributions.end(),[&](const auto& c){return c.profile.binding.channel==channel;});
            require(contribution!=runtime.policy.contributions.end(),"controller live channel outside enrollment");
            auto scope=contract(description,*contribution,recovery_continuous_producer::controller_catalog(*owner));
            const bool late_control=terminal_profile(description);
            {std::lock_guard lock(runtime.mutex);route->state_->late_control_view=
                (late_control||route->state_->issued_discard_view.lock()==view->value)?std::weak_ptr<const receiver_source_binding::record>(view->value):std::weak_ptr<const receiver_source_binding::record>{};}
            const auto prior=connected_routes.find(channel);
            if(prior==connected_routes.end()||decimal(description,"routeGeneration")>decimal(prior->second.description,"routeGeneration"))
                connected_routes.insert_or_assign(channel,connected{route,*view,std::move(description),std::move(scope)});
        }
        if(connected_routes.size()!=runtime.policy.contributions.size())return;
        auto owner=connected_routes.begin()->second.route->state_->owner.lock();if(!owner||owner->is_closed())return;
        observed_owner=owner;
        if(runtime.probe&&runtime.probe->owner==owner.get()&&runtime.probe->scope)
            turn_scope=runtime.probe->scope("selected-controller-turn-through-settlement");
        std::string common_domain;
        const auto common_receipt_binding=connected_routes.begin()->second.description.value("receiptBinding",json{});
        for(const auto& [channel,c]:connected_routes) {
            const auto key=domain(c.description);if(common_domain.empty())common_domain=key;
            require(key==common_domain,"controller overlapping replacement authority requires explicit configuration");
            require(c.description.value("receiptBinding",json{})==common_receipt_binding,"controller receipt producer or cohort differs across contributions");
        }
        uint64_t changed_sources=0;
        for(const auto& [channel,c]:connected_routes)
            if(!runtime.observed.count(channel)||runtime.observed.at(channel).value!=c.view.value)++changed_sources;
        {std::lock_guard lock(runtime.mutex);
            require(changed_sources<=UINT64_MAX-runtime.revision&&changed_sources<=UINT64_MAX-runtime.external_revision,
                "controller demand revision exhausted");
            // One publication replaces the COMPLETE actual selected set and
            // clears an old cohort's failure before any new member can read it.
            // A still-live lower-generation sibling is explicitly deselected.
            for(const auto& route:routes)route->state_->checked_selected_view.reset();
            if(changed_sources){runtime.revision+=changed_sources;runtime.external_revision+=changed_sources;
                runtime.demand=true;runtime.failure={};runtime.awaiting_delivery_retry=false;}
            for(const auto& [_,c]:connected_routes)c.route->state_->checked_selected_view=c.view.value;
        }
        for(const auto& [channel,c]:connected_routes) {
            if(!runtime.observed.count(channel)||runtime.observed.at(channel).value!=c.view.value){
                std::shared_ptr<const recovery_reconciliation_descriptor> retired;
                {std::lock_guard lock(runtime.mutex);retired=std::move(runtime.reconciliation);}
                runtime.observed[channel]=c.view;runtime.frozen.reset();runtime.framing_committed=false;
                runtime.lifecycles.clear();runtime.inspect_required.clear();runtime.terminal_rearm=false;runtime.leases.clear();runtime.predecessors.clear();runtime.disposals.clear();
            }
        }
        for(const auto& [_,c]:connected_routes)
            admission_deadline=std::min(admission_deadline,now()+c.route->state_->source->recovery_remaining(c.view));
        bool reconciliation_waiting=false,retire_admission_intent=false;
        state::install_target_ptr retired_revision_install;
        {std::lock_guard lock(runtime.mutex);reconciliation_waiting=static_cast<bool>(runtime.reconciliation);
            if(!reconciliation_waiting&&(runtime.failure||(runtime.idle&&!runtime.demand&&!runtime.outstanding)))return;
            admission_revision=runtime.revision;
            if(runtime.outstanding)admission_deadline=std::min(admission_deadline,runtime.outstanding->deadline);
            auto& wait=runtime.admission_wait;
            if(wait.attempts&&wait.revision!=runtime.revision){
                wait={};retired_revision_install=std::move(runtime.admission_install);retire_admission_intent=true;
            }
            if(wait.attempts){
                wait.deadline=std::min(wait.deadline,admission_deadline);
                require(now()<wait.deadline&&wait.attempts<admission_retry_attempts,"controller admission retry budget exhausted; gate remains closed");
                if(now()<wait.next_due){settle.keep_admission_wait=true;return;}
            }}
        if(retire_admission_intent)runtime.admission_intent.release();
        retired_revision_install.reset(); // old proof custody leaves after the coordinator leaf
        if(reconciliation_waiting){for(const auto& route:routes)settle.notify(route,notification::reconcile);return;}
        const auto observe=[&](const char* stage){if(runtime.probe&&runtime.probe->owner==owner.get()&&runtime.probe->observed)runtime.probe->observed(stage);};
        // No new Q/frozen/journal graph may coexist with a retired cohort.
        // The actual running/current-controller reservation spans this whole
        // turn; current descriptors took their notification branch above.
        if(recovery_continuous_producer::controller_cohort(*this,owner)==recovery_continuous_producer::cohort_admission::retained){observe("cohort-retained");return;}
        const auto reserve_cohort=[&](const std::shared_ptr<recovery_reconciliation_descriptor>& descriptor){
            const auto admitted=recovery_continuous_producer::controller_cohort(*this,owner,descriptor);
            if(admitted==recovery_continuous_producer::cohort_admission::retained){observe("cohort-retained");return false;}
            observe("cohort-reserved");return true;
        };
        const auto probe_scope=[&](const char* stage)->std::shared_ptr<void>{return runtime.probe&&runtime.probe->owner==owner.get()&&runtime.probe->scope?runtime.probe->scope(stage):nullptr;};
        const auto live=[&]{for(const auto& [_,c]:connected_routes)require(!c.route->state_->retired.load()&&c.route->state_->source->recovery_live(c.view),"controller authenticated source retired during owned operation");};
        const auto finish_install_target=[&](const state::install_target_id& completed){
            state::install_target_ptr retired_install;
            recovery_writer_access::controller_admission_intent::retired_custody retired_writer;
            bool cancel_retry=false;
            {std::lock_guard lock(runtime.mutex);
                if(runtime.admission_install){
                    require(runtime.admission_install->id==completed,"controller completed a different admission install target");
                    retired_install=std::move(runtime.admission_install);runtime.admission_wait={};
                    retired_writer=runtime.admission_intent.retire();cancel_retry=true;
                }
                settle.keep_admission_wait=false;
            }
            retired_writer.reset();retired_install.reset();
#ifndef __EMSCRIPTEN__
            if(cancel_retry)runtime.executor->cancel_retry();
#endif
        };
        const auto owned=[&](const std::function<void(database&)>& body,const state::install_target_id* install=nullptr){
            attempted_install=install?std::optional<state::install_target_id>{*install}:std::nullopt;
            const auto result=recovery_continuous_producer::controller_owned(*this,owner,[&](database& db){live();recovery_cohort_progress_observation::body_entered();body(db);live();},true);
            recovery_cohort_progress_observation::returned(result);known(result);
            // The Native unit has returned with known COMMIT. Intermediate
            // success must not discharge a different, deferred install.
            if(install)finish_install_target(*install);
            else {std::lock_guard lock(runtime.mutex);settle.keep_admission_wait=bool(runtime.admission_install);}
        };
        const auto owned_completed_disposal=[&](const std::function<void(database&)>& body){
            attempted_install.reset();
            const auto result=recovery_continuous_producer::controller_owned(*this,owner,[&](database& db){live();body(db);live();},true);
            try {known(result);}
            catch(const controller_admission_wait&){throw;}
            catch(const controller_stale_turn_cancelled&){throw;}
            catch(const controller_generation_unsettled&){throw;}
            catch(...){throw controller_disposal_refused(std::current_exception(),result);}
            {std::lock_guard lock(runtime.mutex);settle.keep_admission_wait=bool(runtime.admission_install);}
        };
        // Read and validate the COMPLETE local precursor before any remote
        // disposal. The installed branch deliberately precedes old context
        // parsing; only canceled predecessors need compatibility authority.
        const auto disposal_snapshot=[&](int64_t physical,int64_t barrier,int64_t attempt,uint64_t revision) {
            require(runtime.frozen&&runtime.frozen_attempt==attempt&&runtime.frozen_barrier==barrier,"controller disposal lacks frozen cohort");
            recovery_continuous_producer::verify_for_owned_write(*runtime.frozen);
            auto* writer=recovery_writer_access::active_writer(*owner);require(writer!=nullptr,"controller disposal requires owned writer");
            const auto phase=writer->query("SELECT incarnation,phase,barrier,attempt FROM main._lattice_producer_continuity WHERE id=1");
            require(phase.size()==1&&integer(phase[0],"incarnation")==physical&&integer(phase[0],"phase")==2&&
                integer(phase[0],"barrier")==barrier&&integer(phase[0],"attempt")==attempt,"controller disposal durable phase changed");
            observe("disposal-before-generation-validation");
            {std::lock_guard lock(runtime.mutex);if(runtime.revision!=revision)
                throw controller_generation_changed(revision,"controller disposal generation changed");}
            recovery_request_store requests(owner);receive_install_store receiver(owner,runtime.caps.install.installations);receiver.audit();
            const auto fingerprints=requests.fingerprints();
            for(const auto& [channel,_]:fingerprints)require(connected_routes.count(channel),"controller disposal unknown request channel");
            const auto cohort=picosha2::hash256_hex_string(json(fingerprints).dump());
            std::map<std::string,state::disposal> result;
            for(const auto& frozen:runtime.frozen->frozen_journals()) {
                const auto& channel=frozen.scope.address.channel;const auto& c=connected_routes.at(channel);
                const auto current=receiver.read(channel);require(current&&current->binding==frozen.scope.profile.binding,
                    "controller disposal actual receiver unavailable");
                const auto row=requests.read(channel);if(!row){require(!current->active&&!current->last_installed,"controller initial Q receiver has prior state");continue;}
                const auto oldq=cr::decode(row->request_frame,runtime.caps.codec);const auto* old_request=std::get_if<cr::request>(&oldq.body);
                require(old_request&&oldq.logical.channel==channel&&oldq.logical.sequence==uint64_t(row->sequence)&&
                    old_request->source==source_binding(frozen.scope.profile),"controller disposal durable Q identity differs");
                const auto compatibility=[&]{const auto at=runtime.predecessors.find(channel);
                    const auto proof=at==runtime.predecessors.end()?std::shared_ptr<const recovery_reconciliation_descriptor::predecessor>{}:at->second;
                    return compatible_context(*row,c.description,proof,c.route,c.view,revision,physical,2,barrier,attempt,runtime.caps.codec);};
                if(row->sequence==attempt){require(row->journal==frozen.scope.address&&row->journal_revision==frozen.scope.revision&&row->barrier==barrier&&
                    compatibility()&&row->domain==common_domain,"controller disposal current Q binding changed");continue;}
                require(!current->active,"controller disposal predecessor receiver is active");
                bool installed=false;
                if(!row->manifest_frame.empty()) {
                    const auto oldm=cr::decode(row->manifest_frame,runtime.caps.codec);
                    require(oldm.logical==oldq.logical&&std::holds_alternative<cr::manifest>(oldm.body),"controller disposal durable M identity differs");
                    const auto identity=describe_canonical_range(oldq.logical,std::get<cr::request>(oldq.body),std::get<cr::manifest>(oldm.body),runtime.caps.codec,row->route).installation_identity;
                    installed=current->last_installed==std::optional<receive_install_identity>{identity};
                }
                const bool canceled=!installed&&compatibility()&&row->domain==common_domain&&
                    (row->manifest_frame.empty()?canceled_predecessor(*row,frozen.scope,*current,std::get<cr::request>(oldq.body),2,barrier,attempt):
                    row->sequence==attempt-1&&row->barrier==barrier-1&&current->last_sequence==row->sequence&&
                    (!current->last_installed||current->last_installed->sequence<row->sequence)&&frozen.scope.address.incarnation==row->journal.incarnation&&
                    row->journal.generation<=INT64_MAX-2&&frozen.scope.address.generation==row->journal.generation+2&&frozen.scope.last_attempt==attempt);
                require(installed||canceled,"controller disposal predecessor lacks installed or canceled evidence");
                state::disposal receipt;receipt.route=c.route;receipt.view=c.view;auto& key=receipt.key;
                key.physical=physical;key.barrier=barrier;key.attempt=attempt;key.revision=revision;
                key.journal=row->journal;key.frozen_journal=frozen.scope.address;key.frozen_revision=frozen.scope.revision;
                key.row_barrier=row->barrier;key.row_sequence=row->sequence;key.row_revision=row->journal_revision;key.row_route=row->route;
                key.logical=oldq.logical;key.request_digest=std::get<cr::request>(oldq.body).request_digest;
                key.request_hash=picosha2::hash256_hex_string(row->request_frame);key.manifest_hash=picosha2::hash256_hex_string(row->manifest_frame);
                key.old_context=picosha2::hash256_hex_string(row->source_context);key.old_domain=picosha2::hash256_hex_string(row->domain);
                key.current_context=picosha2::hash256_hex_string(source_context(c.description));key.cohort=cohort;key.receiver=*current;key.installed=installed;
                require(result.size()<runtime.policy.contributions.size(),"controller disposal receipt capacity");result.emplace(channel,std::move(receipt));
            }
            live();return result;
        };
        const auto same_disposal=[](const state::disposal& a,const state::disposal& b){
            return a.route.lock()==b.route.lock()&&a.view.value==b.view.value&&a.key==b.key;
        };
        const auto send_control=[&](const connected& c,const std::string& op,uint64_t index,const auto& fill,
            int64_t physical=0,int64_t phase=0,int64_t barrier=0,int64_t attempt=0,uint64_t revision=0,
            std::optional<state::disposal> completed={}) {
            auto outgoing=std::make_shared<state::pending>();
            {std::lock_guard lock(runtime.mutex);
                // Subscribe BEFORE inspecting actual credit. A concurrent final
                // callback release either sees this bit or precedes our zero check.
                runtime.budget->capacity_wait.store(true);
                if(runtime.budget->bytes.load()==0&&runtime.budget->slots.load()==0){
                    runtime.budget->capacity_wait.store(false);
                    outgoing->reservation=runtime.reserve_locked(8388608,false);
                }}
            if(!outgoing->reservation){
                settle.keep_admission_wait=true;
                if(runtime.probe&&runtime.probe->owner==owner.get()&&runtime.probe->response_capacity_wait)
                    runtime.probe->response_capacity_wait(); // passive DATA, off leaf
                return;
            }
            outgoing->route=c.route;outgoing->view=c.view;outgoing->request_id=uuid_t::generate().to_string();outgoing->operation=op;outgoing->index=index;outgoing->completed_disposal=std::move(completed);
            {std::lock_guard lock(runtime.mutex);outgoing->terminal_inbox=terminal_profile(c.description)||outgoing->completed_disposal.has_value()||c.route->state_->issued_discard_view.lock()==c.view.value;}
            outgoing->proof_physical=physical;outgoing->proof_phase=phase;outgoing->proof_barrier=barrier;outgoing->proof_attempt=attempt;outgoing->proof_revision=revision;
            json command={{"kind","recoveryReady"},{"version",1},{"operation",op},{"requestID",outgoing->request_id},{"routeGeneration",c.description.at("routeGeneration")}};
            const auto remaining=c.route->state_->source->recovery_remaining(c.view);require(remaining>100,"controller source authorization renewal required");
            fill(command,remaining);
            outgoing->request_bytes=command.dump();require(outgoing->request_bytes.size()<=8388608&&outgoing->request_bytes.size()<=pending_bytes-4194304,"controller outgoing aggregate capacity");
            outgoing->reservation->shrink(outgoing->request_bytes.size());outgoing->deadline=now()+std::min<int64_t>(remaining,30000);
            observe("outgoing-built-before-publication");bool late_pending=false;
            {std::lock_guard lock(runtime.mutex);require(!runtime.outstanding,"controller overlapping request admission");
                // This payload has never been published or physically handed
                // off. Throwing unwinds the leaf before its final owner drops.
                if(outgoing->completed_disposal&&runtime.revision!=outgoing->completed_disposal->key.revision)
                    throw controller_stale_turn_cancelled(outgoing->completed_disposal->key.revision,"controller disposal handoff generation changed");
                runtime.budget->capacity_wait.store(true);
                late_pending=runtime.budget->slots.load()!=0;
                if(!late_pending){runtime.budget->capacity_wait.store(false);runtime.outstanding=outgoing;}}
            if(late_pending){
                settle.keep_admission_wait=true;
                if(runtime.probe&&runtime.probe->owner==owner.get()&&runtime.probe->response_capacity_wait)
                    runtime.probe->response_capacity_wait();
                observe("late-control-handoff-deferred");return;
            }
            auto message=transport_message::from_string(outgoing->request_bytes);message.msg_type=transport_message::type::binary;
            require(c.route->state_->source->recovery_send(c.view,*c.route->state_->transport,message),"controller final physical handoff refused");
            if(outgoing->completed_disposal){std::lock_guard lock(runtime.mutex);c.route->state_->issued_discard_view=c.view.value;c.route->state_->late_control_view=c.view.value;}
            // Passive private probe only, off coordinator/SQL/transport leaves.
            // The actual pending request has been published and handed off.
            observe("outgoing-handed-off-before-turn-settlement");
        };
        // Socket callbacks reserve at most two bounded replies. Only this worker
        // parses it or touches SQL. Claiming the reply keeps its full byte
        // charge until the exact transactional consumer finishes.
        std::shared_ptr<state::pending> pending;
        {std::lock_guard lock(runtime.mutex);pending=runtime.outstanding;}
        for(unsigned reply_quantum=0;pending&&reply_quantum<2;++reply_quantum) {
            auto route=pending->route.lock();
            bool disposal_retired=false;
            {std::lock_guard lock(runtime.mutex);disposal_retired=pending->completed_disposal&&pending->completed_disposal->key.revision!=runtime.revision;}
            if(!route||route->state_->retired.load()||!route->state_->source->recovery_live(pending->view)||disposal_retired||now()>=pending->deadline){
                const bool expired=now()>=pending->deadline;
                {std::lock_guard lock(runtime.mutex);if(runtime.outstanding==pending)runtime.outstanding.reset();}
                settle.keep_admission_wait=true;
                observe(expired?"pending-expired-before-successor":"pending-retired-before-successor");return;
            }
            std::shared_ptr<state::reply> front;
            {std::lock_guard lock(runtime.mutex);
                for(const auto& reply:pending->inbox)if(reply&&(!front||reply->order<front->order))front=reply;
                if(!front||!front->ready)return;}
            // Stable immutable bytes survive parsing, SQL, and a no-effect
            // admission deferral. Do not dequeue before known consumption.
            const auto& response=front->bytes;
            observe(pending->operation=="read"?"range-response-ready":"control-response-ready");
            const auto description=parse(route->state_->source->recovery_description(pending->view),65536);
            const auto channel=description.at("channel").get<std::string>();
            const auto response_value=parse(response,recovery_request_store::frame_bytes);
            if(repeated_description(response_value)) {
                // Pending control/range requests must not turn a repeated
                // describe into a generic parse failure with live authority.
                // invalidate compares the actual retained record under its
                // leaf; a replaced view cannot revoke the successor.
                if(route->state_->source->recovery_live(pending->view)&&route->state_->source->invalidate(pending->view.value))
                    refuse("receiver source unsolicited, repeated or expired recovery frame");
                {std::lock_guard lock(runtime.mutex);if(runtime.outstanding==pending)runtime.outstanding.reset();}
                settle.keep_admission_wait=true;return;
            }
            bool original_discard_admitted;
            {std::lock_guard lock(runtime.mutex);original_discard_admitted=route->state_->issued_discard_view.lock()==pending->view.value;}
            if((terminal_profile(description)||(original_discard_admitted&&response_value.value("operation",std::string{})=="discard"))&&
                response_value.is_object()&&response_value.contains("kind")&&response_value.at("kind")=="recoveryReady"&&
                response_value.contains("version")&&response_value.at("version")==1&&response_value.contains("operation")&&
                (response_value.at("operation")=="inspect"||response_value.at("operation")=="discard"||response_value.at("operation")=="predecessor")&&
                response_value.contains("requestID")&&response_value.at("requestID").is_string()&&response_value.at("requestID")!=pending->request_id&&
                response_value.contains("routeGeneration")&&response_value.at("routeGeneration")==description.at("routeGeneration")){
                if(response_value.at("operation")=="predecessor")late_predecessor_shape(response_value,description);
                else if(terminal_profile(description))lifecycle_reply_shape(response_value);
                else original_discard_reply_shape(response_value,description);
                // A delayed lifecycle reply cannot settle a different request.
                // Keep its actual outstanding request, deadline and Q unchanged.
                {std::lock_guard lock(runtime.mutex);
                    require(runtime.outstanding==pending,"controller stale reply request retired");
                    for(auto& reply:pending->inbox)if(reply==front)reply.reset();}
                observe("terminal-stale-control-ignored");continue;
            }
            if(pending->completed_disposal) {
                const auto& receipt=*pending->completed_disposal;
                const auto submitted=cr::decode(parse(pending->request_bytes,8388608).at("request").get<std::string>(),runtime.caps.codec);
                require(submitted.logical==receipt.key.logical&&std::get<cr::request>(submitted.body).request_digest==receipt.key.request_digest&&
                    submitted.route_generation==decimal(description,"routeGeneration"),"controller completed disposal submitted Q changed");
                require(pending->operation=="discard"&&response_value.at("requestID")==pending->request_id,
                    "controller completed disposal correlation differs");
                if(terminal_profile(description)) {
                    late_lifecycle_shape(response_value,description);
                    require(response_value.contains("lifecycle"),"controller completed disposal lacks terminal source facts");
                    const auto& body=response_value.at("lifecycle");
                    require(body.at("state")=="terminal"&&decimal(body,"bindingHighWater")==receipt.key.logical.sequence&&
                        decimal(body,"sequence")==receipt.key.logical.sequence&&body.at("requestDigest")==receipt.key.request_digest&&
                        body.at("attemptID")==receipt.key.logical.attempt_id&&body.at("receiverIncarnation")==receipt.key.logical.receiver_incarnation&&
                        body.at("channelIncarnation")==receipt.key.logical.channel_incarnation&&body.at("channel")==receipt.key.logical.channel,
                        "controller completed disposal exact Q differs");
                } else original_discard_reply_shape(response_value,description);
                require(response_value.at("operation")=="discard"&&response_value.at("settlement").at("state")=="committed",
                    "controller completed disposal lacks current known COMMIT");
                owned([&](database&){
                    {std::lock_guard lock(runtime.mutex);require(runtime.outstanding==pending,"controller completed disposal request retired");}
                    const auto current=disposal_snapshot(receipt.key.physical,receipt.key.barrier,receipt.key.attempt,receipt.key.revision);
                    const auto at=current.find(channel);require(at!=current.end()&&same_disposal(at->second,receipt),"controller completed disposal local/source custody changed");
                });
                require(runtime.disposals.count(channel)||runtime.disposals.size()<runtime.policy.contributions.size(),"controller completed disposal receipt capacity");
                runtime.disposals.insert_or_assign(channel,receipt);observe("completed-disposal-consumed");
            } else if(pending->operation=="predecessor") {
                late_predecessor_shape(response_value,description);
                require(response_value.at("requestID")==pending->request_id&&response_value.contains("predecessor"),"controller predecessor correlation or committed facts missing");
                const auto submitted=parse(pending->request_bytes,8388608);const auto q=cr::decode(submitted.at("request").get<std::string>(),runtime.caps.codec);
                const auto& request=std::get<cr::request>(q.body);const auto& body=response_value.at("predecessor");
                predecessor_wire::pair(submitted.at("priorProfile"),description.at("profile"),description.contains("receiptBinding"));
                require(body.at("beforeProfileDigest")==predecessor_wire::profile_digest(submitted.at("priorProfile"))&&
                    body.at("requestDigest")==request.request_digest&&body.at("attemptID")==q.logical.attempt_id&&decimal(body,"sequence")==q.logical.sequence&&
                    body.at("receiverIncarnation")==q.logical.receiver_incarnation&&body.at("channelIncarnation")==q.logical.channel_incarnation&&body.at("channel")==q.logical.channel&&
                    q.route_generation==decimal(description,"routeGeneration"),"controller predecessor exact submitted Q differs");
                std::shared_ptr<recovery_reconciliation_descriptor::predecessor> issued;
                owned([&](database& db){
                    {std::lock_guard lock(runtime.mutex);require(runtime.revision==pending->proof_revision&&runtime.outstanding==pending,"controller predecessor generation changed");}
                    const auto phase=db.query("SELECT incarnation,phase,barrier,attempt FROM main._lattice_producer_continuity WHERE id=1 LIMIT 2");
                    require(phase.size()==1&&integer(phase[0],"incarnation")==pending->proof_physical&&integer(phase[0],"phase")==pending->proof_phase&&
                        integer(phase[0],"barrier")==pending->proof_barrier&&integer(phase[0],"attempt")==pending->proof_attempt&&
                        (pending->proof_phase==2||pending->proof_phase==4),"controller predecessor durable phase changed");
                    recovery_request_store requests(owner);const auto row=requests.read(channel);require(row&&row->domain==common_domain,"controller predecessor retained Q missing");
                    const auto retained=cr::decode(row->request_frame,runtime.caps.codec);
                    require(retained.logical==q.logical&&retained.body==q.body&&predecessor_profile(*row,description).dump()==submitted.at("priorProfile").dump(),"controller predecessor retained Q/context changed");
                    issued=std::make_shared<recovery_reconciliation_descriptor::predecessor>();
                    issued->route=route;issued->view=pending->view;issued->logical=q.logical;issued->request_digest=request.request_digest;
                    issued->journal=row->journal;issued->row_barrier=row->barrier;issued->row_sequence=row->sequence;issued->row_revision=row->journal_revision;issued->domain=row->domain;
                    issued->old_context=picosha2::hash256_hex_string(row->source_context);issued->current_context=picosha2::hash256_hex_string(source_context(description));
                    issued->transition_id=body.at("transitionID");issued->transition_digest=body.at("transitionDigest");issued->source_identity_digest=body.at("sourceIdentityDigest");
                    issued->physical=pending->proof_physical;issued->phase=pending->proof_phase;issued->barrier=pending->proof_barrier;issued->attempt=pending->proof_attempt;issued->controller_revision=pending->proof_revision;
                });
                live();require(issued!=nullptr,"controller predecessor inspected facts unavailable");
                runtime.predecessors.insert_or_assign(channel,std::move(issued));observe("predecessor-consumed");
            } else if(pending->operation=="read") {
                // A failed control response is not a range, absence proof or
                // durable progress. Retain Q/stage and renew the real lease.
                const auto& envelope=response_value;
                if(envelope.contains("kind")) {
                    members(envelope,{"kind","version","operation","requestID","routeGeneration","settlement","frameAvailable"});settlement_shape(envelope.at("settlement"));
                    require(envelope.at("version")==1&&envelope.at("kind")=="recoveryReady"&&envelope.at("operation")=="read"&&envelope.at("requestID")==pending->request_id&&
                        envelope.at("routeGeneration")==description.at("routeGeneration")&&envelope.at("frameAvailable")==false,"controller read refusal correlation differs");
                    runtime.leases.erase(channel);
                } else {
                    const auto frame=cr::decode(response,runtime.caps.codec);
                    owned([&](database&){
                        recovery_request_store requests(owner);const auto row=requests.read(channel);require(row.has_value(),"controller range lacks durable Q");
                        const auto q=cr::decode(row->request_frame,runtime.caps.codec);
                        require(frame.logical==q.logical&&frame.route_generation==uint64_t(row->route),"controller range physical or logical attempt differs");
                        canonical_range_staging stages(owner,runtime.caps.install.installations,runtime.caps.codec,runtime.caps.staging);
                        if(const auto* manifest=std::get_if<cr::manifest>(&frame.body)) {
                            require(pending->index==0,"controller unsolicited manifest index");
                            if(row->manifest_frame.empty()){stages.begin(q.logical,std::get<cr::request>(q.body),*manifest,row->route);requests.add_manifest(*row,response);}
                            else {const auto original=cr::decode(row->manifest_frame,runtime.caps.codec);require(original.logical==frame.logical&&original.body==frame.body,"controller manifest changed on resume");}
                        } else {
                            require(!row->manifest_frame.empty(),"controller page before committed manifest");
                            auto current=stages.resume(q.logical,std::get<cr::manifest>(cr::decode(row->manifest_frame,runtime.caps.codec).body).manifest_digest,row->route);
                            require(pending->index==1+current.state.next_content_page+current.state.next_receipt_page,"controller range index differs from durable stage");
                            if(std::holds_alternative<cr::end>(frame.body))stages.verify_end(frame);else stages.append(frame);
                        }
                    });
                }
            } else if(pending->operation=="inspect"||pending->operation=="discard") {
                require(terminal_profile(description),"controller lifecycle reply outside negotiated profile");
                const auto& value=response_value;
                lifecycle_reply_shape(value);
                require(value.at("kind")=="recoveryReady"&&value.at("version")==1&&value.at("operation")==pending->operation&&
                    value.at("requestID")==pending->request_id&&value.at("routeGeneration")==description.at("routeGeneration")&&
                    value.at("leaseAvailable").is_boolean()&&value.at("leaseAvailable")==false,"controller lifecycle correlation differs");
                require(value.at("settlement").at("state")=="committed"&&value.contains("lifecycle"),"controller lifecycle lacks known source COMMIT");
                const auto q=cr::decode(parse(pending->request_bytes,8388608).at("request").get<std::string>(),runtime.caps.codec);
                const auto& request=std::get<cr::request>(q.body);const auto& lifecycle=value.at("lifecycle");
                members(lifecycle,{"state","requestDigest","attemptID","sequence","bindingHighWater","namespaceID","replicaID","receiverIncarnation","channelIncarnation","channel"});
                require(lifecycle.at("state").is_string(),"controller lifecycle state type");const auto status=lifecycle.at("state").get<std::string>();
                const auto high=decimal(lifecycle,"bindingHighWater",0);
                require((status=="available"||status=="terminal"||status=="unstarted")&&
                    (status=="unstarted"?high<q.logical.sequence:high==q.logical.sequence)&&
                    lifecycle.at("requestDigest")==request.request_digest&&lifecycle.at("attemptID")==q.logical.attempt_id&&
                    decimal(lifecycle,"sequence")==q.logical.sequence&&lifecycle.at("namespaceID")==description.at("source").at("receiptNamespace")&&
                    lifecycle.at("replicaID")==description.at("peer").at("replicaID")&&lifecycle.at("receiverIncarnation")==q.logical.receiver_incarnation&&
                    lifecycle.at("channelIncarnation")==q.logical.channel_incarnation&&lifecycle.at("channel")==q.logical.channel&&
                    lifecycle.at("receiverIncarnation")==description.at("peer").at("receiverIncarnation")&&
                    lifecycle.at("channelIncarnation")==description.at("peer").at("channelIncarnation")&&q.logical.channel==channel,
                    "controller lifecycle differs from exact authenticated frozen Q");
                require(pending->operation!="discard"||status=="terminal","controller discard did not terminal-fence Q");
                owned([&](database& db){recovery_request_store requests(owner);const auto row=requests.read(channel);
                    require(row&&row->domain==common_domain,"controller lifecycle source context changed");
                    const auto retained=cr::decode(row->request_frame,runtime.caps.codec);
                    require(retained.logical==q.logical&&retained.body==q.body&&row->route==static_cast<int64_t>(q.route_generation),"controller lifecycle durable Q changed");
                    const auto phase=db.query("SELECT incarnation,phase,barrier,attempt FROM main._lattice_producer_continuity WHERE id=1");
                    require(phase.size()==1&&integer(phase[0],"phase")==2&&integer(phase[0],"barrier")==row->barrier&&integer(phase[0],"attempt")==row->sequence,
                        "controller lifecycle frozen attempt changed");
                    const auto at=runtime.predecessors.find(channel);
                    const auto compatibility=at==runtime.predecessors.end()?std::shared_ptr<const recovery_reconciliation_descriptor::predecessor>{}:at->second;
                    uint64_t revision;{std::lock_guard lock(runtime.mutex);revision=runtime.revision;}
                    require(compatible_context(*row,description,compatibility,route,pending->view,revision,integer(phase[0],"incarnation"),2,
                        integer(phase[0],"barrier"),integer(phase[0],"attempt"),runtime.caps.codec),"controller lifecycle source context changed");
                    require(status!="unstarted"||row->manifest_frame.empty(),"controller previously manifested Q became unstarted");
                });
                runtime.inspect_required.erase(channel);runtime.leases.erase(channel);
                runtime.lifecycles.insert_or_assign(channel,state::lifecycle{route,pending->view,q.logical,request.request_digest,status});
                if(status=="terminal"){
                    for(const auto& [_,part]:connected_routes)require(terminal_profile(part.description),"controller terminal rearm needs every negotiated source");
                    runtime.terminal_rearm=true;runtime.leases.clear();
                }else if(status=="unstarted")runtime.leases.emplace(channel,state::lease{route,pending->view,{},{},{},0,0,now()+1000});
            } else {
                const auto& value=response_value;
                members(value,{"kind","version","operation","requestID","routeGeneration","leaseAvailable"},
                    {"settlement","expiration","preparation","publication","captureError","requiresFullRequest","leaseID","requestDigest","attemptID","sequence","frames","wireBytes","durationMilliseconds"});
                require(value.at("leaseAvailable").is_boolean(),"controller lease status type");
                for(const auto* key:{"settlement","expiration","preparation","publication"})if(value.contains(key))settlement_shape(value.at(key));
                if(pending->operation=="resume")require(value.contains("settlement")&&!value.contains("expiration")&&!value.contains("preparation")&&!value.contains("publication")&&!value.contains("captureError")&&!value.contains("requiresFullRequest"),"controller mixed resume result");
                else require(value.contains("expiration")&&!value.contains("settlement"),"controller mixed prepare result");
                require(value.at("kind")=="recoveryReady"&&value.at("version")==1&&value.at("operation")==pending->operation&&
                    value.at("requestID")==pending->request_id&&value.at("routeGeneration")==description.at("routeGeneration"),"controller lease correlation differs");
                if(value.at("leaseAvailable")==true) {
                    if(pending->operation=="resume")require(value.at("settlement").at("state")=="committed","controller resume lease without known source commit");
                    else require(value.at("expiration").at("state")=="committed"&&value.at("publication").at("state")=="committed"&&
                        value.at("captureError")==false&&value.at("requiresFullRequest")==false,"controller preparation lease without complete source publication");
                    const auto q=cr::decode(parse(pending->request_bytes,8388608).at("request").get<std::string>(),runtime.caps.codec);
                    require(value.at("requestDigest")==std::get<cr::request>(q.body).request_digest&&value.at("attemptID")==q.logical.attempt_id&&decimal(value,"sequence")==q.logical.sequence,
                        "controller returned lease differs from frozen Q");
                    const auto duration=value.at("durationMilliseconds").get<int64_t>();require(duration>0&&duration<=3600000&&now()<=INT64_MAX-duration,"controller returned lease duration invalid");
                    const auto id=value.at("leaseID").get<std::string>();require(!id.empty()&&id.size()<=128,"controller lease identity capacity");
                    const auto frames=decimal(value,"frames");require(frames<=770&&frames<=description.at("profile").at("frames").get<uint64_t>(),"controller lease frame inventory capacity");
                    require(decimal(value,"wireBytes")<=description.at("profile").at("transferBytes").get<uint64_t>(),"controller lease wire inventory capacity");
                    runtime.leases.insert_or_assign(channel,state::lease{route,pending->view,id,std::get<cr::request>(q.body).request_digest,q.logical.attempt_id,q.logical.sequence,frames,now()+duration});
                    runtime.lifecycles.erase(channel);runtime.inspect_required.erase(channel);
                } else {
                    require(value.at("leaseAvailable")==false,"controller invalid lease status");
                    for(const auto* key:{"leaseID","requestDigest","attemptID","sequence","frames","wireBytes","durationMilliseconds"})require(!value.contains(key),"controller unavailable lease carries positive identity");
                    // No source error is converted to absence. A later prepare
                    // can only succeed under the source's own exact sequence,
                    // active-binding and high-water checks; it cannot overwrite
                    // a retained transfer. Mark this as a bounded retry choice.
                    runtime.leases.erase(channel);
                    if(pending->operation=="resume") {
                        // Empty lease identity denotes one allowed prepare
                        // attempt, never an authenticated negative outcome.
                        if(terminal_profile(description))runtime.inspect_required.insert(channel);
                        else runtime.leases.emplace(channel,state::lease{route,pending->view,{},{},{},0,0,now()+1000});
                    } else refuse("controller source preparation refused; exact Q retained");
                }
            }
            {std::lock_guard lock(runtime.mutex);if(runtime.outstanding==pending)runtime.outstanding.reset();}
            pending.reset(); // worker/request payloads retire outside the leaf
            settle.keep_admission_wait=false; // actual correlated consumption
            observe("response-consumed");
            observe("pending-consumed-before-successor");
        }
        if(pending){settle.after=[route=pending->route.lock()]{if(route)route->wake();};return;}
        for(unsigned quantum=0;quantum<4;++quantum) {
            int64_t phase=0,barrier=0,attempt=0,physical_incarnation=0;uint64_t demand_revision;
            {std::lock_guard lock(runtime.mutex);demand_revision=runtime.revision;}
            owned([&](database& db){const auto rows=db.query("SELECT CASE WHEN typeof(incarnation)='integer' THEN incarnation END AS incarnation,CASE WHEN typeof(phase)='integer' THEN phase END AS phase,CASE WHEN typeof(barrier)='integer' THEN barrier END AS barrier,CASE WHEN typeof(attempt)='integer' THEN attempt END AS attempt FROM main._lattice_producer_continuity WHERE id=1 LIMIT 2");require(rows.size()==1,"controller physical phase missing");phase=integer(rows[0],"phase");barrier=integer(rows[0],"barrier");attempt=integer(rows[0],"attempt");physical_incarnation=integer(rows[0],"incarnation");});
            {std::lock_guard lock(runtime.mutex);if(runtime.admission_install){const auto& target=runtime.admission_install->id;
                require(target.revision==demand_revision&&target.physical==physical_incarnation&&phase==2&&
                    target.barrier==barrier&&target.attempt==attempt&&target.frozen==runtime.frozen.get(),
                    "controller deferred install target changed without cancellation or revision");}}
            try{if(runtime.probe&&runtime.probe->owner==owner.get()&&runtime.probe->phase_committed)
                runtime.probe->phase_committed();}catch(...){} // passive DATA, off Native/coordinator leaves

            for(auto at=runtime.disposals.begin();at!=runtime.disposals.end();) {
                const auto& key=at->second.key;
                if(key.physical!=physical_incarnation||key.phase!=phase||key.barrier!=barrier||key.attempt!=attempt||key.revision!=demand_revision)at=runtime.disposals.erase(at);
                else ++at;
            }
            if(runtime.terminal_rearm&&phase==1){
                // An unknown/secondary local result can have committed the
                // cancellation. Inspect that exact successor before publishing
                // runtime state; never carry old terminal authority into new Q.
                require(runtime.frozen&&runtime.frozen_barrier<INT64_MAX&&runtime.frozen_attempt<INT64_MAX&&
                    barrier==runtime.frozen_barrier+1&&attempt==runtime.frozen_attempt+1,"controller terminal successor differs from frozen predecessor");
                owned([&](database&){validate_reopen_owned(owner,runtime.policy,phase,barrier,attempt);});
                recovery_continuous_producer::controller_publish_reconcile(*this,owner,barrier,attempt);
                runtime.frozen.reset();runtime.framing_committed=false;runtime.leases.clear();runtime.lifecycles.clear();runtime.inspect_required.clear();runtime.terminal_rearm=false;runtime.predecessors.clear();
                runtime.terminal_successor_attempt=attempt;observe("terminal-cancel-inspected");
            }
            if(phase==0) {
                bool demand;{std::lock_guard lock(runtime.mutex);demand=runtime.demand;}
                if(!demand){runtime.idle=true;for(const auto& route:routes)route->state_->blocked.store(false,std::memory_order_release);return;}
                runtime.idle=false;
                for(const auto& route:routes)route->state_->blocked.store(true,std::memory_order_release);
                int64_t next=0;owned([&](database&){next=recovery_continuous_producer::controller_next_attempt_owned(owner);});
                auto begun=recovery_continuous_producer::begin_impl(owner,next,true);known(begun.settlement);observe("barrier-committed");if(begun.waiting)return;continue;
            }
            for(const auto& route:routes)route->state_->blocked.store(true,std::memory_order_release);
            if(phase==2||phase==4) {
                std::optional<recovery_request_row> needs_predecessor;
                owned([&](database&){
                    recovery_request_store requests(owner);receive_install_store receiver(owner,runtime.caps.install.installations);bool audited=false;
                    for(const auto& contribution:runtime.policy.contributions){const auto row=requests.read(contribution.profile.binding.channel);
                        if(!row){require(phase==2,"controller restricted predecessor framing missing");continue;}
                        const auto& c=connected_routes.at(row->journal.channel);
                        if(row->source_context==source_context(c.description))continue;
                        if(!audited){validate_reopen_owned(owner,runtime.policy,phase,barrier,attempt);audited=true;}
                        // Classify actual installed evidence BEFORE examining an
                        // old context or issuing any remote proof request.
                        if(phase==2&&row->sequence!=attempt&&!row->manifest_frame.empty()){
                            const auto actual=receiver.read(row->journal.channel);const auto q=cr::decode(row->request_frame,runtime.caps.codec),m=cr::decode(row->manifest_frame,runtime.caps.codec);
                            const auto identity=describe_canonical_range(q.logical,std::get<cr::request>(q.body),std::get<cr::manifest>(m.body),runtime.caps.codec,row->route).installation_identity;
                            if(actual&&!actual->active&&actual->last_installed==std::optional<receive_install_identity>{identity})continue;
                        }
                        const auto at=runtime.predecessors.find(row->journal.channel);
                        const auto proof=at==runtime.predecessors.end()?std::shared_ptr<const recovery_reconciliation_descriptor::predecessor>{}:at->second;
                        if(!compatible_context(*row,c.description,proof,c.route,c.view,demand_revision,physical_incarnation,phase,barrier,attempt,runtime.caps.codec)&&!needs_predecessor)
                            needs_predecessor=*row;
                    }
                });
                if(needs_predecessor){const auto& row=*needs_predecessor;const auto& c=connected_routes.at(row.journal.channel);
                    auto q=cr::decode(row.request_frame,runtime.caps.codec);q.route_generation=decimal(c.description,"routeGeneration");
                    const auto prior=predecessor_profile(row,c.description);
                    send_control(c,"predecessor",0,[&](json& command,int64_t){command["request"]=cr::encode(q,runtime.caps.codec);command["priorProfile"]=prior;},
                        physical_incarnation,phase,barrier,attempt,demand_revision);return;
                }
            }
            const auto compatible=[&](const recovery_request_row& row,const connected& c){
                {std::lock_guard lock(runtime.mutex);if(runtime.revision!=demand_revision)return false;}
                const auto at=runtime.predecessors.find(row.journal.channel);
                const auto proof=at==runtime.predecessors.end()?std::shared_ptr<const recovery_reconciliation_descriptor::predecessor>{}:at->second;
                return compatible_context(row,c.description,proof,c.route,c.view,demand_revision,physical_incarnation,phase,barrier,attempt,runtime.caps.codec);
            };
            if(phase==4) {
                auto descriptor=std::shared_ptr<recovery_reconciliation_descriptor>(new recovery_reconciliation_descriptor);
                if(!reserve_cohort(descriptor))return;
                descriptor->owner_=owner;descriptor->limits_=runtime.caps;descriptor->controller_=shared_from_this();descriptor->controller_revision_=demand_revision;
                descriptor->physical_incarnation_=physical_incarnation;descriptor->barrier_=barrier;descriptor->attempt_=attempt;descriptor->phase_=4;descriptor->restart_revalidation_=true;
                owned([&](database&){
                    recovery_request_store requests(owner);recovery_obligation_store journal(owner,runtime.caps.obligations,runtime.caps.install.installations);
                    receive_install_store receiver(owner,runtime.caps.install.installations);receiver.audit();journal.audit();
                    for(const auto& c:runtime.policy.contributions){const auto row=requests.read(c.profile.binding.channel);const auto scope=journal.read(c.profile.binding.channel);const auto current=receiver.read(c.profile.binding.channel);
                        require(row&&scope&&current&&row->sequence==attempt-1&&row->barrier==barrier-1&&scope->mode==recovery_obligation_mode::recording&&scope->last_attempt==row->sequence&&
                            scope->address.incarnation==row->journal.incarnation&&scope->address.generation==row->journal.generation+1&&scope->revision>=row->journal_revision+1&&
                            current->binding==c.profile.binding&&!current->active&&current->last_sequence==row->sequence&&(!current->last_installed||current->last_installed->sequence<row->sequence),
                            "controller restricted restart lacks exact canceled receiver/journal");
                        const auto& actual=connected_routes.at(c.profile.binding.channel);require(row->domain==common_domain&&compatible(*row,actual),"controller restricted restart source changed");
                        auto snapshot=journal.snapshot_for_reconciliation(scope->address);const auto q=cr::decode(row->request_frame,runtime.caps.codec);
                        // The retained projection is indexed by the exact Q receipt order.
                        recovery_reconciliation_descriptor::contribution contribution{*row,std::move(snapshot),{},actual.route,actual.route->state_->source,actual.view};
                        require(compatible(*row,actual),"controller descriptor source compatibility changed");
                        if(row->source_context!=source_context(actual.description))contribution.compatibility=runtime.predecessors.at(row->journal.channel);
                        if(row->receipt_decisions=="0")descriptor->dispositions_unavailable_=true;
                        else {
                            const auto& decisions=row->receipt_decisions;const auto& receipts=std::get<cr::request>(q.body).receipts;
                            require(receipts.size()<=recovery_request_store::decision_entries&&decisions.size()==65+2*receipts.size()&&!decisions.empty()&&decisions[0]=='1',"controller canceled receipt decisions missing or count differs");
                            std::set<std::string> selected;
                            for(size_t i=0;i<receipts.size();++i)if(decisions[66+2*i]=='1')selected.insert(canonical_writer_adapter::uuid_key(receipts[i].original_id));
                            for(const auto& entry:contribution.journal.entries)if(selected.count(entry.canonical_original_id)){
                                require(entry.stage==recovery_obligation_stage::open,"controller retained retry original already settled");contribution.unknown_originals.push_back(entry.canonical_original_id);}
                        }
                        descriptor->contributions_.push_back(std::move(contribution));
                    }
                });
                // Migrated unavailable knowledge permits only no-send refreeze.
                // Missing/corrupt v2 data never selects this migration path.
                if(descriptor->dispositions_unavailable_)for(const auto& part:descriptor->contributions_)
                    require(part.framing.receipt_decisions=="0"&&part.unknown_originals.empty(),"controller mixed migrated and verified receipt decisions");
                if(runtime.probe&&runtime.probe->owner==owner.get()&&runtime.probe->reconciliation_prepublication)
                    runtime.probe->reconciliation_prepublication(); // No Native/coordinator/test leaf is held.
                {std::lock_guard lock(runtime.mutex);require(runtime.revision==demand_revision,"controller restricted restart generation changed");
                    // An unavailable legacy projection authorizes no restricted
                    // send. Its local no-send refreeze must not spend the one
                    // actual UNKNOWN pass of the fresh, reserved successor Q.
                    if(!descriptor->dispositions_unavailable_)runtime.reconciled_external_revision=runtime.external_revision;
                    descriptor->external_revision_=runtime.external_revision;descriptor->delivery_retry_revision_=runtime.delivery_retry_revision;
                    // Only the fresh phase-2 UNKNOWN decision consumes retry
                    // demand. Reconstruction cannot discard an earlier expiry.
                    runtime.reconciliation=std::move(descriptor);}observe("reconciliation-pending");for(const auto& route:routes)settle.notify(route,notification::reconcile);return;
            }
            if(phase==1) {auto status=recovery_continuous_producer::inspect_impl(owner,true);known(status.settlement);require(status.barrier.has_value(),"controller closed phase lacks actual barrier");
                auto frozen=recovery_continuous_producer::finish_impl(*status.barrier,true);if(frozen.waiting)return;known(frozen.settlement);
                if(runtime.terminal_successor_attempt==attempt)observe("terminal-refreeze-committed");continue;}
            if(phase==3) {
                auto scope_probe=probe_scope("resume");
                recovery_cohort_progress_observation::before(recovery_cohort_progress_observation::stage::resume);
                owned([&](database& db){
                    recovery_request_store requests(owner);receive_install_store receiver(owner,runtime.caps.install.installations);
                    recovery_obligation_store journals(owner,runtime.caps.obligations,runtime.caps.install.installations);
                    canonical_range_staging stages(owner,runtime.caps.install.installations,runtime.caps.codec,runtime.caps.staging);
                    for(const auto& c:runtime.policy.contributions) {
                        const auto row=requests.read(c.profile.binding.channel);require(row&&row->sequence==attempt&&!row->manifest_frame.empty(),"controller resume framing missing");
                        const auto q=cr::decode(row->request_frame,runtime.caps.codec),m=cr::decode(row->manifest_frame,runtime.caps.codec);
                        const auto actual=journals.read(c.profile.binding.channel);require(actual&&actual->mode==recovery_obligation_mode::installed,"controller resume journal not installed");
                        canonical_install_admission grant;grant.owner_=owner;grant.attempt_=q.logical;grant.route_=row->route;grant.request_digest_=std::get<cr::request>(q.body).request_digest;
                        grant.manifest_digest_=std::get<cr::manifest>(m.body).manifest_digest;grant.profile_=c.profile;grant.journal_=actual->address;grant.journal_revision_=row->journal_revision;
                        grant.coverage_id_=connected_routes.at(c.profile.binding.channel).description.at("source").at("coverageID");grant.limits_=runtime.caps;
                        grant.receive_guard_=receive_delivery_guard_access::read_owned(*owner,db,c.profile.binding.channel);
                        const auto identity=describe_canonical_range(q.logical,std::get<cr::request>(q.body),std::get<cr::manifest>(m.body),runtime.caps.codec,row->route).installation_identity;
                        (void)inspect_committed_canonical_owned(grant,identity,std::get<cr::request>(q.body),std::get<cr::manifest>(m.body));
                        stages.release_installed(q.logical,grant.manifest_digest_,row->route);
                        journals.resume(actual->address,identity);
                    }
                    recovery_continuous_producer::controller_resume_owned(*this,owner,barrier,attempt);
                });
                recovery_cohort_progress_observation::completed();
                scope_probe.reset();observe("resume-committed");
                recovery_continuous_producer::controller_publish_resume(*this,owner,barrier,attempt);
                runtime.frozen.reset();runtime.framing_committed=false;runtime.predecessors.clear();runtime.idle=true;
                {std::lock_guard lock(runtime.mutex);if(runtime.revision==demand_revision)runtime.demand=false;runtime.failure={};runtime.awaiting_delivery_retry=false;}
                for(const auto& route:routes){route->state_->blocked.store(false,std::memory_order_release);settle.notify(route,notification::resumed);}return;
            }
            require(phase==2,"controller unsupported durable phase");
            if(!runtime.frozen||runtime.frozen_attempt!=attempt||runtime.frozen_barrier!=barrier) {
                auto status=recovery_continuous_producer::inspect_impl(owner,true);known(status.settlement);require(status.barrier.has_value(),"controller frozen barrier missing");
                auto frozen=recovery_continuous_producer::finish_impl(*status.barrier,true);if(frozen.waiting)return;known(frozen.settlement);require(frozen.unsent.has_value(),"controller frozen local custody missing");
                auto parked=std::make_shared<verified_unsent_set>(std::move(*frozen.unsent));recovery_continuous_producer::controller_park_proof(*parked);runtime.frozen=std::move(parked);runtime.frozen_attempt=attempt;runtime.frozen_barrier=barrier;runtime.framing_committed=false;
            }
            const auto proof=runtime.frozen;
            bool created=false;
            if(!runtime.framing_committed) {
                std::optional<recovery_request_row> selected_disposal;std::optional<state::disposal> selected_receipt;
                auto disposal_probe=probe_scope("completed-disposal-validation");
                owned_completed_disposal([&](database&){
                    const auto candidates=disposal_snapshot(physical_incarnation,barrier,attempt,demand_revision);
                    recovery_request_store requests(owner);
                    for(const auto& [channel,receipt]:candidates) {
                        const auto at=runtime.disposals.find(channel);
                        if((at==runtime.disposals.end()||!same_disposal(at->second,receipt))&&!selected_disposal){
                            selected_disposal=requests.read(channel);selected_receipt=receipt;
                        }
                    }
                });
                disposal_probe.reset();
                if(selected_disposal) {
                    const auto& c=connected_routes.at(selected_disposal->journal.channel);auto q=cr::decode(selected_disposal->request_frame,runtime.caps.codec);
                    q.route_generation=decimal(c.description,"routeGeneration");observe("completed-disposal-cohort-validated");
                    send_control(c,"discard",0,[&](json& command,int64_t){command["request"]=cr::encode(q,runtime.caps.codec);},
                        physical_incarnation,2,barrier,attempt,demand_revision,std::move(selected_receipt));return;
                }
            }
            if(!runtime.framing_committed) {
                auto framing_probe=probe_scope("completed-disposal-framing");
                owned_completed_disposal([&](database& db){
                const auto candidates=disposal_snapshot(physical_incarnation,barrier,attempt,demand_revision);
                for(const auto& [channel,receipt]:candidates){const auto at=runtime.disposals.find(channel);
                    require(at!=runtime.disposals.end()&&same_disposal(at->second,receipt),"controller framing replacement lacks whole-cohort disposal");}
                observe("completed-disposal-before-framing-replacement");
                recovery_continuous_producer::verify_for_owned_write(*proof);recovery_request_store requests(owner);
                receive_install_store receiver(owner,runtime.caps.install.installations);
                std::map<std::string,recovery_obligation_record> originals;
                for(const auto& scope:proof->frozen_journals())for(const auto& entry:scope.entries){
                    require(originals.count(entry.canonical_original_id)||originals.size()<8192,"controller complete union exceeds finite request capacity");
                    const auto [at,added]=originals.emplace(entry.canonical_original_id,entry.record);require(added||at->second==entry.record,"controller shared original differs");}
                std::map<std::string,std::string> immutable_originals;
                const auto& first_description=connected_routes.at(proof->frozen_journals().front().scope.address.channel).description;
                if(first_description.contains("receiptBinding"))immutable_originals=recovery_export_adapter::frozen_original_identities(owner,*proof,
                    receipt_json::binding(first_description.at("receiptBinding")),first_description.at("source").at("schemaDigest").get<std::string>());
                for(const auto& scope:proof->frozen_journals()) {
                    const auto& connected=connected_routes.at(scope.scope.address.channel);const auto& d=connected.description;
                    const auto existing=requests.read(scope.scope.address.channel);
                    if(existing&&existing->sequence==attempt){require(existing->journal==scope.scope.address&&existing->journal_revision==scope.scope.revision&&existing->barrier==barrier&&
                        compatible(*existing,connected)&&existing->domain==common_domain,"controller frozen request binding changed");continue;}
                    if(existing){const auto oldq=cr::decode(existing->request_frame,runtime.caps.codec);const auto current=receiver.read(scope.scope.address.channel);
                        bool installed=false;
                        if(current&&!existing->manifest_frame.empty()){const auto oldm=cr::decode(existing->manifest_frame,runtime.caps.codec);
                            const auto old=describe_canonical_range(oldq.logical,std::get<cr::request>(oldq.body),std::get<cr::manifest>(oldm.body),runtime.caps.codec,existing->route);
                            installed=current->last_installed==std::optional<receive_install_identity>{old.installation_identity}&&!current->active;}
                        // Existing manifested UNKNOWN reconciliation may have
                        // advanced claims/revision during its restricted pass.
                        // The new manifestless path has no such authority.
                        const bool canceled=!installed&&current&&compatible(*existing,connected)&&existing->domain==common_domain&&
                            (existing->manifest_frame.empty()?canceled_predecessor(*existing,scope.scope,*current,std::get<cr::request>(oldq.body),2,barrier,attempt):
                            !current->active&&existing->sequence==attempt-1&&existing->barrier==barrier-1&&current->last_sequence==existing->sequence&&
                            (!current->last_installed||current->last_installed->sequence<existing->sequence)&&scope.scope.address.incarnation==existing->journal.incarnation&&
                            existing->journal.generation<=INT64_MAX-2&&scope.scope.address.generation==existing->journal.generation+2&&scope.scope.last_attempt==attempt);
                        require(installed||canceled,"controller prior Q lacks exact installed or canceled receiver evidence");requests.erase(*existing);}
                    const auto prior=receiver.read(scope.scope.address.channel);require(prior&&prior->binding==scope.scope.profile.binding&&!prior->active,"controller Q actual receiver unavailable");
                    cr::attempt logical{d.at("peer").at("receiverIncarnation"),d.at("peer").at("channelIncarnation"),scope.scope.address.channel,static_cast<uint64_t>(attempt),uuid_t::generate().to_string()};
                    cr::request q;q.source=source_binding(scope.scope.profile);q.expected.binding=q.source;q.expected.revision=prior->revision;
                    if(d.contains("receiptBinding")){q.registered_producer=receipt_json::binding(d.at("receiptBinding"));q.receipt_namespace=scope.scope.profile.receipt_namespace;}
                    q.expected.base={prior->frontier.kind==receive_frontier_kind::position?cr::frontier_kind::position:prior->frontier.kind==receive_frontier_kind::beginning_null?cr::frontier_kind::beginning_null:cr::frontier_kind::uninitialized,
                        prior->frontier.position?std::optional<uint64_t>{static_cast<uint64_t>(*prior->frontier.position)}:std::nullopt};q.budget=negotiate(d,runtime.caps.codec);
                    require(originals.size()<=d.at("profile").at("requestEntries").get<size_t>()&&originals.size()<=d.at("profile").at("requestTargets").get<size_t>(),"controller actual source request count capacity");
                    for(const auto& [id,entry]:originals)q.receipts.push_back({id,scope.scope.profile.receipt_namespace,{{entry.table,canonical_writer_adapter::uuid_key(entry.target_id)}},
                        q.registered_producer?std::optional<std::string>{immutable_originals.at(id)}:std::nullopt});
                    q.request_digest=cr::request_sha256(logical,q,runtime.caps.codec);const auto route=decimal(d,"routeGeneration");
                    requests.insert({scope.scope.address,barrier,attempt,scope.scope.revision,static_cast<int64_t>(route),common_domain,source_context(d),cr::encode({logical,route,q},runtime.caps.codec),{}});created=true;
                }
                live();{std::lock_guard lock(runtime.mutex);require(runtime.revision==demand_revision,"controller framing replacement generation changed");}
                });
            }
            runtime.framing_committed=true;runtime.disposals.clear();
            if(created)observe("completed-disposal-framing-committed");
            if(created&&runtime.terminal_successor_attempt==attempt){observe("terminal-request-committed");runtime.terminal_successor_attempt=0;}
            // Known Q COMMIT precedes every handoff. A restart always attempts
            // exact resume first; a newly committed Q can start preparation.
            bool all_complete=true;std::optional<recovery_request_row> selected;uint64_t index=0;
            owned([&](database&){recovery_request_store requests(owner);canonical_range_staging stages(owner,runtime.caps.install.installations,runtime.caps.codec,runtime.caps.staging);
                for(const auto& c:runtime.policy.contributions){auto row=requests.read(c.profile.binding.channel);require(row.has_value(),"controller contribution Q missing");
                    const auto& part=connected_routes.at(c.profile.binding.channel);const auto& d=part.description;require(compatible(*row,part)&&row->domain==common_domain,"controller retained source context changed");const auto route=decimal(d,"routeGeneration");
                    const auto q=cr::decode(row->request_frame,runtime.caps.codec);
                    if(row->route!=static_cast<int64_t>(route)){
                        bool migrated_local_cancel=false;
                        if(!row->manifest_frame.empty()){
                            const auto m=cr::decode(row->manifest_frame,runtime.caps.codec);
                            // A real v1 row has no receipt projection/reservation.
                            // No unavailable legacy receipt is classified here.
                            // Audit its exact addressed stage but retain even
                            // incomplete reconstructible bytes on their durable
                            // route solely for local no-send cancellation.
                            // No new frame intake or route authority is issued.
                            if(row->receipt_decisions=="0"){
                                (void)stages.resume(q.logical,std::get<cr::manifest>(m.body).manifest_digest,row->route);
                                migrated_local_cancel=true;
                            }
                            if(!migrated_local_cancel)stages.rebind(q.logical,std::get<cr::manifest>(m.body).manifest_digest,row->route,route);
                        }
                        if(migrated_local_cancel)observe("migrated-staged-local-cancel");
                        else {requests.rebind(*row,route);row->route=route;}
                    }
                    if(row->manifest_frame.empty()){all_complete=false;if(!selected){selected=std::move(row);index=0;}continue;}
                    const auto m=cr::decode(row->manifest_frame,runtime.caps.codec);const auto progress=stages.resume(q.logical,std::get<cr::manifest>(m.body).manifest_digest,row->route);
                    // Typed migrated-unavailable rows need only an audited
                    // exact manifest/stage for local cancellation. Ordinary
                    // rows still need complete verification before disposition.
                    if(!progress.content_verified&&row->receipt_decisions!="0"){all_complete=false;if(!selected){selected=std::move(row);index=1+progress.state.next_content_page+progress.state.next_receipt_page;}}
                }});
            if(runtime.terminal_rearm) {
                // One terminal contribution closes the entire frozen cohort.
                // No more reads/install selection until every exact Q is fenced.
                selected.reset();all_complete=false;index=0;
                const auto terminal_current=[&](const recovery_request_row& row,const connected& part){
                    const auto at=runtime.lifecycles.find(row.journal.channel);
                    if(at==runtime.lifecycles.end())return false;
                    const auto q=cr::decode(row.request_frame,runtime.caps.codec);const auto& retained=at->second;
                    return retained.state=="terminal"&&retained.route.lock()==part.route&&retained.view.value==part.view.value&&
                        retained.attempt==q.logical&&retained.request_digest==std::get<cr::request>(q.body).request_digest;
                };
                owned([&](database&){recovery_request_store requests(owner);
                    for(const auto& c:runtime.policy.contributions){const auto row=requests.read(c.profile.binding.channel);const auto& part=connected_routes.at(c.profile.binding.channel);
                        require(row&&terminal_profile(part.description)&&row->sequence==attempt&&row->barrier==barrier&&
                            compatible(*row,part)&&row->domain==common_domain,"controller terminal cohort framing/source changed");
                        if(!terminal_current(*row,part)&&!selected)selected=*row;
                    }
                });
                if(!selected){
                    require(barrier<INT64_MAX&&attempt<INT64_MAX,"controller terminal restart sequence exhausted");
                    auto scope_probe=probe_scope("terminal-cancel");
                    owned([&](database& db){
                        recovery_continuous_producer::verify_for_owned_write(*proof);
                        require(recovery_continuous_producer::controller_cohort(*this,owner)==recovery_continuous_producer::cohort_admission::available,
                            "controller terminal restart retained cohort changed");
                        {std::lock_guard lock(runtime.mutex);require(runtime.revision==demand_revision&&!runtime.outstanding&&!runtime.reconciliation,
                            "controller terminal restart generation or work changed");}
                        recovery_request_store requests(owner);const auto framing=requests.fingerprints();
                        recovery_obligation_store journal(owner,runtime.caps.obligations,runtime.caps.install.installations);
                        receive_install_store receiver(owner,runtime.caps.install.installations);
                        canonical_range_staging stages(owner,runtime.caps.install.installations,runtime.caps.codec,runtime.caps.staging);
                        journal.audit();receiver.audit();stages.audit();
                        std::vector<recovery_obligation_snapshot> before;std::vector<receive_install_snapshot> receivers;
                        for(const auto& frozen:proof->frozen_journals()){
                            const auto& channel=frozen.scope.address.channel;const auto row=requests.read(channel);const auto& part=connected_routes.at(channel);
                            require(row&&terminal_current(*row,part)&&compatible(*row,part)&&row->domain==common_domain&&
                                row->sequence==attempt&&row->barrier==barrier&&row->journal==frozen.scope.address&&row->journal_revision==frozen.scope.revision&&
                                row->route==static_cast<int64_t>(decimal(part.description,"routeGeneration")),"controller terminal cancellation lost exact Q/source custody");
                            const auto snapshot=journal.snapshot_for_install(frozen.scope.address,attempt);const auto actual=receiver.read(channel);
                            require(snapshot.scope==frozen.scope&&snapshot.entries==frozen.entries&&actual&&actual->binding==frozen.scope.profile.binding&&
                                (!actual->last_installed||actual->last_installed->sequence<attempt),"controller terminal cancellation changed original inventory or installed proof");
                            require(frozen.scope.address.generation<INT64_MAX&&frozen.scope.revision<INT64_MAX,"controller terminal journal generation exhausted");
                            if(row->manifest_frame.empty()){
                                require(!actual->active&&actual->last_sequence==attempt-1&&
                                    db.query("SELECT 1 FROM main._lattice_range_attempt WHERE channel=? LIMIT 1",{std::vector<uint8_t>(channel.begin(),channel.end())}).empty(),
                                    "controller manifestless cancellation has active or retired receiver/stage");
                            }else{
                                const auto q=cr::decode(row->request_frame,runtime.caps.codec),m=cr::decode(row->manifest_frame,runtime.caps.codec);
                                const auto described=describe_canonical_range(q.logical,std::get<cr::request>(q.body),std::get<cr::manifest>(m.body),runtime.caps.codec,row->route);
                                require(actual->last_sequence==attempt&&actual->active==std::optional<receive_install_identity>{described.installation_identity},
                                    "controller terminal cancellation lacks exact uninstalled active identity");
                            }
                            before.push_back(snapshot);receivers.push_back(*actual);
                        }
                        // Validate every member before mutating any member.
                        for(const auto& frozen:before){const auto row=requests.read(frozen.scope.address.channel);
                            if(!row->manifest_frame.empty()){const auto q=cr::decode(row->request_frame,runtime.caps.codec),m=cr::decode(row->manifest_frame,runtime.caps.codec);
                                stages.abandon_active(q.logical,std::get<cr::manifest>(m.body).manifest_digest,row->route);}
                            journal.cancel_frozen_for_retry(frozen.scope.address,attempt,frozen.scope.revision);
                        }
                        require(requests.fingerprints()==framing,"controller terminal cancellation altered retained Q/M");
                        for(size_t n=0;n<before.size();++n){auto expected=before[n];auto expected_receiver=receivers[n];
                            expected.scope.mode=recovery_obligation_mode::recording;++expected.scope.address.generation;++expected.scope.revision;
                            expected_receiver.active.reset();expected_receiver.last_sequence=attempt;
                            const auto actual=journal.snapshot_for_reconciliation(expected.scope.address);
                            require(actual.scope==expected.scope&&actual.entries==expected.entries&&
                                receiver.read(expected.scope.address.channel)==std::optional<receive_install_snapshot>{expected_receiver},
                                "controller terminal cancellation original/ACK/claim or receiver postimage differs");
                        }
                        journal.audit();receiver.audit();stages.audit();live();
                        {std::lock_guard lock(runtime.mutex);require(runtime.revision==demand_revision,"controller terminal cancellation demand changed");}
                        recovery_continuous_producer::controller_restart_terminal_owned(*this,owner,physical_incarnation,barrier,attempt);
                    });
                    finish_install_target({demand_revision,physical_incarnation,barrier,attempt,proof.get()});
                    scope_probe.reset();observe("terminal-cancel-committed");
                    recovery_continuous_producer::controller_publish_reconcile(*this,owner,barrier+1,attempt+1);
                    runtime.terminal_successor_attempt=attempt+1;
                    runtime.frozen.reset();runtime.framing_committed=false;runtime.leases.clear();runtime.lifecycles.clear();runtime.inspect_required.clear();runtime.terminal_rearm=false;runtime.predecessors.clear();
                    observe("terminal-cancel-published");continue;
                }
            }
            if(all_complete) {
                auto descriptor=std::shared_ptr<recovery_reconciliation_descriptor>(new recovery_reconciliation_descriptor);
                if(!reserve_cohort(descriptor))return;
                recovery_cohort_progress_observation::reserved();
                descriptor->owner_=owner;descriptor->limits_=runtime.caps;descriptor->controller_=shared_from_this();descriptor->frozen_=proof;descriptor->controller_revision_=demand_revision;
                descriptor->physical_incarnation_=physical_incarnation;descriptor->barrier_=barrier;descriptor->attempt_=attempt;descriptor->phase_=2;
                bool unknown=false;const std::set<std::string> unsent(proof->canonical_originals().begin(),proof->canonical_originals().end());
                recovery_cohort_progress_observation::before(recovery_cohort_progress_observation::stage::classification);
                owned([&](database&){recovery_continuous_producer::verify_for_owned_write(*proof);recovery_request_store requests(owner);
                    canonical_range_staging stages(owner,runtime.caps.install.installations,runtime.caps.codec,runtime.caps.staging);
                    for(const auto& snapshot:proof->frozen_journals()){
                        const auto row=requests.read(snapshot.scope.address.channel);require(row.has_value(),"controller pending framing missing");
                        const auto q=cr::decode(row->request_frame,runtime.caps.codec),m=cr::decode(row->manifest_frame,runtime.caps.codec);
                        const auto& actual=connected_routes.at(snapshot.scope.address.channel);
                        recovery_reconciliation_descriptor::contribution contribution{*row,snapshot,{},actual.route,actual.route->state_->source,actual.view};
                        require(compatible(*row,actual),"controller descriptor source compatibility changed");
                        if(row->source_context!=source_context(actual.description))contribution.compatibility=runtime.predecessors.at(row->journal.channel);
                        const auto verified=stages.resume(q.logical,std::get<cr::manifest>(m.body).manifest_digest,row->route);
                        require(verified.content_verified||row->receipt_decisions=="0","controller pending stage unverified");
                        if(row->receipt_decisions=="0"){
                            // This Q predates future-projection reservation. Do not
                            // classify it as UNKNOWN or issue restricted exports:
                            // cancel with explicit unavailable history, refreeze,
                            // and reacquire evidence using a new reserved Q.
                            descriptor->dispositions_unavailable_=true;unknown=true;
                            contribution.receipt_decisions="0";
                            descriptor->contributions_.push_back(std::move(contribution));continue;
                        }
                        // Receipt knowledge and retry eligibility are separate from
                        // the need to cancel. A genuine UNKNOWN may acquire its
                        // first claim in a mixed restricted pass; C/N never may.
                        bool needs_cancel=false;
                        std::set<std::string> unknown_ids;contribution.receipt_decisions.clear();
                        require(std::get<cr::request>(q.body).receipts.size()<=recovery_request_store::decision_entries,"controller verified request entry cap");
                        contribution.receipt_decisions.reserve(2*std::get<cr::request>(q.body).receipts.size());
                        for(uint64_t n=0;n<verified.state.offer.counts.receipt_pages;++n){const auto page=std::get<cr::receipt_page>(stages.read_verified_page(q.logical,std::get<cr::manifest>(m.body).manifest_digest,row->route,cr::stream_kind::receipts,n));
                            for(const auto& item:page.items){
                                require(contribution.receipt_decisions.size()<=recovery_request_store::decision_bytes-65-2,"controller verified receipt projection exceeds entry cap");
                                const bool unresolved=std::holds_alternative<cr::unknown>(item.value);const auto id=canonical_writer_adapter::uuid_key(item.original_id);
                                needs_cancel|=unresolved&&!unsent.count(id);
                                contribution.receipt_decisions.push_back(unresolved?'U':std::holds_alternative<cr::committed>(item.value)?'C':'N');
                                contribution.receipt_decisions.push_back(unresolved?'1':'0');if(unresolved)unknown_ids.insert(id);}}
                        require(contribution.receipt_decisions.size()==2*std::get<cr::request>(q.body).receipts.size(),"controller verified receipt projection count differs");
                        contribution.receipt_decisions=requests.seal_receipt_decisions(*row,contribution.receipt_decisions);
                        for(const auto& entry:snapshot.entries)if(unknown_ids.count(entry.canonical_original_id))contribution.unknown_originals.push_back(entry.canonical_original_id);
                        // Only possibly exported UNKNOWN requires cancellation.
                        // If the whole cohort is globally UNSENT, retain the
                        // direct install path. If any member needs cancel, the
                        // persisted U1 subset also permits genuine first claims.
                        unknown|=needs_cancel;descriptor->contributions_.push_back(std::move(contribution));
                    }
                });
                recovery_cohort_progress_observation::completed();
                if(descriptor->dispositions_unavailable_)for(const auto& part:descriptor->contributions_)
                    require(part.framing.receipt_decisions=="0"&&part.receipt_decisions=="0"&&part.unknown_originals.empty(),
                        "controller mixed migrated and reserved frozen framing");
                if(unknown){{std::lock_guard lock(runtime.mutex);require(runtime.revision==demand_revision,"controller pending generation changed");
                    if(!descriptor->dispositions_unavailable_){
                        if(runtime.reconciled_external_revision==runtime.external_revision&&runtime.reconciled_delivery_retry_revision==runtime.delivery_retry_revision)
                            throw delivery_retry_wait();
                        runtime.reconciled_external_revision=runtime.external_revision;runtime.reconciled_delivery_retry_revision=runtime.delivery_retry_revision;
                    }
                    descriptor->external_revision_=runtime.external_revision;descriptor->delivery_retry_revision_=runtime.delivery_retry_revision;
                    runtime.awaiting_delivery_retry=false;runtime.reconciliation=std::move(descriptor);}observe("reconciliation-pending");for(const auto& route:routes)settle.notify(route,notification::reconcile);return;}
                const state::install_target_id install_target{demand_revision,physical_incarnation,barrier,attempt,proof.get()};
                auto scope_probe=probe_scope("install");
                recovery_cohort_progress_observation::before(recovery_cohort_progress_observation::stage::install);
                owned([&](database& db){
                    recovery_continuous_producer::verify_for_owned_write(*proof);recovery_request_store requests(owner);
                    canonical_cohort_admission cohort;cohort.owner_=owner;cohort.local_=proof;cohort.verify_current_sources_=[&]{live();
                        for(const auto& contribution:runtime.policy.contributions){const auto row=requests.read(contribution.profile.binding.channel);const auto& c=connected_routes.at(contribution.profile.binding.channel);
                            require(row&&compatible(*row,c)&&row->domain==common_domain,"controller final install source compatibility changed");}
                    };
                    cohort.finalize_owned_=[&]{recovery_continuous_producer::controller_installed_owned(*this,*proof);};
                    for(const auto& c:runtime.policy.contributions){auto guard=receive_delivery_guard_access::read_owned(*owner,db,c.profile.binding.channel);
                        if(!guard.present){const auto token=receive_delivery_guard_access::begin(*owner,db,c.profile.binding.channel);require(token.may_advance&&!token.capacity_refused,"controller modern receive guard allocation refused");}}
                    // Capture only after all global guard counters have settled.
                    for(const auto& scope:proof->frozen_journals()) {
                        const auto row=requests.read(scope.scope.address.channel);const auto q=cr::decode(row->request_frame,runtime.caps.codec),m=cr::decode(row->manifest_frame,runtime.caps.codec);
                        const auto& connected=connected_routes.at(scope.scope.address.channel);
                        canonical_install_admission grant;grant.owner_=owner;grant.attempt_=q.logical;grant.route_=row->route;grant.request_digest_=std::get<cr::request>(q.body).request_digest;
                        grant.manifest_digest_=std::get<cr::manifest>(m.body).manifest_digest;grant.profile_=scope.scope.profile;grant.journal_=scope.scope.address;grant.journal_revision_=scope.scope.revision;
                        grant.coverage_id_=connected.description.at("source").at("coverageID");grant.contract_=connected.scope;grant.limits_=runtime.caps;
                        receive_install_store receiver(owner,runtime.caps.install.installations);grant.supersede_=receiver.read(scope.scope.address.channel)->last_installed;
                        grant.receive_guard_=receive_delivery_guard_access::read_owned(*owner,db,scope.scope.address.channel);
                        cohort.channels_.push_back(std::move(grant));cohort.domains_.push_back(common_domain);
                    }
                    (void)install_canonical_cohort_owned(cohort);
                },&install_target);
                recovery_cohort_progress_observation::completed();
                scope_probe.reset();observe("install-committed");continue;
            }
            require(selected.has_value(),"controller incomplete stage selection missing");
            auto& c=connected_routes.at(selected->journal.channel);auto q=cr::decode(selected->request_frame,runtime.caps.codec);q.route_generation=selected->route;
            auto lease=runtime.leases.find(selected->journal.channel);
            const bool usable=lease!=runtime.leases.end()&&!lease->second.id.empty()&&lease->second.view.value==c.view.value&&
                lease->second.request_digest==std::get<cr::request>(q.body).request_digest&&now()<lease->second.deadline;
            const auto lifecycle=runtime.lifecycles.find(selected->journal.channel);
            const bool discard=runtime.terminal_rearm||(lifecycle!=runtime.lifecycles.end()&&lifecycle->second.state=="available"&&
                lifecycle->second.view.value==c.view.value&&lifecycle->second.attempt==q.logical);
            const std::string op=discard?"discard":runtime.inspect_required.count(selected->journal.channel)?"inspect":
                usable?"read":created?"prepare":lease!=runtime.leases.end()&&lease->second.id.empty()&&selected->manifest_frame.empty()?"prepare":"resume";
            send_control(c,op,index,[&](json& command,int64_t remaining){
                if(op=="read"){require(index<lease->second.frames,"controller frame index exceeds actual lease inventory");command["leaseID"]=lease->second.id;command["requestDigest"]=lease->second.request_digest;
                    command["attemptID"]=lease->second.attempt_id;command["sequence"]=std::to_string(lease->second.sequence);command["index"]=std::to_string(index);}
                else {command["request"]=cr::encode(q,runtime.caps.codec);
                    if(op=="prepare"||op=="resume")command["durationMilliseconds"]=std::min<int64_t>({remaining-100,3600000,c.description.at("profile").at("leaseMilliseconds").get<int64_t>()});}
            });
            return;
        }
    }catch(...){
        auto error=std::current_exception();std::shared_ptr<state::pending> released;
        uint64_t cancelled_revision=0;
        try{std::rethrow_exception(error);}catch(const controller_stale_turn_cancelled& cancelled){cancelled_revision=cancelled.revision;}catch(...){}
        if(cancelled_revision) {
            bool current_demand=false;std::vector<std::shared_ptr<recovery_receiver_route>> current_routes;
            current_routes.reserve(runtime.policy.physical_routes); // no vector allocation/final owner on the leaf
            {std::lock_guard lock(runtime.mutex);
                current_demand=runtime.revision!=cancelled_revision&&runtime.demand;
                if(current_demand){
                    // Neither a rollback nor an unsent payload proves remote
                    // settlement. The current turn revalidates durable Q and
                    // the actual source before acquiring any new authority.
                    released=std::move(runtime.outstanding);
                    for(const auto& weak:runtime.routes)if(auto route=weak.lock())current_routes.push_back(std::move(route));
                    settle.keep_admission_wait=true;
                }}
            if(current_demand){
                released.reset(); // old request/source/endpoint owners off leaf
                try{if(auto owner=observed_owner.lock();owner&&runtime.probe&&runtime.probe->owner==owner.get()&&runtime.probe->observed)
                    runtime.probe->observed("stale-generation-cancelled-before-current-turn");}catch(...){}
                // request() could only coalesce while running. Settlement
                // clears running before this actual bounded current-turn wake.
                settle.after=[current_routes]{for(const auto& route:current_routes)if(!route->state_->retired.load()){route->wake();break;}};
                return;
            }
        }
        bool admission_busy=false;recovery_install_deferred actual_deferred=recovery_install_deferred::none;
        try{std::rethrow_exception(error);}catch(const controller_admission_wait& actual){admission_busy=true;actual_deferred=actual.reason;}catch(...){}
        if(admission_busy) {
          try {
            state::install_target_ptr candidate_install{nullptr,state::install_target_delete{runtime.creator}};
            bool needs_target=false;
            {std::lock_guard lock(runtime.mutex);needs_target=attempted_install&&
                runtime.revision==admission_revision&&!runtime.admission_intent_revoked&&!runtime.admission_install;}
            if(needs_target){
                candidate_install.reset(new state::install_target{});
                require(runtime.creator==controller_process(),"controller install target belongs to another process");
                candidate_install->id=*attempted_install; // proof custody is captured only under the coordinator leaf below
            }
            bool deferred=false,current_episode=false;int64_t intent_deadline=0,retry_due=0;
            {std::lock_guard lock(runtime.mutex);auto& wait=runtime.admission_wait;
                // An external generation is observed by the next ordinary
                // turn. This stale turn cannot spend or reset its allowance.
                if(runtime.revision!=admission_revision||runtime.admission_intent_revoked)deferred=true;
                else {
                    if(attempted_install){
                        require(attempted_install->revision==admission_revision&&attempted_install->frozen==runtime.frozen.get()&&
                            attempted_install->barrier==runtime.frozen_barrier&&attempted_install->attempt==runtime.frozen_attempt,
                            "controller deferred install lost its exact frozen target");
                        if(runtime.admission_install)require(runtime.admission_install->id==*attempted_install,
                            "controller admission cannot overwrite an unfinished install target");
                        else {
                            require(candidate_install&&!candidate_install->frozen,"controller deferred install target empty custody missing");
                            // The off-leaf allocation is still empty: this exact
                            // strong copy cannot release a prior proof on leaf.
                            candidate_install->frozen=runtime.frozen;
                            require(candidate_install->frozen.get()==attempted_install->frozen,"controller deferred install target custody changed");
                            runtime.admission_install=std::move(candidate_install);
                        }
                    }
                    if(!wait.attempts){wait.revision=admission_revision;wait.deadline=admission_deadline;}
                    wait.deadline=std::min(wait.deadline,admission_deadline);
                    if(now()<wait.deadline&&wait.attempts<admission_retry_attempts){++wait.attempts;wait.next_due=now()+admission_retry_tick_ms;deferred=true;current_episode=true;intent_deadline=wait.deadline;retry_due=wait.next_due;}
                }
                if(deferred)settle.keep_admission_wait=true;
            }
            if(deferred){
                // Publish denial before the actual deferral observation. This
                // uses the same episode end; a coalesced wake cannot renew it.
                // Cell publication/strong custody happens outside the leaf.
                std::exception_ptr intent_error;
                try{if(current_episode){
                    const auto owner=observed_owner.lock();require(owner&&!owner->is_closed(),"controller admission intent owner retired");
                    runtime.admission_intent.begin(owner,std::chrono::steady_clock::time_point(std::chrono::milliseconds(intent_deadline)));
                    arm_admission_retry(retry_due); // same actual episode/next_due, no renewed budget
                }else {runtime.admission_intent.release();
#ifndef __EMSCRIPTEN__
                    runtime.executor->cancel_retry();
#endif
                }}
                catch(...){intent_error=std::current_exception();settle.keep_admission_wait=false;runtime.admission_intent.release();}
                if(!intent_error){
                try{if(auto owner=observed_owner.lock();owner&&runtime.probe&&runtime.probe->owner==owner.get()&&runtime.probe->observed)
                    runtime.probe->observed("admission-deferred");}catch(...){}
                // Separate production-null passive copy after actual no-effect
                // refusal and after the leaf ended. Existing fault-stage
                // callbacks are not invoked with any new stage.
                try{if(auto owner=observed_owner.lock();owner&&runtime.probe&&runtime.probe->owner==owner.get()&&runtime.probe->admission_observed)
                    runtime.probe->admission_observed(deferred_observation_label(actual_deferred));}catch(...){}
                return;
                }
                error=std::move(intent_error); // real cell/owner failure, never relabel as a retry
            }else error=std::make_exception_ptr(db_error("controller admission retry budget exhausted; gate remains closed"));
          }catch(...){error=std::current_exception();settle.keep_admission_wait=false;}
        }
        std::array<std::shared_ptr<state::reply>,2> retired_late;
        bool awaiting_delivery=false,retry_arrived=false;
        try{std::rethrow_exception(error);}catch(const delivery_retry_wait&){awaiting_delivery=true;}catch(...){}
        // Observation only: the typed UNKNOWN wait has left its SQL and leaf
        // scopes. A real timer can now race the catch's counter recheck.
        if(awaiting_delivery)try{if(auto owner=observed_owner.lock();owner&&runtime.probe&&
            runtime.probe->owner==owner.get()&&runtime.probe->observed)
                runtime.probe->observed("delivery-retry-wait-before-latch");}catch(...){}
        state::install_target_ptr failed_install;
        {std::lock_guard lock(runtime.mutex);
            failed_install=std::move(runtime.admission_install);settle.keep_admission_wait=false;
            // The actual timer may arrive after the UNKNOWN decision unlocks
            // but before this catch stores its wait. Preserve that admitted
            // demand instead of latching over it until an unrelated event.
            retry_arrived=awaiting_delivery&&(runtime.reconciled_external_revision!=runtime.external_revision||
                runtime.reconciled_delivery_retry_revision!=runtime.delivery_retry_revision);
            if(retry_arrived){runtime.demand=true;runtime.awaiting_delivery_retry=false;}
            else {runtime.failure=error;runtime.awaiting_delivery_retry=awaiting_delivery;}
            released=std::move(runtime.outstanding);
            retired_late=std::move(runtime.late_inbox);
        }
        released.reset(); // source/endpoint ownership is released off the leaf
        retired_late={};
        std::vector<std::shared_ptr<recovery_receiver_route>> report;
        {std::lock_guard lock(runtime.mutex);for(const auto& weak:runtime.routes)if(auto route=weak.lock())report.push_back(std::move(route));}
        if(retry_arrived){settle.after=[report]{for(const auto& route:report)if(!route->state_->retired.load()){route->wake();break;}};return;}
        for(const auto& route:report)settle.notify(route,notification::error,error);
        try{std::rethrow_exception(error);}catch(const std::exception& e){LOG_ERROR("recovery-controller","receiver remains closed: %s",e.what());}catch(...){LOG_ERROR("recovery-controller","receiver remains closed after unknown failure");}
    }
}
std::shared_ptr<recovery_continuous_route> recovery_receiver_route::reconciliation_work_route()const {return state_->continuous;}
std::shared_ptr<const recovery_reconciliation_descriptor> recovery_receiver_route::pending_reconciliation()const {
    if(state_->retired.load())return {};
    std::lock_guard lock(controller_->state_->mutex);const auto& current=controller_->state_->reconciliation;
    if(!current)return {};
    for(const auto& contribution:current->contributions_)if(contribution.route.lock().get()==this)return current;
    return {};
}
bool recovery_receiver_controller::reconciliation_route_current(
    const std::shared_ptr<const recovery_reconciliation_descriptor>& descriptor,const std::shared_ptr<recovery_continuous_route>& continuous,
    const std::shared_ptr<lattice_db>& owner,uint64_t physical) {
    require(descriptor&&descriptor->phase_==4&&descriptor->owner()==owner&&owner&&continuous&&physical,
        "restricted export lacks exact phase-4 owner/descriptor");
    if(owner->is_closed())return false;
    auto controller=descriptor->controller_.lock();if(!controller)return false;
    {std::lock_guard lock(controller->state_->mutex);if(controller->state_->reconciliation!=descriptor||controller->state_->revision!=descriptor->controller_revision_)return false;}
    bool matched=false;
    for(const auto& c:descriptor->contributions_)if(auto route=c.route.lock())if(route->state_->continuous==continuous&&route->state_->owner.lock()==owner&&
        !route->state_->retired.load()&&c.source==route->state_->source&&c.source->recovery_live(c.view)&&c.source->recovery_lifecycle(c.view)==physical){
        require(!matched,"restricted export ambiguous actual route");
        if(!compatible_context(c.framing,parse(c.source->recovery_description(c.view),65536),c.compatibility,route,c.view,
            descriptor->controller_revision_,descriptor->physical_incarnation_,descriptor->phase_,descriptor->barrier_,descriptor->attempt_,descriptor->limits_.codec))return false;
        matched=true;}
    return matched;
}
void recovery_receiver_controller::verify_reconciliation_route(
    const std::shared_ptr<const recovery_reconciliation_descriptor>& descriptor,const std::shared_ptr<recovery_continuous_route>& continuous,
    const std::shared_ptr<lattice_db>& owner,uint64_t physical,const std::vector<std::string>* originals) {
    require(descriptor&&descriptor->phase_==4&&descriptor->owner()==owner&&owner&&!owner->is_closed()&&continuous&&physical,
        "restricted export lacks exact phase-4 owner/descriptor");
    auto controller=descriptor->controller_.lock();require(controller!=nullptr,"restricted export controller retired");
    {std::lock_guard lock(controller->state_->mutex);require(controller->state_->reconciliation==descriptor&&controller->state_->revision==descriptor->controller_revision_,"restricted export descriptor replaced");}
    const recovery_reconciliation_descriptor::contribution* matched=nullptr;
    // Record the first actual failed predicate for each contribution while
    // performing the SAME short-circuit checks. Do not re-read source/lifetime
    // state after refusal and mistake that later observation for its cause.
    std::array<size_t,7> missed{};
    for(const auto& c:descriptor->contributions_){
        const auto route=c.route.lock();
        if(!route){++missed[0];continue;}
        if(route->state_->continuous!=continuous){++missed[1];continue;}
        if(route->state_->owner.lock()!=owner){++missed[2];continue;}
        if(route->state_->retired.load()){++missed[3];continue;}
        if(c.source!=route->state_->source){++missed[4];continue;}
        if(!c.source->recovery_live(c.view)){++missed[5];continue;}
        if(c.source->recovery_lifecycle(c.view)!=physical){++missed[6];continue;}
        require(!matched,"restricted export ambiguous actual route");
        require(compatible_context(c.framing,parse(c.source->recovery_description(c.view),65536),c.compatibility,route,c.view,
            descriptor->controller_revision_,descriptor->physical_incarnation_,descriptor->phase_,descriptor->barrier_,descriptor->attempt_,descriptor->limits_.codec),"restricted export source compatibility changed");matched=&c;
    }
    if(!matched)throw db_error("restricted export physical authenticated source differs"
        " [first-failed predicates: routeExpired="+std::to_string(missed[0])+
        ", continuous="+std::to_string(missed[1])+", owner="+std::to_string(missed[2])+
        ", retired="+std::to_string(missed[3])+", source="+std::to_string(missed[4])+
        ", viewLive="+std::to_string(missed[5])+", lifecycle="+std::to_string(missed[6])+"]");
    if(originals){require(!originals->empty()&&originals->size()<=8192,"restricted export original window capacity");
        size_t next=0;for(const auto& allowed:matched->unknown_originals)if(next<originals->size()&&allowed==(*originals)[next])++next;
        require(next==originals->size(),"restricted export window outside exact ordered retained-Q candidates");}
}
recovery_reconciliation_result recovery_receiver_controller::controller_reconcile_owned(
    const std::shared_ptr<const recovery_reconciliation_descriptor>& descriptor,recovery_reconciliation_step step,
    const std::function<void(database&)>& body,bool* coordinator_busy) {
    if(coordinator_busy)*coordinator_busy=false;
    require(descriptor&&body,"controller reconciliation input missing");auto controller=descriptor->controller_.lock();
    const auto owner=descriptor->owner();require(controller&&owner&&!owner->is_closed(),"controller reconciliation actual owner retired");
    auto& runtime=*controller->state_;
    recovery_reconciliation_result result;
    auto reservation=std::make_shared<recovery_reconciliation_reservation>();reservation->controller=controller;reservation->owner=owner;
    {std::lock_guard lock(runtime.mutex);
        require(runtime.reconciliation==descriptor&&runtime.revision==descriptor->controller_revision_,"controller reconciliation descriptor replaced");
        if(runtime.running){result.coordinator_busy_=true;if(coordinator_busy)*coordinator_busy=true;return result;}
        require(!runtime.reconciliation_reservation&&runtime.revision<UINT64_MAX-1&&runtime.external_revision<UINT64_MAX,"controller reconciliation reservation exhausted");
        runtime.running=true;runtime.reconciliation_reservation=reservation.get();reservation->active=true;}
    result.descriptor_=descriptor;result.step_=step;result.reservation_=reservation;
    const bool cancel=step==recovery_reconciliation_step::cancelled;
    const auto continuity=cancel?std::shared_ptr<recovery_unknown_reconciliation>{}:recovery_unknown_reconciliation::acquire(descriptor);
    require(cancel||continuity,"controller reconciliation first-claim worker unavailable");
    const auto first_claims=continuity?continuity->refreeze_claims():std::shared_ptr<const std::vector<int64_t>>{};
    require(descriptor->phase_==(cancel?2:4),"controller reconciliation step/phase differs");
    require(!cancel||(descriptor->barrier_<INT64_MAX&&descriptor->attempt_<INT64_MAX),"controller reconciliation sequence exhausted");
    result.next_barrier_=descriptor->barrier_+(cancel?1:0);result.next_attempt_=descriptor->attempt_+(cancel?1:0);
    std::shared_ptr<void> scope_probe;
    if(runtime.probe&&runtime.probe->owner==owner.get()&&runtime.probe->scope)
        scope_probe=runtime.probe->scope(cancel?"reconcile-cancel":"reconcile-refreeze");
    result.settlement_=recovery_continuous_producer::controller_owned(*controller,owner,[&](database& db){
        const auto current_sources=[&]{
            {std::lock_guard lock(runtime.mutex);require(runtime.reconciliation==descriptor&&runtime.revision==descriptor->controller_revision_,"controller reconciliation compatibility generation changed");}
            for(const auto& c:descriptor->contributions_){const auto route=c.route.lock();
                require(route&&!route->state_->retired.load()&&c.source==route->state_->source&&c.source&&c.source->recovery_live(c.view),"controller reconciliation source retired");
                require(compatible_context(c.framing,parse(c.source->recovery_description(c.view),65536),c.compatibility,route,c.view,
                    descriptor->controller_revision_,descriptor->physical_incarnation_,descriptor->phase_,descriptor->barrier_,descriptor->attempt_,descriptor->limits_.codec),"controller reconciliation source compatibility changed");}
        };
        current_sources();
        const auto rows=db.query("SELECT CASE WHEN typeof(incarnation)='integer' THEN incarnation END AS incarnation,CASE WHEN typeof(phase)='integer' THEN phase END AS phase,CASE WHEN typeof(barrier)='integer' THEN barrier END AS barrier,CASE WHEN typeof(attempt)='integer' THEN attempt END AS attempt FROM main._lattice_producer_continuity WHERE id=1 LIMIT 2");
        require(rows.size()==1&&integer(rows[0],"incarnation")==descriptor->physical_incarnation_&&integer(rows[0],"phase")==descriptor->phase_&&
            integer(rows[0],"barrier")==descriptor->barrier_&&integer(rows[0],"attempt")==descriptor->attempt_,"controller reconciliation physical generation differs");
        if(cancel){require(descriptor->frozen_!=nullptr,"controller frozen reconciliation lacks actual provenance");recovery_continuous_producer::verify_for_owned_write(*descriptor->frozen_);}
        recovery_request_store requests(owner);auto framing=requests.fingerprints();
        if(cancel)for(const auto& part:descriptor->contributions_){auto after=part.framing;after.receipt_decisions=part.receipt_decisions;framing.at(after.journal.channel)=requests.fingerprint(after);}
        recovery_obligation_store journal(owner,runtime.caps.obligations,runtime.caps.install.installations);
        receive_install_store receiver(owner,runtime.caps.install.installations);receiver.audit();journal.audit();
        std::vector<recovery_obligation_snapshot> journals;std::vector<receive_install_snapshot> receivers;
        for(size_t contribution=0;contribution<descriptor->contributions_.size();++contribution) {
            const auto& c=descriptor->contributions_[contribution];
            require(requests.read(c.framing.journal.channel)==std::optional<recovery_request_row>{c.framing},"controller reconciliation frozen Q/M changed");
            const auto scope=journal.read(c.framing.journal.channel);const auto installed=receiver.read(c.framing.journal.channel);
            require(scope&&installed&&scope->profile==c.journal.scope.profile&&scope->address==c.journal.scope.address,"controller reconciliation journal address changed");
            auto snapshot=cancel?journal.snapshot_for_install(scope->address,descriptor->attempt_):journal.snapshot_for_reconciliation(scope->address);
            require(snapshot.entries.size()==c.journal.entries.size(),"controller reconciliation pending inventory changed");
            for(size_t n=0;n<snapshot.entries.size();++n){auto current=snapshot.entries[n],original=c.journal.entries[n];
                if(!cancel){const auto first=first_claims->at(continuity->claim_offsets_[contribution]+n);
                    original.first_export_claim=first?std::optional<int64_t>{first}:std::nullopt;}
                require(current==original,"controller reconciliation original, order, receipt or first claim changed");}
            if(cancel)require(snapshot.scope==c.journal.scope,"controller frozen reconciliation scope changed");
            else require(scope->mode==recovery_obligation_mode::recording&&scope->last_attempt==c.framing.sequence&&scope->revision>=c.journal.scope.revision,
                "controller restricted reconciliation scope changed");
            require(installed->binding==scope->profile.binding&&installed->last_sequence==c.framing.sequence&&
                (!installed->last_installed||installed->last_installed->sequence<c.framing.sequence),"controller reconciliation attempt already installed or superseded");
            journals.push_back(std::move(snapshot));receivers.push_back(*installed);
        }
        body(db); // closed internal helper only; no public callback/issuer
        require(requests.fingerprints()==framing,"controller reconciliation altered retained framing");
        for(size_t n=0;n<journals.size();++n){auto expected=journals[n];auto expected_receiver=receivers[n];
            if(cancel){expected.scope.mode=recovery_obligation_mode::recording;++expected.scope.address.generation;++expected.scope.revision;expected_receiver.active.reset();}
            const auto current=journal.snapshot_for_reconciliation(expected.scope.address);
            require(current.scope==expected.scope&&current.entries==expected.entries&&receiver.read(expected.scope.address.channel)==std::optional<receive_install_snapshot>{expected_receiver},
                "controller reconciliation authorized postimage differs");}
        receiver.audit();journal.audit();current_sources();
        recovery_continuous_producer::controller_transition_reconcile_owned(*controller,owner,descriptor->phase_,descriptor->barrier_,descriptor->attempt_,
            cancel?4:1,result.next_barrier_,result.next_attempt_);
    });
    scope_probe.reset();
    if(result.settlement_.state!=recovery_install_state::committed){reservation->release();result.reservation_.reset();}
    else if(runtime.probe&&runtime.probe->owner==owner.get()&&runtime.probe->observed)
        runtime.probe->observed(cancel?"reconcile-cancel-committed":"reconcile-refreeze-committed");
    return result;
}
void recovery_receiver_controller::controller_reconcile_publish(recovery_reconciliation_result&& result) {
    require(result.descriptor_&&result.reservation_&&result.settlement_.state==recovery_install_state::committed,
        "controller reconciliation publication needs reserved known COMMIT");
    const auto descriptor=std::move(result.descriptor_);auto reservation=std::move(result.reservation_);
    const auto controller=reservation->controller;const auto owner=reservation->owner;
    require(controller&&owner&&owner==descriptor->owner()&&!owner->is_closed(),"controller reconciliation publication retired");
    auto& runtime=*controller->state_;
    {std::lock_guard lock(runtime.mutex);require(reservation->active&&runtime.running&&runtime.reconciliation_reservation==reservation.get()&&
        runtime.reconciliation==descriptor&&runtime.revision==descriptor->controller_revision_&&runtime.revision<UINT64_MAX,
        "controller reconciliation publication reservation changed");
        if(runtime.admission_install){
            const state::install_target_id canceled{descriptor->controller_revision_,descriptor->physical_incarnation_,
                descriptor->barrier_,descriptor->attempt_,descriptor->frozen_.get()};
            require(result.step_==recovery_reconciliation_step::cancelled&&runtime.admission_install->id==canceled,
                "controller reconciliation cannot retire another install target");
        }
    }
    // All coordinator preconditions are checked before runtime publication.
    // The reserved result excludes worker turns; real external requests are
    // coalesced until release, and cannot relabel this known COMMIT.
    recovery_continuous_producer::controller_publish_reconcile(*controller,owner,result.next_barrier_,result.next_attempt_);
    std::shared_ptr<const recovery_reconciliation_descriptor> retired;
    state::install_target_ptr retired_install;
    recovery_writer_access::controller_admission_intent::retired_custody retired_writer;
    {std::lock_guard lock(runtime.mutex);
        retired_install=std::move(runtime.admission_install);runtime.admission_wait={};
        retired_writer=runtime.admission_intent.retire();
        retired=std::move(runtime.reconciliation);++runtime.revision;runtime.failure={};runtime.awaiting_delivery_retry=false;runtime.demand=true;
    }
    retired_writer.reset();retired_install.reset();
#ifndef __EMSCRIPTEN__
    runtime.executor->cancel_retry();
#endif
    runtime.frozen.reset();runtime.framing_committed=false;runtime.predecessors.clear();
    reservation->release(); // payload/owner release is outside the leaf
    if(runtime.probe&&runtime.probe->owner==owner.get()&&runtime.probe->observed)
        runtime.probe->observed(result.step_==recovery_reconciliation_step::cancelled?"reconcile-cancel-published":"reconcile-refreeze-published");
    std::shared_ptr<recovery_receiver_route> next;
    {std::lock_guard lock(runtime.mutex);for(const auto& weak:runtime.routes)if(auto route=weak.lock())if(!route->state_->retired.load()){next=std::move(route);break;}}
    if(next)controller->wake(next);
}
} // namespace lattice::detail

#include "recovery_canonical_final_audit.hpp"
#include <cstring>
namespace lattice::detail {
void recovery_canonical_final_audit::table_(const recovery_obligation_bootstrap_reader& reader,ordinary_schema_projection& result,
    std::string_view name,std::string_view sql,std::initializer_list<column> columns,std::initializer_list<std::string_view> indexes) {
    // Projection strings, vectors and map nodes use the actual rebound
    // allocator within the caller's SAME Open/account lexical storage scope.
    // No guessed node size or allocator overhead is converted into credit.
    reader.claim_workspace_(0); // validate the retained real account before copying DATA
    ordinary_projection_table table;table.name.assign(name.data(),name.size());table.create_sql.assign(sql.data(),sql.size());
    table.role=ordinary_projection_role::link;table.local_id=false;table.columns.reserve(columns.size());
    for(const auto& value:columns)table.columns.push_back({value.name,value.type,value.nullable,false,{}});
    for(const auto index:indexes)table.index_programs.emplace_back(index.data(),index.size());
    if(columns.size()>std::numeric_limits<std::size_t>::max()-result.columns||name.size()+sql.size()>std::numeric_limits<std::size_t>::max()-result.logical_bytes)
        throw db_error("canonical final projection envelope overflow");
    result.columns+=columns.size();result.logical_bytes+=name.size()+sql.size();
    if(!result.tables.emplace(table.name,std::move(table)).second)throw db_error("canonical final compiled table overlaps selected catalog");
}
void recovery_canonical_final_audit::claim_rows_(recovery_obligation_bootstrap_reader& reader,const std::vector<database::row_t>& rows) {
    reader.require_final_snapshot_();std::uint64_t bytes=0;
    const auto add=[&](std::uint64_t n){if(n>UINT64_MAX-bytes)throw db_error("canonical final retained row overflow");bytes+=n;};
    for(const auto& row:rows) {
        for(const auto& [key,value]:row) {
            (void)key;
            if(const auto* text=std::get_if<std::string>(&value))add(text->size());
            else if(const auto* blob=std::get_if<std::vector<std::uint8_t>>(&value))add(blob->size());
        }
    }
    reader.claim_workspace_(bytes);
}
void recovery_canonical_final_audit::append_projection_(const recovery_continuous_policy& policy,
    const recovery_obligation_bootstrap_reader& reader,ordinary_schema_projection& projection) {
    for(const auto& [name,table]:projection.tables) {
        const std::string_view key{name.data(),name.size()};(void)table;
        if(key.starts_with("_lattice_recovery_")||key.starts_with("_lattice_range_"))
            throw db_error("canonical final namespace was supplied by an uncompiled catalog family");
    }
    if(policy.receiver==recovery_continuous_receiver_profile::disabled)return;
    if(policy.receiver!=recovery_continuous_receiver_profile::full_canonical_v2)throw db_error("canonical final receiver profile is unsupported");
    recovery_request_store::append_final_projection_(reader,projection);
    canonical_range_staging::append_final_projection_(reader,projection);
    append_domains_(reader,projection);recovery_witness_access::append_final_projection_(reader,projection);
}
void recovery_canonical_final_audit::audit_(lattice_db& owner,database& actual,recovery_obligation_bootstrap_reader& reader,
    const recovery_continuous_policy& policy,std::int64_t phase,std::int64_t barrier,std::int64_t attempt) {
    reader.require_owner_(actual);reader.require_final_snapshot_();
    if(reader.final_owner_()!=&actual||reader.final_parent_()!=&owner)throw db_error("canonical final reader has a different actual role or parent");
    const auto& declaration=reader.final_declaration_();
    if(declaration.obligations!=policy.limits.obligations||declaration.installations!=policy.limits.installations||declaration.producers!=policy.limits.producers)
        throw db_error("canonical final actual admission profile differs");
    if(policy.receiver!=recovery_continuous_receiver_profile::full_canonical_v2)throw db_error("canonical final audit requires its actual full receiver profile");
    recovery_receiver_controller::audit_final_(reader,policy,phase,barrier,attempt);
}
void recovery_canonical_final_audit::audit_core_receivers_(recovery_obligation_bootstrap_reader& reader,
    const recovery_continuous_policy& policy,std::int64_t phase,std::int64_t attempt) {
    reader.require_final_snapshot_();
    if(policy.receiver!=recovery_continuous_receiver_profile::disabled)throw db_error("core final receiver audit has a canonical profile");
    const auto& limits=reader.final_declaration_().installations;
    if(limits!=policy.limits.installations)throw db_error("core final receiver limits differ from actual admission");
    (void)receive_install_store::audit_final_(reader,limits);
    for(const auto& profile:policy.contributions) {
        const auto scope=reader.final_scope_(profile.profile.binding.channel);
        const auto received=receive_install_store::read_final_(reader,limits,profile.profile.binding.channel);
        const auto prior_attempt=phase==0?attempt:attempt-1;
        if(!scope||!received||prior_attempt<0||received->binding!=profile.profile.binding||received->active||received->last_installed||received->revision!=0||
           received->frontier!=receive_install_frontier{}||received->last_sequence!=prior_attempt||
           scope->mode!=(phase==2?recovery_obligation_mode::frozen:recovery_obligation_mode::recording)||
           scope->last_attempt!=(phase==2?attempt:prior_attempt))
            throw db_error("continuous lineage/journal/receiver restart state differs");
    }
}
void recovery_receiver_controller::audit_final_(recovery_obligation_bootstrap_reader& reader,const recovery_continuous_policy& policy,int64_t phase,int64_t barrier,int64_t attempt) {
    reader.require_final_snapshot_();const auto caps=limits(policy);
    recovery_request_store::final_audit_(reader);
    recovery_canonical_final_audit::audit_domains_(reader,caps.install);
    require(recovery_witness_access::read_final_(reader).has_value(),"controller witness missing on reopen");
    canonical_range_staging::audit_final_(reader,caps.install.installations,caps.codec,caps.staging);
    // The SAME final reader already completed full obligation+producer audit.
    // Recheck actual receiver census here; this path performs no migration.
    (void)receive_install_store::audit_final_(reader,caps.install.installations);
    const auto count=reader.query_(recovery_obligation_bootstrap_statement::kind::final_controller_unresolved);
    require(count.size()==1&&integer(count[0],"n")<=8192,"controller reopened unresolved-original capacity differs");
    std::set<std::string,std::less<std::string>,ordinary_initialization_allocator<std::string>> allowed;
    for(const auto& c:policy.contributions){reader.claim_workspace_(c.profile.binding.channel.size());allowed.insert(c.profile.binding.channel);const auto scope=reader.final_scope_(c.profile.binding.channel);const auto actual=receive_install_store::read_final_(reader,caps.install.installations,c.profile.binding.channel);
        require(scope&&scope->profile==c.profile&&actual&&actual->binding==c.profile.binding,"controller reopened contribution binding differs");
        require(phase==0||phase==1||phase==4?scope->mode==recovery_obligation_mode::recording:
            phase==2?scope->mode==recovery_obligation_mode::frozen:phase==3&&scope->mode==recovery_obligation_mode::installed,
            "controller reopened journal phase differs");
        const auto framing=recovery_request_store::final_read_(reader,c.profile.binding.channel);
        if(framing){
            const auto decoded=cr::decode(framing->request_frame,caps.codec);const auto* q=std::get_if<cr::request>(&decoded.body);
            require(q&&decoded.logical.channel==c.profile.binding.channel&&decoded.logical.sequence==uint64_t(framing->sequence)&&q->source==source_binding(c.profile),"controller reopened Q differs");
            if(phase==4)require(framing->receipt_decisions=="0"||(q->receipts.size()<=recovery_request_store::decision_entries&&framing->receipt_decisions.size()==65+2*q->receipts.size()&&!framing->receipt_decisions.empty()&&framing->receipt_decisions[0]=='1'),
                "controller reopened canceled receipt decisions missing or count differs");
            if(!framing->manifest_frame.empty()){
                const auto m=cr::decode(framing->manifest_frame,caps.codec);require(m.logical==decoded.logical&&std::holds_alternative<cr::manifest>(m.body),"controller reopened manifest framing differs");
                const auto described=describe_canonical_range(decoded.logical,*q,std::get<cr::manifest>(m.body),caps.codec,framing->route);
                require(described.installation_binding==c.profile.binding,"controller reopened manifest binding differs");
                if(phase==0||phase==3||(phase==1&&actual->last_installed==std::optional<receive_install_identity>{described.installation_identity})){require(actual->last_installed==std::optional<receive_install_identity>{described.installation_identity}&&scope->installed_manifest==described.installation_identity.manifest_digest&&
                    scope->installed_revision==actual->revision,"controller reopened installed framing differs");
                    require(!actual->active&&actual->last_sequence==framing->sequence&&
                        (phase!=1||(framing->sequence==attempt-1&&scope->last_attempt==framing->sequence)),"controller prior installed request is not the exact barrier predecessor");}
            }else require((phase==2&&framing->sequence==attempt&&framing->barrier==barrier&&framing->journal==scope->address&&framing->journal_revision==scope->revision)||
                canceled_predecessor(*framing,*scope,*actual,*q,phase,barrier,attempt),"controller manifestless Q lacks exact current or canceled predecessor");
            if(framing->manifest_frame.empty()&&(phase==1||phase==2)&&framing->sequence==attempt-1)
                require(canceled_predecessor(*framing,*scope,*actual,*q,phase,barrier,attempt),"controller reopened canceled predecessor differs");
            if(phase==1)require(framing->sequence==attempt-1&&actual->last_sequence==framing->sequence&&!actual->active,
                "controller preparing phase lacks its exact prior receiver sequence");
            if(phase==4||(phase==1&&framing->sequence<attempt&&(!actual->last_installed||actual->last_installed->sequence<framing->sequence)))require(framing->sequence==attempt-1&&framing->barrier+1>framing->barrier&&
                scope->last_attempt==framing->sequence&&scope->address.incarnation==framing->journal.incarnation&&scope->address.generation==framing->journal.generation+1&&
                scope->revision>=framing->journal_revision+1&&!actual->active&&actual->last_sequence==framing->sequence&&
                (!actual->last_installed||actual->last_installed->sequence<framing->sequence),"controller reopened reconciliation differs from exact canceled attempt");
        }else require(!actual->last_installed&&phase!=3,"controller missing installed framing");
        if(phase==2||phase==3)require(scope->last_attempt==attempt,"controller reopened attempt differs");
        if(phase==3)require(framing&&framing->sequence==attempt&&!framing->manifest_frame.empty(),"controller installed phase lacks complete framing");
    }
    for(const auto& channel:recovery_request_store::final_channels_(reader))require(allowed.count(channel),"controller unknown durable request channel");
}
}
