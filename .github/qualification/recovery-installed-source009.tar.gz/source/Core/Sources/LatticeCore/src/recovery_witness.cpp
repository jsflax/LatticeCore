#include "provider_native_internal.hpp"
#include <lattice/store_physical_api.hpp>
#include "recovery_witness.hpp"
#include "recovery_writer_access.hpp"
#include <algorithm>
#include <cstring>
#include <limits>
#include <string_view>

namespace lattice::detail {
namespace {
constexpr const char* schema =
    "CREATE TABLE _lattice_recovery_witness(id INTEGER PRIMARY KEY CHECK(id=1),"
    "version INTEGER NOT NULL,incarnation BLOB NOT NULL,generation INTEGER NOT NULL) WITHOUT ROWID";
[[noreturn]] void refuse(const char* message) { throw db_error(message); }
void require(bool yes, const char* message) { if (!yes) refuse(message); }
struct statement {
    lattice_sqlite3541_stmt* p = nullptr;
    statement(lattice_sqlite3541_connection* db, const char* sql) {
        database::record_statement();
        const auto rc = ::lattice::detail::store_physical_prepare_v2(db, sql, -1, &p, nullptr);
        if (rc != LATTICE_SQLITE3541_OK || !p) { ::lattice::detail::store_physical_finalize(p); p = nullptr; refuse("recovery witness prepare failed"); }
    }
    ~statement() { ::lattice::detail::store_physical_finalize(p); }
    statement(const statement&) = delete;
    bool next() {
        const auto rc = ::lattice::detail::store_physical_step(p);
        if (rc == LATTICE_SQLITE3541_ROW) return true;
        require(rc == LATTICE_SQLITE3541_DONE, "recovery witness step failed"); return false;
    }
    void done() { require(!next(), "recovery witness write returned rows"); }
    int64_t integer(int i) {
        require(lattice_sqlite3541_column_type(p, i) == LATTICE_SQLITE3541_INTEGER, "recovery witness integer type mismatch");
        return lattice_sqlite3541_column_int64(p, i);
    }
    bool text_is(int i, std::string_view expected) {
        if (lattice_sqlite3541_column_type(p, i) != LATTICE_SQLITE3541_TEXT ||
            lattice_sqlite3541_column_bytes(p, i) != static_cast<int>(expected.size())) return false;
        const auto* bytes = lattice_sqlite3541_column_text(p, i);
        return bytes && std::memcmp(bytes, expected.data(), expected.size()) == 0;
    }
};
bool existing(lattice_sqlite3541_connection* db) {
    statement s(db, "SELECT type,tbl_name,sql FROM main.sqlite_schema "
                    "WHERE name='_lattice_recovery_witness' COLLATE NOCASE LIMIT 2");
    if (!s.next()) return false;
    require(s.text_is(0, "table") && s.text_is(1, "_lattice_recovery_witness") && s.text_is(2, schema),
        "recovery witness schema mismatch");
    require(!s.next(), "recovery witness schema alias ambiguity");
    // No unknown trigger/index may suppress or amplify a witness update. The
    // WITHOUT ROWID primary key creates no sqlite_schema autoindex entry.
    statement attached(db, "SELECT 1 FROM main.sqlite_schema "
        "WHERE tbl_name='_lattice_recovery_witness' COLLATE NOCASE AND type!='table' LIMIT 1");
    require(!attached.next(), "recovery witness unexpected trigger/index");
    return true;
}
recovery_witness value(lattice_sqlite3541_connection* db) {
    // Reject corrupt wide scalars inside SQLite before returning a value to the
    // client. typeof/length inspect type/byte length without copying a huge
    // corrupt BLOB/TEXT value into the result register.
    statement s(db, "SELECT CASE WHEN typeof(id)='integer' THEN id END,"
        "CASE WHEN typeof(version)='integer' THEN version END,"
        "CASE WHEN typeof(incarnation)='blob' AND length(incarnation)=16 THEN incarnation END,"
        "CASE WHEN typeof(generation)='integer' THEN generation END "
        "FROM main._lattice_recovery_witness LIMIT 2");
    require(s.next() && s.integer(0) == 1 && s.integer(1) == 1, "recovery witness missing/version mismatch");
    require(lattice_sqlite3541_column_type(s.p, 2) == LATTICE_SQLITE3541_BLOB && lattice_sqlite3541_column_bytes(s.p, 2) == 16,
        "recovery witness incarnation type/length mismatch");
    const auto* bytes = lattice_sqlite3541_column_blob(s.p, 2);
    require(bytes != nullptr, "recovery witness incarnation unavailable");
    recovery_witness result;
    std::memcpy(result.incarnation.data(), bytes, result.incarnation.size());
    result.generation = s.integer(3);
    require(result.generation > 0 && !s.next(), "recovery witness generation/singleton mismatch");
    return result;
}
} // namespace

std::optional<recovery_witness> recovery_witness_access::read(database& reader) {
    require(!reader.is_closed(), "recovery witness reader is closed");
    auto* db = reader.internal_handle();
    if (!existing(db)) return std::nullopt;
    return value(db);
}

recovery_witness recovery_witness_access::bump(lattice_db& owner) {
    auto* writer = recovery_writer_access::active_writer(owner);
    require(writer != nullptr, "recovery witness requires owned writer");
    auto* db = writer->internal_handle();
    if (!existing(db)) {
        statement create(db, schema); create.done();
        // randomblob is a store-local collision-resistant incarnation, not an
        // authenticated epoch. A restore may move generation backwards; readers
        // compare the entire tuple for inequality, never only greater-than.
        statement insert(db, "INSERT INTO main._lattice_recovery_witness VALUES(1,1,randomblob(16),1)");
        insert.done();
        require(lattice_sqlite3541_changes(db) == 1, "recovery witness insertion ignored");
        require(existing(db), "recovery witness creation missing");
        return value(db);
    }
    const auto before = value(db);
    require(before.generation < std::numeric_limits<int64_t>::max(), "recovery witness generation exhausted");
    statement update(db, "UPDATE main._lattice_recovery_witness SET generation=generation+1 WHERE id=1 AND generation=?");
    require(lattice_sqlite3541_bind_int64(update.p, 1, before.generation) == LATTICE_SQLITE3541_OK, "recovery witness bind failed");
    update.done();
    require(lattice_sqlite3541_changes(db) == 1, "recovery witness update ignored");
    const auto after = value(db);
    require(after.incarnation == before.incarnation && after.generation == before.generation + 1,
        "recovery witness update changed unexpectedly");
    return after;
}
std::optional<recovery_witness> read_recovery_witness(database& reader) { return recovery_witness_access::read(reader); }
recovery_witness bump_recovery_witness(lattice_db& owner) { return recovery_witness_access::bump(owner); }
} // namespace lattice::detail

#include "recovery_canonical_final_audit.hpp"
namespace lattice::detail {
std::optional<recovery_witness> recovery_witness_access::read_final_(recovery_obligation_bootstrap_reader& reader) {
    reader.require_final_snapshot_();using kind=recovery_obligation_bootstrap_statement::kind;
    const auto shape=reader.query_(kind::final_witness_schema);if(shape.empty())return std::nullopt;
    const auto text=[](const database::row_t& row,const char* key,std::string_view expected) {
        const auto found=row.find(key);return found!=row.end()&&std::holds_alternative<std::string>(found->second)&&std::get<std::string>(found->second)==expected;
    };
    require(shape.size()==1&&text(shape[0],"type","table")&&text(shape[0],"tbl_name","_lattice_recovery_witness")&&text(shape[0],"sql",schema),"recovery witness schema mismatch");
    require(reader.query_(kind::final_witness_attached).empty(),"recovery witness unexpected trigger/index");
    const auto values=reader.query_(kind::final_witness_values);
    const auto integer=[](const database::row_t& row,const char* key) {
        const auto found=row.find(key);require(found!=row.end()&&std::holds_alternative<std::int64_t>(found->second),"recovery witness integer type mismatch");return std::get<std::int64_t>(found->second);
    };
    require(values.size()==1&&integer(values[0],"id")==1&&integer(values[0],"version")==1,"recovery witness missing/version mismatch");
    const auto found=values[0].find("incarnation");
    require(found!=values[0].end()&&std::holds_alternative<std::vector<std::uint8_t>>(found->second)&&std::get<std::vector<std::uint8_t>>(found->second).size()==16,"recovery witness incarnation type/length mismatch");
    recovery_witness result;const auto& bytes=std::get<std::vector<std::uint8_t>>(found->second);
    std::copy(bytes.begin(),bytes.end(),result.incarnation.begin());result.generation=integer(values[0],"generation");
    require(result.generation>0,"recovery witness generation/singleton mismatch");return result;
}
void recovery_witness_access::append_final_projection_(const recovery_obligation_bootstrap_reader& reader,ordinary_schema_projection& projection) {
    recovery_canonical_final_audit::table_(reader,projection,"_lattice_recovery_witness",schema,
        {{"id",column_type::integer,false},{"version",column_type::integer,false},{"incarnation",column_type::blob,false},{"generation",column_type::integer,false}});
}
}
