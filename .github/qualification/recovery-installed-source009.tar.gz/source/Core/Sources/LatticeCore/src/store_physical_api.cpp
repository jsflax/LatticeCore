#include "provider_native_internal.hpp" // private full API precedes public types-only guard
#include "wal_callback_return.hpp"
#if !defined(__EMSCRIPTEN__) && (defined(__APPLE__) || defined(__linux__))
#include "store_physical_api.hpp"
#include "ordinary_resource_normal_startup.hpp"
#include "database_initialization_budget.hpp"
#include "database_sql_dispatcher.hpp"
#include "observer_delivery_sql_runtime.hpp"
#include "database_retirement.hpp"
#include <lattice/detail/observer_delivery_startup.hpp>
#include "database_initialization_test_probe.hpp"
#include "store_physical_vfs.hpp"
#include "wal_extent_vfs.hpp"
#include <cstring>
#include <lattice/db.hpp>
#include <atomic>
#include <mutex>
#include <optional>

namespace lattice::detail {
// Real nonresource allocation producer. Its stable address is retained until
// BOTH actual engine free and the last owning/reference return. No pathname,
// profile, physical lease, SQL authority or account is manufactured here.
class store_provider_native_original final {
    friend class store_physical_api;
    const void* const instance=lattice_sqlite3541_provider_instance();
    const std::uint64_t creator=database_native_process();
    sqlite_provider::v1::connection_original native;
    lattice_sqlite3541_connection* actual=nullptr; // immutable comparison after genuine return
    store_provider_native_original* next=nullptr;
    std::uint64_t references=1; // actual owning wrapper; Native callers pin separately
    bool owner_returned=false,retired=false,listed=false;
    std::exception_ptr close_failure; // actual first structural ending error; never an invented Native rc
    std::exception_ptr open_failure;
    store_provider_native_original()noexcept=default;
    ~store_provider_native_original()noexcept=default; // DATA only, no Native retry
};
struct store_physical_api::original {
    const std::uint64_t creator=database_native_process();
    store_physical_lifetime::pin held;
    sqlite_provider::v1::connection_original provider_native; // actual owning open must fill BEFORE any escape
    std::exception_ptr provider_close_failure,provider_open_failure;
    bool* initialization_native_entered=nullptr; // fixed Source stamp, used once at true Native call only
    // Fixed typed DATA only. This is setup/compiled-cache custody, never an
    // ordinary transaction/observer-payload refund. Actual API/VFS/Native
    // ending precedes off-leaf completion/deletion of this SAME original.
    std::shared_ptr<database_initialization_budget> initialization_budget;
    // SAME actual init EX DATA adopted BEFORE Native entry. Only real physical
    // ending and existing off-both-stacks original deletion retire this hold.
    std::shared_ptr<store_resource_catalog_initialization_guard> catalog_initialization_guard;
    original* next=nullptr;
    enum class returned_action : std::uint8_t {none,complete,destroy};
    original* returned_next=nullptr;
    returned_action returned=returned_action::none;
    lattice_sqlite3541_connection* actual=nullptr; // lookup DATA only; never dereferenced or invoked
    std::uint64_t references=1;
    bool primary=true,listed=false,current=false,completion_claimed=false,completion_returned=false;
    void* completion_cookie=nullptr;
    void(*completion)(void*)noexcept=nullptr;
    explicit original(const store_physical_lifetime::pin& pin):held(pin){}
};
namespace {
const std::uint64_t physical_api_creator=database_native_process();
std::mutex physical_api_leaf;
std::atomic<bool> physical_api_used{false};

}
store_physical_api::original* store_physical_api::head_=nullptr;
store_provider_native_original* store_physical_api::legacy_head_=nullptr;
thread_local store_physical_api::original* store_physical_api::returned_tails_=nullptr;
thread_local database_initialization_budget* store_physical_api::returned_budgets_=nullptr;
thread_local bool store_physical_api::draining_tails_=false;
thread_local std::uint64_t store_physical_api::native_return_work_=0;
thread_local store_physical_api::api_scope* store_physical_api::api_scope::current_=nullptr;
store_physical_api::original* store_physical_api::prepare_(const store_physical_lifetime::pin& held,void* cookie,void(*completed)(void*)noexcept,
    const std::shared_ptr<store_resource_catalog_initialization_guard>& initialization_guard,
    const std::shared_ptr<database_initialization_budget>& initialization_account,bool* actual_native_entered) {
    if(!held.current()||physical_api_creator!=database_native_process())
        throw db_error("physical API original requires its actual creator");
    if(!cookie||!completed)throw db_error("physical API original requires its actual cleanup producer");
    if(initialization_guard&&!initialization_account)throw db_error("physical init guard lacks its actual account");
    if(initialization_account) {
        initialization_account->require_current_();
        if(initialization_guard)store_resource_initialization_original::require_catalog_guard_account_(initialization_guard,initialization_account);
        initialization_account->claim_workspace_(sizeof(original)); // actual complete node request before new
    }
    const auto issuing_creator=database_native_process();
    auto* value=new original(held);
    if(issuing_creator!=database_native_process())
        throw db_error("physical API original changed process during admission"); // child abandons capsule before inherited shared controls
    value->initialization_budget=initialization_account;value->catalog_initialization_guard=initialization_guard;
    value->initialization_native_entered=actual_native_entered;
    value->completion_cookie=cookie;value->completion=completed;
    if(value->creator!=database_native_process())
        throw db_error("physical API original changed process during admission"); // child abandons capsule
    if(!held.current()){delete value;throw db_error("physical API original lost its lease during admission");}
    return value;
}
bool store_physical_api::publish_(original* issued,lattice_sqlite3541_connection* actual,void* cookie,void(*completed)(void*)noexcept)noexcept {
    if(!issued||issued->creator!=database_native_process()||physical_api_creator!=database_native_process())return false;
    try {
        std::lock_guard lock(physical_api_leaf);
        if(issued->listed||!issued->held.current()||!completed)return false;
        // Only the actual new SQLite open return can supersede an address.
        // Old cleanup frames already carry their immutable original pin.
        for(auto* at=head_;at;at=at->next)
            if(at->actual==actual)at->current=false;
        issued->actual=actual;issued->completion_cookie=cookie;issued->completion=completed;
        issued->listed=true;issued->current=actual!=nullptr;
        issued->next=head_;head_=issued;
        physical_api_used.store(true,std::memory_order_release);return true;
    }catch(...){return false;} // Issuer retains unproved registration/lease custody.
}
bool store_physical_api::publish_member_(original* issued,lattice_sqlite3541_connection* actual,void* cookie,void(*completed)(void*)noexcept)noexcept {
    if(!issued||!actual||issued->creator!=database_native_process()||physical_api_creator!=database_native_process())return false;
    try{std::lock_guard lock(physical_api_leaf);
        if(issued->listed||!issued->held.current()||!completed||!cookie)return false;
        bool primary=false;std::size_t count=0;
        for(auto* at=head_;at;at=at->next)if(at->current&&at->actual==actual){
            primary=primary||at->primary;if(at->completion_cookie==cookie)return false;++count;
        }
        if(!primary||count>=maximum_originals)return false;
        issued->primary=false;issued->actual=actual;issued->completion_cookie=cookie;issued->completion=completed;
        issued->listed=true;issued->current=true;issued->next=head_;head_=issued;return true;
    }catch(...){return false;}
}
void store_physical_api::abandon_unpublished_(original* issued)noexcept {
    if(!issued||issued->creator!=database_native_process())return;
    if(!issued->listed)delete issued; // called outside Native/VFS/registry leaves
}
bool store_physical_api::foreign_protected_()noexcept {
    return physical_api_creator!=database_native_process()&&physical_api_used.load(std::memory_order_acquire);
}
store_physical_api::ticket store_physical_api::capture_issued_(original* actual)noexcept {
    ticket result;result.creator=database_native_process();
    if(!actual||actual->creator!=result.creator||physical_api_creator!=result.creator){result.inherited=true;return result;}
    try{std::lock_guard lock(physical_api_leaf);
        if(actual->references==UINT64_MAX){result.inherited=true;return result;}
        ++actual->references;result.value=actual;result.values[0]=actual;result.count=1;
    }catch(...){result.inherited=true;}
    return result;
}
store_physical_api::ticket store_physical_api::capture_(lattice_sqlite3541_connection* actual)noexcept {
    ticket result;result.creator=database_native_process();
    if(!physical_api_used.load(std::memory_order_acquire))return result;
    if(physical_api_creator!=result.creator){result.inherited=true;return result;}
    try{
        std::lock_guard lock(physical_api_leaf);
        std::size_t count=0;
        for(auto* at=head_;at;at=at->next)if(at->current&&at->actual==actual){
            if(at->references==UINT64_MAX||count==maximum_originals){result.inherited=true;return result;}++count;
        }
        // Count/overflow validation precedes all reference changes. No Native
        // pin allocation or destructor is performed beneath this DATA leaf.
        for(auto* at=head_;at;at=at->next)if(at->current&&at->actual==actual){
            ++at->references;result.values[result.count++]=at;
            if(at->primary)result.value=at;
        }
        if(!result.value&&result.count)result.value=result.values[0];
    }catch(...){result.inherited=true;}
    return result;
}
store_physical_vfs* store_physical_api::actual_owner_(const ticket& actual)noexcept {
    if(actual.inherited||actual.creator!=database_native_process()||!actual.value||!actual.value->primary||
       actual.value->completion!=&store_physical_vfs::complete_||!actual.value->completion_cookie)return nullptr;
    auto* root=static_cast<store_physical_vfs*>(actual.value->completion_cookie);
    return root->current_()&&root->root_==root?root:nullptr;
}
thread_local store_physical_native_scope* store_physical_native_scope::current_=nullptr;
bool store_physical_api::retain_initialization_budget_(store_physical_open_original& owner,
    const std::shared_ptr<database_initialization_budget>& budget)noexcept {
    if(!budget||!budget->current_()||owner.creator_!=database_native_process()||
       owner.exclusive_target_||owner.legacy_||foreign_protected_())return false;
    auto actual=capture_open_(owner,owner.actual_);
    if(actual.inherited||actual.count!=1||!actual.value||!actual.value->primary||
       !actual_owner_(actual)||native_custody_here_(actual.value))return false;
    const auto observed=store_physical_lifetime::observe_(actual.value->held);
    if(!observed.current||observed.unknown||observed.connection_retired||
       observed.active_api||observed.active_native||observed.active_vfs||
       store_physical_lifetime::observer_policy_unsettled_(actual.value->held))return false;
    try {
        std::lock_guard lock(physical_api_leaf);
        auto* original=actual.value;
        if(owner.creator_!=database_native_process()||!budget->current_()||
           !original->listed||!original->current||original->actual!=owner.actual_||
           original->completion_claimed||original->completion_returned)return false;
        if(original->initialization_budget)return original->initialization_budget==budget;
        // Empty destination + closed DATA shared_ptr: no user copy/allocation,
        // displaced destruction or Native call occurs under this leaf.
        original->initialization_budget=budget;
        return true;
    }catch(...){return false;}
}
sqlite_provider::v1::connection_ref store_physical_api::native_ref_(
    const store_physical_open_original& owner,lattice_sqlite3541_connection* native) {
    using namespace sqlite_provider::v1;
    if(owner.provider_instance_!=lattice_sqlite3541_provider_instance()||
       owner.creator_!=database_native_process()||foreign_protected_()||!native||
       !owner.bound_||owner.native_retired_||owner.actual_!=native)
        throw error(rejection::foreign_instance);
    if(owner.provider_legacy_){
        auto* original=static_cast<store_provider_native_original*>(owner.provider_legacy_);
        if((!owner.legacy_&&!owner.exclusive_target_)||original->instance!=owner.provider_instance_||
           original->creator!=database_native_process()||original->owner_returned||
           original->actual!=native||original->retired)throw error(rejection::invalid_original);
        return original->native.borrow_();
    }
    auto original=capture_open_(owner,native);
    if(original.inherited||!original.value||!original.value->primary)
        throw error(rejection::invalid_original);
    // Same preadmitted record owns the provider's real Native return. The
    // provider checks its own instance/PID/serial before its first dereference.
    return original.value->provider_native.borrow_();
}
sqlite_provider::v1::connection_ref store_physical_open_original::native_ref_(lattice_sqlite3541_connection* native)const {
    return store_physical_api::native_ref_(*this,native);
}
bool store_physical_api::can_issue_open_(const store_physical_open_original& owner)noexcept {
    return !owner.bound_&&!owner.original_&&owner.creator_==database_native_process()&&!foreign_protected_();
}
bool store_physical_api::issue_open_(store_physical_open_original& owner,original* issued)noexcept {
    if(!can_issue_open_(owner)||!issued||issued->creator!=database_native_process()||!issued->primary)return false;
    // The producer preadmits this exact reference BEFORE SQLite can return a
    // handle or run any VFS callback. No current-address lookup occurs here.
    auto retained=capture_issued_(issued);if(retained.inherited||!retained.value)return false;
    owner.original_=retained.value;retained.count=0;retained.value=nullptr;
    owner.provider_instance_=lattice_sqlite3541_provider_instance();owner.bound_=true;owner.legacy_=false;return true;
}
bool store_physical_api::issue_legacy_open_(store_physical_open_original& owner) {
    if(!can_issue_open_(owner))return false;
    // Only the actual open producer calls this AFTER resource admission has
    // positively selected its uninstalled or exact memory/TEMP route.
    if(!prepare_legacy_(owner))return false;
    owner.provider_instance_=lattice_sqlite3541_provider_instance();owner.bound_=true;owner.legacy_=true;return true;
}
bool store_physical_api::prepare_legacy_(store_physical_open_original& owner) {
    if(owner.creator_!=database_native_process()||owner.provider_legacy_||
       !lattice_sqlite3541_provider_process_current()||physical_api_creator!=database_native_process())return false;
    store_provider_native_original* actual=nullptr;
    try {
        actual=new store_provider_native_original;
        if(owner.creator_!=database_native_process())return false; // child abandons inherited allocation
        std::lock_guard lock(physical_api_leaf);
        actual->next=legacy_head_;legacy_head_=actual;actual->listed=true;
        owner.provider_legacy_=actual;return true;
    }catch(...){if(owner.creator_==database_native_process())delete actual;throw;}
}
bool store_physical_api::provider_native_entered_(const lattice_sqlite3541_provider_request& request)noexcept {
    if(request.instance!=lattice_sqlite3541_provider_instance()||!request.creator||request.creator!=database_native_process()||
       physical_api_creator!=request.creator||!request.physical_original)return false;
    if(request.source==3) {
        if(auto* observation=legacy_preentry_observation_) {
            ++observation->reached;if(observation->refuse)return false;
        }
        return true; // actual legacy API scope, no physical/Source guard grant
    }
    if(request.source!=1&&request.source!=2)return false;
    const auto& owner=*static_cast<const store_physical_open_original*>(request.physical_original);
    if(owner.provider_instance_!=request.instance||owner.creator_!=request.creator||!owner.bound_||
       owner.legacy_||owner.native_retired_||owner.actual_||!owner.original_)return false;
    auto* actual=static_cast<original*>(owner.original_);
    if(actual->creator!=request.creator||!actual->held.current()||actual->actual)return false;
    store_physical_lifetime::native_open_entered_(actual->held);
    if(actual->initialization_native_entered)*actual->initialization_native_entered=true;
    return true;
}
std::exception_ptr store_physical_api::provider_open_failure_(const original* actual)noexcept {
    if(physical_api_creator!=database_native_process()||!actual||actual->creator!=database_native_process())return {};
    return actual->provider_open_failure;
}
bool store_physical_api::provider_open_current_(const lattice_sqlite3541_provider_request& request,
    std::chrono::steady_clock::time_point end)noexcept {
    // Called only by this provider's genuine one-use source. Fence before any
    // opaque Core owner/account/original payload, lock or shared DATA access.
    if(request.instance!=lattice_sqlite3541_provider_instance()||!request.creator||
       request.creator!=database_native_process()||physical_api_creator!=request.creator||
       !lattice_sqlite3541_provider_process_current()||!request.physical_original||
       end==std::chrono::steady_clock::time_point::max()||std::chrono::steady_clock::now()>=end)return false;
    try {
        if(request.source==3) {
            if(request.core_owner||request.core_open||request.account_original)return false;
            const auto& actual=*static_cast<const store_provider_native_original*>(request.physical_original);
            std::lock_guard lock(physical_api_leaf);
            return actual.instance==request.instance&&actual.creator==request.creator&&actual.listed&&
                !actual.owner_returned&&!actual.retired&&!actual.actual;
        }
        if(request.source!=1&&request.source!=2)return false;
        const auto& actual=*static_cast<const store_physical_open_original*>(request.physical_original);
        if(actual.provider_instance_!=request.instance||actual.creator_!=request.creator||!actual.bound_||actual.legacy_||
           actual.native_retired_||actual.actual_||actual.provider_legacy_||!actual.original_)return false;
        auto* issued=static_cast<original*>(actual.original_);
        if(issued->creator!=request.creator||!issued->primary||!issued->held.current()||issued->actual||
           issued->completion!=&store_physical_vfs::complete_||!issued->completion_cookie)return false;
        const auto* physical=static_cast<const store_physical_vfs*>(issued->completion_cookie);
        if(!physical->current_()||physical->root_!=physical||physical->original_!=issued)return false;
        if(request.source==2)return !request.core_owner&&!request.core_open&&!request.account_original;
        if(!request.core_owner||!request.core_open||!request.account_original||!issued->initialization_budget||
           issued->initialization_budget.get()!=request.account_original)return false;
        const auto& owner=*static_cast<const database*>(request.core_owner);
        const auto& open=*static_cast<const observer_delivery_open_startup*>(request.core_open);
        auto* account=static_cast<const database_initialization_budget*>(request.account_original);
        account->require_current_();
        const auto& expected=open.preopen_account_(const_cast<database&>(owner),physical->path_,end);
        return (!expected||expected.get()==account)&&open.original_deadline_()==end;
    }catch(...) {
        // Capture only in the actual creator, before ANY further health check.
        // The real first exception is returned to the owning C++ open producer;
        // no exception may unwind through SQLite C frames.
        if(request.creator!=database_native_process()||request.instance!=lattice_sqlite3541_provider_instance())return false;
        const auto primary=std::current_exception();
        if(request.source==3) {
            auto* actual=const_cast<store_provider_native_original*>(static_cast<const store_provider_native_original*>(request.physical_original));
            if(actual&&actual->creator==request.creator&&!actual->open_failure)actual->open_failure=primary;
        }else if(request.source==1||request.source==2) {
            const auto* owner=static_cast<const store_physical_open_original*>(request.physical_original);
            if(owner&&owner->creator_==request.creator&&owner->original_) {
                auto* actual=static_cast<original*>(owner->original_);
                if(actual->creator==request.creator&&!actual->provider_open_failure)actual->provider_open_failure=primary;
            }
            if(request.source==1&&request.core_open)
                static_cast<const observer_delivery_open_startup*>(request.core_open)->fail_initialization_();
        }
        return false;
    }
}

store_physical_api::registration_scope::registration_scope(database& owner,const observer_delivery_open_startup& open,unsigned family)
    :creator_(database_native_process()),owner_(&owner),open_(&open) {
    using namespace sqlite_provider::v1;
    owner.require_creator_();open.require_initializing_(owner);
    const auto& actual=owner.physical_open_original_;
    if(actual.provider_instance_!=lattice_sqlite3541_provider_instance()||actual.creator_!=creator_||
       physical_api_creator!=creator_||!actual.bound_||actual.legacy_||actual.native_retired_||
       actual.actual_!=owner.db_||!actual.original_)throw error(rejection::invalid_original);
    auto held=capture_open_(actual,owner.db_);
    if(held.inherited||!held.value||held.value!=actual.original_)throw error(rejection::invalid_original);
    const auto& provider=held.value->provider_native;
    const auto& account=open.initialization_budget_(owner);
    if(!account)throw error(rejection::invalid_original);account->require_current_();
    account_=account.get();
    if(provider.source_!=1||provider.owner_!=&owner||provider.open_!=&open||provider.physical_!=&actual||
       !account||provider.account_!=account.get()||!provider.borrow_current_())throw error(rejection::invalid_original);
    lattice_sqlite3541_provider_fact expected{};
    expected.instance=provider.instance_;expected.creator=provider.creator_;expected.serial=provider.serial_;
    expected.core_owner=provider.owner_;expected.core_open=provider.open_;expected.physical_original=provider.physical_;
    expected.account_original=provider.account_;expected.vfs=&provider.vfs_->record_;
    expected.source=provider.source_;expected.connection_original=&provider;
    if(!lattice_sqlite3541_provider_registration_begin(&batch_,owner.db_,&expected,family,this,&current_)) {
        rethrow_failure_();throw error(rejection::invalid_original);
    }
}
int store_physical_api::registration_scope::current_(void* opaque)noexcept {
    auto* self=static_cast<registration_scope*>(opaque);
    if(!self||self->creator_!=database_native_process())return 0;
    try {
        auto& owner=*self->owner_;const auto& open=*self->open_;
        owner.require_creator_();open.require_initializing_(owner);
        const auto& account=open.initialization_budget_(owner);
        if(!account||(self->account_&&self->account_!=account.get()))
            throw sqlite_provider::v1::error(sqlite_provider::v1::rejection::invalid_original);
        account->require_current_();
        const auto& actual=owner.physical_open_original_;
        if(self->batch_.active&&(self->batch_.expected.core_owner!=&owner||self->batch_.expected.core_open!=&open||
           self->batch_.expected.physical_original!=&actual||self->batch_.expected.account_original!=account.get()||
           self->batch_.actual!=owner.db_))throw sqlite_provider::v1::error(sqlite_provider::v1::rejection::invalid_original);
        return 1;
    }catch(...) {
        // Capture before any throwing health check; actual same-process DATA
        // only. Nothing crosses the SQLite C frame as a C++ exception.
        if(self->creator_!=database_native_process())return 0;
        const auto primary=std::current_exception();
        auto& retained=self->primary_.get<0>();if(!retained)retained=primary;
        self->open_->fail_initialization_();return 0;
    }
}
void store_physical_api::registration_scope::rethrow_failure_() {
    if(creator_!=database_native_process())throw sqlite_provider::v1::error(sqlite_provider::v1::rejection::inherited_original);
    if(const auto primary=primary_.get<0>())std::rethrow_exception(primary);
}
store_physical_api::registration_scope::~registration_scope()noexcept {
    // Never inspect TLS, lock, unlock or destroy Native-bearing inherited DATA.
    if(creator_!=database_native_process())return;
    if(!finished_)lattice_sqlite3541_provider_registration_end(&batch_,0);
}
int store_physical_api::registration_scope::function_(unsigned slot,const char* name,int args,int flags,void* userdata,
    void(*function)(lattice_sqlite3541_context*,int,lattice_sqlite3541_value**),void(*destroy)(void*),bool* entered) {
    using namespace sqlite_provider::v1;
    if(entered)*entered=false;
    if(creator_!=database_native_process())throw error(rejection::inherited_original);
    bool called=false;int rc=LATTICE_SQLITE3541_OK;
    try {
        if(finished_)throw error(rejection::consumed_original);
        auto actual=capture_(batch_.actual);
        if(actual.inherited)throw error(rejection::inherited_original);
        api_scope returned(actual);
        if(!returned.entered())throw error(rejection::invalid_original);
        called=lattice_sqlite3541_provider_registration_function(&batch_,slot,batch_.actual,name,args,flags,userdata,function,destroy,&rc)!=0;
        if(entered)*entered=called;
        if(creator_!=database_native_process())throw error(rejection::inherited_original);
        if(called&&batch_.family==4)
            account_->note_api_error_(rc,false);
        if(!called){rethrow_failure_();throw error(rejection::invalid_original);}
        if(rc==LATTICE_SQLITE3541_OK)rethrow_failure_();
        return rc; // genuine actual create_function_v2 return, never policy code
    }catch(...) {
        // v2 consumes userdata exactly once. Same-creator pre-Native refusal
        // retains the original wrapper's explicit destruction policy.
        if(!called&&destroy&&creator_==database_native_process()&&creator_==physical_api_creator)destroy(userdata);
        throw;
    }
}
int store_physical_api::registration_scope::authorizer_(
    int(*call)(void*,int,const char*,const char*,const char*,const char*)noexcept,void* context) {
    using namespace sqlite_provider::v1;
    if(creator_!=database_native_process())throw error(rejection::inherited_original);
    if(finished_||batch_.family!=4)throw error(rejection::consumed_original);
    if(!current_(this)){rethrow_failure_();throw error(rejection::invalid_original);}
    bool called=false;
    const int rc=database_sql_dispatcher::bind_impl_(*owner_,database_authorizer_slot::local_producer,
        call,context,&batch_,&called);
    if(creator_!=database_native_process())throw error(rejection::inherited_original);
    if(called)account_->note_api_error_(rc,false);
    if(!called){rethrow_failure_();throw error(rejection::invalid_original);}
    if(rc==LATTICE_SQLITE3541_OK)rethrow_failure_();
    return rc;
}
void store_physical_api::registration_scope::finish_() {
    using namespace sqlite_provider::v1;
    if(creator_!=database_native_process())throw error(rejection::inherited_original);
    if(finished_)throw error(rejection::consumed_original);
    const bool complete=lattice_sqlite3541_provider_registration_end(&batch_,1)!=0;finished_=true;
    if(!complete){rethrow_failure_();throw error(rejection::invalid_original);}
}

void store_physical_api::require_provider_registrations_(const store_physical_open_original& actual,
    const database& owner,const observer_delivery_open_startup& open) {
    using namespace sqlite_provider::v1;
    if(actual.provider_instance_!=lattice_sqlite3541_provider_instance()||actual.creator_!=database_native_process()||
       physical_api_creator!=database_native_process()||!actual.bound_||actual.legacy_||actual.native_retired_||
       actual.actual_!=owner.db_||!actual.original_)throw error(rejection::invalid_original);
    auto held=capture_open_(actual,owner.db_);
    if(held.inherited||!held.value||held.value!=actual.original_)throw error(rejection::invalid_original);
    const auto& provider=held.value->provider_native;
    const auto& account=open.initialization_budget_(owner);
    if(provider.source_!=1||provider.owner_!=&owner||provider.open_!=&open||provider.physical_!=&actual||
       !account||provider.account_!=account.get()||!provider.registrations_current_())
        throw error(rejection::invalid_original);
}
void store_physical_api::require_producer_registrations_(const database& owner,
    const observer_delivery_open_startup& open,
    int(*call)(void*,int,const char*,const char*,const char*,const char*)noexcept,void* context) {
    using namespace sqlite_provider::v1;
    owner.require_creator_();open.require_initializing_(owner);
    const auto& account=open.initialization_budget_(owner);
    if(!account)throw error(rejection::invalid_original);
    account->require_current_();
    database::catalog_native_admission_ admitted(owner);
    require_producer_receipt_(owner,open,*account,call,context);
}
void store_physical_api::require_completed_producer_registrations_(const database& owner,
    const observer_delivery_open_startup& open,
    int(*call)(void*,int,const char*,const char*,const char*,const char*)noexcept,void* context) {
    using namespace sqlite_provider::v1;
    owner.require_creator_();
    // A separate completed-phase DATA validator supplies the very same
    // still-current setup budget; pending startup never enters this route.
    const auto& account=open.completed_registration_account_(owner);
    if(!account)throw error(rejection::invalid_original);
    account->require_current_();
    // Called before the owner's publication mutex. The actual seal and
    // producer receipt are observed under one genuine current Native leaf.
    database::catalog_native_admission_ admitted(owner);
    if(!owner.observer_delivery_sql_||!owner.observer_delivery_sql_->sealed_original_for_(owner,open))
        throw error(rejection::invalid_original);
    require_producer_receipt_(owner,open,*account,call,context);
}
void store_physical_api::require_producer_receipt_(const database& owner,
    const observer_delivery_open_startup& open,const database_initialization_budget& account,
    int(*call)(void*,int,const char*,const char*,const char*,const char*)noexcept,void* context) {
    using namespace sqlite_provider::v1;
    owner.require_creator_();account.require_current_();
    const auto& actual=owner.physical_open_original_;
    if(actual.provider_instance_!=lattice_sqlite3541_provider_instance()||actual.creator_!=database_native_process()||
       physical_api_creator!=database_native_process()||!actual.bound_||actual.legacy_||actual.native_retired_||
       actual.actual_!=owner.db_||!actual.original_)throw error(rejection::invalid_original);
    auto held=capture_open_(actual,owner.db_);
    if(held.inherited||!held.value||held.value!=actual.original_)throw error(rejection::invalid_original);
    api_scope returned(held);
    if(!returned.entered())throw error(rejection::invalid_original);
    const auto& provider=held.value->provider_native;
    if(provider.source_!=1||provider.owner_!=&owner||provider.open_!=&open||provider.physical_!=&actual||
       provider.account_!=&account||!provider.registrations_current_())throw error(rejection::invalid_original);
    lattice_sqlite3541_provider_fact expected{};
    expected.instance=provider.instance_;expected.creator=provider.creator_;expected.serial=provider.serial_;
    expected.core_owner=provider.owner_;expected.core_open=provider.open_;expected.physical_original=provider.physical_;
    expected.account_original=provider.account_;expected.vfs=&provider.vfs_->record_;
    expected.source=provider.source_;expected.connection_original=&provider;
    auto* cookie=owner.sql_dispatcher_.load(std::memory_order_acquire);
    if(!call||!context||!cookie||cookie->creator_!=database_native_process()||cookie->native_!=owner.db_)
        throw error(rejection::invalid_original);
    auto* mutex=lattice_sqlite3541_db_mutex(owner.db_);
    if(!mutex)throw error(rejection::invalid_original);
    lattice_sqlite3541_mutex_enter(mutex);
    struct unlock {lattice_sqlite3541_mutex* mutex;std::uint64_t creator;
        ~unlock(){if(creator==database_native_process())lattice_sqlite3541_mutex_leave(mutex);}
    } locked{mutex,database_native_process()};
    const auto& slot=cookie->slots_[std::size_t(database_authorizer_slot::local_producer)];
    if(!cookie->active_.load(std::memory_order_acquire)||cookie->in_callback_||
       cookie->publication_failure_!=LATTICE_SQLITE3541_OK||cookie->expiration_failure_!=LATTICE_SQLITE3541_OK||
       slot.call!=call||slot.context!=context||
       !lattice_sqlite3541_provider_producer_receipt(owner.db_,&expected,database_sql_dispatcher::authorize,cookie))
        throw error(rejection::invalid_original);
    account.require_current_();
}
void store_physical_api::claim_provider_vfs_storage_(
    const std::shared_ptr<database_initialization_budget>& actual,std::size_t bytes) {
    if(actual)actual->claim_workspace_(bytes); // exact sizeof at actual issuer, before allocation
}
bool store_physical_api::provider_native_ending_known_(const store_physical_open_original& owner)noexcept {
    if(owner.provider_instance_!=lattice_sqlite3541_provider_instance()||owner.creator_!=database_native_process()||
       physical_api_creator!=database_native_process())return false;
    if(owner.provider_legacy_) {
        const auto* actual=static_cast<const store_provider_native_original*>(owner.provider_legacy_);
        return actual->creator==database_native_process()&&actual->native.native_ending_known_();
    }
    if(owner.original_) {
        const auto* actual=static_cast<const original*>(owner.original_);
        return actual->creator==database_native_process()&&actual->provider_native.native_ending_known_();
    }
    return false;
}

std::shared_ptr<database_initialization_budget> store_physical_api::protected_account_for_return_(
    database& owner,const observer_delivery_open_startup& open) {
    using namespace sqlite_provider::v1;
    owner.require_creator_();
    if(!open.creator_current_()||foreign_protected_()||owner.delivery_startup_.get()!=&open||
       !owner.delivery_initialization_open_current_(&open)||owner.raw_handle_escaped_.load(std::memory_order_acquire))
        throw error(rejection::invalid_original);
    const auto& outer=owner.physical_open_original_;
    if(outer.provider_instance_!=lattice_sqlite3541_provider_instance()||outer.creator_!=database_native_process()||
       !outer.bound_||outer.legacy_||outer.exclusive_target_||outer.native_retired_||
       outer.actual_!=owner.db_||!outer.original_||outer.provider_legacy_)
        throw error(rejection::invalid_original);
    // Actual bound primary only. This ticket pins the real returned physical
    // carrier; it never obtains another original from a reused Native address.
    auto held=capture_open_(outer,owner.db_);
    if(held.inherited||held.count!=1||!held.value||held.value!=outer.original_||
       !held.value->primary||!actual_owner_(held)||held.value->actual!=owner.db_)
        throw error(rejection::invalid_original);
    const auto& actual=held.value->provider_native;
    if(actual.instance_!=lattice_sqlite3541_provider_instance()||actual.creator_!=database_native_process()||
       actual.source_!=1||actual.owner_!=&owner||actual.open_!=&open||actual.physical_!=&outer||
       !actual.attempted_||!actual.native_entered_||actual.actual_!=owner.db_||!actual.account_||
       !actual.borrow_current_()||!held.value->initialization_budget||
       held.value->initialization_budget.get()!=actual.account_)
        throw error(rejection::invalid_original);
    auto account=held.value->initialization_budget; // SAME control/object, no owning clone/allocation
    account->require_current_();
    if(account->deadline_()!=open.original_deadline_())throw error(rejection::invalid_original);
    return account; // DATA only; closed adopter and opened_ still enforce their own one-use/role rules
}

bool store_physical_api::provider_open_unentered_(const original* actual,const store_physical_open_original& owner)noexcept {
    if(!actual||owner.provider_instance_!=lattice_sqlite3541_provider_instance()||
       owner.creator_!=database_native_process()||physical_api_creator!=database_native_process()||
       !owner.bound_||owner.legacy_||owner.native_retired_||owner.actual_||owner.original_!=actual||
       actual->creator!=database_native_process()||!actual->primary||actual->listed||actual->current||actual->actual||
       actual->completion_claimed||actual->completion_returned||actual->provider_native.native_entered_||
       actual->provider_native.actual_||(actual->initialization_native_entered&&*actual->initialization_native_entered)||
       managed_return_here_())return false;
    return store_physical_lifetime::native_open_unentered_(actual->held);
}
bool store_physical_api::complete_provider_unentered_(original* actual,store_physical_open_original& owner)noexcept {
    if(!provider_open_unentered_(actual,owner)||actual->completion!=&store_physical_vfs::complete_||!actual->completion_cookie)return false;
    auto* vfs=static_cast<store_physical_vfs*>(actual->completion_cookie);
    // The real same VFS producer has ACTUALLY returned successful unregister.
    // A false bool, absent name or later pointer is never a replacement receipt.
    const auto& registration=vfs->provider_vfs_original_();
    if(vfs->creator_!=database_native_process()||vfs->root_!=vfs||vfs->original_!=actual||vfs->registered_||
       registration.instance_!=lattice_sqlite3541_provider_instance()||registration.creator_!=database_native_process()||
       registration.phase_!=sqlite_provider::v1::vfs_original::phase::retired||registration.registry_listed_||registration.selections_)return false;
    try{std::lock_guard lock(physical_api_leaf);
        if(actual->listed||actual->completion_claimed||actual->completion_returned||actual->references<3||owner.original_!=actual)return false;
        // Exchange only the real builder + owning-wrapper references. Retained
        // DATA/ticket references remain valid until their real later return.
        actual->completion_claimed=true;actual->completion_returned=true;
        actual->completion=nullptr;actual->completion_cookie=nullptr;
        actual->references-=2;owner.original_=nullptr;owner.native_retired_=true;
        actual->provider_native.retired_=true; // canceled source, NOT a Native free/close fact
        return true;
    }catch(...){return false;}
}

std::exception_ptr store_physical_api::provider_close_failure_(const store_physical_open_original& owner)noexcept {
    if(owner.provider_instance_!=lattice_sqlite3541_provider_instance()||owner.creator_!=database_native_process()||
       physical_api_creator!=database_native_process())return {};
    if(owner.provider_legacy_) {
        auto* actual=static_cast<store_provider_native_original*>(owner.provider_legacy_);
        if(actual->creator==database_native_process())return actual->close_failure;
    }else if(owner.original_) {
        auto* actual=static_cast<original*>(owner.original_);
        if(actual->creator==database_native_process())return actual->provider_close_failure;
    }
    return {};
}
int store_physical_api::open_provider_(original* issued,store_physical_open_original& owner,
    const sqlite_provider::v1::vfs_original& vfs,const char* file,lattice_sqlite3541_connection** returned,int flags,
    std::chrono::steady_clock::time_point end,database* prospective_owner,const observer_delivery_open_startup* prospective_open,
    const std::shared_ptr<database_initialization_budget>& account) {
    using namespace sqlite_provider::v1;
    if(!issued||owner.provider_instance_!=lattice_sqlite3541_provider_instance()||owner.creator_!=database_native_process()||
       !owner.bound_||owner.legacy_||owner.original_!=issued||owner.actual_||owner.native_retired_||
       issued->creator!=database_native_process()||!issued->primary||!issued->held.current()||issued->actual||
       !returned||!file||bool(prospective_owner)!=bool(prospective_open)||bool(prospective_open)!=bool(account))
        throw error(rejection::invalid_original);
    if(prospective_open) {
        account->require_current_();
        const auto& prior=prospective_open->preopen_account_(*prospective_owner,file,end);
        if(prior&&prior!=account)throw error(rejection::invalid_original);
        if(issued->initialization_budget&&issued->initialization_budget!=account)
            throw error(rejection::invalid_original);
        issued->initialization_budget=account; // SAME pre-Native DATA liability retained through actual ending
        open_original source(*prospective_owner,*prospective_open,owner,*account,vfs,end);
        source.core_current_=&provider_open_current_;source.core_entered_=&provider_native_entered_;
        int rc;
        try{rc=connection_original::open_native_into_(source,issued->provider_native,file,flags);}
        catch(...){if(owner.creator_==database_native_process()&&issued->provider_open_failure)
            std::rethrow_exception(issued->provider_open_failure);throw;}
        if(owner.creator_!=database_native_process())throw error(rejection::inherited_original);
        *returned=static_cast<lattice_sqlite3541_connection*>(issued->provider_native.actual_);return rc;
    }
    open_original source(owner,vfs,end); // resource-only: no Open/account/profile receipt
    source.core_current_=&provider_open_current_;source.core_entered_=&provider_native_entered_;
    int rc;
    try{rc=connection_original::open_native_into_(source,issued->provider_native,file,flags);}
    catch(...){if(owner.creator_==database_native_process()&&issued->provider_open_failure)
        std::rethrow_exception(issued->provider_open_failure);throw;}
    if(owner.creator_!=database_native_process())throw error(rejection::inherited_original);
    *returned=static_cast<lattice_sqlite3541_connection*>(issued->provider_native.actual_);return rc;
}
int store_physical_api::open_exclusive_provider_(store_physical_open_original& owner,const char* file,
    lattice_sqlite3541_connection** returned,int flags,const char* vfs,std::chrono::steady_clock::time_point end) {
    if(owner.creator_!=database_native_process()||!owner.bound_||!owner.exclusive_target_||!owner.exclusive_open_attempted_||
       owner.original_||owner.legacy_||owner.native_retired_||owner.actual_||!returned||!vfs)
        throw sqlite_provider::v1::error(sqlite_provider::v1::rejection::invalid_original);
    const auto selected=sqlite_provider::v1::vfs_original::select_(vfs);
    if(!prepare_legacy_(owner))throw sqlite_provider::v1::error(sqlite_provider::v1::rejection::invalid_original);
    owner.provider_instance_=lattice_sqlite3541_provider_instance();
    return open_legacy_(owner,file,returned,flags,*selected.actual_,end);
}
int store_physical_api::open_legacy_(store_physical_open_original& owner,const char* file,
    lattice_sqlite3541_connection** returned,int flags,const sqlite_provider::v1::vfs_original& vfs,
    std::chrono::steady_clock::time_point end) {
    using namespace sqlite_provider::v1;
    if(owner.provider_instance_!=lattice_sqlite3541_provider_instance()||owner.creator_!=database_native_process()||
       !owner.bound_||!owner.provider_legacy_||!returned||!file||owner.actual_||owner.native_retired_||
       (!owner.legacy_&&!owner.exclusive_target_))throw error(rejection::invalid_original);
    auto& actual=*static_cast<store_provider_native_original*>(owner.provider_legacy_);
    if(actual.creator!=database_native_process()||actual.instance!=owner.provider_instance_||
       actual.owner_returned||actual.actual||!actual.listed)throw error(rejection::invalid_original);
    open_original source(actual,vfs,end); // exact allocation owner, never a physical/Open/account surrogate
    source.core_current_=&provider_open_current_;source.core_entered_=&provider_native_entered_;
    api_scope returned_scope;if(!returned_scope.entered())throw error(rejection::invalid_original);
    int rc;
    try{rc=connection_original::open_native_into_(source,actual.native,file,flags);}
    catch(...){if(owner.creator_==database_native_process()&&actual.open_failure)
        std::rethrow_exception(actual.open_failure);throw;}
    if(owner.creator_!=database_native_process())throw error(rejection::inherited_original);
    actual.actual=static_cast<lattice_sqlite3541_connection*>(actual.native.actual_);*returned=actual.actual;
    // Bind the genuine partial/null return BEFORE propagating a real C-guard
    // primary, so the existing owner can still perform its exact cleanup.
    if(owner.exclusive_target_)owner.actual_=actual.actual;
    else if(!open_returned_(owner,nullptr,actual.actual))throw error(rejection::invalid_original);
    if(actual.open_failure)std::rethrow_exception(actual.open_failure);
    return rc;
}
void store_physical_api::release_legacy_(store_physical_open_original& owner)noexcept {
    if(owner.creator_!=database_native_process()||physical_api_creator!=database_native_process())return;
    auto* actual=static_cast<store_provider_native_original*>(std::exchange(owner.provider_legacy_,nullptr));
    if(!actual)return;
    try {
        {std::lock_guard lock(physical_api_leaf);
         if(actual->creator!=database_native_process()||actual->owner_returned||!actual->references)return;
         actual->owner_returned=true;--actual->references;}
        drain_legacy_();
    }catch(...){/* Preserve actual reference/ending debt. */}
}
void store_physical_api::drain_legacy_()noexcept {
    if(physical_api_creator!=database_native_process()||draining_tails_||managed_return_here_())return;
    // A single fixed DATA record is detached under the leaf; destruction is
    // outside it. An unended zombie stays retained, even after owner return.
    for(;;) {
        store_provider_native_original* retired=nullptr;
        try {
            {std::lock_guard lock(physical_api_leaf);
             auto** at=&legacy_head_;
             while(*at){auto* value=*at;
                 if(value->creator!=database_native_process())return;
                 // Do not inspect a live caller's plain recipient fields.
                 // Actual owner return and zero caller references are decided
                 // under this SAME Core DATA leaf before every ending read.
                 if(value->owner_returned&&!value->references){
                     const bool ended=!value->native.attempted_||value->native.native_ending_known_()||
                         value->native.no_native_object_for_(*value);
                     if(ended){
                         *at=value->next;value->next=nullptr;value->listed=false;retired=value;break;
                     }
                 }
                 at=&value->next;
             }}
            if(!retired)return;
            if(returned_tail_observation_)++returned_tail_observation_->legacy_destroyed;
            delete retired; // actual Native free OR distinct proved no-Native-object absence
        }catch(...){return;}
    }
}
void store_physical_api::provider_legacy_call_(const void* source,std::uint64_t creator,
    lattice_sqlite3541_connection* actual,bool ending,void(*work)(void*),void* borrowed) {
    using namespace sqlite_provider::v1;
    if(!source||!creator||creator!=database_native_process()||physical_api_creator!=creator||!actual||!work||
       !lattice_sqlite3541_provider_process_current())throw error(rejection::invalid_original);
    auto* original=const_cast<store_provider_native_original*>(static_cast<const store_provider_native_original*>(source));
    {std::lock_guard lock(physical_api_leaf);
     if(original->instance!=lattice_sqlite3541_provider_instance()||original->creator!=creator||!original->listed||
        original->actual!=actual||(!ending&&(original->retired||original->owner_returned))||
        original->native.native_ending_known_()||original->references==UINT64_MAX)
         throw error(rejection::invalid_original);
     ++original->references;}
    struct pin final {
        store_provider_native_original* actual;
        ~pin()noexcept {
            if(physical_api_creator!=database_native_process())return;
            try{{std::lock_guard lock(physical_api_leaf);if(actual->references)--actual->references;}
                store_physical_api::returned_tail();}catch(...){/* retain debt */}
        }
    } held{original};
    store_physical_native_scope native;
    ticket entered;entered.creator=creator;
    enter_captured_native_(std::move(entered),native);
    if(!native.entered())throw error(rejection::invalid_original);
    api_scope returned;if(!returned.entered())throw error(rejection::invalid_original);
    work(borrowed);
}
bool store_physical_api::open_returned_(store_physical_open_original& owner,original* issued,lattice_sqlite3541_connection* native)noexcept {
    if(!owner.bound_||owner.creator_!=database_native_process()||foreign_protected_()||owner.actual_||
       owner.native_retired_||owner.original_!=issued||owner.legacy_!=(issued==nullptr))return false;
    owner.actual_=native;return true;
}
store_physical_api::ticket store_physical_api::capture_cleanup_(const store_physical_open_original& owner,lattice_sqlite3541_connection* native)noexcept {
    ticket result;result.creator=database_native_process();
    if(owner.creator_!=result.creator||foreign_protected_()||!owner.bound_||owner.native_retired_||
       owner.actual_!=native||!native){result.inherited=true;return result;}
    // Exact target provenance grants only its existing closed caller route;
    // no normal lifetime pin, policy token or generic completion is invented.
    if(owner.exclusive_target_&&owner.exclusive_open_attempted_&&!owner.original_&&!owner.legacy_)return result;
    if(owner.legacy_&&!owner.original_)return result;
    auto* primary=static_cast<original*>(owner.original_);
    if(!primary||primary->creator!=result.creator||!primary->primary){result.inherited=true;return result;}
    try{std::lock_guard lock(physical_api_leaf);
        if(primary->listed){
            if(!primary->current||primary->actual!=native){result.inherited=true;return result;}
            std::size_t count=0;
            for(auto* at=head_;at;at=at->next)if(at->current&&at->actual==native){
                if(at->references==UINT64_MAX||count==maximum_originals){result.inherited=true;return result;}++count;}
            for(auto* at=head_;at;at=at->next)if(at->current&&at->actual==native){
                ++at->references;result.values[result.count++]=at;}
        }else{
            // A failed publication never selects another current row. It may
            // only clean this actual preadmitted partial-open producer. Its
            // unknown registration debt still retains the lease/capsule.
            if(primary->completion_claimed||primary->completion_returned||primary->references==UINT64_MAX){result.inherited=true;return result;}
            ++primary->references;result.values[0]=primary;result.count=1;
        }
        result.value=primary;
    }catch(...){result.inherited=true;}
    return result;
}
void store_physical_api::capture_policy_(const store_physical_open_original& owner,store_physical_policy_original& token)noexcept {
    if(token.original_||token.creator_!=database_native_process()||owner.creator_!=database_native_process())return;
    // Actual bound primary provenance, not a new current-address lookup. A
    // later closed/superseded/legacy original cannot activate a new policy.
    auto current=capture_open_(owner,owner.actual_);
    if(current.inherited||!current.value||!current.value->primary)return;
    auto retained=capture_issued_(current.value);if(retained.inherited||!retained.value)return;
    token.original_=retained.value;retained.count=0;retained.value=nullptr;
}
void store_physical_api::release_policy_(store_physical_policy_original& token)noexcept {
    auto* actual=static_cast<original*>(std::exchange(token.original_,nullptr));
    if(!actual||token.creator_!=database_native_process()||physical_api_creator!=database_native_process())return;
    bool retire=false;
    try{
        {std::lock_guard lock(physical_api_leaf);
         if(!actual->references)return; // Retain malformed-reference debt.
         --actual->references;
         if(!actual->references&&actual->completion_returned){
             // Replace the final reference with this ONE original-owned tail.
             actual->references=1;actual->returned=original::returned_action::destroy;retire=true;
         }}
        if(retire)handoff_returned_tail_(actual);
    }catch(...){/* Preserve DATA reference debt; never manufacture ending. */}
}
bool store_physical_api::observer_policy_unsettled_(const store_physical_policy_original& token)noexcept {
    if(token.creator_!=database_native_process()||foreign_protected_())return true;
    const auto* actual=static_cast<original*>(token.original_);
    return !actual||actual->creator!=database_native_process()||store_physical_lifetime::observer_policy_unsettled_(actual->held);
}
void store_physical_api::note_observer_policy_unsettled_(const store_physical_policy_original& token)noexcept {
    if(token.creator_!=database_native_process()||foreign_protected_())return;
    const auto* actual=static_cast<original*>(token.original_);
    if(actual&&actual->creator==database_native_process())store_physical_lifetime::note_observer_policy_unsettled_(actual->held);
}
void store_physical_api::release_open_(store_physical_open_original& owner)noexcept {
    auto* original=static_cast<store_physical_api::original*>(std::exchange(owner.original_,nullptr));
    if(owner.creator_!=database_native_process())return;
    release_original_(original,owner.creator_);
    release_legacy_(owner);
}
store_physical_api::ticket store_physical_api::capture_open_(const store_physical_open_original& owner,lattice_sqlite3541_connection* native)noexcept {
    ticket result;result.creator=database_native_process();
    if(owner.creator_!=result.creator||foreign_protected_()){result.inherited=true;return result;}
    // A deferred target shell has no actual SQLite handle. This grants no
    // Native access; every nonnull connection requires its real bound receipt.
    if(!owner.bound_&&!native)return result;
    if(!owner.bound_||owner.native_retired_||owner.actual_!=native){result.inherited=true;return result;}
    if(owner.exclusive_target_&&owner.exclusive_open_attempted_&&native&&!owner.original_&&!owner.legacy_)return result;
    if(owner.legacy_&&!owner.original_)return result;
    auto* primary=static_cast<original*>(owner.original_);
    if(!primary||primary->creator!=result.creator){result.inherited=true;return result;}
    try{std::lock_guard lock(physical_api_leaf);
        // Missing/ended/superseded OWN original never falls back to legacy.
        if(!primary->primary||!primary->listed||!primary->current||primary->actual!=native){result.inherited=true;return result;}
        std::size_t count=0;
        for(auto* at=head_;at;at=at->next)if(at->current&&at->actual==native){
            if(at->references==UINT64_MAX||count==maximum_originals){result.inherited=true;return result;}++count;
        }
        for(auto* at=head_;at;at=at->next)if(at->current&&at->actual==native){
            ++at->references;result.values[result.count++]=at;
        }
        result.value=primary;
    }catch(...){result.inherited=true;}
    return result;
}
bool store_physical_api::native_custody_here_(original* actual)noexcept {
    if(!actual||actual->creator!=database_native_process())return false;
    for(auto* frame=store_physical_native_scope::current_;frame;frame=frame->previous_){
        if(frame->creator_!=database_native_process())return false;
        if(!frame->entered_)continue;
        for(std::size_t i=0;i<frame->count_;++i)
            if((frame->entered_mask_&(std::uint64_t(1)<<i))&&frame->originals_[i]==actual)return true;
    }
    return false;
}
bool store_physical_api::native_continuation_(original* actual)noexcept {
    if(!actual||actual->creator!=database_native_process())return false;
    for(auto* frame=store_physical_native_scope::current_;frame;frame=frame->previous_){
        if(frame->creator_!=database_native_process())return false;
        if(!frame->entered_||frame->cleanup_only_)continue; // cleanup/refused frames lend no SQL admission
        for(std::size_t i=0;i<frame->count_;++i)
            if((frame->entered_mask_&(std::uint64_t(1)<<i))&&frame->originals_[i]==actual)return true;
    }
    return false;
}
bool store_physical_api::seal_open_(const store_physical_open_original& owner,std::chrono::steady_clock::time_point end)noexcept {
    if(!owner.bound_||owner.legacy_||owner.creator_!=database_native_process()||foreign_protected_())return false;
    auto* actual=static_cast<original*>(owner.original_);
    if(!actual||actual->creator!=database_native_process()||native_custody_here_(actual))return false;
    // This is admission quiescence DATA ONLY, not physical close or unlink.
    return store_physical_lifetime::seal_native_and_wait_(actual->held,end);
}
bool store_physical_api::observer_policy_unsettled_(const store_physical_open_original& owner)noexcept {
    if(!owner.bound_||owner.legacy_||owner.creator_!=database_native_process()||foreign_protected_())return true;
    const auto* original=static_cast<store_physical_api::original*>(owner.original_);
    return !original||original->creator!=database_native_process()||
        store_physical_lifetime::observer_policy_unsettled_(original->held);
}
void store_physical_api::note_observer_policy_unsettled_(const store_physical_open_original& owner)noexcept {
    if(!owner.bound_||owner.legacy_||owner.creator_!=database_native_process()||foreign_protected_())return;
    const auto* original=static_cast<store_physical_api::original*>(owner.original_);
    if(original&&original->creator==database_native_process())store_physical_lifetime::note_observer_policy_unsettled_(original->held);
}
void store_physical_api::enter_captured_native_(ticket&& actual,store_physical_native_scope& scope)noexcept {
    static_assert(maximum_originals==64);scope.creator_=actual.creator;
    if(actual.inherited){scope.entered_=false;return;}
    for(std::size_t i=0;i<actual.count;++i){
        auto* original=actual.values[i];scope.originals_[scope.count_++]=original;
        // Continuation is per immutable original, NOT merely per primary
        // connection. A newly attached target cannot borrow an older frame.
        if(store_physical_lifetime::native_scope_entered_(original->held,scope.cleanup_only_||native_continuation_(original)))scope.entered_mask_|=std::uint64_t(1)<<i;
        else scope.entered_=false;
    }
    actual.count=0;actual.value=nullptr;
    // Even a genuine legacy/memory route observes its managed leaf nesting.
    // An empty frame has no originals and grants NO continuation/resource SQL.
    scope.previous_=store_physical_native_scope::current_;
    store_physical_native_scope::current_=&scope;scope.registered_=true;
}
void store_physical_api::enter_database_native_(const ::lattice::database& owner,store_physical_native_scope& scope)noexcept {
    if(!owner.creator_current_()){scope.entered_=false;return;}
    enter_native_scope_(owner.physical_open_original_,owner.db_,scope);
}
void store_physical_api::enter_database_cleanup_(const ::lattice::database& owner,store_physical_native_scope& scope)noexcept {
    if(!owner.creator_current_()){scope.entered_=false;return;}
    if(!owner.db_){scope.creator_=database_native_process();return;} // no Native entry
    enter_cleanup_scope_(owner.physical_open_original_,owner.db_,scope);
}
void store_physical_api::enter_cleanup_scope_(const store_physical_open_original& owner,lattice_sqlite3541_connection* native,store_physical_native_scope& scope)noexcept {
    scope.cleanup_only_=true;
    enter_captured_native_(capture_cleanup_(owner,native),scope);
}
void store_physical_api::enter_native_scope_(lattice_sqlite3541_connection* native,store_physical_native_scope& scope)noexcept {
    enter_captured_native_(capture_(native),scope);
}
void store_physical_api::enter_native_scope_(const store_physical_open_original& owner,lattice_sqlite3541_connection* native,store_physical_native_scope& scope)noexcept {
    enter_captured_native_(capture_open_(owner,native),scope);
}
void store_physical_api::leave_native_scope_(store_physical_native_scope& scope)noexcept {
    if(scope.creator_!=database_native_process()||
       (physical_api_creator!=database_native_process()&&(scope.count_||foreign_protected_())))return;
    // A newly-issued current-creator EMPTY legacy observation touches no
    // inherited physical original/counter/registry. Preserve that old route.
    // Keep every exact release below queued until this whole return's counters
    // and metadata leaves have ended, even after unlinking its TLS node.
    const bool return_overflow=native_return_work_==UINT64_MAX;
    if(!return_overflow)++native_return_work_;
    if(scope.registered_){
        // Explicit outer-scope release is allowed while a real nested engine
        // frame remains. Unlink this exact live TLS node, never a current owner.
        auto** link=&store_physical_native_scope::current_;
        while(*link&&*link!=&scope)link=&(*link)->previous_;
        if(*link==&scope)*link=scope.previous_;
        scope.registered_=false;scope.previous_=nullptr;
    }
    if(return_overflow)return; // TLS unlinked; retain actual counter/reference debt.
    while(scope.count_){const auto i=--scope.count_;auto* original=static_cast<store_physical_api::original*>(scope.originals_[i]);
        scope.originals_[i]=nullptr;
        if(scope.entered_mask_&(std::uint64_t(1)<<i))store_physical_lifetime::native_scope_returned_(original->held);
        release_original_(original,scope.creator_);
    }
    scope.entered_mask_=0;
    --native_return_work_;
    returned_tail();
}
store_physical_policy_original::store_physical_policy_original()noexcept:creator_(database_native_process()){}
store_physical_policy_original::store_physical_policy_original(store_physical_policy_original&& other)noexcept
    :original_(std::exchange(other.original_,nullptr)),creator_(other.creator_){}
store_physical_policy_original& store_physical_policy_original::operator=(store_physical_policy_original&& other)noexcept {
    if(this!=&other){store_physical_api::release_policy_(*this);original_=std::exchange(other.original_,nullptr);creator_=other.creator_;}return *this;
}
store_physical_policy_original::~store_physical_policy_original()noexcept{store_physical_api::release_policy_(*this);}
store_physical_policy_original store_physical_policy_original::capture_(const store_physical_open_original& owner)noexcept {
    store_physical_policy_original token;store_physical_api::capture_policy_(owner,token);return token;
}
bool store_physical_policy_original::observer_policy_unsettled()const noexcept{return store_physical_api::observer_policy_unsettled_(*this);}
void store_physical_policy_original::note_observer_policy_unsettled()noexcept{store_physical_api::note_observer_policy_unsettled_(*this);}
store_physical_open_original::store_physical_open_original()noexcept:creator_(database_native_process()){}
store_physical_open_original::store_physical_open_original(store_physical_open_original&& other)noexcept
    :provider_instance_(std::exchange(other.provider_instance_,nullptr)),original_(std::exchange(other.original_,nullptr)),
     provider_legacy_(std::exchange(other.provider_legacy_,nullptr)),actual_(std::exchange(other.actual_,nullptr)),creator_(other.creator_),
     bound_(std::exchange(other.bound_,false)),legacy_(std::exchange(other.legacy_,false)),native_retired_(std::exchange(other.native_retired_,false)),
     exclusive_target_(std::exchange(other.exclusive_target_,false)),exclusive_open_attempted_(std::exchange(other.exclusive_open_attempted_,false)){}
store_physical_open_original& store_physical_open_original::operator=(store_physical_open_original&& other)noexcept {
    if(this!=&other){store_physical_api::release_open_(*this);provider_instance_=std::exchange(other.provider_instance_,nullptr);original_=std::exchange(other.original_,nullptr);
        provider_legacy_=std::exchange(other.provider_legacy_,nullptr);actual_=std::exchange(other.actual_,nullptr);creator_=other.creator_;bound_=std::exchange(other.bound_,false);legacy_=std::exchange(other.legacy_,false);native_retired_=std::exchange(other.native_retired_,false);
        exclusive_target_=std::exchange(other.exclusive_target_,false);exclusive_open_attempted_=std::exchange(other.exclusive_open_attempted_,false);}
    return *this;
}
store_physical_open_original::~store_physical_open_original()noexcept{store_physical_api::release_open_(*this);}
bool store_physical_open_original::retain_initialization_budget_(
    const std::shared_ptr<database_initialization_budget>& budget)noexcept {
    return store_physical_api::retain_initialization_budget_(*this,budget);
}
bool store_physical_open_original::issue_exclusive_target_(std::uint64_t issuer)noexcept {
    // database alone calls this after its SAME retained constructor scope and
    // both genuine target preopen checks. No allocation or pathname adoption.
    if(issuer!=database_native_process()||creator_!=issuer||!store_physical_api::can_issue_open_(*this))return false;
    bound_=true;exclusive_target_=true;return true;
}
int store_physical_open_original::open_exclusive_target_(const char* file,lattice_sqlite3541_connection** actual,int flags,
    const char* vfs,std::chrono::steady_clock::time_point end)noexcept {
    const auto issuer=creator_;
    if(issuer!=database_native_process()||store_physical_api::foreign_protected_())return LATTICE_SQLITE3541_MISUSE;
    if(!bound_||!exclusive_target_||exclusive_open_attempted_||original_||legacy_||native_retired_||actual_)return LATTICE_SQLITE3541_MISUSE;
    exclusive_open_attempted_=true; // Never retry this original, including a null/error return.
    if(!actual)return LATTICE_SQLITE3541_MISUSE;
    *actual=nullptr;
#ifdef LATTICE_SQLITE3541_OPEN_NOFOLLOW
    constexpr int required=LATTICE_SQLITE3541_OPEN_READWRITE|LATTICE_SQLITE3541_OPEN_FULLMUTEX|LATTICE_SQLITE3541_OPEN_NOFOLLOW;
    if(!file||!*file||!vfs||!*vfs||flags!=required||std::chrono::steady_clock::now()>=end)return LATTICE_SQLITE3541_CANTOPEN;
    // Deliberately bypass normal-factory acquisition: the true target already
    // owns its exclusive descriptor/custom VFS and admitted constructor scope.
    try {
        const int rc=store_physical_api::open_exclusive_provider_(*this,file,actual,flags,vfs,end);
        if(issuer!=database_native_process()){*actual=nullptr;return LATTICE_SQLITE3541_MISUSE;}
        actual_=*actual; // Bind ONLY this real provider return, including a partial error handle.
        store_physical_api::unresourced_open_returned(actual_); // stale-map denial, never adoption
        return rc;
    }catch(...){return LATTICE_SQLITE3541_CANTOPEN;}
#else
    (void)file;(void)flags;(void)vfs;(void)end;return LATTICE_SQLITE3541_CANTOPEN;
#endif
}
bool store_physical_open_original::matches_open_(lattice_sqlite3541_connection* actual)const noexcept {
    return creator_==database_native_process()&&bound_&&!native_retired_&&actual_==actual&&
        (!exclusive_target_||(exclusive_open_attempted_&&actual));
}
bool store_physical_open_original::seal_and_wait_(std::chrono::steady_clock::time_point end)const noexcept{return store_physical_api::seal_open_(*this,end);}
bool store_physical_open_original::observer_policy_unsettled()const noexcept{return store_physical_api::observer_policy_unsettled_(*this);}
void store_physical_open_original::note_observer_policy_unsettled()noexcept{store_physical_api::note_observer_policy_unsettled_(*this);}
store_physical_cleanup_scope::store_physical_cleanup_scope(const ::lattice::database& owner)noexcept{store_physical_api::enter_database_cleanup_(owner,held_);}
store_physical_cleanup_scope::store_physical_cleanup_scope(const store_physical_open_original& owner,lattice_sqlite3541_connection* actual)noexcept{store_physical_api::enter_cleanup_scope_(owner,actual,held_);}
store_physical_native_scope::store_physical_native_scope(lattice_sqlite3541_connection* actual)noexcept{store_physical_api::enter_native_scope_(actual,*this);}
store_physical_native_scope::store_physical_native_scope(const ::lattice::database& owner)noexcept{store_physical_api::enter_database_native_(owner,*this);}
store_physical_native_scope::store_physical_native_scope(const store_physical_open_original& owner,lattice_sqlite3541_connection* actual)noexcept{store_physical_api::enter_native_scope_(owner,actual,*this);}
store_physical_native_scope::store_physical_native_scope(const store_physical_open_original* owner,lattice_sqlite3541_connection* actual)noexcept{
    if(owner)store_physical_api::enter_native_scope_(*owner,actual,*this);
    else if(actual)entered_=false; // null managed-route has no Native access
}
store_physical_native_scope::~store_physical_native_scope()noexcept{reset();}
void store_physical_native_scope::reset()noexcept{store_physical_api::leave_native_scope_(*this);}
void store_physical_api::release_(ticket& held)noexcept {
    const auto creator=held.creator;held.value=nullptr;
    while(held.count){auto* actual=held.values[--held.count];held.values[held.count]=nullptr;release_original_(actual,creator);}
}
bool store_physical_api::managed_return_here_()noexcept {
    // The immutable process fence precedes even reading inherited TLS links.
    if(physical_api_creator!=database_native_process())return true;
    return native_return_work_||store_physical_native_scope::current_||
        api_scope::current_||store_physical_lifetime::api_return::current_;
}
void store_physical_api::retire_initialization_budget_(database_initialization_budget* actual)noexcept {
    // The last shared-owner deleter transfers DELETE, not a new reference.
    // Creator checks precede inherited TLS, node or lease access.
    if(physical_api_creator!=database_native_process()||!actual||
       actual->creator_!=database_native_process())return;
    if(actual->returned_delete_)return; // malformed duplicate: retain debt
    actual->returned_delete_=true;
    actual->returned_next_=returned_budgets_;returned_budgets_=actual;
    if(returned_tail_observation_)++returned_tail_observation_->budget_enqueued;
    // This call is still inside the actual standard shared-control deleter.
    // Never run another original's Native completion here. Fixed DATA budgets
    // can end now, including failed first control allocation before any Native.
    drain_initialization_data_only_();
}
void store_physical_api::drain_initialization_data_only_()noexcept {
    if(physical_api_creator!=database_native_process()||draining_tails_||managed_return_here_())return;
    draining_tails_=true;
    while(returned_budgets_&&!managed_return_here_()) {
        auto* actual=returned_budgets_;returned_budgets_=actual->returned_next_;actual->returned_next_=nullptr;
        if(returned_tail_observation_)++returned_tail_observation_->budget_delete_calls;
        // Actual record/client/domain cleanup is fixed DATA only, outside all
        // metadata leaves. No physical original, Native, app target or Open
        // owner is destroyed; the rebound control allocator never reads account.
        actual->delete_after_return_();
        if(physical_api_creator!=database_native_process())return;
    }
    draining_tails_=false;
}
void store_physical_api::handoff_returned_tail_(original* actual)noexcept {
    if(!actual||physical_api_creator!=database_native_process()||actual->creator!=database_native_process())return;
    // Caller owns this original's unique synthetic reference/action. The
    // registry leaf was released before publishing this preallocated link.
    actual->returned_next=returned_tails_;returned_tails_=actual;
    returned_tail();
}
void store_physical_api::finish_returned_tail_(original* actual)noexcept {
    if(!actual||physical_api_creator!=database_native_process()||actual->creator!=database_native_process())return;
    const auto creator=actual->creator;
    const bool complete=actual->returned==original::returned_action::complete;
    if(complete&&actual->completion){
        if(returned_tail_observation_)++returned_tail_observation_->completed;
        actual->completion(actual->completion_cookie);
    }
    // Fixed completion/capture destruction is still a possible foreign return.
    // Abandon inherited capsule before its mutex, DATA holders or further work.
    if(creator!=database_native_process())return;
    bool destroy=false;
    try{
        {std::lock_guard lock(physical_api_leaf);
         if(complete)actual->completion_returned=true;
         actual->returned=original::returned_action::none;
         if(!actual->references)return; // Preserve malformed-reference debt.
         --actual->references;
         destroy=!actual->references&&actual->completion_returned;
         if(destroy&&managed_return_here_()){
             actual->references=1;actual->returned=original::returned_action::destroy;
         }}
        if(!destroy)return;
        if(managed_return_here_()){handoff_returned_tail_(actual);return;}
        if(returned_tail_observation_)++returned_tail_observation_->destroyed;
        delete actual; // typed DATA budget/held pin end only off BOTH real stacks
    }catch(...){/* Keep actual completion/deletion debt; never infer refund. */}
}
void store_physical_api::returned_tail()noexcept {
    if(physical_api_creator!=database_native_process()||draining_tails_||managed_return_here_())return;
    if(returned_tails_)if(const auto observed=database_initialization_test_probe::before_physical_return_drain)observed();
    if(physical_api_creator!=database_native_process()||draining_tails_||managed_return_here_())return;
    draining_tails_=true;
    while((returned_tails_||returned_budgets_)&&!managed_return_here_()){
        if(returned_tails_){
            auto* actual=returned_tails_;returned_tails_=actual->returned_next;actual->returned_next=nullptr;
            finish_returned_tail_(actual);
        }else{
            auto* actual=returned_budgets_;returned_budgets_=actual->returned_next_;actual->returned_next_=nullptr;
            // No Native/API/VFS frame or own-return counter work remains.
            // The same embedded admission record returns its actual DATA
            // credit only here, including pre-grant/control-allocation failure.
            if(returned_tail_observation_)++returned_tail_observation_->budget_delete_calls;
            actual->delete_after_return_();
        }
        if(physical_api_creator!=database_native_process())return; // inherited lists abandoned
    }
    draining_tails_=false;
    drain_legacy_();
}
void store_physical_api::release_original_(original* actual,std::uint64_t creator)noexcept {
    if(!actual||creator!=database_native_process()||physical_api_creator!=database_native_process())return;
    const auto ended=store_physical_lifetime::observe_(actual->held).physical_ended;
    bool retire=false;
    try {
        {std::lock_guard lock(physical_api_leaf);
         if(ended&&actual->listed&&!actual->completion_claimed){
             auto** cursor=&head_;
             while(*cursor&&*cursor!=actual)cursor=&(*cursor)->next;
             if(*cursor==actual){
                 *cursor=actual->next;actual->listed=false;actual->current=false;
                 actual->completion_claimed=true;
                 // Exchange the registry reference for ONE returned-tail
                 // reference (no overflow or extra allocation).
                 actual->returned=original::returned_action::complete;retire=true;
             }
         }
         if(!actual->references)return;
         --actual->references;
         if(!retire&&!actual->references&&actual->completion_returned){
             actual->references=1;actual->returned=original::returned_action::destroy;retire=true;
         }}
        if(retire)handoff_returned_tail_(actual);
    }catch(...){/* Preserve actual registry/lease ending debt. */}
}
store_physical_api::ticket::~ticket()noexcept {store_physical_api::release_(*this);}
store_physical_api::api_scope::api_scope()noexcept:creator_(database_native_process()) {
    if(store_physical_api::foreign_protected_()){entered_=false;return;}
    previous_=current_;current_=this;registered_=true;
}
store_physical_api::api_scope::api_scope(const ticket& actual)noexcept:creator_(actual.creator) {
    if(actual.inherited||creator_!=database_native_process()||
       (actual.count&&creator_!=physical_api_creator)||store_physical_api::foreign_protected_()){entered_=false;return;}
    // A valid empty ticket is still an observation of this genuine wrapper C
    // call. It has no physical originals and grants NO SQL/continuation right.
    previous_=current_;current_=this;registered_=true;
    for(std::size_t i=0;i<actual.count;++i){
        auto* frame=::new(static_cast<void*>(storage_+count_*sizeof(store_physical_lifetime::api_return)))
            store_physical_lifetime::api_return(actual.values[i]->held);
        ++count_;
        if(!frame->entered()){entered_=false;return;}
    }
}
store_physical_api::api_scope::~api_scope()noexcept {
    if(creator_!=database_native_process()||
       (creator_!=physical_api_creator&&(count_||store_physical_api::foreign_protected_())))return;
    // Only a NEW current-process empty observation may unlink here without
    // parent-registry access. Inherited observations still creator-refuse.
    // Keep this observation linked while every actual per-original counter,
    // held-pin and metadata return tail runs, including partial admission.
    while(count_)at_(--count_)->~api_return();
    if(registered_){
        auto** link=&current_;while(*link&&*link!=this)link=&(*link)->previous_;
        if(*link==this)*link=previous_;
        registered_=false;previous_=nullptr;
    }
    store_physical_api::returned_tail();
}

struct store_physical_api::attachment_operation::implementation {
    const std::uint64_t creator=database_native_process();
    store_resource_open resource;
    ticket retained;
    std::optional<ticket> call;
    std::optional<api_scope> frame;
    store_physical_vfs* member=nullptr;
    bool detach=false,entered=false,returned=false;
    implementation(store_resource_open value,ticket prior):resource(std::move(value)),retained(std::move(prior)){}
};
store_physical_api::attachment_operation::attachment_operation(implementation* value)noexcept:impl_(value){}
store_physical_api::attachment_operation::attachment_operation(attachment_operation&& other)noexcept
    :impl_(std::exchange(other.impl_,nullptr)){}
store_physical_api::attachment_operation::~attachment_operation()noexcept {
    auto* value=impl_;if(!value||value->creator!=database_native_process())return;
    if(value->member&&!value->returned)value->member->member_returned_(value->detach,value->entered,false);
    // Actual synchronous SQLite call, permit and caller Native leaf have
    // returned before this owned frame retires. Capture destruction is offleaf.
    value->frame.reset();value->member=nullptr;
    delete value; // call tickets follow frame, then entry SH and exact retained originals
}
void store_physical_api::attachment_operation::enter(){
    auto* value=impl_;
    if(!value||value->creator!=database_native_process()||!value->member||value->entered||value->returned||!value->call)
        throw db_error("resource attachment first call unavailable");
    value->frame.emplace(*value->call);
    if(!value->frame->entered()||!value->member->member_entered_(value->detach))
        throw db_error("resource attachment first call original changed");
    value->entered=true;
}
void store_physical_api::attachment_operation::complete(){
    auto* value=impl_;
    if(!value||value->creator!=database_native_process()||!value->member||!value->entered||value->returned)
        throw db_error("resource attachment actual return unavailable");
    if(!value->member->member_returned_(value->detach,true,true))
        throw db_error("resource attachment return DATA unproved");
    value->returned=true;
}
store_physical_api::attachment_operation store_physical_api::enroll_attachment(lattice_sqlite3541_connection* native,
    const std::string& path,const std::string& alias,const ::lattice::physical_store_identity& expected,
    std::int64_t token,int attached_limit,std::chrono::steady_clock::time_point end){
    if(foreign_protected_()||std::chrono::steady_clock::now()>=end)throw db_error("resource attachment admission expired or inherited");
    auto prior=capture_(native);
    if(prior.inherited||!prior.value||!prior.value->primary||prior.value->completion!=&store_physical_vfs::complete_||
       !prior.value->completion_cookie)throw db_error("resource attachment actual MAIN original missing");
    auto* root=static_cast<store_physical_vfs*>(prior.value->completion_cookie);
    auto resource=store_resource_open::acquire_(path,false,end);
    if(!resource.impl_)throw db_error("resource attachment target is not enrolled");
    const auto creator=database_native_process();
    auto* state=new attachment_operation::implementation(std::move(resource),std::move(prior));
    attachment_operation result(state);
    if(creator!=database_native_process())throw db_error("resource attachment allocation changed creator");
    state->member=state->resource.enroll_(*root,native,alias,expected,token,attached_limit);
    if(creator!=database_native_process())throw db_error("resource attachment publication changed creator");
    state->call.emplace(capture_(native));
    if(state->call->inherited||!state->call->value)throw db_error("resource attachment complete original set unavailable");
    return result;
}
store_physical_api::attachment_operation store_physical_api::retire_attachment(lattice_sqlite3541_connection* native,
    const std::string& path,const std::string& alias,std::int64_t token){
    if(foreign_protected_())throw db_error("resource detach inherited");
    auto prior=capture_(native);
    if(prior.inherited||!prior.value||!prior.value->primary||prior.value->completion!=&store_physical_vfs::complete_||
       !prior.value->completion_cookie)throw db_error("resource detach actual MAIN original missing");
    auto* root=static_cast<store_physical_vfs*>(prior.value->completion_cookie);
    const auto creator=database_native_process();
    auto* state=new attachment_operation::implementation({},std::move(prior));
    attachment_operation result(state);
    if(creator!=database_native_process())throw db_error("resource detach allocation changed creator");
    state->detach=true;state->member=root->find_member_(native,path,alias,token);
    state->call.emplace(capture_(native));
    if(state->call->inherited||!state->call->value)throw db_error("resource detach complete original set unavailable");
    return result;
}

int store_physical_api::open(const char* file,lattice_sqlite3541_connection** actual,int flags,const char* vfs,
    std::chrono::steady_clock::time_point end,store_physical_open_original* issued)noexcept {
    // Legacy internal C-result adapter. Actual Core owners use the throwing
    // route below so a genuine allocation/provider exception stays primary.
    try{return open_owned_(file,actual,flags,vfs,end,issued);}
    catch(...){return LATTICE_SQLITE3541_CANTOPEN;}
}
const char* store_physical_api::prepare_wal_(database* actual,const std::optional<lattice_sqlite3541_int64>& limit,
    const char* file,const char* prior) {
    if(!limit)return prior;
    if(!actual||!actual->creator_current_()||actual->db_||actual->is_closed()||!file||actual->path_!=file||
       actual->mode_!=database::open_mode::read_write||actual->wal_extent_vfs_||prior||*limit<=0)
        throw db_error("actual WAL provider lost its exact pre-Native owner/limit");
    // Only actual owned-open callers enter here AFTER trusted lower resource
    // admission (and its real account, when selected). Native builtin init and
    // wrapped registration must not precede that admission.
    actual->wal_extent_vfs_=wal_extent_vfs::create(file,*limit);
    return actual->wal_extent_vfs_->name();
}
int store_physical_api::open_owned_(const char* file,lattice_sqlite3541_connection** actual,int flags,const char* vfs,
    std::chrono::steady_clock::time_point original_end,store_physical_open_original* issued,database* wal_owner,
    std::optional<lattice_sqlite3541_int64> wal_limit) {
    if(foreign_protected_())return LATTICE_SQLITE3541_MISUSE;
    if(!actual)return LATTICE_SQLITE3541_MISUSE;
    *actual=nullptr;
    if(issued&&!can_issue_open_(*issued))return LATTICE_SQLITE3541_MISUSE;
    const auto creator=database_native_process();
    if(!file)return LATTICE_SQLITE3541_MISUSE;
        // This producer either admits the genuine fixed-account resource
        // context, or positively establishes the unchanged uninstalled route.
        // Installed/failed/foreign contexts never fall back after refusal.
        auto resource=store_resource_open::acquire_(file,(flags&LATTICE_SQLITE3541_OPEN_CREATE)!=0,original_end,(flags&LATTICE_SQLITE3541_OPEN_URI)!=0);
        const auto selected=sqlite_provider::v1::vfs_original::select_(prepare_wal_(wal_owner,wal_limit,file,vfs));
        const auto& lower=*selected.actual_;
        if(resource.impl_){

#ifdef LATTICE_SQLITE3541_OPEN_NOFOLLOW
            flags=(flags&~LATTICE_SQLITE3541_OPEN_CREATE)|LATTICE_SQLITE3541_OPEN_NOFOLLOW;
#else
            return LATTICE_SQLITE3541_CANTOPEN;
#endif
            return resource.open_(lower,actual,flags,issued,original_end);
        }
        store_physical_open_original local;
        auto& owner=issued?*issued:local;
        if(!issue_legacy_open_(owner))return LATTICE_SQLITE3541_MISUSE;
        const int rc=open_legacy_(owner,file,actual,flags,lower,original_end);
        if(creator!=database_native_process()){*actual=nullptr;return LATTICE_SQLITE3541_MISUSE;}
        unresourced_open_returned(*actual);
        // open_legacy_ already bound its SAME genuine return before any primary propagation.
        return rc;
}
int store_physical_api::open_initializing_(const char* file,lattice_sqlite3541_connection** actual,int flags,const char* vfs,
    std::chrono::steady_clock::time_point original_end,store_physical_open_original& issued,
    store_resource_initialization_original& recipient,store_resource_initialization_original* supplied,
    ::lattice::database* prospective_owner,const observer_delivery_open_startup* prospective_open,
    ::lattice::database* wal_owner,std::optional<lattice_sqlite3541_int64> wal_limit) {
    if(foreign_protected_()||!actual||!file||!can_issue_open_(issued)||recipient.creator_||recipient.impl_||
       bool(prospective_owner)!=bool(prospective_open))
        throw db_error("initializing Native open lost its exact empty producer originals");
    *actual=nullptr;const auto creator=database_native_process();
    if(supplied&&(!supplied->transport_current_()||original_end>supplied->original_deadline_()))
        throw db_error("normal factory original changed creator/builder/end before Native");
    // A supplied factory already created/selected this exact incarnation (or
    // genuinely selected the legacy domain). Never create a second original or
    // recreate a changed namespace while transporting that SAME factory owner.
    auto resource=store_resource_open::acquire_(file,(flags&LATTICE_SQLITE3541_OPEN_CREATE)!=0&&!supplied,
        original_end,(flags&LATTICE_SQLITE3541_OPEN_URI)!=0,!supplied,prospective_owner,prospective_open,supplied);
    const auto selected=sqlite_provider::v1::vfs_original::select_(prepare_wal_(wal_owner,wal_limit,file,vfs));
    const auto& lower=*selected.actual_;
    if(resource.impl_) {

#ifdef LATTICE_SQLITE3541_OPEN_NOFOLLOW
        flags=(flags&~LATTICE_SQLITE3541_OPEN_CREATE)|LATTICE_SQLITE3541_OPEN_NOFOLLOW;
#else
        throw db_error("actual initializing Native nofollow support unavailable");
#endif
        return resource.open_initializing_(lower,actual,flags,issued,recipient,supplied,original_end,prospective_owner,prospective_open);
    }
    if(supplied) {
        if(supplied->impl_)throw db_error("actual normal factory resource domain disappeared before Native");
        supplied->transfer_to_(recipient); // genuine legacy factory DATA/end only
    }
    if(!issue_legacy_open_(issued))throw db_error("actual initializing legacy original unavailable");
    if(prospective_open)throw db_error("protected Open requires its actual installed physical/account producer");
    const int rc=open_legacy_(issued,file,actual,flags,lower,original_end);
    if(creator!=database_native_process()){*actual=nullptr;throw db_error("inherited initializing Native return");}
    unresourced_open_returned(*actual);
    // open_legacy_ already bound its SAME genuine return before any primary propagation.
    return rc;
}
const store_physical_open_original* store_physical_api::mutex_owner_(const ::lattice::database& owner)noexcept {
    // Creator denial precedes even reading a borrowed inherited owner field.
    return owner.creator_current_()?&owner.physical_open_original_:nullptr;
}
void store_physical_api::return_mutex_(const store_physical_open_original& original,lattice_sqlite3541_mutex* mutex)noexcept {
    if(original.creator_!=database_native_process()||foreign_protected_()||
       !original.bound_||original.native_retired_)return;
    // Fixed nil-default DATA observation at the real Native attempt boundary.
    // It never authorizes/changes the return and invokes no arbitrary callback.
    api_scope returned;if(!returned.entered())return;
    if(mutex_return_observation_)++*mutex_return_observation_;
    lattice_sqlite3541_mutex_leave(mutex);
}
store_physical_mutex_return::store_physical_mutex_return(const ::lattice::database& owner,lattice_sqlite3541_mutex* mutex)noexcept
    :original_(store_physical_api::mutex_owner_(owner)),mutex_(mutex){}
store_physical_mutex_return::store_physical_mutex_return(const store_physical_open_original& owner,lattice_sqlite3541_mutex* mutex)noexcept
    :original_(&owner),mutex_(mutex){}
store_physical_mutex_return::~store_physical_mutex_return()noexcept{reset();}
void store_physical_mutex_return::reset()noexcept {
    const auto* original=std::exchange(original_,nullptr);auto* mutex=std::exchange(mutex_,nullptr);
    if(original&&mutex)store_physical_api::return_mutex_(*original,mutex);
}
bool store_physical_api::process_current()noexcept{return !foreign_protected_();}
bool store_physical_api::enrolled(lattice_sqlite3541_connection* native)noexcept{
    if(foreign_protected_())return true; // denial, never an inherited lookup
    auto actual=capture_(native);return actual.inherited||actual.value;
}
bool store_physical_api::main_for_lower(lattice_sqlite3541_connection* native,lattice_sqlite3541_vfs* expected,lattice_sqlite3541_file*& inner)noexcept {
    inner=nullptr;
    if(foreign_protected_())return false;
    auto actual=capture_(native);if(actual.inherited)return false;
    if(!actual.value)return true; // Exact legacy wrapper checks remain at caller.
    if(actual.value->completion!=&store_physical_vfs::complete_||!actual.value->completion_cookie)return false;
    auto* owner=static_cast<store_physical_vfs*>(actual.value->completion_cookie);
    lattice_sqlite3541_vfs* observed=nullptr;lattice_sqlite3541_file* outer=nullptr;lattice_sqlite3541_vfs* lower=nullptr;
    api_scope returned(actual);if(!returned.entered())return false;
    const int vfs_result=lattice_sqlite3541_file_control(native,"main",LATTICE_SQLITE3541_FCNTL_VFS_POINTER,&observed);
    if(actual.creator!=database_native_process()){inner=nullptr;return false;}
    if(vfs_result!=LATTICE_SQLITE3541_OK){inner=nullptr;return false;}
    const int file_result=lattice_sqlite3541_file_control(native,"main",LATTICE_SQLITE3541_FCNTL_FILE_POINTER,&outer);
    if(actual.creator!=database_native_process()){inner=nullptr;return false;}
    if(file_result!=LATTICE_SQLITE3541_OK||!owner->identity_layer_(outer,observed,inner,lower)||lower!=expected){inner=nullptr;return false;}
    return true;
}
lattice_sqlite3541_vfs* store_physical_api::identity_vfs(lattice_sqlite3541_connection* native,const char* schema,lattice_sqlite3541_vfs* observed,lattice_sqlite3541_file*& inner)noexcept {
    inner=nullptr;
    if(foreign_protected_())return nullptr;
    auto actual=capture_(native);if(actual.inherited)return nullptr;
    if(!actual.value)return observed;
    if(!schema||!*schema||actual.value->completion!=&store_physical_vfs::complete_||!actual.value->completion_cookie)return nullptr;
    auto* owner=static_cast<store_physical_vfs*>(actual.value->completion_cookie);
    lattice_sqlite3541_file* outer=nullptr;lattice_sqlite3541_vfs* lower=nullptr;
    api_scope returned(actual);if(!returned.entered())return nullptr;
    const int file_result=lattice_sqlite3541_file_control(native,schema,LATTICE_SQLITE3541_FCNTL_FILE_POINTER,&outer);
    if(actual.creator!=database_native_process()){inner=nullptr;return nullptr;}
    if(file_result!=LATTICE_SQLITE3541_OK||!owner->identity_layer_(outer,observed,inner,lower)){inner=nullptr;return nullptr;}
    return lower;
}
int store_physical_api::prepare(lattice_sqlite3541_connection* owner,const char* sql,int size,unsigned int flags,lattice_sqlite3541_stmt** statement,const char** tail,bool v3)noexcept {
    if(foreign_protected_())return LATTICE_SQLITE3541_MISUSE;
    auto actual=capture_(owner);if(actual.inherited)return LATTICE_SQLITE3541_MISUSE;
    api_scope returned(actual);if(!returned.entered())return LATTICE_SQLITE3541_MISUSE;
    return v3?lattice_sqlite3541_prepare_v3(owner,sql,size,flags,statement,tail):lattice_sqlite3541_prepare_v2(owner,sql,size,statement,tail);
}
int store_physical_api::clear_bindings(lattice_sqlite3541_stmt* statement)noexcept {
    if(foreign_protected_())return LATTICE_SQLITE3541_MISUSE;
    if(!statement)return lattice_sqlite3541_clear_bindings(statement);
    auto actual=capture_(lattice_sqlite3541_db_handle(statement));if(actual.inherited)return LATTICE_SQLITE3541_MISUSE;
    api_scope returned(actual);if(!returned.entered())return LATTICE_SQLITE3541_MISUSE;
    return lattice_sqlite3541_clear_bindings(statement);
}
int store_physical_api::create_function(lattice_sqlite3541_connection* owner,const char* name,int n,int encoding,void* data,
    void(*function)(lattice_sqlite3541_context*,int,lattice_sqlite3541_value**),void(*step)(lattice_sqlite3541_context*,int,lattice_sqlite3541_value**),
    void(*final)(lattice_sqlite3541_context*),void(*destroy)(void*),bool v2,bool* actual_native_entered)noexcept {
    if(actual_native_entered)*actual_native_entered=false;
    const auto creator=database_native_process();
    // Never release inherited Native-bearing callback payload on refusal.
    if(foreign_protected_())return LATTICE_SQLITE3541_MISUSE;
    int result=LATTICE_SQLITE3541_MISUSE;bool native_entered=false;
    {
        auto actual=capture_(owner);
        if(!actual.inherited){
            api_scope returned(actual);
            if(returned.entered()){
                // Actual SQLite owns v2's failure/success xDestroy contract.
                // Replacing a registration may destroy its old callback.
                native_entered=true;
                if(actual_native_entered)*actual_native_entered=true;
                result=v2?lattice_sqlite3541_create_function_v2(owner,name,n,encoding,data,function,step,final,destroy):
                    lattice_sqlite3541_create_function(owner,name,n,encoding,data,function,step,final);
            }
        }
    } // Every actual API/registry/physical scope ended BEFORE user destruction.
    // SQLite v2 consumes its userdata even on failure. Preserve that contract
    // for genuine same-creator pre-Native refusal too, exactly once. The local
    // original PID and registry PID must both still match; a callback/fork can
    // never turn this into inherited cleanup. No Native-bearing local follows.
    if(!native_entered&&v2&&destroy&&creator==database_native_process()&&creator==physical_api_creator)
        destroy(data);
    return result;
}
int store_physical_api::finalize(lattice_sqlite3541_stmt* statement)noexcept {
    if(foreign_protected_())return LATTICE_SQLITE3541_MISUSE;
    if(!statement)return lattice_sqlite3541_finalize(nullptr);
    auto actual=capture_(lattice_sqlite3541_db_handle(statement));
    if(actual.inherited)return LATTICE_SQLITE3541_MISUSE;
    api_scope returned(actual);
    if(!returned.entered())return LATTICE_SQLITE3541_MISUSE;
    wal_callback_native_turn callback_return(lattice_sqlite3541_db_handle(statement));
    return lattice_sqlite3541_finalize(statement); // actual tail destructor runs AFTER this C API returns
}
int store_physical_api::step(lattice_sqlite3541_stmt* statement,bool reset)noexcept {
    if(foreign_protected_())return LATTICE_SQLITE3541_MISUSE;
    if(!statement)return reset?lattice_sqlite3541_reset(nullptr):lattice_sqlite3541_step(nullptr);
    auto actual=capture_(lattice_sqlite3541_db_handle(statement));if(actual.inherited)return LATTICE_SQLITE3541_MISUSE;
    api_scope returned(actual);
    if(!returned.entered())return LATTICE_SQLITE3541_MISUSE;
    wal_callback_native_turn callback_return(lattice_sqlite3541_db_handle(statement));
    return reset?lattice_sqlite3541_reset(statement):lattice_sqlite3541_step(statement);
}
int store_physical_api::exec(lattice_sqlite3541_connection* owner,const char* sql,int(*callback)(void*,int,char**,char**),void* data,char** error)noexcept {
    if(foreign_protected_())return LATTICE_SQLITE3541_MISUSE;
    auto actual=capture_(owner);if(actual.inherited)return LATTICE_SQLITE3541_MISUSE;
    api_scope returned(actual);
    if(!returned.entered())return LATTICE_SQLITE3541_MISUSE;
    wal_callback_native_turn callback_return(owner);
    return lattice_sqlite3541_exec(owner,sql,callback,data,error);
}
int store_physical_api::checkpoint(lattice_sqlite3541_connection* owner,const char* schema,int mode,int* log,int* done)noexcept {
    if(foreign_protected_())return LATTICE_SQLITE3541_MISUSE;
    auto actual=capture_(owner);if(actual.inherited)return LATTICE_SQLITE3541_MISUSE;
    api_scope returned(actual);
    if(!returned.entered())return LATTICE_SQLITE3541_MISUSE;
    wal_callback_native_turn callback_return(owner);
    return lattice_sqlite3541_wal_checkpoint_v2(owner,schema,mode,log,done);
}
int store_physical_api::blob_close(lattice_sqlite3541_blob* blob,lattice_sqlite3541_connection* owner)noexcept {
    if(foreign_protected_())return LATTICE_SQLITE3541_MISUSE;
    if(!blob)return lattice_sqlite3541_blob_close(nullptr);
    auto actual=capture_(owner);if(actual.inherited)return LATTICE_SQLITE3541_MISUSE;
    api_scope returned(actual);
    if(!returned.entered())return LATTICE_SQLITE3541_MISUSE;
    wal_callback_native_turn callback_return(owner);
    return lattice_sqlite3541_blob_close(blob);
}
int store_physical_api::close(lattice_sqlite3541_connection* owner,bool deferred)noexcept {
    if(foreign_protected_())return LATTICE_SQLITE3541_MISUSE;
    auto actual=capture_(owner);if(actual.inherited)return LATTICE_SQLITE3541_MISUSE;
    api_scope returned(actual);
    if(!returned.entered())return LATTICE_SQLITE3541_MISUSE;
    wal_callback_native_turn callback_return(owner);
    if(actual.value&&actual.value->completion==&store_physical_vfs::complete_&&actual.value->completion_cookie)
        static_cast<store_physical_vfs*>(actual.value->completion_cookie)->root_->seal_();
    store_provider_native_original* legacy=nullptr;
    if(!actual.value) {
        try{std::lock_guard lock(physical_api_leaf);
            for(auto* at=legacy_head_;at;at=at->next)if(at->actual==owner&&!at->retired){legacy=at;break;}
        }catch(...){return database_retirement_state::not_attempted;}
    }
    int result=database_retirement_state::not_attempted;
    try {
        if(actual.value)result=deferred?actual.value->provider_native.close_deferred_():actual.value->provider_native.close_();
        else if(legacy)result=deferred?legacy->native.close_deferred_():legacy->native.close_();
        else return database_retirement_state::not_attempted; // no actual provider producer; never touch a foreign Native
    }catch(...) {
        if(physical_api_creator!=database_native_process())return database_retirement_state::not_attempted;
        if(actual.value&&!actual.value->provider_close_failure)actual.value->provider_close_failure=std::current_exception();
        if(legacy&&!legacy->close_failure)legacy->close_failure=std::current_exception();
        return database_retirement_state::not_attempted;
    }
    if(legacy&&result==LATTICE_SQLITE3541_OK)legacy->retired=true;
    for(std::size_t i=0;i<actual.count;++i)
        store_physical_lifetime::native_close_returned_(actual.values[i]->held,deferred,result);
    return result;
}
int store_physical_api::close_owned(store_physical_open_original& owner,lattice_sqlite3541_connection* native,bool deferred)noexcept {
    if(foreign_protected_())return LATTICE_SQLITE3541_MISUSE;
    auto actual=capture_cleanup_(owner,native);if(actual.inherited)return LATTICE_SQLITE3541_MISUSE;
    api_scope returned(actual);if(!returned.entered())return LATTICE_SQLITE3541_MISUSE;
    wal_callback_native_turn callback_return(native);
    if(auto* root=actual_owner_(actual))root->root_->seal_();
    int rc=database_retirement_state::not_attempted;
    auto* legacy=static_cast<store_provider_native_original*>(owner.provider_legacy_);
    try {
        if(legacy) {
            if(legacy->creator!=database_native_process()||legacy->actual!=native||legacy->retired||legacy->owner_returned)
                return database_retirement_state::not_attempted;
            rc=deferred?legacy->native.close_deferred_():legacy->native.close_();
        }else if(actual.value&&actual.value==owner.original_) {
            rc=deferred?actual.value->provider_native.close_deferred_():actual.value->provider_native.close_();
        }else return database_retirement_state::not_attempted;
    }catch(...) {
        if(owner.creator_!=database_native_process())return database_retirement_state::not_attempted;
        if(legacy&&!legacy->close_failure)legacy->close_failure=std::current_exception();
        if(actual.value&&!actual.value->provider_close_failure)actual.value->provider_close_failure=std::current_exception();
        return database_retirement_state::not_attempted;
    }
    if(owner.creator_!=database_native_process())return rc;
    if(legacy&&rc==LATTICE_SQLITE3541_OK)legacy->retired=true;
    // BUSY is never rewritten; it permits only the actual fallback. A genuine
    // close/close_v2 success makes this pointer unusable for repeat cleanup.
    if(rc==LATTICE_SQLITE3541_OK)owner.native_retired_=true;
    for(std::size_t i=0;i<actual.count;++i)
        store_physical_lifetime::native_close_returned_(actual.values[i]->held,deferred,rc);
    return rc;
}
void store_physical_api::unresourced_open_returned(lattice_sqlite3541_connection* actual)noexcept {
    if(!actual||physical_api_creator!=database_native_process()||!physical_api_used.load(std::memory_order_acquire))return;
    try{std::lock_guard lock(physical_api_leaf);
        for(auto* at=head_;at;at=at->next)
            if(at->actual==actual)at->current=false;
    }catch(...){/* No resource grant is created by this denial-only observation. */}
}
int store_physical_open_v2_at(const char* file,lattice_sqlite3541_connection** actual,int flags,const char* vfs,std::chrono::steady_clock::time_point end)noexcept{return store_physical_api::open(file,actual,flags,vfs,end);}
int store_physical_open_v2(const char* file,lattice_sqlite3541_connection** actual,int flags,const char* vfs)noexcept{return store_physical_api::open(file,actual,flags,vfs,std::chrono::steady_clock::now()+std::chrono::seconds(30));}
int store_physical_open_v2_owned_at(const char* file,lattice_sqlite3541_connection** actual,int flags,const char* vfs,std::chrono::steady_clock::time_point end,store_physical_open_original& issued)noexcept{return store_physical_api::open(file,actual,flags,vfs,end,&issued);}
int store_physical_close_owned(store_physical_open_original& issued,lattice_sqlite3541_connection* actual)noexcept{return store_physical_api::close_owned(issued,actual,false);}
int store_physical_close_v2_owned(store_physical_open_original& issued,lattice_sqlite3541_connection* actual)noexcept{return store_physical_api::close_owned(issued,actual,true);}
bool store_physical_process_current()noexcept{return store_physical_api::process_current();}
bool store_physical_is_enrolled(lattice_sqlite3541_connection* native)noexcept{return store_physical_api::enrolled(native);}
bool store_physical_main_for_lower(lattice_sqlite3541_connection* native,lattice_sqlite3541_vfs* expected,lattice_sqlite3541_file*& inner)noexcept{return store_physical_api::main_for_lower(native,expected,inner);}
lattice_sqlite3541_vfs* store_physical_identity_vfs(lattice_sqlite3541_connection* native,const char* schema,lattice_sqlite3541_vfs* observed,lattice_sqlite3541_file*& inner)noexcept{return store_physical_api::identity_vfs(native,schema,observed,inner);}
int store_physical_prepare_v2(lattice_sqlite3541_connection* owner,const char* sql,int size,lattice_sqlite3541_stmt** statement,const char** tail)noexcept{return store_physical_api::prepare(owner,sql,size,0,statement,tail,false);}
int store_physical_prepare_v3(lattice_sqlite3541_connection* owner,const char* sql,int size,unsigned int flags,lattice_sqlite3541_stmt** statement,const char** tail)noexcept{return store_physical_api::prepare(owner,sql,size,flags,statement,tail,true);}
int store_physical_clear_bindings(lattice_sqlite3541_stmt* statement)noexcept{return store_physical_api::clear_bindings(statement);}
int store_physical_create_function(lattice_sqlite3541_connection* owner,const char* name,int n,int encoding,void* data,void(*function)(lattice_sqlite3541_context*,int,lattice_sqlite3541_value**),void(*step)(lattice_sqlite3541_context*,int,lattice_sqlite3541_value**),void(*final)(lattice_sqlite3541_context*))noexcept{return store_physical_api::create_function(owner,name,n,encoding,data,function,step,final,nullptr,false);}
int store_physical_create_function_v2(lattice_sqlite3541_connection* owner,const char* name,int n,int encoding,void* data,void(*function)(lattice_sqlite3541_context*,int,lattice_sqlite3541_value**),void(*step)(lattice_sqlite3541_context*,int,lattice_sqlite3541_value**),void(*final)(lattice_sqlite3541_context*),void(*destroy)(void*))noexcept{return store_physical_api::create_function(owner,name,n,encoding,data,function,step,final,destroy,true);}
int store_physical_create_function_v2_checked(lattice_sqlite3541_connection* owner,const char* name,int n,int encoding,void* data,void(*function)(lattice_sqlite3541_context*,int,lattice_sqlite3541_value**),void(*step)(lattice_sqlite3541_context*,int,lattice_sqlite3541_value**),void(*final)(lattice_sqlite3541_context*),void(*destroy)(void*),bool* entered)noexcept{return store_physical_api::create_function(owner,name,n,encoding,data,function,step,final,destroy,true,entered);}
int store_physical_finalize(lattice_sqlite3541_stmt* actual)noexcept{return store_physical_api::finalize(actual);}
int store_physical_step(lattice_sqlite3541_stmt* actual)noexcept{return store_physical_api::step(actual,false);}
int store_physical_reset(lattice_sqlite3541_stmt* actual)noexcept{return store_physical_api::step(actual,true);}
int store_physical_exec(lattice_sqlite3541_connection* actual,const char* sql,int(*callback)(void*,int,char**,char**),void* data,char** error)noexcept{return store_physical_api::exec(actual,sql,callback,data,error);}
int store_physical_wal_checkpoint(lattice_sqlite3541_connection* actual,const char* schema,int mode,int* log,int* done)noexcept{return store_physical_api::checkpoint(actual,schema,mode,log,done);}
int store_physical_blob_close(lattice_sqlite3541_blob* actual,lattice_sqlite3541_connection* owner)noexcept{return store_physical_api::blob_close(actual,owner);}
int store_physical_close(lattice_sqlite3541_connection* actual)noexcept{return store_physical_api::close(actual,false);}
int store_physical_close_v2(lattice_sqlite3541_connection* actual)noexcept{return store_physical_api::close(actual,true);}
void store_physical_unresourced_open_returned(lattice_sqlite3541_connection* actual)noexcept{store_physical_api::unresourced_open_returned(actual);}
}

#else
#include "store_provider_portable_native.inc"
#endif
