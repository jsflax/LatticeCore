#pragma once
#include "../../LatticeSQLiteProvider/src/provider_engine_interface.h"
#include "store_physical_lifetime.hpp"
#include "ordinary_creator_data_storage.hpp"
#include <lattice/store_physical_api.hpp>
#include <array>
#include <cstddef>
#include <new>
#include <optional>
#include <string>
namespace lattice {struct physical_store_identity;}

namespace lattice::detail {
class store_physical_vfs;
class observer_delivery_open_startup;
class store_resource_catalog_initialization_guard;
class ordinary_cohort_attachment_access;
class store_provider_native_original;
struct sqlite_provider_core_access;
class store_physical_api final {
    friend struct sqlite_provider_core_access;
    friend struct sqlite_provider_boundary_test_access;
    friend struct provider_registration_controls_access;
    friend struct provider_producer_registration_controls_access;
    friend class ::lattice::database;
    friend class observer_delivery_sql_runtime;
    friend class observer_delivery_open_startup;
    friend class recovery_local_producer_adapter;
    friend class recovery_continuous_producer;
    friend class database_initialization_budget;
    friend class store_physical_cleanup_scope;
    friend class store_physical_mutex_return;
    friend class store_physical_vfs;
    friend class store_resource_open;
    friend class ordinary_cohort_attachment_access;
    friend class store_physical_native_scope;
    friend class store_physical_open_original;
    friend class store_physical_policy_original;
    friend struct store_physical_vfs_test_access;
    class registration_scope final {
        lattice_sqlite3541_provider_registration batch_{};
        const std::uint64_t creator_;
        ::lattice::database* const owner_;
        const observer_delivery_open_startup* const open_;
        database_initialization_budget* account_=nullptr; // borrowed from this exact pending Open
        ordinary_creator_data_storage<std::exception_ptr> primary_;
        static int current_(void*)noexcept;
        bool finished_=false;
    public:
        registration_scope(::lattice::database&,const observer_delivery_open_startup&,unsigned family);
        ~registration_scope()noexcept;
        registration_scope(const registration_scope&)=delete;
        registration_scope(registration_scope&&)=delete;
        lattice_sqlite3541_provider_registration* native_()noexcept{return &batch_;}
        int function_(unsigned,const char*,int,int,void*,
            void(*)(lattice_sqlite3541_context*,int,lattice_sqlite3541_value**),void(*)(void*),bool* entered=nullptr);
        int authorizer_(int(*)(void*,int,const char*,const char*,const char*,const char*)noexcept,void*);
        void rethrow_failure_();
        void finish_();
    };
    struct original;
    static original* head_;
    static store_provider_native_original* legacy_head_;
    static bool prepare_legacy_(store_physical_open_original&);
    static const char* prepare_wal_(::lattice::database*,const std::optional<lattice_sqlite3541_int64>&,
        const char*,const char*);
    static bool provider_native_entered_(const lattice_sqlite3541_provider_request&)noexcept;
    static std::exception_ptr provider_open_failure_(const original*)noexcept;
    static bool provider_open_current_(const lattice_sqlite3541_provider_request&,
        std::chrono::steady_clock::time_point)noexcept;
    static void require_provider_registrations_(const store_physical_open_original&,
        const ::lattice::database&,const observer_delivery_open_startup&);
    static void require_producer_registrations_(const ::lattice::database&,const observer_delivery_open_startup&,
        int(*)(void*,int,const char*,const char*,const char*,const char*)noexcept,void*);
    static void require_completed_producer_registrations_(const ::lattice::database&,const observer_delivery_open_startup&,
        int(*)(void*,int,const char*,const char*,const char*,const char*)noexcept,void*);
    static void require_producer_receipt_(const ::lattice::database&,const observer_delivery_open_startup&,
        const database_initialization_budget&,int(*)(void*,int,const char*,const char*,const char*,const char*)noexcept,void*);
    static int open_exclusive_provider_(store_physical_open_original&,const char*,lattice_sqlite3541_connection**,int,
        const char*,std::chrono::steady_clock::time_point);
    static int open_provider_(original*,store_physical_open_original&,const sqlite_provider::v1::vfs_original&,
        const char*,lattice_sqlite3541_connection**,int,std::chrono::steady_clock::time_point,
        ::lattice::database*,const observer_delivery_open_startup*,
        const std::shared_ptr<database_initialization_budget>&);
    static int open_legacy_(store_physical_open_original&,const char*,lattice_sqlite3541_connection**,int,
        const sqlite_provider::v1::vfs_original&,std::chrono::steady_clock::time_point);
    static void release_legacy_(store_physical_open_original&)noexcept;
    static void drain_legacy_()noexcept;
    static void claim_provider_vfs_storage_(const std::shared_ptr<database_initialization_budget>&,std::size_t);
    static std::exception_ptr provider_close_failure_(const store_physical_open_original&)noexcept;
    static bool provider_native_ending_known_(const store_physical_open_original&)noexcept;
    // Actual source1 return DATA only, before Store/account adoption. Requires
    // the SAME owner/Open/Native/physical/account original, never a lookup by
    // address, source2/legacy promotion, new account or SQL permission.
    static std::shared_ptr<database_initialization_budget> protected_account_for_return_(
        ::lattice::database&,const observer_delivery_open_startup&);
    static bool provider_open_unentered_(const original*,const store_physical_open_original&)noexcept;
    static bool complete_provider_unentered_(original*,store_physical_open_original&)noexcept;
    static void provider_legacy_call_(const void*,std::uint64_t,lattice_sqlite3541_connection*,bool,void(*)(void*),void*);
    static sqlite_provider::v1::connection_ref native_ref_(const store_physical_open_original&,lattice_sqlite3541_connection*);
    static void provider_native_call_(const store_physical_open_original&,lattice_sqlite3541_connection*,
        bool statement_ending,void(*fixed_native_work)(void*),void* borrowed_work);
    // One preallocated node/retirement reference per actual admitted original;
    // no new payload, allocation, service or raw-address work item is issued.
    static thread_local original* returned_tails_;
    // Last-owner DELETE custody for a preallocated setup budget which has
    // not necessarily reached any physical-open original yet.
    static thread_local database_initialization_budget* returned_budgets_;
    static void retire_initialization_budget_(database_initialization_budget*)noexcept;
    static void drain_initialization_data_only_()noexcept;
    static thread_local bool draining_tails_;
    static thread_local std::uint64_t native_return_work_;
    static bool managed_return_here_()noexcept;
    static void handoff_returned_tail_(original*)noexcept;
    static void finish_returned_tail_(original*)noexcept;
    // Same finite typed-member profile as the existing bounded-WAL owner.
    // The typed target producer checks the actual SQLite attachment limit
    // before publication, reserving one frame for the primary original.
    // This fixed DATA frame storage is not a queue/RSS quota.
    static constexpr std::size_t maximum_originals=64;
    struct ticket {
        original* value=nullptr; // primary original, or first cleanup original
        std::array<original*,maximum_originals> values{};
        std::size_t count=0;
        std::uint64_t creator=0;
        bool inherited=false;
        ticket()noexcept=default;
        ticket(const ticket&)=delete;
        ticket& operator=(const ticket&)=delete;
        ticket(ticket&& other)noexcept:value(std::exchange(other.value,nullptr)),values(other.values),
            count(std::exchange(other.count,0)),creator(other.creator),inherited(other.inherited){}
        ~ticket()noexcept;
    };
    class api_scope final {
        alignas(store_physical_lifetime::api_return) std::byte storage_[maximum_originals*sizeof(store_physical_lifetime::api_return)];
        std::size_t count_=0;bool entered_=true;
        const std::uint64_t creator_;
        api_scope* previous_=nullptr;
        bool registered_=false;
        static thread_local api_scope* current_;
        friend class store_physical_api;
        store_physical_lifetime::api_return* at_(std::size_t i)noexcept {
            return std::launder(reinterpret_cast<store_physical_lifetime::api_return*>(storage_+i*sizeof(store_physical_lifetime::api_return)));
        }
    public:
        // Empty observation is issued at an ACTUAL legacy C-call boundary,
        // never around earlier resource/domain admission or waiting.
        api_scope()noexcept;
        explicit api_scope(const ticket&)noexcept;
        ~api_scope()noexcept;
        api_scope(const api_scope&)=delete;
        bool entered()const noexcept{return entered_;}
    };
    // Preallocated BEFORE SQLite open. Only the actual lifetime VFS can bind
    // this to the genuine open return and its already-issued physical lease.
    static original* prepare_(const store_physical_lifetime::pin&,void*,void(*)(void*)noexcept,
        const std::shared_ptr<store_resource_catalog_initialization_guard>& initialization_guard={},
        const std::shared_ptr<database_initialization_budget>& initialization_account={},
        bool* actual_native_entered=nullptr);
    static bool publish_(original*,lattice_sqlite3541_connection*,void*,void(*)(void*)noexcept)noexcept;
    static bool publish_member_(original*,lattice_sqlite3541_connection*,void*,void(*)(void*)noexcept)noexcept;
    static ticket capture_issued_(original*)noexcept;
    static void abandon_unpublished_(original*)noexcept;
    static ticket capture_(lattice_sqlite3541_connection*)noexcept;
    static ticket capture_open_(const store_physical_open_original&,lattice_sqlite3541_connection*)noexcept;
    static bool retain_initialization_budget_(store_physical_open_original&,
        const std::shared_ptr<database_initialization_budget>&)noexcept;
    static bool can_issue_open_(const store_physical_open_original&)noexcept;
    static bool issue_open_(store_physical_open_original&,original*)noexcept;
    static bool issue_legacy_open_(store_physical_open_original&);
    static bool open_returned_(store_physical_open_original&,original*,lattice_sqlite3541_connection*)noexcept;
    static ticket capture_cleanup_(const store_physical_open_original&,lattice_sqlite3541_connection*)noexcept;
    static void release_open_(store_physical_open_original&)noexcept;
    static void capture_policy_(const store_physical_open_original&,store_physical_policy_original&)noexcept;
    static void release_policy_(store_physical_policy_original&)noexcept;
    static bool observer_policy_unsettled_(const store_physical_policy_original&)noexcept;
    static void note_observer_policy_unsettled_(const store_physical_policy_original&)noexcept;
    static bool seal_open_(const store_physical_open_original&,std::chrono::steady_clock::time_point)noexcept;
    static bool observer_policy_unsettled_(const store_physical_open_original&)noexcept;
    static void note_observer_policy_unsettled_(const store_physical_open_original&)noexcept;
    static void enter_captured_native_(ticket&&,store_physical_native_scope&)noexcept;
    static void enter_database_native_(const ::lattice::database&,store_physical_native_scope&)noexcept;
    static void enter_database_cleanup_(const ::lattice::database&,store_physical_native_scope&)noexcept;
    static void enter_cleanup_scope_(const store_physical_open_original&,lattice_sqlite3541_connection*,store_physical_native_scope&)noexcept;
    static void enter_native_scope_(const store_physical_open_original&,lattice_sqlite3541_connection*,store_physical_native_scope&)noexcept;
    static bool native_continuation_(original*)noexcept;
    static bool native_custody_here_(original*)noexcept;
    static store_physical_vfs* actual_owner_(const ticket&)noexcept;
    static void enter_native_scope_(lattice_sqlite3541_connection*,store_physical_native_scope&)noexcept;
    static void leave_native_scope_(store_physical_native_scope&)noexcept;
    static void release_(ticket&)noexcept;
    static void release_original_(original*,std::uint64_t)noexcept;
    static bool foreign_protected_()noexcept;
    class attachment_operation final {
        struct implementation;
        implementation* impl_=nullptr;
        explicit attachment_operation(implementation*)noexcept;
        friend class store_physical_api;
    public:
        attachment_operation(attachment_operation&&)noexcept;
        attachment_operation(const attachment_operation&)=delete;
        ~attachment_operation()noexcept;
        void enter();
        void complete();
    };
    static attachment_operation enroll_attachment(lattice_sqlite3541_connection*,const std::string&,const std::string&,
        const ::lattice::physical_store_identity&,std::int64_t,int actual_attached_limit,std::chrono::steady_clock::time_point);
    static attachment_operation retire_attachment(lattice_sqlite3541_connection*,const std::string&,const std::string&,std::int64_t);
public:
    // Private Core implementation header only. Real API-return stack for
    // portable internal C leaves; no Native/resource/Open authority.
    class portable_call_scope final {
        api_scope actual_;
    public:
        portable_call_scope()noexcept=default;
        portable_call_scope(const portable_call_scope&)=delete;
    };
    static int open_owned_(const char*,lattice_sqlite3541_connection**,int,const char*,std::chrono::steady_clock::time_point,
        store_physical_open_original* issued,::lattice::database* wal_owner=nullptr,
        std::optional<lattice_sqlite3541_int64> wal_limit=std::nullopt);
    static int open(const char*,lattice_sqlite3541_connection**,int,const char*,std::chrono::steady_clock::time_point,store_physical_open_original* issued=nullptr)noexcept;
    static int open_initializing_(const char*,lattice_sqlite3541_connection**,int,const char*,std::chrono::steady_clock::time_point,
        store_physical_open_original&,store_resource_initialization_original&,store_resource_initialization_original*,
        ::lattice::database* prospective_owner=nullptr,const observer_delivery_open_startup* prospective_open=nullptr,
        ::lattice::database* wal_owner=nullptr,std::optional<lattice_sqlite3541_int64> wal_limit=std::nullopt);
    static bool process_current()noexcept;
    static void return_mutex_(const store_physical_open_original&,lattice_sqlite3541_mutex*)noexcept;
    static const store_physical_open_original* mutex_owner_(const ::lattice::database&)noexcept;
    static inline thread_local std::uint64_t* mutex_return_observation_=nullptr;
    // Default-null private fixed fault cut at the actual source3 C-entry check.
    // It can only refuse; no callback, Native effect, original or grant is made.
    struct legacy_preentry_observation {bool refuse=false;std::uint64_t reached=0;};
    static inline thread_local legacy_preentry_observation* legacy_preentry_observation_=nullptr;
    struct returned_tail_observation {std::uint64_t completed=0,destroyed=0,budget_enqueued=0,budget_delete_calls=0,legacy_destroyed=0;};
    static inline thread_local returned_tail_observation* returned_tail_observation_=nullptr;
    // Internal return hook, denial-only: no caller can force a drain beneath
    // either genuine Native/API/VFS stack or the return counter work itself.
    static void returned_tail()noexcept;
    static bool enrolled(lattice_sqlite3541_connection*)noexcept;
    static bool main_for_lower(lattice_sqlite3541_connection*,lattice_sqlite3541_vfs*,lattice_sqlite3541_file*&)noexcept;
    static lattice_sqlite3541_vfs* identity_vfs(lattice_sqlite3541_connection*,const char*,lattice_sqlite3541_vfs*,lattice_sqlite3541_file*&)noexcept;
    static int prepare(lattice_sqlite3541_connection*,const char*,int,unsigned int,lattice_sqlite3541_stmt**,const char**,bool)noexcept;
    static int clear_bindings(lattice_sqlite3541_stmt*)noexcept;
    static int create_function(lattice_sqlite3541_connection*,const char*,int,int,void*,void(*)(lattice_sqlite3541_context*,int,lattice_sqlite3541_value**),
        void(*)(lattice_sqlite3541_context*,int,lattice_sqlite3541_value**),void(*)(lattice_sqlite3541_context*),void(*)(void*),bool,bool* actual_native_entered=nullptr)noexcept;
    static int finalize(lattice_sqlite3541_stmt*)noexcept;
    static int step(lattice_sqlite3541_stmt*,bool reset)noexcept;
    static int exec(lattice_sqlite3541_connection*,const char*,int(*)(void*,int,char**,char**),void*,char**)noexcept;
    static int checkpoint(lattice_sqlite3541_connection*,const char*,int,int*,int*)noexcept;
    static int blob_close(lattice_sqlite3541_blob*,lattice_sqlite3541_connection*)noexcept;
    static int close(lattice_sqlite3541_connection*,bool deferred)noexcept;
    static int close_owned(store_physical_open_original&,lattice_sqlite3541_connection*,bool deferred)noexcept;
    static void unresourced_open_returned(lattice_sqlite3541_connection*)noexcept;
};
// Source-internal return-scope adapters. They preserve actual SQLite results;
// an argument is never turned into SQL/ownership authority. No public SDK API.
int store_physical_open_v2(const char*,lattice_sqlite3541_connection**,int,const char*)noexcept;
// The caller supplies its original entry deadline; lower open/cleanup retains
// independently issued original custody, never a renewed deletion deadline.
int store_physical_open_v2_at(const char*,lattice_sqlite3541_connection**,int,const char*,
    std::chrono::steady_clock::time_point original_end)noexcept;
// Owning producers carry the exact preadmitted original through partial/error
// returns. These private implementation adapters never find it by a recycled
// sqlite3* address. Cleanup carries the same original, including first BUSY.
int store_physical_open_v2_owned_at(const char*,lattice_sqlite3541_connection**,int,const char*,
    std::chrono::steady_clock::time_point,store_physical_open_original&)noexcept;
int store_physical_close_owned(store_physical_open_original&,lattice_sqlite3541_connection*)noexcept;
int store_physical_close_v2_owned(store_physical_open_original&,lattice_sqlite3541_connection*)noexcept;
// DATA peeling of only our actual issued wrapper. The caller must already
// hold its genuine Native connection scope; no descriptor or SQL authority is
// created. Unresourced connections preserve their original pointer route.
bool store_physical_main_for_lower(lattice_sqlite3541_connection*,lattice_sqlite3541_vfs* expected_lower,lattice_sqlite3541_file*& actual_inner)noexcept;
lattice_sqlite3541_vfs* store_physical_identity_vfs(lattice_sqlite3541_connection*,const char* schema,lattice_sqlite3541_vfs* observed,lattice_sqlite3541_file*& actual_inner)noexcept;
// Creator denial precedes ANY inherited Native mutex/API access. These DATA
// checks do not manufacture an open original or confer raw access permission.
bool store_physical_process_current()noexcept;
bool store_physical_is_enrolled(lattice_sqlite3541_connection*)noexcept;
int store_physical_prepare_v2(lattice_sqlite3541_connection*,const char*,int,lattice_sqlite3541_stmt**,const char**)noexcept;
int store_physical_prepare_v3(lattice_sqlite3541_connection*,const char*,int,unsigned int,lattice_sqlite3541_stmt**,const char**)noexcept;
int store_physical_clear_bindings(lattice_sqlite3541_stmt*)noexcept;
int store_physical_create_function(lattice_sqlite3541_connection*,const char*,int,int,void*,
    void(*)(lattice_sqlite3541_context*,int,lattice_sqlite3541_value**),void(*)(lattice_sqlite3541_context*,int,lattice_sqlite3541_value**),void(*)(lattice_sqlite3541_context*))noexcept;
int store_physical_create_function_v2(lattice_sqlite3541_connection*,const char*,int,int,void*,
    void(*)(lattice_sqlite3541_context*,int,lattice_sqlite3541_value**),void(*)(lattice_sqlite3541_context*,int,lattice_sqlite3541_value**),void(*)(lattice_sqlite3541_context*),void(*)(void*))noexcept;
// Same guarded v2 call, plus DATA witnessing whether the real SQLite API was
// entered. Pre-Native refusal retains its existing result/destruction contract
// and must not be mislabeled an actual SQLite registration error.
int store_physical_create_function_v2_checked(lattice_sqlite3541_connection*,const char*,int,int,void*,
    void(*)(lattice_sqlite3541_context*,int,lattice_sqlite3541_value**),void(*)(lattice_sqlite3541_context*,int,lattice_sqlite3541_value**),
    void(*)(lattice_sqlite3541_context*),void(*)(void*),bool* actual_native_entered)noexcept;
int store_physical_finalize(lattice_sqlite3541_stmt*)noexcept;
int store_physical_step(lattice_sqlite3541_stmt*)noexcept;
int store_physical_reset(lattice_sqlite3541_stmt*)noexcept;
int store_physical_exec(lattice_sqlite3541_connection*,const char*,int(*)(void*,int,char**,char**),void*,char**)noexcept;
int store_physical_wal_checkpoint(lattice_sqlite3541_connection*,const char*,int,int*,int*)noexcept;
int store_physical_blob_close(lattice_sqlite3541_blob*,lattice_sqlite3541_connection* actual_owner)noexcept;
int store_physical_close(lattice_sqlite3541_connection*)noexcept;
int store_physical_close_v2(lattice_sqlite3541_connection*)noexcept;
// Actual successful/unpublished unresourced open producer only. Supersedes
// stale address associations, never creates a physical resource permission.
void store_physical_unresourced_open_returned(lattice_sqlite3541_connection*)noexcept;
}
