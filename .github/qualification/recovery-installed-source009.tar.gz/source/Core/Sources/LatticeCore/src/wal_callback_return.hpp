#include "provider_native_internal.hpp" // actual private ABI before carrier object declarations
#pragma once
#include "ordinary_creator_data_storage.hpp"
#include <sqlite3.h>
#include <exception>
#include <utility>

namespace lattice::detail {
// Fixed DATA return custody only. Neither lexical frame admits SQL/Native or
// extends the lifetime of its comparison-only connection. A C callback can
// address a recipient only through the ACTUAL currently executing Native turn.
class wal_callback_native_turn;
class wal_callback_return final {
    friend class wal_callback_native_turn;
    const std::uint64_t creator_=database_native_process();
    lattice_sqlite3541_connection* const connection_;
    ordinary_creator_data_storage<std::exception_ptr> primary_;
    wal_callback_return* previous_=nullptr;
    bool linked_=false;
    static inline thread_local wal_callback_return* current_=nullptr;
    static inline thread_local std::uint64_t stack_creator_=0;
    void unlink_()noexcept {
        if(creator_!=database_native_process()||!linked_)return;
        if(current_==this)current_=previous_;
        linked_=false;
    }
public:
    explicit wal_callback_return(lattice_sqlite3541_connection*)noexcept;
    wal_callback_return(const wal_callback_return&)=delete;
    ~wal_callback_return()noexcept{unlink_();}
    static bool pending(lattice_sqlite3541_connection* actual)noexcept {
        if(stack_creator_!=database_native_process())return false;
        auto* frame=current_;
        return frame&&frame->creator_==database_native_process()&&frame->connection_==actual&&bool(frame->primary_.get<0>());
    }
    bool failed()const noexcept {
        return creator_==database_native_process()&&linked_&&bool(const_cast<wal_callback_return*>(this)->primary_.get<0>());
    }
    void finish() {
        if(creator_!=database_native_process())return;
        // An inner helper coalesces only outside an executing Native turn.
        // The outer genuine receiving caller still owns cleanup and the error.
        if(!linked_)return;
        unlink_();
        if(primary_.get<0>())std::rethrow_exception(primary_.get<0>());
    }
};
class wal_callback_native_turn final {
    friend class wal_callback_return;
    const std::uint64_t creator_=database_native_process();
    lattice_sqlite3541_connection* const connection_;
    wal_callback_return* recipient_=nullptr;
    bool delivering_=false;
    wal_callback_native_turn* previous_=nullptr;
    static inline thread_local wal_callback_native_turn* current_=nullptr;
    static inline thread_local std::uint64_t stack_creator_=0;
public:
    explicit wal_callback_native_turn(lattice_sqlite3541_connection* actual)noexcept:connection_(actual) {
        if(stack_creator_!=creator_){current_=nullptr;stack_creator_=creator_;}
        if(wal_callback_return::stack_creator_!=creator_){wal_callback_return::current_=nullptr;wal_callback_return::stack_creator_=creator_;}
        previous_=current_;
        auto* candidate=wal_callback_return::current_;
        if(candidate&&candidate->creator_==creator_&&candidate->connection_==actual) {
            recipient_=candidate;
            // A recursive raw C call cannot consume the outer call's carrier.
            // A genuine nested C++ call installs its own distinct recipient.
            for(auto* turn=previous_;turn;turn=turn->previous_) {
                if(turn->creator_!=creator_){recipient_=nullptr;break;}
                if(turn->recipient_==candidate){recipient_=nullptr;break;}
            }
        }
        current_=this;
    }
    wal_callback_native_turn(const wal_callback_native_turn&)=delete;
    ~wal_callback_native_turn()noexcept {
        if(creator_==database_native_process()&&current_==this)current_=previous_;
    }
    static bool receives(lattice_sqlite3541_connection* actual)noexcept {
        if(stack_creator_!=database_native_process())return false;
        auto* turn=current_;
        return turn&&turn->creator_==database_native_process()&&turn->connection_==actual&&turn->recipient_&&!turn->delivering_&&wal_callback_return::current_==turn->recipient_;
    }
    class delivery_scope final {
        const std::uint64_t creator_=database_native_process();
        wal_callback_native_turn* turn_=nullptr;
    public:
        explicit delivery_scope(lattice_sqlite3541_connection* actual)noexcept {
            if(receives(actual)){turn_=current_;turn_->delivering_=true;}
        }
        delivery_scope(const delivery_scope&)=delete;
        ~delivery_scope()noexcept {
            if(creator_==database_native_process()&&turn_&&current_==turn_)turn_->delivering_=false;
        }
    };
    static void capture(lattice_sqlite3541_connection* actual)noexcept {
        if(!receives(actual))return;
        auto* recipient=current_->recipient_;
        if(!recipient->primary_.get<0>())recipient->primary_.get<0>()=std::current_exception();
    }
};
inline wal_callback_return::wal_callback_return(lattice_sqlite3541_connection* actual)noexcept:connection_(actual) {
    if(stack_creator_!=creator_){current_=nullptr;stack_creator_=creator_;}
    if(wal_callback_native_turn::stack_creator_!=creator_){wal_callback_native_turn::current_=nullptr;wal_callback_native_turn::stack_creator_=creator_;}
    // Internal prepare/step helpers share an existing receiving caller only
    // while C is not executing. Callback-created C++ calls always get their
    // own frame, including when they use the very same connection.
    if(!wal_callback_native_turn::current_&&current_&&current_->connection_==actual)return;
    previous_=current_;current_=this;linked_=true;
}
}
