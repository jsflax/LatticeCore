// swift-tools-version: 6.0
import PackageDescription
// Standalone provider definition/reference. The parent package must name this
// dependency for EVERY native consumer in one coherent later migration.
let package = Package(
    name: "LatticeSQLiteProvider",
    products: [.library(name: "LatticeSQLiteProvider", type: .static, targets: ["LatticeSQLiteProvider"])],
    targets: [.target(name: "LatticeSQLiteProvider", path: ".", exclude: ["CMakeLists.txt", "tests"],
        sources: ["src/sqlite_provider_engine.c", "src/provider.cpp"], publicHeadersPath: "include",
        cSettings: [.define("LATTICE_SQLITE3541_THREADSAFE",to:"1"),
            .define("LATTICE_SQLITE3541_ENABLE_FTS5",to:"1"),
            .define("LATTICE_SQLITE3541_ENABLE_RTREE",to:"1"),
            .define("LATTICE_SQLITE3541_OMIT_LOAD_EXTENSION",to:"1"),
            .unsafeFlags(["-std=c11","-fvisibility=hidden"])],
        cxxSettings: [.unsafeFlags(["-std=c++20","-fvisibility=hidden","-fvisibility-inlines-hidden"])],
        linkerSettings: [.linkedLibrary("m",.when(platforms:[.linux])),
            .linkedLibrary("pthread",.when(platforms:[.linux]))])],
    cLanguageStandard: .c11, cxxLanguageStandard: .cxx20)
