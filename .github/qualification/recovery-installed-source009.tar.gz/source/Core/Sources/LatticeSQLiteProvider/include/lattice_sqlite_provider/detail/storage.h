#ifndef LATTICE_SQLITE3541_PROVIDER_STORAGE_H
#define LATTICE_SQLITE3541_PROVIDER_STORAGE_H
#include <stdint.h>
struct lattice_sqlite3541_connection;
struct lattice_sqlite3541_vfs;
struct lattice_sqlite3541_provider_vfs {
  const void *instance;
  uint64_t creator;
  const void *original;
  struct lattice_sqlite3541_vfs *actual;
};
struct lattice_sqlite3541_provider_request {
  const void *instance;
  uint64_t creator;
  uint64_t serial;
  const void *original;
  const void *core_owner;
  const void *core_open;
  const void *physical_original;
  const void *account_original;
  const struct lattice_sqlite3541_provider_vfs *vfs;
  unsigned phase;
  unsigned source; /* 1: protected Open; 2: resource-only physical; 3: genuine legacy Native owner */
  const void *connection_original;
};
struct lattice_sqlite3541_provider_fact {
  const void *instance;
  uint64_t creator;
  uint64_t serial;
  const void *core_owner;
  const void *core_open;
  const void *physical_original;
  const void *account_original;
  const struct lattice_sqlite3541_provider_vfs *vfs;
  const void *connection_original;
  const void *rtree_module;
  const void *rtree_i32_module;
  const void *fts5_module;
  const void *fts5_aux;
  unsigned phase;
  unsigned source;
  unsigned builtins;
  unsigned revoked;
  unsigned autoload_suppressed;
  unsigned registration_attempted;
  unsigned registration_complete;
  int (*producer_authorizer)(void*,int,const char*,const char*,const char*,const char*);
  void *producer_authorizer_context;
  int first_rc;
};
#endif
