#pragma once
#include "provider.hpp"
#include <cstddef>
#include <cstdint>
// Deliberately versioned C++ Native escape. No system object enters this API.
// These are lexical borrows of an actual producer-owned connection original.
// The original wrapper must remain alive and unmoved throughout every borrow;
// this retains the existing Native escape precondition, not destruction safety.
// Core must apply its actual policy/physical/operation gates before issuing or
// using one. A reference proves engine origin only, never SQL/profile authority.
namespace lattice::sqlite_provider::v1 {
class connection_ref final {
    friend class connection_original;
    friend struct native_access;
    const void* instance_;
    std::uint64_t creator_,serial_;
    const connection_original* original_;
    void* actual_;
    explicit connection_ref(const connection_original&);
public:
    connection_ref(const connection_ref&)=delete;
    connection_ref(connection_ref&&)=delete;
    connection_ref& operator=(const connection_ref&)=delete;
    ~connection_ref()noexcept=default;
};
class statement_original final {
    friend struct native_access;
    const void* instance_=nullptr;
    std::uint64_t creator_=0,serial_=0;
    const connection_original* connection_=nullptr;
    void* actual_connection_=nullptr;
    void* actual_=nullptr;
public:
    statement_original()noexcept=default;
    statement_original(const statement_original&)=delete;
    statement_original(statement_original&&)=delete;
    statement_original& operator=(const statement_original&)=delete;
    ~statement_original()noexcept=default; // Actual caller owns checked ending.
};
// Explicit Native results remain their actual rc. Structural origin denial is
// an error(rejection), never a fabricated Native rc. No operation reopens,
// heals a registration receipt, issues an account or finalizes foreign work.
// These genuine C++ calls receive an actual observer exception only after the
// same Native/API turn returns. prepare binds any genuine partial output before
// throwing; finalize consumes its actual statement identity before throwing.
// Callers retain checked cleanup responsibility for a bound partial output.
int prepare_v2(const connection_ref&,const char*,int,statement_original&,const char**);
int prepare_v3(const connection_ref&,const char*,int,unsigned,statement_original&,const char**);
int step(const statement_original&);
int reset(const statement_original&);
int clear_bindings(const statement_original&);
int finalize(statement_original&);
int bind_null(const statement_original&,int);
int bind_int64(const statement_original&,int,std::int64_t);
int bind_double(const statement_original&,int,double);
int bind_blob64(const statement_original&,int,const void*,std::uint64_t,lattice_sqlite3541_destructor_type);
int bind_text64(const statement_original&,int,const char*,std::uint64_t,lattice_sqlite3541_destructor_type,unsigned char);
int bind_zeroblob64(const statement_original&,int,std::uint64_t);
int bind_parameter_count(const statement_original&);
const char* bind_parameter_name(const statement_original&,int);
int column_count(const statement_original&);
int column_type(const statement_original&,int);
int column_int(const statement_original&,int);
std::int64_t column_int64(const statement_original&,int);
double column_double(const statement_original&,int);
const unsigned char* column_text(const statement_original&,int);
const void* column_blob(const statement_original&,int);
int column_bytes(const statement_original&,int);
const char* column_name(const statement_original&,int);
int stmt_busy(const statement_original&);
int stmt_readonly(const statement_original&);
const char* sql(const statement_original&);
int get_autocommit(const connection_ref&);
int errcode(const connection_ref&);
int extended_errcode(const connection_ref&);
const char* errmsg(const connection_ref&);
std::int64_t changes64(const connection_ref&);
std::int64_t last_insert_rowid(const connection_ref&);
void interrupt(const connection_ref&);
}
