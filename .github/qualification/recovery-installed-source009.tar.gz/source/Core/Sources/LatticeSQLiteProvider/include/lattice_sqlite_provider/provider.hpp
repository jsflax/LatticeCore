#pragma once
#include "types.h"
#include "detail/storage.h"
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <exception>
#include <thread>
// Provider-owned types are DISTINCT from system sqlite3 objects. No raw-adopt,
// reinterpret/cast helper, global sqlite3.h replacement or extension thunk API.
namespace lattice {
class database;
namespace detail {
class store_physical_api;
class store_physical_vfs;
class wal_extent_vfs;
class ordinary_target_staging_io;
class observer_delivery_open_startup;
class store_physical_open_original;
class database_initialization_budget;
class store_provider_native_original;
class store_deletion_operation;
struct store_physical_vfs_test_access;
struct readonly_open_provider_test_access;
}}
namespace lattice::sqlite_provider::v1 {
class vfs_original;
class open_original;
class connection_original;
class connection_ref;
class statement_original;
struct native_access;
struct engine_access;
enum class rejection {invalid_original,foreign_instance,inherited_original,expired_original,
    consumed_original,changed_vfs,vfs_in_use,serial_exhausted,native_failure};
class error final:public std::exception {
    rejection reason_;
    int actual_=0;
    bool has_actual_=false;
public:
    explicit error(rejection reason)noexcept:reason_(reason){}
    explicit error(int actual)noexcept:reason_(rejection::native_failure),actual_(actual),has_actual_(true){}
    rejection reason()const noexcept{return reason_;}
    bool has_actual_code()const noexcept{return has_actual_;}
    int actual_code()const noexcept{return actual_;} // meaningful only if has_actual_code()
    const char* what()const noexcept override{return "private SQLite provider admission/ending failed";}
};
// This record captures the ACTUAL registered table/lower descriptions. Merely
// having a similarly named/laid-out struct cannot construct an original.
class vfs_original final {
    friend struct engine_access;
    friend class open_original;
    friend class ::lattice::detail::store_physical_vfs;
    friend class ::lattice::detail::wal_extent_vfs;
    friend class ::lattice::detail::ordinary_target_staging_io;
    friend class ::lattice::detail::store_deletion_operation;
    friend class ::lattice::detail::store_physical_api;
    friend struct ::lattice::detail::store_physical_vfs_test_access;
    friend struct ::lattice::detail::readonly_open_provider_test_access;
    const void* instance_=nullptr;
    std::uint64_t creator_=0;
    lattice_sqlite3541_provider_vfs record_{};
    lattice_sqlite3541_vfs* actual_=nullptr;
    lattice_sqlite3541_vfs snapshot_{};
    std::array<char,256> name_{};
    const vfs_original* lower_=nullptr;
    unsigned depth_=0;
    vfs_original* registry_next_=nullptr; // intrusive actual-issued original, no per-selection allocation
    std::uint64_t selections_=0,native_pins_=0;
    bool registry_listed_=false,unregistering_=false;
    static void publish_selection_(vfs_original&);
    static void release_selection_(const vfs_original*)noexcept;
    class selection final {
        friend class vfs_original;
        friend class ::lattice::detail::store_physical_api;
        const vfs_original* actual_;
        explicit selection(const vfs_original&)noexcept;
    public:
        selection(const selection&)=delete;
        selection(selection&&)=delete;
        ~selection()noexcept;
    };
    static selection select_(const char* actual_name);
    enum class phase:unsigned {prepared,registered,retired,unknown};
    phase phase_=phase::prepared;
    struct builtin_key{};
    vfs_original(builtin_key,lattice_sqlite3541_vfs&);
    vfs_original(lattice_sqlite3541_vfs&,const vfs_original&);
    static const vfs_original& builtin_();
    int register_();
    int unregister_();
    bool current_()const noexcept;
    bool native_in_use_()const; // fixed DATA observation, never an ending grant
public:
    vfs_original(const vfs_original&)=delete;
    vfs_original& operator=(const vfs_original&)=delete;
    vfs_original(vfs_original&&)=delete;
    ~vfs_original()noexcept=default; // Actual Core issuer owns explicit ending.
};
// Fixed source-private original. Only the real Core physical issuer can
// prepare it from its SAME owner/Open/physical/account and actual VFS original.
// That issuer MUST perform its current creator/role/budget/physical checks.
// No public default constructor or bool/filename/pointer adoption is provided.
class open_original final {
    friend struct engine_access;
    friend class connection_original;
    friend class ::lattice::detail::store_physical_api;
    friend class ::lattice::detail::observer_delivery_open_startup;
    const void* instance_;
    const std::uint64_t creator_;
    const std::thread::id builder_;
    const std::chrono::steady_clock::time_point end_;
    const ::lattice::database* owner_;
    const ::lattice::detail::observer_delivery_open_startup* open_;
    const void* physical_; // exact typed Core source selected by source_, never raw Native
    const ::lattice::detail::database_initialization_budget* account_;
    const vfs_original* vfs_;
    std::uint64_t serial_=0;
    // Closed source kind: protected Open or physical-only legacy producer.
    // This DATA never turns legacy into a pending delivery/profile grant.
    const unsigned source_;
    const connection_original* recipient_=nullptr;
    // Only the closed actual Core issuer binds its own private fixed DATA
    // validator. Not a public/user callback, Native work or renewable grant.
    bool(*core_current_)(const lattice_sqlite3541_provider_request&,
        std::chrono::steady_clock::time_point)noexcept=nullptr;
    bool(*core_entered_)(const lattice_sqlite3541_provider_request&)noexcept=nullptr;
    unsigned phase_=0;
    lattice_sqlite3541_provider_request record_{};
    open_original(const ::lattice::database&,
        const ::lattice::detail::observer_delivery_open_startup&,
        const ::lattice::detail::store_physical_open_original&,
        const ::lattice::detail::database_initialization_budget&,
        const vfs_original&,std::chrono::steady_clock::time_point);
    // Distinct genuine producers: resource-only physical original, or the
    // actual uninstalled/memory Native allocation owner. Neither is an Open,
    // account, freshness witness or protected registration receipt.
    open_original(const ::lattice::detail::store_physical_open_original&,
        const vfs_original&,std::chrono::steady_clock::time_point);
    open_original(const ::lattice::detail::store_provider_native_original&,
        const vfs_original&,std::chrono::steady_clock::time_point);
public:
    open_original(const open_original&)=delete;
    open_original(open_original&&)=delete;
    open_original& operator=(const open_original&)=delete;
    ~open_original()noexcept=default;
};
// Only a genuine Native return fills this fixed original. Foreign-image
// instance/creator checks precede every implementation/Native dereference.
class connection_original final {
    friend struct engine_access;
    friend struct native_access;
    friend class connection_ref;
    friend class ::lattice::database;
    friend class ::lattice::detail::store_physical_api;
    const void* instance_=nullptr;
    std::uint64_t creator_=0,serial_=0;
    unsigned source_=0;
    void* actual_=nullptr;
    const void* owner_=nullptr;
    const void* open_=nullptr;
    const void* physical_=nullptr;
    const void* account_=nullptr;
    const vfs_original* vfs_=nullptr;
    unsigned vfs_pin_count_=0; // guarded by actual VFS original metadata leaf
    bool attempted_=false,retired_=false,native_entered_=false;
    std::atomic<bool> native_ended_{false};
    bool native_ending_known_()const noexcept;
    // Distinct DATA absence proof, checked only after the actual Core caller
    // and owning reference returned; never a Native-close/free receipt.
    bool no_native_object_for_(const ::lattice::detail::store_provider_native_original&)const noexcept;
    static int open_native_into_(open_original&,connection_original&,const char*,int);
    int close_();
    int close_deferred_();
    bool registrations_current_()const noexcept;
    bool borrow_current_()const noexcept;
#if defined(__clang__)
    connection_ref borrow_()const [[clang::lifetimebound]];
#else
    connection_ref borrow_()const;
#endif
public:
    connection_original()noexcept=default;
    connection_original(const connection_original&)=delete;
    connection_original(connection_original&&)=delete;
    connection_original& operator=(const connection_original&)=delete;
    ~connection_original()noexcept=default; // No inferred Native ending.
};
}
