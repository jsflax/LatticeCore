/*
** 2006 June 7
**
** The author disclaims copyright to this source code.  In place of
** a legal notice, here is a blessing:
**
**    May you do good and not evil.
**    May you find forgiveness for yourself and forgive others.
**    May you share freely, never taking more than you give.
**
*************************************************************************
** This header file defines the SQLite interface for use by
** shared libraries that want to be imported as extensions into
** an SQLite instance.  Shared libraries that intend to be loaded
** as extensions by SQLite should #include this file instead of 
** sqlite3.h.
*/
#ifndef LATTICE_SQLITE3541_PRIVATE_3EXT_H
#define LATTICE_SQLITE3541_PRIVATE_3EXT_H
#include "native_api.h" /* SAME private provider types; never system SQLite */

/*
** The following structure holds pointers to all of the SQLite API
** routines.
**
** WARNING:  In order to maintain backwards compatibility, add new
** interfaces to the end of this structure only.  If you insert new
** interfaces in the middle of this structure, then older different
** versions of SQLite will not be able to load each other's shared
** libraries!
*/
struct lattice_sqlite3541_api_routines {
  void * (*aggregate_context)(lattice_sqlite3541_context*,int nBytes);
  int  (*aggregate_count)(lattice_sqlite3541_context*);
  int  (*bind_blob)(lattice_sqlite3541_stmt*,int,const void*,int n,void(*)(void*));
  int  (*bind_double)(lattice_sqlite3541_stmt*,int,double);
  int  (*bind_int)(lattice_sqlite3541_stmt*,int,int);
  int  (*bind_int64)(lattice_sqlite3541_stmt*,int,lattice_sqlite3541_legacy_int64);
  int  (*bind_null)(lattice_sqlite3541_stmt*,int);
  int  (*bind_parameter_count)(lattice_sqlite3541_stmt*);
  int  (*bind_parameter_index)(lattice_sqlite3541_stmt*,const char*zName);
  const char * (*bind_parameter_name)(lattice_sqlite3541_stmt*,int);
  int  (*bind_text)(lattice_sqlite3541_stmt*,int,const char*,int n,void(*)(void*));
  int  (*bind_text16)(lattice_sqlite3541_stmt*,int,const void*,int,void(*)(void*));
  int  (*bind_value)(lattice_sqlite3541_stmt*,int,const lattice_sqlite3541_value*);
  int  (*busy_handler)(lattice_sqlite3541_connection*,int(*)(void*,int),void*);
  int  (*busy_timeout)(lattice_sqlite3541_connection*,int ms);
  int  (*changes)(lattice_sqlite3541_connection*);
  int  (*close)(lattice_sqlite3541_connection*);
  int  (*collation_needed)(lattice_sqlite3541_connection*,void*,void(*)(void*,lattice_sqlite3541_connection*,
                           int eTextRep,const char*));
  int  (*collation_needed16)(lattice_sqlite3541_connection*,void*,void(*)(void*,lattice_sqlite3541_connection*,
                             int eTextRep,const void*));
  const void * (*column_blob)(lattice_sqlite3541_stmt*,int iCol);
  int  (*column_bytes)(lattice_sqlite3541_stmt*,int iCol);
  int  (*column_bytes16)(lattice_sqlite3541_stmt*,int iCol);
  int  (*column_count)(lattice_sqlite3541_stmt*pStmt);
  const char * (*column_database_name)(lattice_sqlite3541_stmt*,int);
  const void * (*column_database_name16)(lattice_sqlite3541_stmt*,int);
  const char * (*column_decltype)(lattice_sqlite3541_stmt*,int i);
  const void * (*column_decltype16)(lattice_sqlite3541_stmt*,int);
  double  (*column_double)(lattice_sqlite3541_stmt*,int iCol);
  int  (*column_int)(lattice_sqlite3541_stmt*,int iCol);
  lattice_sqlite3541_legacy_int64  (*column_int64)(lattice_sqlite3541_stmt*,int iCol);
  const char * (*column_name)(lattice_sqlite3541_stmt*,int);
  const void * (*column_name16)(lattice_sqlite3541_stmt*,int);
  const char * (*column_origin_name)(lattice_sqlite3541_stmt*,int);
  const void * (*column_origin_name16)(lattice_sqlite3541_stmt*,int);
  const char * (*column_table_name)(lattice_sqlite3541_stmt*,int);
  const void * (*column_table_name16)(lattice_sqlite3541_stmt*,int);
  const unsigned char * (*column_text)(lattice_sqlite3541_stmt*,int iCol);
  const void * (*column_text16)(lattice_sqlite3541_stmt*,int iCol);
  int  (*column_type)(lattice_sqlite3541_stmt*,int iCol);
  lattice_sqlite3541_value* (*column_value)(lattice_sqlite3541_stmt*,int iCol);
  void * (*commit_hook)(lattice_sqlite3541_connection*,int(*)(void*),void*);
  int  (*complete)(const char*sql);
  int  (*complete16)(const void*sql);
  int  (*create_collation)(lattice_sqlite3541_connection*,const char*,int,void*,
                           int(*)(void*,int,const void*,int,const void*));
  int  (*create_collation16)(lattice_sqlite3541_connection*,const void*,int,void*,
                             int(*)(void*,int,const void*,int,const void*));
  int  (*create_function)(lattice_sqlite3541_connection*,const char*,int,int,void*,
                          void (*xFunc)(lattice_sqlite3541_context*,int,lattice_sqlite3541_value**),
                          void (*xStep)(lattice_sqlite3541_context*,int,lattice_sqlite3541_value**),
                          void (*xFinal)(lattice_sqlite3541_context*));
  int  (*create_function16)(lattice_sqlite3541_connection*,const void*,int,int,void*,
                            void (*xFunc)(lattice_sqlite3541_context*,int,lattice_sqlite3541_value**),
                            void (*xStep)(lattice_sqlite3541_context*,int,lattice_sqlite3541_value**),
                            void (*xFinal)(lattice_sqlite3541_context*));
  int (*create_module)(lattice_sqlite3541_connection*,const char*,const lattice_sqlite3541_module*,void*);
  int  (*data_count)(lattice_sqlite3541_stmt*pStmt);
  lattice_sqlite3541_connection * (*db_handle)(lattice_sqlite3541_stmt*);
  int (*declare_vtab)(lattice_sqlite3541_connection*,const char*);
  int  (*enable_shared_cache)(int);
  int  (*errcode)(lattice_sqlite3541_connection*db);
  const char * (*errmsg)(lattice_sqlite3541_connection*);
  const void * (*errmsg16)(lattice_sqlite3541_connection*);
  int  (*exec)(lattice_sqlite3541_connection*,const char*,lattice_sqlite3541_callback,void*,char**);
  int  (*expired)(lattice_sqlite3541_stmt*);
  int  (*finalize)(lattice_sqlite3541_stmt*pStmt);
  void  (*free)(void*);
  void  (*free_table)(char**result);
  int  (*get_autocommit)(lattice_sqlite3541_connection*);
  void * (*get_auxdata)(lattice_sqlite3541_context*,int);
  int  (*get_table)(lattice_sqlite3541_connection*,const char*,char***,int*,int*,char**);
  int  (*global_recover)(void);
  void  (*interruptx)(lattice_sqlite3541_connection*);
  lattice_sqlite3541_legacy_int64  (*last_insert_rowid)(lattice_sqlite3541_connection*);
  const char * (*libversion)(void);
  int  (*libversion_number)(void);
  void *(*malloc)(int);
  char *(LATTICE_SQLITE3541_CDECL*mprintf)(const char*,...);
  int  (*open)(const char*,lattice_sqlite3541_connection**);
  int  (*open16)(const void*,lattice_sqlite3541_connection**);
  int  (*prepare)(lattice_sqlite3541_connection*,const char*,int,lattice_sqlite3541_stmt**,const char**);
  int  (*prepare16)(lattice_sqlite3541_connection*,const void*,int,lattice_sqlite3541_stmt**,const void**);
  void * (*profile)(lattice_sqlite3541_connection*,void(*)(void*,const char*,lattice_sqlite3541_legacy_uint64),void*);
  void  (*progress_handler)(lattice_sqlite3541_connection*,int,int(*)(void*),void*);
  void *(*realloc)(void*,int);
  int  (*reset)(lattice_sqlite3541_stmt*pStmt);
  void  (*result_blob)(lattice_sqlite3541_context*,const void*,int,void(*)(void*));
  void  (*result_double)(lattice_sqlite3541_context*,double);
  void  (*result_error)(lattice_sqlite3541_context*,const char*,int);
  void  (*result_error16)(lattice_sqlite3541_context*,const void*,int);
  void  (*result_int)(lattice_sqlite3541_context*,int);
  void  (*result_int64)(lattice_sqlite3541_context*,lattice_sqlite3541_legacy_int64);
  void  (*result_null)(lattice_sqlite3541_context*);
  void  (*result_text)(lattice_sqlite3541_context*,const char*,int,void(*)(void*));
  void  (*result_text16)(lattice_sqlite3541_context*,const void*,int,void(*)(void*));
  void  (*result_text16be)(lattice_sqlite3541_context*,const void*,int,void(*)(void*));
  void  (*result_text16le)(lattice_sqlite3541_context*,const void*,int,void(*)(void*));
  void  (*result_value)(lattice_sqlite3541_context*,lattice_sqlite3541_value*);
  void *(*rollback_hook)(lattice_sqlite3541_connection*,void(*)(void*),void*);
  int  (*set_authorizer)(lattice_sqlite3541_connection*,int(*)(void*,int,const char*,const char*,
                         const char*,const char*),void*);
  void  (*set_auxdata)(lattice_sqlite3541_context*,int,void*,void (*)(void*));
  char *(LATTICE_SQLITE3541_CDECL*xsnprintf)(int,char*,const char*,...);
  int  (*step)(lattice_sqlite3541_stmt*);
  int  (*table_column_metadata)(lattice_sqlite3541_connection*,const char*,const char*,const char*,
                                char const**,char const**,int*,int*,int*);
  void  (*thread_cleanup)(void);
  int  (*total_changes)(lattice_sqlite3541_connection*);
  void * (*trace)(lattice_sqlite3541_connection*,void(*xTrace)(void*,const char*),void*);
  int  (*transfer_bindings)(lattice_sqlite3541_stmt*,lattice_sqlite3541_stmt*);
  void * (*update_hook)(lattice_sqlite3541_connection*,void(*)(void*,int ,char const*,char const*,
                                         lattice_sqlite3541_legacy_int64),void*);
  void * (*user_data)(lattice_sqlite3541_context*);
  const void * (*value_blob)(lattice_sqlite3541_value*);
  int  (*value_bytes)(lattice_sqlite3541_value*);
  int  (*value_bytes16)(lattice_sqlite3541_value*);
  double  (*value_double)(lattice_sqlite3541_value*);
  int  (*value_int)(lattice_sqlite3541_value*);
  lattice_sqlite3541_legacy_int64  (*value_int64)(lattice_sqlite3541_value*);
  int  (*value_numeric_type)(lattice_sqlite3541_value*);
  const unsigned char * (*value_text)(lattice_sqlite3541_value*);
  const void * (*value_text16)(lattice_sqlite3541_value*);
  const void * (*value_text16be)(lattice_sqlite3541_value*);
  const void * (*value_text16le)(lattice_sqlite3541_value*);
  int  (*value_type)(lattice_sqlite3541_value*);
  char *(*vmprintf)(const char*,va_list);
  /* Added ??? */
  int (*overload_function)(lattice_sqlite3541_connection*, const char *zFuncName, int nArg);
  /* Added by 3.3.13 */
  int (*prepare_v2)(lattice_sqlite3541_connection*,const char*,int,lattice_sqlite3541_stmt**,const char**);
  int (*prepare16_v2)(lattice_sqlite3541_connection*,const void*,int,lattice_sqlite3541_stmt**,const void**);
  int (*clear_bindings)(lattice_sqlite3541_stmt*);
  /* Added by 3.4.1 */
  int (*create_module_v2)(lattice_sqlite3541_connection*,const char*,const lattice_sqlite3541_module*,void*,
                          void (*xDestroy)(void *));
  /* Added by 3.5.0 */
  int (*bind_zeroblob)(lattice_sqlite3541_stmt*,int,int);
  int (*blob_bytes)(lattice_sqlite3541_blob*);
  int (*blob_close)(lattice_sqlite3541_blob*);
  int (*blob_open)(lattice_sqlite3541_connection*,const char*,const char*,const char*,lattice_sqlite3541_int64,
                   int,lattice_sqlite3541_blob**);
  int (*blob_read)(lattice_sqlite3541_blob*,void*,int,int);
  int (*blob_write)(lattice_sqlite3541_blob*,const void*,int,int);
  int (*create_collation_v2)(lattice_sqlite3541_connection*,const char*,int,void*,
                             int(*)(void*,int,const void*,int,const void*),
                             void(*)(void*));
  int (*file_control)(lattice_sqlite3541_connection*,const char*,int,void*);
  lattice_sqlite3541_int64 (*memory_highwater)(int);
  lattice_sqlite3541_int64 (*memory_used)(void);
  lattice_sqlite3541_mutex *(*mutex_alloc)(int);
  void (*mutex_enter)(lattice_sqlite3541_mutex*);
  void (*mutex_free)(lattice_sqlite3541_mutex*);
  void (*mutex_leave)(lattice_sqlite3541_mutex*);
  int (*mutex_try)(lattice_sqlite3541_mutex*);
  int (*open_v2)(const char*,lattice_sqlite3541_connection**,int,const char*);
  int (*release_memory)(int);
  void (*result_error_nomem)(lattice_sqlite3541_context*);
  void (*result_error_toobig)(lattice_sqlite3541_context*);
  int (*sleep)(int);
  void (*soft_heap_limit)(int);
  lattice_sqlite3541_vfs *(*vfs_find)(const char*);
  int (*vfs_register)(lattice_sqlite3541_vfs*,int);
  int (*vfs_unregister)(lattice_sqlite3541_vfs*);
  int (*xthreadsafe)(void);
  void (*result_zeroblob)(lattice_sqlite3541_context*,int);
  void (*result_error_code)(lattice_sqlite3541_context*,int);
  int (LATTICE_SQLITE3541_CDECL*test_control)(int, ...);
  void (*randomness)(int,void*);
  lattice_sqlite3541_connection *(*context_db_handle)(lattice_sqlite3541_context*);
  int (*extended_result_codes)(lattice_sqlite3541_connection*,int);
  int (*limit)(lattice_sqlite3541_connection*,int,int);
  lattice_sqlite3541_stmt *(*next_stmt)(lattice_sqlite3541_connection*,lattice_sqlite3541_stmt*);
  const char *(*sql)(lattice_sqlite3541_stmt*);
  int (*status)(int,int*,int*,int);
  int (*backup_finish)(lattice_sqlite3541_backup*);
  lattice_sqlite3541_backup *(*backup_init)(lattice_sqlite3541_connection*,const char*,lattice_sqlite3541_connection*,const char*);
  int (*backup_pagecount)(lattice_sqlite3541_backup*);
  int (*backup_remaining)(lattice_sqlite3541_backup*);
  int (*backup_step)(lattice_sqlite3541_backup*,int);
  const char *(*compileoption_get)(int);
  int (*compileoption_used)(const char*);
  int (*create_function_v2)(lattice_sqlite3541_connection*,const char*,int,int,void*,
                            void (*xFunc)(lattice_sqlite3541_context*,int,lattice_sqlite3541_value**),
                            void (*xStep)(lattice_sqlite3541_context*,int,lattice_sqlite3541_value**),
                            void (*xFinal)(lattice_sqlite3541_context*),
                            void(*xDestroy)(void*));
  int (LATTICE_SQLITE3541_CDECL*db_config)(lattice_sqlite3541_connection*,int,...);
  lattice_sqlite3541_mutex *(*db_mutex)(lattice_sqlite3541_connection*);
  int (*db_status)(lattice_sqlite3541_connection*,int,int*,int*,int);
  int (*extended_errcode)(lattice_sqlite3541_connection*);
  void (LATTICE_SQLITE3541_CDECL*log)(int,const char*,...);
  lattice_sqlite3541_int64 (*soft_heap_limit64)(lattice_sqlite3541_int64);
  const char *(*sourceid)(void);
  int (*stmt_status)(lattice_sqlite3541_stmt*,int,int);
  int (*strnicmp)(const char*,const char*,int);
  int (*unlock_notify)(lattice_sqlite3541_connection*,void(*)(void**,int),void*);
  int (*wal_autocheckpoint)(lattice_sqlite3541_connection*,int);
  int (*wal_checkpoint)(lattice_sqlite3541_connection*,const char*);
  void *(*wal_hook)(lattice_sqlite3541_connection*,int(*)(void*,lattice_sqlite3541_connection*,const char*,int),void*);
  int (*blob_reopen)(lattice_sqlite3541_blob*,lattice_sqlite3541_int64);
  int (LATTICE_SQLITE3541_CDECL*vtab_config)(lattice_sqlite3541_connection*,int op,...);
  int (*vtab_on_conflict)(lattice_sqlite3541_connection*);
  /* Version 3.7.16 and later */
  int (*close_v2)(lattice_sqlite3541_connection*);
  const char *(*db_filename)(lattice_sqlite3541_connection*,const char*);
  int (*db_readonly)(lattice_sqlite3541_connection*,const char*);
  int (*db_release_memory)(lattice_sqlite3541_connection*);
  const char *(*errstr)(int);
  int (*stmt_busy)(lattice_sqlite3541_stmt*);
  int (*stmt_readonly)(lattice_sqlite3541_stmt*);
  int (*stricmp)(const char*,const char*);
  int (*uri_boolean)(const char*,const char*,int);
  lattice_sqlite3541_int64 (*uri_int64)(const char*,const char*,lattice_sqlite3541_int64);
  const char *(*uri_parameter)(const char*,const char*);
  char *(*xvsnprintf)(int,char*,const char*,va_list);
  int (*wal_checkpoint_v2)(lattice_sqlite3541_connection*,const char*,int,int*,int*);
  /* Version 3.8.7 and later */
  int (*auto_extension)(void(*)(void));
  int (*bind_blob64)(lattice_sqlite3541_stmt*,int,const void*,lattice_sqlite3541_uint64,
                     void(*)(void*));
  int (*bind_text64)(lattice_sqlite3541_stmt*,int,const char*,lattice_sqlite3541_uint64,
                      void(*)(void*),unsigned char);
  int (*cancel_auto_extension)(void(*)(void));
  int (*load_extension)(lattice_sqlite3541_connection*,const char*,const char*,char**);
  void *(*malloc64)(lattice_sqlite3541_uint64);
  lattice_sqlite3541_uint64 (*msize)(void*);
  void *(*realloc64)(void*,lattice_sqlite3541_uint64);
  void (*reset_auto_extension)(void);
  void (*result_blob64)(lattice_sqlite3541_context*,const void*,lattice_sqlite3541_uint64,
                        void(*)(void*));
  void (*result_text64)(lattice_sqlite3541_context*,const char*,lattice_sqlite3541_uint64,
                         void(*)(void*), unsigned char);
  int (*strglob)(const char*,const char*);
  /* Version 3.8.11 and later */
  lattice_sqlite3541_value *(*value_dup)(const lattice_sqlite3541_value*);
  void (*value_free)(lattice_sqlite3541_value*);
  int (*result_zeroblob64)(lattice_sqlite3541_context*,lattice_sqlite3541_uint64);
  int (*bind_zeroblob64)(lattice_sqlite3541_stmt*, int, lattice_sqlite3541_uint64);
  /* Version 3.9.0 and later */
  unsigned int (*value_subtype)(lattice_sqlite3541_value*);
  void (*result_subtype)(lattice_sqlite3541_context*,unsigned int);
  /* Version 3.10.0 and later */
  int (*status64)(int,lattice_sqlite3541_int64*,lattice_sqlite3541_int64*,int);
  int (*strlike)(const char*,const char*,unsigned int);
  int (*db_cacheflush)(lattice_sqlite3541_connection*);
  /* Version 3.12.0 and later */
  int (*system_errno)(lattice_sqlite3541_connection*);
  /* Version 3.14.0 and later */
  int (*trace_v2)(lattice_sqlite3541_connection*,unsigned,int(*)(unsigned,void*,void*,void*),void*);
  char *(*expanded_sql)(lattice_sqlite3541_stmt*);
  /* Version 3.18.0 and later */
  void (*set_last_insert_rowid)(lattice_sqlite3541_connection*,lattice_sqlite3541_int64);
  /* Version 3.20.0 and later */
  int (*prepare_v3)(lattice_sqlite3541_connection*,const char*,int,unsigned int,
                    lattice_sqlite3541_stmt**,const char**);
  int (*prepare16_v3)(lattice_sqlite3541_connection*,const void*,int,unsigned int,
                      lattice_sqlite3541_stmt**,const void**);
  int (*bind_pointer)(lattice_sqlite3541_stmt*,int,void*,const char*,void(*)(void*));
  void (*result_pointer)(lattice_sqlite3541_context*,void*,const char*,void(*)(void*));
  void *(*value_pointer)(lattice_sqlite3541_value*,const char*);
  int (*vtab_nochange)(lattice_sqlite3541_context*);
  int (*value_nochange)(lattice_sqlite3541_value*);
  const char *(*vtab_collation)(lattice_sqlite3541_index_info*,int);
  /* Version 3.24.0 and later */
  int (*keyword_count)(void);
  int (*keyword_name)(int,const char**,int*);
  int (*keyword_check)(const char*,int);
  lattice_sqlite3541_str *(*str_new)(lattice_sqlite3541_connection*);
  char *(*str_finish)(lattice_sqlite3541_str*);
  void (LATTICE_SQLITE3541_CDECL*str_appendf)(lattice_sqlite3541_str*, const char *zFormat, ...);
  void (*str_vappendf)(lattice_sqlite3541_str*, const char *zFormat, va_list);
  void (*str_append)(lattice_sqlite3541_str*, const char *zIn, int N);
  void (*str_appendall)(lattice_sqlite3541_str*, const char *zIn);
  void (*str_appendchar)(lattice_sqlite3541_str*, int N, char C);
  void (*str_reset)(lattice_sqlite3541_str*);
  int (*str_errcode)(lattice_sqlite3541_str*);
  int (*str_length)(lattice_sqlite3541_str*);
  char *(*str_value)(lattice_sqlite3541_str*);
  /* Version 3.25.0 and later */
  int (*create_window_function)(lattice_sqlite3541_connection*,const char*,int,int,void*,
                            void (*xStep)(lattice_sqlite3541_context*,int,lattice_sqlite3541_value**),
                            void (*xFinal)(lattice_sqlite3541_context*),
                            void (*xValue)(lattice_sqlite3541_context*),
                            void (*xInv)(lattice_sqlite3541_context*,int,lattice_sqlite3541_value**),
                            void(*xDestroy)(void*));
  /* Version 3.26.0 and later */
  const char *(*normalized_sql)(lattice_sqlite3541_stmt*);
  /* Version 3.28.0 and later */
  int (*stmt_isexplain)(lattice_sqlite3541_stmt*);
  int (*value_frombind)(lattice_sqlite3541_value*);
  /* Version 3.30.0 and later */
  int (*drop_modules)(lattice_sqlite3541_connection*,const char**);
  /* Version 3.31.0 and later */
  lattice_sqlite3541_int64 (*hard_heap_limit64)(lattice_sqlite3541_int64);
  const char *(*uri_key)(const char*,int);
  const char *(*filename_database)(const char*);
  const char *(*filename_journal)(const char*);
  const char *(*filename_wal)(const char*);
  /* Version 3.32.0 and later */
  const char *(*create_filename)(const char*,const char*,const char*,
                           int,const char**);
  void (*free_filename)(const char*);
  lattice_sqlite3541_file *(*database_file_object)(const char*);
  /* Version 3.34.0 and later */
  int (*txn_state)(lattice_sqlite3541_connection*,const char*);
  /* Version 3.36.1 and later */
  lattice_sqlite3541_int64 (*changes64)(lattice_sqlite3541_connection*);
  lattice_sqlite3541_int64 (*total_changes64)(lattice_sqlite3541_connection*);
  /* Version 3.37.0 and later */
  int (*autovacuum_pages)(lattice_sqlite3541_connection*,
     unsigned int(*)(void*,const char*,unsigned int,unsigned int,unsigned int),
     void*, void(*)(void*));
  /* Version 3.38.0 and later */
  int (*error_offset)(lattice_sqlite3541_connection*);
  int (*vtab_rhs_value)(lattice_sqlite3541_index_info*,int,lattice_sqlite3541_value**);
  int (*vtab_distinct)(lattice_sqlite3541_index_info*);
  int (*vtab_in)(lattice_sqlite3541_index_info*,int,int);
  int (*vtab_in_first)(lattice_sqlite3541_value*,lattice_sqlite3541_value**);
  int (*vtab_in_next)(lattice_sqlite3541_value*,lattice_sqlite3541_value**);
  /* Version 3.39.0 and later */
  int (*deserialize)(lattice_sqlite3541_connection*,const char*,unsigned char*,
                     lattice_sqlite3541_int64,lattice_sqlite3541_int64,unsigned);
  unsigned char *(*serialize)(lattice_sqlite3541_connection*,const char *,lattice_sqlite3541_int64*,
                              unsigned int);
  const char *(*db_name)(lattice_sqlite3541_connection*,int);
  /* Version 3.40.0 and later */
  int (*value_encoding)(lattice_sqlite3541_value*);
  /* Version 3.41.0 and later */
  int (*is_interrupted)(lattice_sqlite3541_connection*);
  /* Version 3.43.0 and later */
  int (*stmt_explain)(lattice_sqlite3541_stmt*,int);
  /* Version 3.44.0 and later */
  void *(*get_clientdata)(lattice_sqlite3541_connection*,const char*);
  int (*set_clientdata)(lattice_sqlite3541_connection*, const char*, void*, void(*)(void*));
  /* Version 3.50.0 and later */
  int (*setlk_timeout)(lattice_sqlite3541_connection*,int,int);
  /* Version 3.51.0 and later */
  int (*set_errmsg)(lattice_sqlite3541_connection*,int,const char*);
  int (*db_status64)(lattice_sqlite3541_connection*,int,lattice_sqlite3541_int64*,lattice_sqlite3541_int64*,int);
  /* Version 3.52.0 and later */
  void (*str_truncate)(lattice_sqlite3541_str*,int);
  void (*str_free)(lattice_sqlite3541_str*);
  int (*carray_bind)(lattice_sqlite3541_stmt*,int,void*,int,int,void(*)(void*));
  int (*carray_bind_v2)(lattice_sqlite3541_stmt*,int,void*,int,int,void(*)(void*),void*);
  /* Version 3.54.0 and later */
  lattice_sqlite3541_int64 (*incomplete)(const char*);
  void (*result_str)(lattice_sqlite3541_context*,lattice_sqlite3541_str*,int);
};

/*
** This is the function signature used for all extension entry points.  It
** is also defined in the file "loadext.c".
*/
typedef int (*lattice_sqlite3541_loadext_entry)(
  lattice_sqlite3541_connection *db,                       /* Handle to the database. */
  char **pzErrMsg,                   /* Used to set error string on failure. */
  const lattice_sqlite3541_api_routines *pThunk /* Extension API function pointers. */
);

/*
** The following macros redefine the API routines so that they are
** redirected through the global sqlite3_api structure.
**
** This header file is also used by the loadext.c source file
** (part of the main SQLite library - not an extension) so that
** it can get access to the sqlite3_api_routines structure
** definition.  But the main library does not want to redefine
** the API.  So the redefinition macros are only valid if the
** SQLITE_CORE macros is undefined.
*/
#if !defined(LATTICE_SQLITE3541_CORE) && !defined(LATTICE_SQLITE3541_OMIT_LOAD_EXTENSION)
#define lattice_sqlite3541_aggregate_context      lattice_sqlite3541_api->aggregate_context
#ifndef LATTICE_SQLITE3541_OMIT_DEPRECATED
#define lattice_sqlite3541_aggregate_count        lattice_sqlite3541_api->aggregate_count
#endif
#define lattice_sqlite3541_bind_blob              lattice_sqlite3541_api->bind_blob
#define lattice_sqlite3541_bind_double            lattice_sqlite3541_api->bind_double
#define lattice_sqlite3541_bind_int               lattice_sqlite3541_api->bind_int
#define lattice_sqlite3541_bind_int64             lattice_sqlite3541_api->bind_int64
#define lattice_sqlite3541_bind_null              lattice_sqlite3541_api->bind_null
#define lattice_sqlite3541_bind_parameter_count   lattice_sqlite3541_api->bind_parameter_count
#define lattice_sqlite3541_bind_parameter_index   lattice_sqlite3541_api->bind_parameter_index
#define lattice_sqlite3541_bind_parameter_name    lattice_sqlite3541_api->bind_parameter_name
#define lattice_sqlite3541_bind_text              lattice_sqlite3541_api->bind_text
#define lattice_sqlite3541_bind_text16            lattice_sqlite3541_api->bind_text16
#define lattice_sqlite3541_bind_value             lattice_sqlite3541_api->bind_value
#define lattice_sqlite3541_busy_handler           lattice_sqlite3541_api->busy_handler
#define lattice_sqlite3541_busy_timeout           lattice_sqlite3541_api->busy_timeout
#define lattice_sqlite3541_changes                lattice_sqlite3541_api->changes
#define lattice_sqlite3541_close                  lattice_sqlite3541_api->close
#define lattice_sqlite3541_collation_needed       lattice_sqlite3541_api->collation_needed
#define lattice_sqlite3541_collation_needed16     lattice_sqlite3541_api->collation_needed16
#define lattice_sqlite3541_column_blob            lattice_sqlite3541_api->column_blob
#define lattice_sqlite3541_column_bytes           lattice_sqlite3541_api->column_bytes
#define lattice_sqlite3541_column_bytes16         lattice_sqlite3541_api->column_bytes16
#define lattice_sqlite3541_column_count           lattice_sqlite3541_api->column_count
#define lattice_sqlite3541_column_database_name   lattice_sqlite3541_api->column_database_name
#define lattice_sqlite3541_column_database_name16 lattice_sqlite3541_api->column_database_name16
#define lattice_sqlite3541_column_decltype        lattice_sqlite3541_api->column_decltype
#define lattice_sqlite3541_column_decltype16      lattice_sqlite3541_api->column_decltype16
#define lattice_sqlite3541_column_double          lattice_sqlite3541_api->column_double
#define lattice_sqlite3541_column_int             lattice_sqlite3541_api->column_int
#define lattice_sqlite3541_column_int64           lattice_sqlite3541_api->column_int64
#define lattice_sqlite3541_column_name            lattice_sqlite3541_api->column_name
#define lattice_sqlite3541_column_name16          lattice_sqlite3541_api->column_name16
#define lattice_sqlite3541_column_origin_name     lattice_sqlite3541_api->column_origin_name
#define lattice_sqlite3541_column_origin_name16   lattice_sqlite3541_api->column_origin_name16
#define lattice_sqlite3541_column_table_name      lattice_sqlite3541_api->column_table_name
#define lattice_sqlite3541_column_table_name16    lattice_sqlite3541_api->column_table_name16
#define lattice_sqlite3541_column_text            lattice_sqlite3541_api->column_text
#define lattice_sqlite3541_column_text16          lattice_sqlite3541_api->column_text16
#define lattice_sqlite3541_column_type            lattice_sqlite3541_api->column_type
#define lattice_sqlite3541_column_value           lattice_sqlite3541_api->column_value
#define lattice_sqlite3541_commit_hook            lattice_sqlite3541_api->commit_hook
#define lattice_sqlite3541_complete               lattice_sqlite3541_api->complete
#define lattice_sqlite3541_complete16             lattice_sqlite3541_api->complete16
#define lattice_sqlite3541_create_collation       lattice_sqlite3541_api->create_collation
#define lattice_sqlite3541_create_collation16     lattice_sqlite3541_api->create_collation16
#define lattice_sqlite3541_create_function        lattice_sqlite3541_api->create_function
#define lattice_sqlite3541_create_function16      lattice_sqlite3541_api->create_function16
#define lattice_sqlite3541_create_module          lattice_sqlite3541_api->create_module
#define lattice_sqlite3541_create_module_v2       lattice_sqlite3541_api->create_module_v2
#define lattice_sqlite3541_data_count             lattice_sqlite3541_api->data_count
#define lattice_sqlite3541_db_handle              lattice_sqlite3541_api->db_handle
#define lattice_sqlite3541_declare_vtab           lattice_sqlite3541_api->declare_vtab
#define lattice_sqlite3541_enable_shared_cache    lattice_sqlite3541_api->enable_shared_cache
#define lattice_sqlite3541_errcode                lattice_sqlite3541_api->errcode
#define lattice_sqlite3541_errmsg                 lattice_sqlite3541_api->errmsg
#define lattice_sqlite3541_errmsg16               lattice_sqlite3541_api->errmsg16
#define lattice_sqlite3541_exec                   lattice_sqlite3541_api->exec
#ifndef LATTICE_SQLITE3541_OMIT_DEPRECATED
#define lattice_sqlite3541_expired                lattice_sqlite3541_api->expired
#endif
#define lattice_sqlite3541_finalize               lattice_sqlite3541_api->finalize
#define lattice_sqlite3541_free                   lattice_sqlite3541_api->free
#define lattice_sqlite3541_free_table             lattice_sqlite3541_api->free_table
#define lattice_sqlite3541_get_autocommit         lattice_sqlite3541_api->get_autocommit
#define lattice_sqlite3541_get_auxdata            lattice_sqlite3541_api->get_auxdata
#define lattice_sqlite3541_get_table              lattice_sqlite3541_api->get_table
#ifndef LATTICE_SQLITE3541_OMIT_DEPRECATED
#define lattice_sqlite3541_global_recover         lattice_sqlite3541_api->global_recover
#endif
#define lattice_sqlite3541_interrupt              lattice_sqlite3541_api->interruptx
#define lattice_sqlite3541_last_insert_rowid      lattice_sqlite3541_api->last_insert_rowid
#define lattice_sqlite3541_libversion             lattice_sqlite3541_api->libversion
#define lattice_sqlite3541_libversion_number      lattice_sqlite3541_api->libversion_number
#define lattice_sqlite3541_malloc                 lattice_sqlite3541_api->malloc
#define lattice_sqlite3541_mprintf                lattice_sqlite3541_api->mprintf
#define lattice_sqlite3541_open                   lattice_sqlite3541_api->open
#define lattice_sqlite3541_open16                 lattice_sqlite3541_api->open16
#define lattice_sqlite3541_prepare                lattice_sqlite3541_api->prepare
#define lattice_sqlite3541_prepare16              lattice_sqlite3541_api->prepare16
#define lattice_sqlite3541_prepare_v2             lattice_sqlite3541_api->prepare_v2
#define lattice_sqlite3541_prepare16_v2           lattice_sqlite3541_api->prepare16_v2
#define lattice_sqlite3541_profile                lattice_sqlite3541_api->profile
#define lattice_sqlite3541_progress_handler       lattice_sqlite3541_api->progress_handler
#define lattice_sqlite3541_realloc                lattice_sqlite3541_api->realloc
#define lattice_sqlite3541_reset                  lattice_sqlite3541_api->reset
#define lattice_sqlite3541_result_blob            lattice_sqlite3541_api->result_blob
#define lattice_sqlite3541_result_double          lattice_sqlite3541_api->result_double
#define lattice_sqlite3541_result_error           lattice_sqlite3541_api->result_error
#define lattice_sqlite3541_result_error16         lattice_sqlite3541_api->result_error16
#define lattice_sqlite3541_result_int             lattice_sqlite3541_api->result_int
#define lattice_sqlite3541_result_int64           lattice_sqlite3541_api->result_int64
#define lattice_sqlite3541_result_null            lattice_sqlite3541_api->result_null
#define lattice_sqlite3541_result_text            lattice_sqlite3541_api->result_text
#define lattice_sqlite3541_result_text16          lattice_sqlite3541_api->result_text16
#define lattice_sqlite3541_result_text16be        lattice_sqlite3541_api->result_text16be
#define lattice_sqlite3541_result_text16le        lattice_sqlite3541_api->result_text16le
#define lattice_sqlite3541_result_value           lattice_sqlite3541_api->result_value
#define lattice_sqlite3541_rollback_hook          lattice_sqlite3541_api->rollback_hook
#define lattice_sqlite3541_set_authorizer         lattice_sqlite3541_api->set_authorizer
#define lattice_sqlite3541_set_auxdata            lattice_sqlite3541_api->set_auxdata
#define lattice_sqlite3541_snprintf               lattice_sqlite3541_api->xsnprintf
#define lattice_sqlite3541_step                   lattice_sqlite3541_api->step
#define lattice_sqlite3541_table_column_metadata  lattice_sqlite3541_api->table_column_metadata
#define lattice_sqlite3541_thread_cleanup         lattice_sqlite3541_api->thread_cleanup
#define lattice_sqlite3541_total_changes          lattice_sqlite3541_api->total_changes
#define lattice_sqlite3541_trace                  lattice_sqlite3541_api->trace
#ifndef LATTICE_SQLITE3541_OMIT_DEPRECATED
#define lattice_sqlite3541_transfer_bindings      lattice_sqlite3541_api->transfer_bindings
#endif
#define lattice_sqlite3541_update_hook            lattice_sqlite3541_api->update_hook
#define lattice_sqlite3541_user_data              lattice_sqlite3541_api->user_data
#define lattice_sqlite3541_value_blob             lattice_sqlite3541_api->value_blob
#define lattice_sqlite3541_value_bytes            lattice_sqlite3541_api->value_bytes
#define lattice_sqlite3541_value_bytes16          lattice_sqlite3541_api->value_bytes16
#define lattice_sqlite3541_value_double           lattice_sqlite3541_api->value_double
#define lattice_sqlite3541_value_int              lattice_sqlite3541_api->value_int
#define lattice_sqlite3541_value_int64            lattice_sqlite3541_api->value_int64
#define lattice_sqlite3541_value_numeric_type     lattice_sqlite3541_api->value_numeric_type
#define lattice_sqlite3541_value_text             lattice_sqlite3541_api->value_text
#define lattice_sqlite3541_value_text16           lattice_sqlite3541_api->value_text16
#define lattice_sqlite3541_value_text16be         lattice_sqlite3541_api->value_text16be
#define lattice_sqlite3541_value_text16le         lattice_sqlite3541_api->value_text16le
#define lattice_sqlite3541_value_type             lattice_sqlite3541_api->value_type
#define lattice_sqlite3541_vmprintf               lattice_sqlite3541_api->vmprintf
#define lattice_sqlite3541_vsnprintf              lattice_sqlite3541_api->xvsnprintf
#define lattice_sqlite3541_overload_function      lattice_sqlite3541_api->overload_function
#define lattice_sqlite3541_prepare_v2             lattice_sqlite3541_api->prepare_v2
#define lattice_sqlite3541_prepare16_v2           lattice_sqlite3541_api->prepare16_v2
#define lattice_sqlite3541_clear_bindings         lattice_sqlite3541_api->clear_bindings
#define lattice_sqlite3541_bind_zeroblob          lattice_sqlite3541_api->bind_zeroblob
#define lattice_sqlite3541_blob_bytes             lattice_sqlite3541_api->blob_bytes
#define lattice_sqlite3541_blob_close             lattice_sqlite3541_api->blob_close
#define lattice_sqlite3541_blob_open              lattice_sqlite3541_api->blob_open
#define lattice_sqlite3541_blob_read              lattice_sqlite3541_api->blob_read
#define lattice_sqlite3541_blob_write             lattice_sqlite3541_api->blob_write
#define lattice_sqlite3541_create_collation_v2    lattice_sqlite3541_api->create_collation_v2
#define lattice_sqlite3541_file_control           lattice_sqlite3541_api->file_control
#define lattice_sqlite3541_memory_highwater       lattice_sqlite3541_api->memory_highwater
#define lattice_sqlite3541_memory_used            lattice_sqlite3541_api->memory_used
#define lattice_sqlite3541_mutex_alloc            lattice_sqlite3541_api->mutex_alloc
#define lattice_sqlite3541_mutex_enter            lattice_sqlite3541_api->mutex_enter
#define lattice_sqlite3541_mutex_free             lattice_sqlite3541_api->mutex_free
#define lattice_sqlite3541_mutex_leave            lattice_sqlite3541_api->mutex_leave
#define lattice_sqlite3541_mutex_try              lattice_sqlite3541_api->mutex_try
#define lattice_sqlite3541_open_v2                lattice_sqlite3541_api->open_v2
#define lattice_sqlite3541_release_memory         lattice_sqlite3541_api->release_memory
#define lattice_sqlite3541_result_error_nomem     lattice_sqlite3541_api->result_error_nomem
#define lattice_sqlite3541_result_error_toobig    lattice_sqlite3541_api->result_error_toobig
#define lattice_sqlite3541_sleep                  lattice_sqlite3541_api->sleep
#define lattice_sqlite3541_soft_heap_limit        lattice_sqlite3541_api->soft_heap_limit
#define lattice_sqlite3541_vfs_find               lattice_sqlite3541_api->vfs_find
#define lattice_sqlite3541_vfs_register           lattice_sqlite3541_api->vfs_register
#define lattice_sqlite3541_vfs_unregister         lattice_sqlite3541_api->vfs_unregister
#define lattice_sqlite3541_threadsafe             lattice_sqlite3541_api->xthreadsafe
#define lattice_sqlite3541_result_zeroblob        lattice_sqlite3541_api->result_zeroblob
#define lattice_sqlite3541_result_error_code      lattice_sqlite3541_api->result_error_code
#define lattice_sqlite3541_test_control           lattice_sqlite3541_api->test_control
#define lattice_sqlite3541_randomness             lattice_sqlite3541_api->randomness
#define lattice_sqlite3541_context_db_handle      lattice_sqlite3541_api->context_db_handle
#define lattice_sqlite3541_extended_result_codes  lattice_sqlite3541_api->extended_result_codes
#define lattice_sqlite3541_limit                  lattice_sqlite3541_api->limit
#define lattice_sqlite3541_next_stmt              lattice_sqlite3541_api->next_stmt
#define lattice_sqlite3541_sql                    lattice_sqlite3541_api->sql
#define lattice_sqlite3541_status                 lattice_sqlite3541_api->status
#define lattice_sqlite3541_backup_finish          lattice_sqlite3541_api->backup_finish
#define lattice_sqlite3541_backup_init            lattice_sqlite3541_api->backup_init
#define lattice_sqlite3541_backup_pagecount       lattice_sqlite3541_api->backup_pagecount
#define lattice_sqlite3541_backup_remaining       lattice_sqlite3541_api->backup_remaining
#define lattice_sqlite3541_backup_step            lattice_sqlite3541_api->backup_step
#define lattice_sqlite3541_compileoption_get      lattice_sqlite3541_api->compileoption_get
#define lattice_sqlite3541_compileoption_used     lattice_sqlite3541_api->compileoption_used
#define lattice_sqlite3541_create_function_v2     lattice_sqlite3541_api->create_function_v2
#define lattice_sqlite3541_db_config              lattice_sqlite3541_api->db_config
#define lattice_sqlite3541_db_mutex               lattice_sqlite3541_api->db_mutex
#define lattice_sqlite3541_db_status              lattice_sqlite3541_api->db_status
#define lattice_sqlite3541_extended_errcode       lattice_sqlite3541_api->extended_errcode
#define lattice_sqlite3541_log                    lattice_sqlite3541_api->log
#define lattice_sqlite3541_soft_heap_limit64      lattice_sqlite3541_api->soft_heap_limit64
#define lattice_sqlite3541_sourceid               lattice_sqlite3541_api->sourceid
#define lattice_sqlite3541_stmt_status            lattice_sqlite3541_api->stmt_status
#define lattice_sqlite3541_strnicmp               lattice_sqlite3541_api->strnicmp
#define lattice_sqlite3541_unlock_notify          lattice_sqlite3541_api->unlock_notify
#define lattice_sqlite3541_wal_autocheckpoint     lattice_sqlite3541_api->wal_autocheckpoint
#define lattice_sqlite3541_wal_checkpoint         lattice_sqlite3541_api->wal_checkpoint
#define lattice_sqlite3541_wal_hook               lattice_sqlite3541_api->wal_hook
#define lattice_sqlite3541_blob_reopen            lattice_sqlite3541_api->blob_reopen
#define lattice_sqlite3541_vtab_config            lattice_sqlite3541_api->vtab_config
#define lattice_sqlite3541_vtab_on_conflict       lattice_sqlite3541_api->vtab_on_conflict
/* Version 3.7.16 and later */
#define lattice_sqlite3541_close_v2               lattice_sqlite3541_api->close_v2
#define lattice_sqlite3541_db_filename            lattice_sqlite3541_api->db_filename
#define lattice_sqlite3541_db_readonly            lattice_sqlite3541_api->db_readonly
#define lattice_sqlite3541_db_release_memory      lattice_sqlite3541_api->db_release_memory
#define lattice_sqlite3541_errstr                 lattice_sqlite3541_api->errstr
#define lattice_sqlite3541_stmt_busy              lattice_sqlite3541_api->stmt_busy
#define lattice_sqlite3541_stmt_readonly          lattice_sqlite3541_api->stmt_readonly
#define lattice_sqlite3541_stricmp                lattice_sqlite3541_api->stricmp
#define lattice_sqlite3541_uri_boolean            lattice_sqlite3541_api->uri_boolean
#define lattice_sqlite3541_uri_int64              lattice_sqlite3541_api->uri_int64
#define lattice_sqlite3541_uri_parameter          lattice_sqlite3541_api->uri_parameter
#define lattice_sqlite3541_uri_vsnprintf          lattice_sqlite3541_api->xvsnprintf
#define lattice_sqlite3541_wal_checkpoint_v2      lattice_sqlite3541_api->wal_checkpoint_v2
/* Version 3.8.7 and later */
#define lattice_sqlite3541_auto_extension         lattice_sqlite3541_api->auto_extension
#define lattice_sqlite3541_bind_blob64            lattice_sqlite3541_api->bind_blob64
#define lattice_sqlite3541_bind_text64            lattice_sqlite3541_api->bind_text64
#define lattice_sqlite3541_cancel_auto_extension  lattice_sqlite3541_api->cancel_auto_extension
#define lattice_sqlite3541_load_extension         lattice_sqlite3541_api->load_extension
#define lattice_sqlite3541_malloc64               lattice_sqlite3541_api->malloc64
#define lattice_sqlite3541_msize                  lattice_sqlite3541_api->msize
#define lattice_sqlite3541_realloc64              lattice_sqlite3541_api->realloc64
#define lattice_sqlite3541_reset_auto_extension   lattice_sqlite3541_api->reset_auto_extension
#define lattice_sqlite3541_result_blob64          lattice_sqlite3541_api->result_blob64
#define lattice_sqlite3541_result_text64          lattice_sqlite3541_api->result_text64
#define lattice_sqlite3541_strglob                lattice_sqlite3541_api->strglob
/* Version 3.8.11 and later */
#define lattice_sqlite3541_value_dup              lattice_sqlite3541_api->value_dup
#define lattice_sqlite3541_value_free             lattice_sqlite3541_api->value_free
#define lattice_sqlite3541_result_zeroblob64      lattice_sqlite3541_api->result_zeroblob64
#define lattice_sqlite3541_bind_zeroblob64        lattice_sqlite3541_api->bind_zeroblob64
/* Version 3.9.0 and later */
#define lattice_sqlite3541_value_subtype          lattice_sqlite3541_api->value_subtype
#define lattice_sqlite3541_result_subtype         lattice_sqlite3541_api->result_subtype
/* Version 3.10.0 and later */
#define lattice_sqlite3541_status64               lattice_sqlite3541_api->status64
#define lattice_sqlite3541_strlike                lattice_sqlite3541_api->strlike
#define lattice_sqlite3541_db_cacheflush          lattice_sqlite3541_api->db_cacheflush
/* Version 3.12.0 and later */
#define lattice_sqlite3541_system_errno           lattice_sqlite3541_api->system_errno
/* Version 3.14.0 and later */
#define lattice_sqlite3541_trace_v2               lattice_sqlite3541_api->trace_v2
#define lattice_sqlite3541_expanded_sql           lattice_sqlite3541_api->expanded_sql
/* Version 3.18.0 and later */
#define lattice_sqlite3541_set_last_insert_rowid  lattice_sqlite3541_api->set_last_insert_rowid
/* Version 3.20.0 and later */
#define lattice_sqlite3541_prepare_v3             lattice_sqlite3541_api->prepare_v3
#define lattice_sqlite3541_prepare16_v3           lattice_sqlite3541_api->prepare16_v3
#define lattice_sqlite3541_bind_pointer           lattice_sqlite3541_api->bind_pointer
#define lattice_sqlite3541_result_pointer         lattice_sqlite3541_api->result_pointer
#define lattice_sqlite3541_value_pointer          lattice_sqlite3541_api->value_pointer
/* Version 3.22.0 and later */
#define lattice_sqlite3541_vtab_nochange          lattice_sqlite3541_api->vtab_nochange
#define lattice_sqlite3541_value_nochange         lattice_sqlite3541_api->value_nochange
#define lattice_sqlite3541_vtab_collation         lattice_sqlite3541_api->vtab_collation
/* Version 3.24.0 and later */
#define lattice_sqlite3541_keyword_count          lattice_sqlite3541_api->keyword_count
#define lattice_sqlite3541_keyword_name           lattice_sqlite3541_api->keyword_name
#define lattice_sqlite3541_keyword_check          lattice_sqlite3541_api->keyword_check
#define lattice_sqlite3541_str_new                lattice_sqlite3541_api->str_new
#define lattice_sqlite3541_str_finish             lattice_sqlite3541_api->str_finish
#define lattice_sqlite3541_str_appendf            lattice_sqlite3541_api->str_appendf
#define lattice_sqlite3541_str_vappendf           lattice_sqlite3541_api->str_vappendf
#define lattice_sqlite3541_str_append             lattice_sqlite3541_api->str_append
#define lattice_sqlite3541_str_appendall          lattice_sqlite3541_api->str_appendall
#define lattice_sqlite3541_str_appendchar         lattice_sqlite3541_api->str_appendchar
#define lattice_sqlite3541_str_reset              lattice_sqlite3541_api->str_reset
#define lattice_sqlite3541_str_errcode            lattice_sqlite3541_api->str_errcode
#define lattice_sqlite3541_str_length             lattice_sqlite3541_api->str_length
#define lattice_sqlite3541_str_value              lattice_sqlite3541_api->str_value
/* Version 3.25.0 and later */
#define lattice_sqlite3541_create_window_function lattice_sqlite3541_api->create_window_function
/* Version 3.26.0 and later */
#define lattice_sqlite3541_normalized_sql         lattice_sqlite3541_api->normalized_sql
/* Version 3.28.0 and later */
#define lattice_sqlite3541_stmt_isexplain         lattice_sqlite3541_api->stmt_isexplain
#define lattice_sqlite3541_value_frombind         lattice_sqlite3541_api->value_frombind
/* Version 3.30.0 and later */
#define lattice_sqlite3541_drop_modules           lattice_sqlite3541_api->drop_modules
/* Version 3.31.0 and later */
#define lattice_sqlite3541_hard_heap_limit64      lattice_sqlite3541_api->hard_heap_limit64
#define lattice_sqlite3541_uri_key                lattice_sqlite3541_api->uri_key
#define lattice_sqlite3541_filename_database      lattice_sqlite3541_api->filename_database
#define lattice_sqlite3541_filename_journal       lattice_sqlite3541_api->filename_journal
#define lattice_sqlite3541_filename_wal           lattice_sqlite3541_api->filename_wal
/* Version 3.32.0 and later */
#define lattice_sqlite3541_create_filename        lattice_sqlite3541_api->create_filename
#define lattice_sqlite3541_free_filename          lattice_sqlite3541_api->free_filename
#define lattice_sqlite3541_database_file_object   lattice_sqlite3541_api->database_file_object
/* Version 3.34.0 and later */
#define lattice_sqlite3541_txn_state              lattice_sqlite3541_api->txn_state
/* Version 3.36.1 and later */
#define lattice_sqlite3541_changes64              lattice_sqlite3541_api->changes64
#define lattice_sqlite3541_total_changes64        lattice_sqlite3541_api->total_changes64
/* Version 3.37.0 and later */
#define lattice_sqlite3541_autovacuum_pages       lattice_sqlite3541_api->autovacuum_pages
/* Version 3.38.0 and later */
#define lattice_sqlite3541_error_offset           lattice_sqlite3541_api->error_offset
#define lattice_sqlite3541_vtab_rhs_value         lattice_sqlite3541_api->vtab_rhs_value
#define lattice_sqlite3541_vtab_distinct          lattice_sqlite3541_api->vtab_distinct
#define lattice_sqlite3541_vtab_in                lattice_sqlite3541_api->vtab_in
#define lattice_sqlite3541_vtab_in_first          lattice_sqlite3541_api->vtab_in_first
#define lattice_sqlite3541_vtab_in_next           lattice_sqlite3541_api->vtab_in_next
/* Version 3.39.0 and later */
#ifndef LATTICE_SQLITE3541_OMIT_DESERIALIZE
#define lattice_sqlite3541_deserialize            lattice_sqlite3541_api->deserialize
#define lattice_sqlite3541_serialize              lattice_sqlite3541_api->serialize
#endif
#define lattice_sqlite3541_db_name                lattice_sqlite3541_api->db_name
/* Version 3.40.0 and later */
#define lattice_sqlite3541_value_encoding         lattice_sqlite3541_api->value_encoding
/* Version 3.41.0 and later */
#define lattice_sqlite3541_is_interrupted         lattice_sqlite3541_api->is_interrupted
/* Version 3.43.0 and later */
#define lattice_sqlite3541_stmt_explain           lattice_sqlite3541_api->stmt_explain
/* Version 3.44.0 and later */
#define lattice_sqlite3541_get_clientdata         lattice_sqlite3541_api->get_clientdata
#define lattice_sqlite3541_set_clientdata         lattice_sqlite3541_api->set_clientdata
/* Version 3.50.0 and later */
#define lattice_sqlite3541_setlk_timeout          lattice_sqlite3541_api->setlk_timeout
/* Version 3.51.0 and later */
#define lattice_sqlite3541_set_errmsg             lattice_sqlite3541_api->set_errmsg
#define lattice_sqlite3541_db_status64            lattice_sqlite3541_api->db_status64
/* Version 3.52.0 and later */
#define lattice_sqlite3541_str_truncate           lattice_sqlite3541_api->str_truncate
#define lattice_sqlite3541_str_free               lattice_sqlite3541_api->str_free
#define lattice_sqlite3541_carray_bind            lattice_sqlite3541_api->carray_bind
#define lattice_sqlite3541_carray_bind_v2         lattice_sqlite3541_api->carray_bind_v2
/* Version 3.54.0 and later */
#define lattice_sqlite3541_incomplete             lattice_sqlite3541_api->incomplete
#define lattice_sqlite3541_result_str             lattice_sqlite3541_api->result_str
#endif /* !defined(SQLITE_CORE) && !defined(SQLITE_OMIT_LOAD_EXTENSION) */

#if !defined(LATTICE_SQLITE3541_CORE) && !defined(LATTICE_SQLITE3541_OMIT_LOAD_EXTENSION)
  /* This case when the file really is being compiled as a loadable 
  ** extension */
# define LATTICE_SQLITE3541_EXTENSION_INIT1     const lattice_sqlite3541_api_routines *lattice_sqlite3541_api=0;
# define LATTICE_SQLITE3541_EXTENSION_INIT2(v)  lattice_sqlite3541_api=v;
# define LATTICE_SQLITE3541_EXTENSION_INIT3     \
    extern const lattice_sqlite3541_api_routines *lattice_sqlite3541_api;
#else
  /* This case when the file is being statically linked into the 
  ** application */
# define LATTICE_SQLITE3541_EXTENSION_INIT1     /*no-op*/
# define LATTICE_SQLITE3541_EXTENSION_INIT2(v)  (void)v; /* unused parameter */
# define LATTICE_SQLITE3541_EXTENSION_INIT3     /*no-op*/
#endif

#endif /* SQLITE3EXT_H */
