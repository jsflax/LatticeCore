#include "provider_engine_interface.h" // private full API precedes types-only guard
#include "lattice_sqlite_provider/provider.hpp"
#include <atomic>
#include <cstring>
#include <mutex>
#include "provider_serial.hpp"
#if defined(__APPLE__) || defined(__linux__)
#include <unistd.h>
#endif
namespace lattice::sqlite_provider::v1 {
namespace {
std::uint64_t process()noexcept {
    return lattice_sqlite3541_provider_current_process();
}
std::atomic<std::uint64_t> next_serial{1};
std::atomic<bool> serial_exhausted{false};
// Actual-issued intrusive census. Process fencing precedes this mutex; entries
// are added only by genuine builtin/wrapped original constructors/registration.
std::mutex vfs_original_leaf;
vfs_original* vfs_original_head=nullptr;
std::uint64_t issue_serial() {
    return detail::claim_serial(next_serial,serial_exhausted);
}
void copy_name(std::array<char,256>& result,const char* actual) {
    if(!actual)throw error(rejection::changed_vfs);
    std::size_t count=0;while(count<result.size()&&actual[count])++count;
    if(!count||count==result.size())throw error(rejection::changed_vfs);
    std::memcpy(result.data(),actual,count);result[count]=0;
}
bool table_matches(const lattice_sqlite3541_vfs& one,const lattice_sqlite3541_vfs& two)noexcept {
    // pNext is the engine's own mutable registry link, never callback authority.
#define LP_FIELD(field) if(one.field!=two.field)return false
    LP_FIELD(iVersion);LP_FIELD(szOsFile);LP_FIELD(mxPathname);LP_FIELD(zName);LP_FIELD(pAppData);
    LP_FIELD(xOpen);LP_FIELD(xDelete);LP_FIELD(xAccess);LP_FIELD(xFullPathname);
    LP_FIELD(xDlOpen);LP_FIELD(xDlError);LP_FIELD(xDlSym);LP_FIELD(xDlClose);
    LP_FIELD(xRandomness);LP_FIELD(xSleep);LP_FIELD(xCurrentTime);LP_FIELD(xGetLastError);
    if(one.iVersion>=2){LP_FIELD(xCurrentTimeInt64);}
    if(one.iVersion>=3){LP_FIELD(xSetSystemCall);LP_FIELD(xGetSystemCall);LP_FIELD(xNextSystemCall);}
#undef LP_FIELD
    return true;
}
}
struct engine_access final {
    static bool vfs(const vfs_original& original,bool registered,bool cleanup=false)noexcept {
        // Fixed outer DATA first; never touch foreign/inherited table/lower data.
        if(original.instance_!=lattice_sqlite3541_provider_instance()||!original.creator_||
           original.creator_!=process()||!lattice_sqlite3541_provider_process_current())return false;
        if(!cleanup&&!lattice_sqlite3541_provider_realm_current())return false;
        if(registered?original.phase_!=vfs_original::phase::registered:
           (original.phase_!=vfs_original::phase::prepared&&original.phase_!=vfs_original::phase::registered))return false;
        if(!original.actual_||original.record_.instance!=original.instance_||
           original.record_.creator!=original.creator_||original.record_.original!=&original||
           original.record_.actual!=original.actual_||!table_matches(*original.actual_,original.snapshot_)||
           !original.actual_->zName||std::strncmp(original.actual_->zName,original.name_.data(),original.name_.size()))return false;
        if(!original.lower_)return original.depth_==0;
        return original.depth_>0&&original.depth_<=2&&original.lower_->depth_+1==original.depth_&&
            vfs(*original.lower_,true,cleanup);
    }
    static void pin_vfs(connection_original& original) {
        if(original.instance_!=lattice_sqlite3541_provider_instance()||!original.creator_||
           original.creator_!=process()||!lattice_sqlite3541_provider_process_current())
            throw error(rejection::inherited_original);
        std::lock_guard lock(vfs_original_leaf);
        if(original.vfs_pin_count_)throw error(rejection::consumed_original);
        const vfs_original* chain[3]{};unsigned count=0;
        for(auto* at=original.vfs_;at;at=at->lower_){
            if(count==3||!vfs(*at,true)||at->unregistering_||at->native_pins_==UINT64_MAX)
                throw error(rejection::changed_vfs);
            chain[count++]=at;
        }
        if(!count)throw error(rejection::changed_vfs);
        for(unsigned i=0;i<count;++i)++const_cast<vfs_original*>(chain[i])->native_pins_;
        original.vfs_pin_count_=count;
    }
    static void release_vfs(connection_original& original)noexcept {
        if(original.instance_!=lattice_sqlite3541_provider_instance()||!original.creator_||
           original.creator_!=process()||!lattice_sqlite3541_provider_process_current())return;
        try {
            std::lock_guard lock(vfs_original_leaf);
            const auto count=original.vfs_pin_count_;if(!count)return;
            if(count>3)return;
            const vfs_original* chain[3]{};auto* at=original.vfs_;
            for(unsigned i=0;i<count;++i){
                if(!at||at->instance_!=original.instance_||at->creator_!=original.creator_||!at->native_pins_)return;
                chain[i]=at;at=at->lower_;
            }
            if(at)return; // malformed/changed chain preserves the actual pin debt
            for(unsigned i=0;i<count;++i)--const_cast<vfs_original*>(chain[i])->native_pins_;
            original.vfs_pin_count_=0;
        }catch(...){/* Actual Native ending remains true; registration pin debt remains retained. */}
    }
    static bool request(const lattice_sqlite3541_provider_request& record)noexcept {
        if(record.instance!=lattice_sqlite3541_provider_instance()||!record.creator||record.creator!=process()||
           !record.original||!record.serial||(record.phase!=1&&record.phase!=2))return false;
        const auto& original=*static_cast<const open_original*>(record.original);
        if(original.instance_!=record.instance||original.creator_!=record.creator||
           original.builder_!=std::this_thread::get_id()||original.phase_!=1||
           original.serial_!=record.serial||original.source_!=record.source||!original.recipient_||
           record.connection_original!=original.recipient_||&original.record_!=&record||
           original.end_==std::chrono::steady_clock::time_point::max()||
           std::chrono::steady_clock::now()>=original.end_)return false;
        const bool protected_source=original.source_==1&&original.owner_&&original.open_&&original.account_;
        const bool physical_source=(original.source_==2||original.source_==3)&&!original.owner_&&!original.open_&&!original.account_;
        return (protected_source||physical_source)&&original.physical_&&original.vfs_&&
            record.core_owner==original.owner_&&record.core_open==original.open_&&
            record.physical_original==original.physical_&&record.account_original==original.account_&&
            record.vfs==&original.vfs_->record_&&vfs(*original.vfs_,true)&&
            original.core_current_&&original.core_entered_&&original.core_current_(record,original.end_);
    }
    static bool current(const connection_original& original)noexcept {
        return original.instance_==lattice_sqlite3541_provider_instance()&&original.creator_&&
            original.creator_==process()&&original.attempted_&&!original.retired_&&
            !original.native_ended_.load(std::memory_order_acquire)&&
            original.actual_&&original.serial_&&original.physical_&&original.vfs_&&
            ((original.source_==1&&original.owner_&&original.open_&&original.account_)||
             ((original.source_==2||original.source_==3)&&!original.owner_&&!original.open_&&!original.account_))&&
            vfs(*original.vfs_,true);
    }
    static lattice_sqlite3541_provider_fact expected(const connection_original& original)noexcept {
        lattice_sqlite3541_provider_fact result{};result.instance=original.instance_;result.creator=original.creator_;
        result.serial=original.serial_;result.core_owner=original.owner_;result.core_open=original.open_;
        result.physical_original=original.physical_;result.account_original=original.account_;
        result.vfs=&original.vfs_->record_;result.source=original.source_;result.connection_original=&original;return result;
    }
    static void native_ended(const lattice_sqlite3541_provider_fact& fact)noexcept {
        // Actual engine free site supplies this genuine recipient. Outer image
        // and process checks precede dereferencing its retained C++ record.
        if(fact.instance!=lattice_sqlite3541_provider_instance()||!fact.creator||fact.creator!=process()||
           !lattice_sqlite3541_provider_process_current()||!fact.connection_original)return;
        auto& actual=*const_cast<connection_original*>(static_cast<const connection_original*>(fact.connection_original));
        if(actual.instance_!=fact.instance||actual.creator_!=fact.creator||actual.serial_!=fact.serial||
           actual.source_!=fact.source||!actual.attempted_)return;
        release_vfs(actual); // true engine final-free site, including actual zombie ending
        actual.native_ended_.store(true,std::memory_order_release);
    }
    static bool record_vfs(const lattice_sqlite3541_provider_vfs& record,bool cleanup=false)noexcept {
        if(record.instance!=lattice_sqlite3541_provider_instance()||!record.creator||record.creator!=process()||!record.original)return false;
        const auto& original=*static_cast<const vfs_original*>(record.original);
        return &original.record_==&record&&vfs(original,false,cleanup);
    }
};
vfs_original::vfs_original(builtin_key,lattice_sqlite3541_vfs& actual)
    :instance_(lattice_sqlite3541_provider_instance()),creator_(process()),actual_(&actual),snapshot_(actual),phase_(phase::registered) {
    if(!creator_)throw error(rejection::inherited_original);copy_name(name_,actual.zName);
    record_={instance_,creator_,this,&actual};
    publish_selection_(*this);
}
vfs_original::vfs_original(lattice_sqlite3541_vfs& actual,const vfs_original& lower)
    :instance_(lattice_sqlite3541_provider_instance()),creator_(process()),actual_(&actual),lower_(&lower) {
    if(!creator_||!engine_access::vfs(lower,true))throw error(rejection::changed_vfs);
    depth_=lower.depth_+1;
    if(depth_>2||actual.iVersion<1||actual.iVersion>3||
       actual.szOsFile<static_cast<int>(sizeof(lattice_sqlite3541_file))||!actual.xOpen||!actual.xDelete||
       !actual.xAccess||!actual.xFullPathname)throw error(rejection::changed_vfs);
    snapshot_=actual;copy_name(name_,actual.zName);record_={instance_,creator_,this,&actual};
}
const vfs_original& vfs_original::builtin_() {
    // Fence before the C++ static guard: a child must not wait on or adopt an
    // inherited in-progress/initialized private engine realm.
    if(!lattice_sqlite3541_provider_process_current())throw error(rejection::inherited_original);
    static const vfs_original actual(builtin_key{},[]()->lattice_sqlite3541_vfs& {
        lattice_sqlite3541_vfs* table=nullptr;const int rc=lattice_sqlite3541_provider_builtin_default(&table);
        if(rc!=LATTICE_SQLITE3541_OK)throw error(rc);
        if(!table)throw error(rejection::changed_vfs);return *table;
    }());
    return actual;
}
int vfs_original::register_() {
    if(!engine_access::vfs(*this,false)||phase_!=phase::prepared)throw error(rejection::changed_vfs);
    const int rc=lattice_sqlite3541_provider_register_vfs(&record_);
    if(creator_!=process())throw error(rejection::inherited_original);
    phase_=rc==LATTICE_SQLITE3541_OK?phase::registered:phase::unknown;
    if(rc==LATTICE_SQLITE3541_OK)publish_selection_(*this);
    return rc;
}
int vfs_original::unregister_() {
    if(!engine_access::vfs(*this,true,true))throw error(rejection::changed_vfs);
    {std::lock_guard lock(vfs_original_leaf);
     if(!registry_listed_||unregistering_)throw error(rejection::changed_vfs);
     if(selections_||native_pins_)throw error(rejection::vfs_in_use); // no fabricated Native return
     unregistering_=true;}
    const int rc=lattice_sqlite3541_provider_unregister_vfs(&record_);
    if(creator_!=process())throw error(rejection::inherited_original);
    {std::lock_guard lock(vfs_original_leaf);
     auto** link=&vfs_original_head;
     while(*link&&*link!=this)link=&(*link)->registry_next_;
     if(*link!=this){phase_=phase::unknown;throw error(rejection::changed_vfs);}
     *link=registry_next_;registry_next_=nullptr;registry_listed_=false;
     phase_=rc==LATTICE_SQLITE3541_OK?phase::retired:phase::unknown;}
    return rc;
}
void vfs_original::publish_selection_(vfs_original& actual) {
    if(actual.instance_!=lattice_sqlite3541_provider_instance()||!actual.creator_||actual.creator_!=process()||
       !lattice_sqlite3541_provider_process_current())throw error(rejection::inherited_original);
    std::lock_guard lock(vfs_original_leaf);
    if(actual.registry_listed_||actual.unregistering_||actual.phase_!=phase::registered)
        throw error(rejection::changed_vfs);
    for(auto* at=vfs_original_head;at;at=at->registry_next_)
        if(at->actual_==actual.actual_||std::strcmp(at->name_.data(),actual.name_.data())==0)
            throw error(rejection::changed_vfs); // no name/pointer alias adoption
    actual.registry_next_=vfs_original_head;vfs_original_head=&actual;actual.registry_listed_=true;
}
vfs_original::selection::selection(const vfs_original& actual)noexcept:actual_(&actual){}
vfs_original::selection::~selection()noexcept{vfs_original::release_selection_(actual_);}
vfs_original::selection vfs_original::select_(const char* name) {
    // builtin_ fences before its C++ static; unknown names never call raw find.
    const auto& builtin=builtin_();
    if(!lattice_sqlite3541_provider_process_current())throw error(rejection::inherited_original);
    std::lock_guard lock(vfs_original_leaf);
    vfs_original* selected=nullptr;
    for(auto* at=vfs_original_head;at;at=at->registry_next_) {
        if((name&&std::strcmp(at->name_.data(),name)==0)||(!name&&at==&builtin)) {
            if(selected)throw error(rejection::changed_vfs);selected=at;
        }
    }
    if(!selected||selected->unregistering_||!engine_access::vfs(*selected,true)||selected->selections_==UINT64_MAX)
        throw error(rejection::changed_vfs);
    ++selected->selections_;return selection(*selected);
}
void vfs_original::release_selection_(const vfs_original* original)noexcept {
    if(!original||!lattice_sqlite3541_provider_process_current())return;
    // The selecting Core call retains its actual VFS issuer across this scope.
    // This fixed DATA pin prevents registered-table ending during Native open.
    if(original->instance_!=lattice_sqlite3541_provider_instance()||original->creator_!=process())return;
    try{std::lock_guard lock(vfs_original_leaf);
        auto& actual=*const_cast<vfs_original*>(original);
        if(actual.selections_)--actual.selections_;
    }catch(...){/* Retain the actual selection/registration debt. */}
}
bool vfs_original::current_()const noexcept{return engine_access::vfs(*this,true);}
bool vfs_original::native_in_use_()const {
    if(instance_!=lattice_sqlite3541_provider_instance()||!creator_||creator_!=process()||
       !lattice_sqlite3541_provider_process_current())throw error(rejection::inherited_original);
    std::lock_guard lock(vfs_original_leaf);return native_pins_!=0;
}
open_original::open_original(const ::lattice::database& owner,
    const ::lattice::detail::observer_delivery_open_startup& open,
    const ::lattice::detail::store_physical_open_original& physical,
    const ::lattice::detail::database_initialization_budget& account,
    const vfs_original& vfs,std::chrono::steady_clock::time_point end)
    :instance_(lattice_sqlite3541_provider_instance()),creator_(process()),builder_(std::this_thread::get_id()),end_(end),
     owner_(&owner),open_(&open),physical_(&physical),account_(&account),vfs_(&vfs),source_(1) {
    if(!creator_||!engine_access::vfs(vfs,true)||end==std::chrono::steady_clock::time_point::max()||
       end<=std::chrono::steady_clock::now())throw error(rejection::invalid_original);
    serial_=issue_serial();record_={instance_,creator_,serial_,this,&owner,&open,&physical,&account,&vfs.record_,0,source_,nullptr};
}
open_original::open_original(const ::lattice::detail::store_physical_open_original& physical,
    const vfs_original& vfs,std::chrono::steady_clock::time_point end)
    :instance_(lattice_sqlite3541_provider_instance()),creator_(process()),builder_(std::this_thread::get_id()),end_(end),
     owner_(nullptr),open_(nullptr),physical_(&physical),account_(nullptr),vfs_(&vfs),source_(2) {
    if(!creator_||!engine_access::vfs(vfs,true)||end==std::chrono::steady_clock::time_point::max()||
       end<=std::chrono::steady_clock::now())throw error(rejection::invalid_original);
    serial_=issue_serial();record_={instance_,creator_,serial_,this,nullptr,nullptr,&physical,nullptr,&vfs.record_,0,source_,nullptr};
}
open_original::open_original(const ::lattice::detail::store_provider_native_original& physical,
    const vfs_original& vfs,std::chrono::steady_clock::time_point end)
    :instance_(lattice_sqlite3541_provider_instance()),creator_(process()),builder_(std::this_thread::get_id()),end_(end),
     owner_(nullptr),open_(nullptr),physical_(&physical),account_(nullptr),vfs_(&vfs),source_(3) {
    if(!creator_||!engine_access::vfs(vfs,true)||end==std::chrono::steady_clock::time_point::max()||
       end<=std::chrono::steady_clock::now())throw error(rejection::invalid_original);
    serial_=issue_serial();record_={instance_,creator_,serial_,this,nullptr,nullptr,&physical,nullptr,&vfs.record_,0,source_,nullptr};
}
int connection_original::open_native_into_(open_original& original,connection_original& recipient,const char* file,int flags) {
    if(original.instance_!=lattice_sqlite3541_provider_instance()||original.creator_!=process())throw error(rejection::foreign_instance);
    if(original.phase_||recipient.attempted_||recipient.actual_||recipient.instance_)throw error(rejection::consumed_original);
    original.phase_=1;original.record_.phase=1; // Every attempted source is one-use.
    original.recipient_=&recipient;original.record_.connection_original=&recipient;
    if(!(flags&LATTICE_SQLITE3541_OPEN_FULLMUTEX)||(flags&LATTICE_SQLITE3541_OPEN_NOMUTEX)||
       !engine_access::request(original.record_))throw error(rejection::invalid_original);
    // The destination records THIS source before actual Native; no retry even
    // when the true return has no handle. No per-open profile/account is issued.
    recipient.attempted_=true;recipient.instance_=original.instance_;recipient.creator_=original.creator_;
    recipient.serial_=original.serial_;recipient.source_=original.source_;recipient.owner_=original.owner_;recipient.open_=original.open_;
    recipient.physical_=original.physical_;recipient.account_=original.account_;recipient.vfs_=original.vfs_;
    engine_access::pin_vfs(recipient); // SAME actual chain retained before the true C entry
    try {
    lattice_sqlite3541_connection* actual=nullptr;
    // All C++ source/recipient validation has returned. This fixed Core stamp
    // immediately precedes the ACTUAL private C engine open call; no public
    // callback, renewed permission or guessed Native success exists.
    if(!original.core_entered_||!original.core_entered_(original.record_))throw error(rejection::invalid_original);
    recipient.native_entered_=true; // fixed actual entry, immediately before C; never reset
    const int rc=lattice_sqlite3541_provider_open(&original.record_,file,&actual,flags);
    if(original.creator_!=process())throw error(rejection::inherited_original);
    original.phase_=2;recipient.actual_=actual;
    // A genuine null open return has no outstanding Native object to end.
    // Nonnull errors/partial handles require their actual later close/free.
    if(!actual){engine_access::release_vfs(recipient);recipient.native_ended_.store(true,std::memory_order_release);}
    return rc;
    }catch(...) {
        if(original.creator_==process()&&!recipient.native_entered_)
            engine_access::release_vfs(recipient); // actual C entry never occurred
        throw; // entered/foreign/unknown endings retain their SAME pins
    }
}
int connection_original::close_() {
    if(instance_!=lattice_sqlite3541_provider_instance()||creator_!=process()||
       !lattice_sqlite3541_provider_process_current())throw error(rejection::foreign_instance);
    if(!attempted_||retired_)throw error(rejection::invalid_original);
    const int rc=lattice_sqlite3541_close(static_cast<lattice_sqlite3541_connection*>(actual_));
    if(creator_!=process())throw error(rejection::inherited_original);
    if(rc==LATTICE_SQLITE3541_OK){actual_=nullptr;retired_=true;}return rc;
}
int connection_original::close_deferred_() {
    if(instance_!=lattice_sqlite3541_provider_instance()||creator_!=process()||
       !lattice_sqlite3541_provider_process_current())throw error(rejection::foreign_instance);
    if(!attempted_||retired_)throw error(rejection::invalid_original);
    const int rc=lattice_sqlite3541_close_v2(static_cast<lattice_sqlite3541_connection*>(actual_));
    if(creator_!=process())throw error(rejection::inherited_original);
    if(rc==LATTICE_SQLITE3541_OK){actual_=nullptr;retired_=true;}return rc;
}
bool connection_original::native_ending_known_()const noexcept {
    if(instance_!=lattice_sqlite3541_provider_instance()||!creator_||creator_!=process()||
       !lattice_sqlite3541_provider_process_current())return false;
    return attempted_&&native_ended_.load(std::memory_order_acquire);
}
bool connection_original::no_native_object_for_(const ::lattice::detail::store_provider_native_original& producer)const noexcept {
    // Process/image fence precedes every source field. No VFS/Native is read or
    // called: its real pin count has already returned to zero on the source's
    // same-thread failed entry path. Do not call during an outstanding caller.
    if(instance_!=lattice_sqlite3541_provider_instance()||!creator_||creator_!=process()||
       !lattice_sqlite3541_provider_process_current())return false;
    return attempted_&&serial_&&source_==3&&physical_==&producer&&
        !owner_&&!open_&&!account_&&!actual_&&!native_entered_&&!vfs_pin_count_;
}
bool connection_original::borrow_current_()const noexcept{return engine_access::current(*this);}
bool connection_original::registrations_current_()const noexcept {
    // A physical-only connection can expose a bound Native reference but never
    // stand in for a genuine protected startup registration receipt.
    if(source_!=1||!engine_access::current(*this))return false;
    const auto expected=engine_access::expected(*this);
    return lattice_sqlite3541_provider_completed_receipt(static_cast<lattice_sqlite3541_connection*>(actual_),&expected)!=0;
}
}
extern "C" int lattice_sqlite3541_provider_request_current(const lattice_sqlite3541_provider_request* record) {
    return record&&lattice::sqlite_provider::v1::engine_access::request(*record);
}
extern "C" int lattice_sqlite3541_provider_vfs_current(const lattice_sqlite3541_provider_vfs* record) {
    return record&&lattice::sqlite_provider::v1::engine_access::record_vfs(*record);
}

extern "C" int lattice_sqlite3541_provider_vfs_cleanup_original(const lattice_sqlite3541_provider_vfs* record) {
    return record&&lattice::sqlite_provider::v1::engine_access::record_vfs(*record,true);
}

extern "C" void lattice_sqlite3541_provider_connection_ended(const lattice_sqlite3541_provider_fact* fact) {
    if(fact)lattice::sqlite_provider::v1::engine_access::native_ended(*fact);
}
