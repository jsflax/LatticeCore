#ifndef LATTICE_SQLITE3541_PROVIDER_CONTRACT_H
#define LATTICE_SQLITE3541_PROVIDER_CONTRACT_H
#include <stdint.h>
#include <stddef.h>
#include "../include/lattice_sqlite_provider/detail/storage.h"
/* Global opaque C tag declarations precede instrumentation prototypes in the
** amalgamation. Parameter-scope declarations would create distinct C types. */
struct lattice_sqlite3541_context;
struct lattice_sqlite3541_value;
struct lattice_sqlite3541_module;
/* Fixed provider implementation functions, never supplied as callbacks. */
#ifdef __cplusplus
extern "C" {
#endif
int lattice_sqlite3541_provider_request_current(const struct lattice_sqlite3541_provider_request*);
int lattice_sqlite3541_provider_vfs_current(const struct lattice_sqlite3541_provider_vfs*);
int lattice_sqlite3541_provider_vfs_cleanup_original(const struct lattice_sqlite3541_provider_vfs*);
struct lattice_sqlite3541_provider_fact;
void lattice_sqlite3541_provider_connection_ended(const struct lattice_sqlite3541_provider_fact*);
const void *lattice_sqlite3541_provider_instance(void);
uint64_t lattice_sqlite3541_provider_current_process(void); /* pure actual host/runtime PID, no Native/configuration */
#ifdef __cplusplus
}
#endif
#endif
