#pragma once
#include <cstdint>
struct lattice_sqlite3541_connection;
namespace lattice::sqlite_provider::v1::detail {
// Closed source-only operation kind. This is not a callable public callback
// channel, Native adoption API, SQL purpose or initialization grant.
enum class core_native_call_kind:unsigned {ordinary=1,statement_ending=2};
// Defined by the SAME coherent Core image. Only actual provider Native-v1
// implementation thunks enter here, synchronously, without retaining work.
#if defined(__GNUC__) || defined(__clang__)
__attribute__((visibility("hidden")))
#endif
void core_native_call(unsigned actual_source,const void* actual_source_original,std::uint64_t creator,
    lattice_sqlite3541_connection* actual,core_native_call_kind,void(*fixed_native_work)(void*),void* borrowed_work);
}
