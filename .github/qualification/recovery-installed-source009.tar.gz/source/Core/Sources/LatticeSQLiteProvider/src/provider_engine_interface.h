#ifndef LATTICE_SQLITE3541_PROVIDER_ENGINE_INTERFACE_H
#define LATTICE_SQLITE3541_PROVIDER_ENGINE_INTERFACE_H
#include "native_api.h"
#include "provider_contract.h"
#ifdef __cplusplus
extern "C" {
#endif
int lattice_sqlite3541_provider_process_current(void);
int lattice_sqlite3541_provider_realm_current(void);
int lattice_sqlite3541_provider_builtin_default(lattice_sqlite3541_vfs**);
int lattice_sqlite3541_provider_register_vfs(const struct lattice_sqlite3541_provider_vfs*);
int lattice_sqlite3541_provider_unregister_vfs(const struct lattice_sqlite3541_provider_vfs*);
int lattice_sqlite3541_provider_open(struct lattice_sqlite3541_provider_request*,const char*,lattice_sqlite3541_connection**,int);
int lattice_sqlite3541_provider_receipt(lattice_sqlite3541_connection*,const struct lattice_sqlite3541_provider_fact*);
int lattice_sqlite3541_provider_completed_receipt(lattice_sqlite3541_connection*,const struct lattice_sqlite3541_provider_fact*);

/* SOURCE-PRIVATE. Only Core's same-owner issuer can populate expected. The
** engine owns one Native-mutex level from begin until the exact end/abort.
** This fixed synchronous frame is never stored in a Native object. */
struct lattice_sqlite3541_provider_registration {
  struct lattice_sqlite3541_provider_fact expected;
  struct lattice_sqlite3541_connection *actual;
  uint64_t creator;
  unsigned family, next, count, active, armed, stage, failed;
  void *core_scope;
  int (*core_current)(void*); /* actual fixed Core DATA validator, no public callback */
  const char *name;
  int args, encoding;
  void *userdata;
  void (*function)(struct lattice_sqlite3541_context*,int,struct lattice_sqlite3541_value**);
  const struct lattice_sqlite3541_module *module;
  void (*destroy)(void*);
  int (*authorizer)(void*,int,const char*,const char*,const char*,const char*);
};
int lattice_sqlite3541_provider_registration_begin(struct lattice_sqlite3541_provider_registration*,
    struct lattice_sqlite3541_connection*,const struct lattice_sqlite3541_provider_fact*,unsigned,void*,int(*)(void*));
int lattice_sqlite3541_provider_registration_function(struct lattice_sqlite3541_provider_registration*,unsigned,
    struct lattice_sqlite3541_connection*,const char*,int,int,void*,
    void(*)(struct lattice_sqlite3541_context*,int,struct lattice_sqlite3541_value**),void(*)(void*),int*);
int lattice_sqlite3541_provider_registration_module(struct lattice_sqlite3541_provider_registration*,unsigned,
    struct lattice_sqlite3541_connection*,const char*,const struct lattice_sqlite3541_module*,void*,void(*)(void*),int*);
int lattice_sqlite3541_provider_registration_end(struct lattice_sqlite3541_provider_registration*,int);
int lattice_sqlite3541_provider_registration_authorizer(struct lattice_sqlite3541_provider_registration*,
    struct lattice_sqlite3541_connection*,int(*)(void*,int,const char*,const char*,const char*,const char*),void*,int*);
int lattice_sqlite3541_provider_producer_receipt(struct lattice_sqlite3541_connection*,
    const struct lattice_sqlite3541_provider_fact*,int(*)(void*,int,const char*,const char*,const char*,const char*),void*);
void lattice_sqlite3541_provider_producer_changed(struct lattice_sqlite3541_connection*);
#ifdef __cplusplus
}
#endif
#endif
