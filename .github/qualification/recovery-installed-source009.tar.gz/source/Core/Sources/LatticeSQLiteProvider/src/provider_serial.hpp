#pragma once
#include "lattice_sqlite_provider/provider.hpp"
#include <atomic>
#include <limits>
// Source-private counter primitive. A returned integer is not an Open/native
// original; only provider.cpp's actual private issuer uses its global counter.
namespace lattice::sqlite_provider::v1::detail {
static_assert(std::atomic<std::uint64_t>::is_always_lock_free &&
              std::atomic<bool>::is_always_lock_free,
              "private SQLite provider requires always-lockfree serial atomics");
inline std::uint64_t claim_serial(std::atomic<std::uint64_t>& next,
                                  std::atomic<bool>& exhausted) {
    if(exhausted.load(std::memory_order_acquire))throw error(rejection::serial_exhausted);
    auto value=next.load(std::memory_order_acquire);
    for(;;){
        if(!value||value==std::numeric_limits<std::uint64_t>::max()){
            exhausted.store(true,std::memory_order_release);
            throw error(rejection::serial_exhausted);
        }
        // The saturated value is NEVER incremented. A delayed exhausted-store
        // cannot expose zero or reuse an earlier serial under concurrent calls.
        if(next.compare_exchange_weak(value,value+1,
                std::memory_order_acq_rel,std::memory_order_acquire))return value;
    }
}
}
