#include "../src/provider_engine_interface.h"
#include <gtest/gtest.h>
#if defined(__APPLE__) || defined(__linux__)
#include <cerrno>
#include <chrono>
#include <csignal>
#include <sys/wait.h>
#include <thread>
#include <unistd.h>
TEST(PrivateSQLiteProviderProcessRealm,RealForkCannotAdoptTheParentsUsedRealm){
    // Actual fixed DATA guard, not a synthetic PID, Open or Native permission.
    ASSERT_EQ(lattice_sqlite3541_provider_process_current(),1);
    const pid_t child=::fork();ASSERT_GE(child,0);
    if(child==0){
        const int inherited=lattice_sqlite3541_provider_process_current();
        ::_exit(inherited==0?0:17);
    }
    const auto end=std::chrono::steady_clock::now()+std::chrono::seconds(3);
    int status=0;pid_t result=0;
    do{
        result=::waitpid(child,&status,WNOHANG);
        if(result<0&&errno==EINTR)continue;
        if(result!=0)break;
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }while(std::chrono::steady_clock::now()<end);
    const bool exceeded=result==0;
    if(exceeded){
        const int killed=::kill(child,SIGKILL);
        EXPECT_TRUE(killed==0||errno==ESRCH);
        do{result=::waitpid(child,&status,0);}while(result<0&&errno==EINTR);
    }
    EXPECT_FALSE(exceeded);ASSERT_EQ(result,child);
    ASSERT_TRUE(WIFEXITED(status));EXPECT_EQ(WEXITSTATUS(status),0);
    EXPECT_EQ(lattice_sqlite3541_provider_process_current(),1);
}
#endif
