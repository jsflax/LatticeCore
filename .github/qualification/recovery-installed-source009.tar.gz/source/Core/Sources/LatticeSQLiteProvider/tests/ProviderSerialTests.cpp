#include "../src/provider_serial.hpp"
#include <gtest/gtest.h>
#include <array>
#include <chrono>
#include <optional>
#include <thread>
namespace provider=lattice::sqlite_provider::v1;
TEST(PrivateSQLiteProviderSerial,OrdinaryClaimsUseActualMonotoneCounter){
    std::atomic<std::uint64_t> next{1};std::atomic<bool> exhausted{false};
    EXPECT_EQ(provider::detail::claim_serial(next,exhausted),1u);
    EXPECT_EQ(provider::detail::claim_serial(next,exhausted),2u);
    EXPECT_EQ(next.load(),3u);EXPECT_FALSE(exhausted.load());
}
TEST(PrivateSQLiteProviderSerial,ConcurrentBoundaryNeverWrapsOrReusesSerial){
    const auto last=std::numeric_limits<std::uint64_t>::max();
    std::atomic<std::uint64_t> next{last-1};std::atomic<bool> exhausted{false},start{false};
    std::array<std::atomic<std::uint64_t>,3> values{};
    // 1 is a real claimed serial, 2 actual serial-exhausted, 3 unexpected error,
    // 4 bounded coordination failure. No fake Native/PID/Open/budget is used.
    std::array<std::atomic<unsigned>,3> results{};
    std::array<std::optional<std::jthread>,3> threads;
    for(std::size_t i=0;i<threads.size();++i){
        threads[i].emplace([&,i]{
            const auto end=std::chrono::steady_clock::now()+std::chrono::seconds(2);
            while(!start.load(std::memory_order_acquire)){
                if(std::chrono::steady_clock::now()>=end){results[i]=4;return;}
                std::this_thread::yield();
            }
            try{values[i]=provider::detail::claim_serial(next,exhausted);results[i]=1;}
            catch(const provider::error& e){results[i]=e.reason()==provider::rejection::serial_exhausted?2:3;}
            catch(...){results[i]=3;}
        });
    }
    start.store(true,std::memory_order_release);
    for(auto& thread:threads)thread->join();
    unsigned claims=0,refusals=0;
    for(std::size_t i=0;i<results.size();++i){
        if(results[i]==1){++claims;EXPECT_EQ(values[i].load(),last-1);}
        else{EXPECT_EQ(results[i].load(),2u);if(results[i]==2)++refusals;}
    }
    EXPECT_EQ(claims,1u);EXPECT_EQ(refusals,2u);
    EXPECT_EQ(next.load(),last);EXPECT_TRUE(exhausted.load());
    try{(void)provider::detail::claim_serial(next,exhausted);FAIL()<<"exhaustion must be sticky";}
    catch(const provider::error& e){EXPECT_EQ(e.reason(),provider::rejection::serial_exhausted);}
    EXPECT_EQ(next.load(),last);
}
TEST(PrivateSQLiteProviderSerial,InvalidZeroCounterRefusesWithoutIncrement){
    std::atomic<std::uint64_t> next{0};std::atomic<bool> exhausted{false};
    try{(void)provider::detail::claim_serial(next,exhausted);FAIL()<<"zero is not a serial";}
    catch(const provider::error& e){EXPECT_EQ(e.reason(),provider::rejection::serial_exhausted);}
    EXPECT_EQ(next.load(),0u);EXPECT_TRUE(exhausted.load());
}
