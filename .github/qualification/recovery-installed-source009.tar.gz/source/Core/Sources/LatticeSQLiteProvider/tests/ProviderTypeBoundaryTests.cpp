#include "lattice_sqlite_provider/provider.hpp"
// Independent system types are intentionally included AFTER provider types.
// Their header guards/constants/types must remain intact in the same TU.
#include <sqlite3.h>
#include <type_traits>
namespace provider=lattice::sqlite_provider::v1;
static_assert(!std::is_same_v<lattice_sqlite3541_connection,sqlite3>);
static_assert(!std::is_same_v<lattice_sqlite3541_stmt,sqlite3_stmt>);
static_assert(!std::is_same_v<lattice_sqlite3541_vfs,sqlite3_vfs>);
static_assert(!std::is_same_v<lattice_sqlite3541_context,sqlite3_context>);
static_assert(!std::is_same_v<lattice_sqlite3541_value,sqlite3_value>);
static_assert(!std::is_same_v<lattice_sqlite3541_rtree_query_info,sqlite3_rtree_query_info>);
static_assert(!std::is_convertible_v<sqlite3*,lattice_sqlite3541_connection*>);
static_assert(!std::is_convertible_v<sqlite3_stmt*,lattice_sqlite3541_stmt*>);
static_assert(!std::is_default_constructible_v<provider::open_original>);
static_assert(!std::is_copy_constructible_v<provider::open_original>);
static_assert(!std::is_move_constructible_v<provider::open_original>);
static_assert(!std::is_copy_constructible_v<provider::connection_original>);
static_assert(!std::is_move_constructible_v<provider::connection_original>);
static_assert(!std::is_constructible_v<provider::connection_original,sqlite3*>);
static_assert(!std::is_constructible_v<provider::vfs_original,sqlite3_vfs&>);
static_assert(!std::is_default_constructible_v<provider::vfs_original>);
// These are actual compiler constraints, not runtime/receipt acceptance. This
// new source remains UNCOMPILED and is not linked into existing product tests.

#include "lattice_sqlite_provider/native_v1.hpp"
static_assert(!std::is_default_constructible_v<provider::connection_ref>);
static_assert(!std::is_copy_constructible_v<provider::connection_ref>);
static_assert(!std::is_move_constructible_v<provider::connection_ref>);
static_assert(!std::is_constructible_v<provider::connection_ref,sqlite3*>);
static_assert(!std::is_constructible_v<provider::statement_original,sqlite3_stmt*>);
static_assert(!std::is_convertible_v<provider::connection_ref,sqlite3*>);
static_assert(!std::is_convertible_v<provider::statement_original,sqlite3_stmt*>);
static_assert(!std::is_copy_constructible_v<provider::statement_original>);
static_assert(!std::is_move_constructible_v<provider::statement_original>);
