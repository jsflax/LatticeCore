#ifndef LatticeBridge_hpp
#define LatticeBridge_hpp

#ifdef __cplusplus

#include <lattice.hpp>

namespace lattice {

inline OptionalString string_to_optional(const std::string& s) {
    return s;
}

inline OptionalInt64 int64_to_optional(int64_t v) {
    return v;
}

inline std::optional<std::vector<sync_filter_entry>> sync_filter_to_optional(const SyncFilterVector& v) {
    return std::vector<sync_filter_entry>(v.begin(), v.end());
}

using int64_t = int64_t;


using LinkListPtr = link_list*;

using StringVector = std::vector<std::string>;

#define get_field_(type, name) \
type get_##name(const std::string& name) const SWIFT_NAME(get_##name(named:)) { \
    return get_field<type>(name); \
}

// Type aliases for Swift C++ interop

using ManagedString = managed<std::string>;
using ManagedOptionalString = managed<std::optional<std::string>>;
using ManagedStringList = managed<std::vector<std::string>>;
using ManagedOptionalStringList = managed<std::optional<std::vector<std::string>>>;

using ManagedInt = managed<int64_t>;
using ManagedOptionalInt = managed<std::optional<int64_t>>;
using ManagedIntList = managed<std::vector<int>>;

using ManagedDouble = managed<double>;
using ManagedOptionalDouble = managed<std::optional<double>>;
using ManagedDoubleList = managed<std::vector<double>>;

using ManagedBool = managed<bool>;
using ManagedOptionalBool = managed<std::optional<bool>>;
using ManagedBoolList = managed<std::vector<bool>>;

using ManagedFloat = managed<float>;
using ManagedOptionalFloat = managed<std::optional<float>>;
using ManagedListFloat = managed<std::vector<float>>;

using ManagedTimestamp = managed<timestamp_t>;
using ManagedOptionalTimestamp = managed<std::optional<timestamp_t>>;
using ManagedListTimestamp = managed<std::vector<timestamp_t>>;

// Build a timestamp from seconds-since-epoch without going through Swift's
// `Duration` (iOS 16+). Equivalent to the `Duration.seconds(_:)` bridge but
// available on every deployment target, so the Date marshaling back-deploys.
inline timestamp_t timestamp_from_seconds(double seconds) {
    return timestamp_t(std::chrono::duration_cast<timestamp_t::duration>(
        std::chrono::duration<double>(seconds)));
}

using ManagedData = managed<ByteVector>;
using ManagedOptionalData = managed<std::optional<ByteVector>>;
using ManagedListData = managed<std::vector<ByteVector>>;

using ManagedUUID = managed<uuid_t>;
using ManagedOptionalUUID = managed<std::optional<uuid_t>>;
using ManagedListUUID = managed<std::vector<uuid_t>>;

using ManagedGeobounds = managed<geo_bounds>;
using ManagedListGeobounds = managed<std::vector<geo_bounds>>;

using ManagedLink = managed<swift_dynamic_object*>;

using ManagedFloatList = managed<std::vector<float>>;
using ManagedLinkList = managed<std::vector<swift_dynamic_object*>>;
using ManagedModel = managed<swift_dynamic_object>;

using ManagedOptionalModel = managed<std::optional<swift_dynamic_object>>;
using ModelVector = std::vector<swift_dynamic_object>;
using DynamicObjectVector = std::vector<dynamic_object>;
using DynamicObjectPtrVector = std::vector<dynamic_object*>;
// FRT path: a vector of foreign-reference pointers. Value path (iOS 15):
// dynamic_object_ref is a copyable value type, so the bulk vector holds values
// directly (the inner shared_ptr keeps each object alive).
#if LATTICE_HAS_FRT
using DynamicObjectRefPtrVector = std::vector<dynamic_object_ref*>;

// Helper function for Swift to push to vector
// (Works around Swift-C++ interop bug where SWIFT_SHARED_REFERENCE types
// are incorrectly converted when passed to std::vector::push_back)
inline bool push_dynamic_object_ref_checked(DynamicObjectRefPtrVector& vec, dynamic_object_ref* ptr) noexcept {
    return sealed([&] {
        if (!ptr || !ptr->valid()) throw std::runtime_error("Bulk add requires valid object refs");
        vec.push_back(ptr);
        return true;
    });
}
inline void push_dynamic_object_ref(DynamicObjectRefPtrVector& vec, dynamic_object_ref* ptr) {
    (void)push_dynamic_object_ref_checked(vec, ptr);
}
#else
using DynamicObjectRefPtrVector = std::vector<dynamic_object_ref>;

inline bool push_dynamic_object_ref_checked(DynamicObjectRefPtrVector& vec, const dynamic_object_ref& r) noexcept {
    return sealed([&] {
        if (!r.valid()) throw std::runtime_error("Bulk add requires valid object refs");
        vec.push_back(r);
        return true;
    });
}
inline void push_dynamic_object_ref(DynamicObjectRefPtrVector& vec, const dynamic_object_ref& r) {
    (void)push_dynamic_object_ref_checked(vec, r);
}
#endif

using OptionalManagedModel = std::optional<managed<swift_dynamic_object>>;

static OptionalManagedModel from_nonoptional(managed<swift_dynamic_object> o) {
    return o;
}
static ManagedModel from_optional(std::optional<managed<swift_dynamic_object>> o) {
    return *o;
}

template <typename T>
static std::optional<T> to_optional(const T& t);
template <>
std::optional<swift_configuration::SchemaPair> to_optional<swift_configuration::SchemaPair>(const swift_configuration::SchemaPair& p) {
    return p;
}
// Forward declarations
class swift_lattice;
class swift_lattice_ref;

static std::optional<cxx_error> last_error_;

// Swift-interop only (Apple blocks). Non-blocks compilers — the WASM
// build — never call this; Swift is not in that graph.
#ifdef __BLOCKS__
void try_catch(void (^_try)(), void (^_catch)(cxx_error)) {
    try {
        _try();
    } catch(const std::exception& e) {
        _catch(e);
    }
}
#endif  // __BLOCKS__

static std::optional<cxx_error> last_caught_error() {
    return last_error_;
}

cxx_error last_uncaught_error() {
    try {
        std::rethrow_exception(std::current_exception());
    } catch (const std::exception& e) {
        return cxx_error(e);
    }
}

void test_throws() {
    throw std::runtime_error("test error");
}

} // namespace lattice

#endif // __cplusplus

#endif /* LatticeBridge_hpp */
