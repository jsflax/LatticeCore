#include "../../LatticeCore/src/provider_native_internal.hpp"
#include <lattice.hpp>

namespace lattice {
swift_lattice::bbox_connection_guard::bbox_connection_guard(database& connection) : physical_call(connection) {
            if(!physical_call.entered())throw db_error("resource Native caller original unavailable");
            if (connection.is_closed() || !connection.internal_handle()) throw db_error("spatial connection is closed");
            mutex = lattice_sqlite3541_db_mutex(connection.internal_handle());
            lattice_sqlite3541_mutex_enter(mutex);
        }
swift_lattice::bbox_connection_guard::~bbox_connection_guard() { lattice_sqlite3541_mutex_leave(mutex); }
std::vector<database::row_t> swift_lattice::query_bbox_locked(database& connection,
        const std::string& sql, const ColumnValueVector& parameters) {
        lattice_sqlite3541_stmt* statement = nullptr;
        struct finalize { lattice_sqlite3541_stmt*& statement; ~finalize() { if (statement) ::lattice::detail::store_physical_finalize(statement); } } cleanup{statement};
        const char* tail = nullptr;
        database::record_statement();
        if (::lattice::detail::store_physical_prepare_v2(connection.internal_handle(), sql.c_str(), -1, &statement, &tail) != LATTICE_SQLITE3541_OK)
            throw db_error(lattice_sqlite3541_errmsg(connection.internal_handle()));
        while (tail && *tail && std::isspace(static_cast<unsigned char>(*tail))) ++tail;
        if (!statement || (tail && *tail) || !lattice_sqlite3541_stmt_readonly(statement) ||
            lattice_sqlite3541_bind_parameter_count(statement) != static_cast<int>(parameters.size()))
            throw db_error("spatial query requires one read-only statement with matching bindings");
        for (size_t i = 0; i != parameters.size(); ++i) {
            const int index = static_cast<int>(i + 1);
            const int result = std::visit([&](const auto& value) -> int {
                using T = std::decay_t<decltype(value)>;
                if constexpr (std::is_same_v<T, std::nullptr_t>) return lattice_sqlite3541_bind_null(statement, index);
                else if constexpr (std::is_same_v<T, int64_t>) return lattice_sqlite3541_bind_int64(statement, index, value);
                else if constexpr (std::is_same_v<T, double>) return lattice_sqlite3541_bind_double(statement, index, value);
                else if constexpr (std::is_same_v<T, std::string>)
                    return lattice_sqlite3541_bind_text64(statement, index, value.data(), value.size(), LATTICE_SQLITE3541_TRANSIENT, LATTICE_SQLITE3541_UTF8);
                else return value.empty() ? lattice_sqlite3541_bind_zeroblob(statement, index, 0) :
                    lattice_sqlite3541_bind_blob64(statement, index, value.data(), value.size(), LATTICE_SQLITE3541_TRANSIENT);
            }, parameters[i]);
            if (result != LATTICE_SQLITE3541_OK) throw db_error("spatial parameter binding failed");
        }
        std::vector<std::string> columns;
        for (int i = 0; i != lattice_sqlite3541_column_count(statement); ++i) {
            const auto* name = lattice_sqlite3541_column_name(statement, i);
            if (!name) throw db_error("spatial column name allocation failed");
            columns.emplace_back(name);
        }
        std::vector<database::row_t> rows;
        int result;
        while ((result = ::lattice::detail::store_physical_step(statement)) == LATTICE_SQLITE3541_ROW) {
            database::row_t row;
            for (int i = 0; i != static_cast<int>(columns.size()); ++i) {
                column_value_t value;
                switch (lattice_sqlite3541_column_type(statement, i)) {
                    case LATTICE_SQLITE3541_INTEGER: value = static_cast<int64_t>(lattice_sqlite3541_column_int64(statement, i)); break;
                    case LATTICE_SQLITE3541_FLOAT: value = lattice_sqlite3541_column_double(statement, i); break;
                    case LATTICE_SQLITE3541_TEXT: {
                        const auto* text = reinterpret_cast<const char*>(lattice_sqlite3541_column_text(statement, i));
                        if (!text) throw db_error("spatial text allocation failed");
                        value = std::string(text, lattice_sqlite3541_column_bytes(statement, i)); break;
                    }
                    case LATTICE_SQLITE3541_BLOB: {
                        const auto* blob = static_cast<const uint8_t*>(lattice_sqlite3541_column_blob(statement, i));
                        const int length = lattice_sqlite3541_column_bytes(statement, i);
                        if (length && !blob) throw db_error("spatial blob allocation failed");
                        value = length ? std::vector<uint8_t>(blob, blob + length) : std::vector<uint8_t>{}; break;
                    }
                    default: value = nullptr; break;
                }
                row.emplace(columns[static_cast<size_t>(i)], std::move(value));
            }
            rows.push_back(std::move(row));
        }
        if (result != LATTICE_SQLITE3541_DONE) throw db_error(lattice_sqlite3541_errmsg(connection.internal_handle()));
        return rows;
    }
}
