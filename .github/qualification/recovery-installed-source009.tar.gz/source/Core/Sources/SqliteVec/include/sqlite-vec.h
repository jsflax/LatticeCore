#ifndef LATTICE_SQLITE3541_VEC_H
#define LATTICE_SQLITE3541_VEC_H

// Constants-only public header. Native declarations are source-private.

#ifdef LATTICE_SQLITE3541_VEC_STATIC
  #define LATTICE_SQLITE3541_VEC_API
#else
  #ifdef _WIN32
    #define LATTICE_SQLITE3541_VEC_API __declspec(dllexport)
  #else
    #define LATTICE_SQLITE3541_VEC_API
  #endif
#endif

#define LATTICE_SQLITE3541_VEC_VERSION "v0.1.10-alpha.3"
// TODO rm
#define LATTICE_SQLITE3541_VEC_DATE "2026-04-01T06:40:47Z+0000"
#define LATTICE_SQLITE3541_VEC_SOURCE "4e2dfcb79dcb961bdbaca11dfc91b5bfb9de4fd3"


#define LATTICE_SQLITE3541_VEC_VERSION_MAJOR 0
#define LATTICE_SQLITE3541_VEC_VERSION_MINOR 1
#define LATTICE_SQLITE3541_VEC_VERSION_PATCH 10

#ifdef __cplusplus
extern "C" {
#endif



#ifdef __cplusplus
}  /* end of the 'extern "C"' block */
#endif

#endif /* ifndef SQLITE_VEC_H */
