#ifndef LATTICE_SQLITE3541_VEC_PRIVATE_NATIVE_API_H
#define LATTICE_SQLITE3541_VEC_PRIVATE_NATIVE_API_H
// SOURCE-PRIVATE homogeneous provider binding; never an installed raw escape.
#if !defined(LATTICE_SQLITE3541_CORE)
#error "Lattice Vec requires its homogeneous private SQLite provider target"
#endif
#include "../../LatticeSQLiteProvider/src/native_api.h"
#include "../include/sqlite-vec.h"
#ifdef __cplusplus
extern "C" {
#endif
LATTICE_SQLITE3541_VEC_API int lattice_sqlite3541_vec_init(lattice_sqlite3541_connection *,char **,
    const lattice_sqlite3541_api_routines *);
#ifdef __cplusplus
}
#endif
#endif
