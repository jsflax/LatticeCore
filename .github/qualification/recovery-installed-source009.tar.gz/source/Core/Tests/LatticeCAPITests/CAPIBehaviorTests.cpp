// LatticeCAPITests — behavioral tests against the C ABI (C1 slice 2).
//
// Unlike CAPISurfaceTests (which pins the DECLARED surface by parsing
// sources), this target LINKS the C surface and exercises it end-to-end:
// slice 2's additions (sync options, sync progress + observers, detach,
// row cache, increment, statement counters, checkpoint, upload floor) plus
// behavioral pins for slice 1's fixes (the formerly-phantom cross-process
// observers actually fire across instances; receive_sync_data applies with
// per-entry error isolation).
//
// This file includes ONLY lattice.h from the product — everything
// observable must be observable through the C ABI, exactly as a
// Kotlin/Python binding would see it. (nlohmann/json.hpp is included as a
// TEST-SIDE verifier only, to parse lattice_object_to_json output — JSON
// object key order is unspecified, so string comparison would overpin.)
// (SwiftPM: macOS-only executable target `LatticeCAPITests`; CMake: built
// everywhere — see docs/capi-gap-audit.md V1 for why the SwiftPM Linux
// closure must not grow the C API library.)

#include <gtest/gtest.h>

#include "lattice.h"

#include <nlohmann/json.hpp>

#include <atomic>
#include <chrono>
#include <cstddef>
#include <cstring>
#include <filesystem>
#include <functional>
#include <random>
#include <string>
#include <thread>
#include <vector>

namespace {

// ============================================================================
// Helpers
// ============================================================================

struct TempPath {
    std::filesystem::path path;

    explicit TempPath(const std::string& name)
        : path(std::filesystem::temp_directory_path()
               / (name + "_" + random_suffix() + ".sqlite")) {}

    ~TempPath() {
        std::error_code ec;
        std::filesystem::remove(path, ec);
        std::filesystem::remove(path.string() + "-wal", ec);
        std::filesystem::remove(path.string() + "-shm", ec);
    }

    TempPath(const TempPath&) = delete;
    TempPath& operator=(const TempPath&) = delete;

    std::string str() const { return path.string(); }

private:
    static std::string random_suffix() {
        static std::mt19937 rng(std::random_device{}());
        std::uniform_int_distribution<uint32_t> dist;
        return std::to_string(dist(rng));
    }
};

// Person schema: name TEXT, age INTEGER (+ optional extra column for
// schema-mismatch fixtures).
struct PersonSchema {
    lattice_property_t props[3];
    lattice_schema_t schema;

    explicit PersonSchema(bool with_extra_column = false) {
        std::memset(props, 0, sizeof(props));
        props[0].name = "name";
        props[0].type = LATTICE_TYPE_TEXT;
        props[0].kind = LATTICE_KIND_PRIMITIVE;
        props[0].nullable = true;
        props[1].name = "age";
        props[1].type = LATTICE_TYPE_INTEGER;
        props[1].kind = LATTICE_KIND_PRIMITIVE;
        props[1].nullable = true;
        props[2].name = "extra";
        props[2].type = LATTICE_TYPE_TEXT;
        props[2].kind = LATTICE_KIND_PRIMITIVE;
        props[2].nullable = true;
        std::memset(&schema, 0, sizeof(schema));
        schema.table_name = "Person";
        schema.properties = props;
        schema.property_count = with_extra_column ? 3u : 2u;
    }
};

// Adds a Person and returns the managed object handle (caller releases once).
lattice_object_t* add_person(lattice_db_t* db, const char* name, int64_t age) {
    lattice_object_t* obj = lattice_db_create_object(db, "Person");
    EXPECT_NE(obj, nullptr) << lattice_last_error();
    if (!obj) return nullptr;
    lattice_object_set_string(obj, "name", name);
    lattice_object_set_int(obj, "age", age);
    lattice_object_t* managed = lattice_db_add(db, obj);
    EXPECT_NE(managed, nullptr) << lattice_last_error();
    if (managed) {
        // lattice_db_add returns the same handle with an extra retain.
        lattice_object_release(managed);
    }
    return obj;
}

bool wait_for(const std::function<bool()>& cond,
              std::chrono::milliseconds timeout = std::chrono::seconds(10)) {
    auto deadline = std::chrono::steady_clock::now() + timeout;
    while (std::chrono::steady_clock::now() < deadline) {
        if (cond()) return true;
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
    return cond();
}

size_t count_json_strings(const char* json_array) {
    if (!json_array) return 0;
    size_t quotes = 0;
    for (const char* p = json_array; *p; p++) {
        if (*p == '"' && (p == json_array || p[-1] != '\\')) quotes++;
    }
    return quotes / 2;
}

// Inline scheduler for lattice_db_create_with_scheduler in tests.
void inline_invoke(void* /*context*/, void (*callback)(void*), void* callback_context) {
    callback(callback_context);
}

}  // namespace

// ============================================================================
// Feature flags (slice 2 flips)
// ============================================================================

TEST(CAPIFeatures, Slice2FeatureStringsAreTrue) {
    for (const char* f : {"checkpoint", "detach", "row_cache", "statement_counters",
                          "sync_progress", "sync_tuning", "to_json"}) {
        EXPECT_TRUE(lattice_capi_has_feature(f)) << f;
    }
    // Still reserved. unified_open deliberately stays false at 1.0 — the
    // drop-gate decision is documented in docs/design-unified-open.md.
    for (const char* f : {"read_generations", "unified_open"}) {
        EXPECT_FALSE(lattice_capi_has_feature(f)) << f;
    }
    EXPECT_FALSE(lattice_capi_has_feature("no_such_feature"));
    EXPECT_FALSE(lattice_capi_has_feature(nullptr));
}

// ============================================================================
// Sync options
// ============================================================================

TEST(CAPISyncOptions, InitFillsDefaults) {
    lattice_sync_options_t opts;
    std::memset(&opts, 0xAB, sizeof(opts));  // poison
    lattice_sync_options_init(&opts);
    EXPECT_EQ(opts.struct_size, sizeof(lattice_sync_options_t));
    EXPECT_EQ(opts.chunk_size, 0);
    EXPECT_EQ(opts.max_reconnect_attempts, -1);
    EXPECT_EQ(opts.base_delay_seconds, 0.0);
    EXPECT_EQ(opts.max_delay_seconds, 0.0);
    EXPECT_EQ(opts.stable_connection_ms, -1);
    EXPECT_EQ(opts.upload_coalesce_ms, -1);
    EXPECT_EQ(opts.checkpoint_passive_interval_ms, -1);
    EXPECT_EQ(opts.checkpoint_truncate_interval_ms, -1);
    EXPECT_EQ(opts.use_upload_floor, -1);
    EXPECT_EQ(opts.sync_filter_json, nullptr);
    EXPECT_EQ(opts.sync_id, nullptr);
    lattice_sync_options_init(nullptr);  // documented no-op
}

TEST(CAPISyncOptions, RoundTripThroughRealOpen) {
    TempPath path("capi_syncopts");
    PersonSchema ps;

    lattice_sync_options_t opts;
    lattice_sync_options_init(&opts);
    opts.chunk_size = 512;
    opts.max_reconnect_attempts = 7;
    opts.base_delay_seconds = 0.5;
    opts.max_delay_seconds = 30.0;
    opts.stable_connection_ms = 4000;
    opts.upload_coalesce_ms = 25;
    opts.checkpoint_passive_interval_ms = 1000;
    opts.checkpoint_truncate_interval_ms = 60000;
    opts.use_upload_floor = 1;
    opts.sync_filter_json = R"([{"table":"Person","predicate":"age > 10"}])";

    // No WSS endpoint: the tuning overlays configuration::sync_tuning and the
    // open must succeed and behave as a fully functional database.
    lattice_db_t* db = lattice_db_create_with_sync_options(
        path.str().c_str(), &ps.schema, 1, nullptr, nullptr, nullptr, &opts);
    ASSERT_NE(db, nullptr) << lattice_last_error();

    lattice_object_t* p = add_person(db, "tuned", 42);
    ASSERT_NE(p, nullptr);
    EXPECT_EQ(lattice_db_count(db, "Person", nullptr), 1u);
    lattice_object_release(p);
    lattice_db_close(db);
    lattice_db_release(db);
}

TEST(CAPISyncOptions, NullOptionsBehavesLikeCreateWithSync) {
    TempPath path("capi_syncopts_null");
    PersonSchema ps;
    lattice_db_t* db = lattice_db_create_with_sync_options(
        path.str().c_str(), &ps.schema, 1, nullptr, nullptr, nullptr, nullptr);
    ASSERT_NE(db, nullptr) << lattice_last_error();
    lattice_object_t* p = add_person(db, "plain", 1);
    ASSERT_NE(p, nullptr);
    EXPECT_EQ(lattice_db_count(db, "Person", nullptr), 1u);
    lattice_object_release(p);
    lattice_db_close(db);
    lattice_db_release(db);
}

TEST(CAPISyncOptions, NonsenseValuesAreIgnoredNotFatal) {
    TempPath path("capi_syncopts_junk");
    PersonSchema ps;

    lattice_sync_options_t opts;
    lattice_sync_options_init(&opts);
    // Mirror of the bridge setters: all of these are IGNORED (knob keeps the
    // library default) — the open must still succeed.
    opts.chunk_size = -5;
    opts.max_reconnect_attempts = -3;
    opts.base_delay_seconds = -1.0;
    opts.max_delay_seconds = -2.0;
    opts.stable_connection_ms = -100;
    opts.upload_coalesce_ms = -7;
    opts.checkpoint_passive_interval_ms = -1;
    opts.checkpoint_truncate_interval_ms = -9;

    lattice_db_t* db = lattice_db_create_with_sync_options(
        path.str().c_str(), &ps.schema, 1, nullptr, nullptr, nullptr, &opts);
    ASSERT_NE(db, nullptr) << lattice_last_error();
    lattice_object_t* p = add_person(db, "junk", 2);
    ASSERT_NE(p, nullptr);
    EXPECT_EQ(lattice_db_count(db, "Person", nullptr), 1u);
    lattice_object_release(p);
    lattice_db_close(db);
    lattice_db_release(db);
}

TEST(CAPISyncOptions, ZeroStructSizeFailsTheOpen) {
    TempPath path("capi_syncopts_zsz");
    PersonSchema ps;
    lattice_sync_options_t opts;
    std::memset(&opts, 0, sizeof(opts));  // struct_size == 0: init was skipped
    lattice_db_t* db = lattice_db_create_with_sync_options(
        path.str().c_str(), &ps.schema, 1, nullptr, nullptr, nullptr, &opts);
    EXPECT_EQ(db, nullptr);
    ASSERT_NE(lattice_last_error(), nullptr);
    EXPECT_NE(std::string(lattice_last_error()).find("struct_size"), std::string::npos);
}

TEST(CAPISyncOptions, ReservedSyncIdFailsTheOpen) {
    TempPath path("capi_syncopts_sid");
    PersonSchema ps;
    lattice_sync_options_t opts;
    lattice_sync_options_init(&opts);
    opts.sync_id = "wss:custom";
    lattice_db_t* db = lattice_db_create_with_sync_options(
        path.str().c_str(), &ps.schema, 1, nullptr, nullptr, nullptr, &opts);
    EXPECT_EQ(db, nullptr);
    ASSERT_NE(lattice_last_error(), nullptr);
    EXPECT_NE(std::string(lattice_last_error()).find("sync_id"), std::string::npos);
}

TEST(CAPISyncOptions, MalformedFilterJsonFailsTheOpen) {
    TempPath path("capi_syncopts_badjson");
    PersonSchema ps;
    lattice_sync_options_t opts;
    lattice_sync_options_init(&opts);
    opts.sync_filter_json = "{\"table\": \"Person\"}";  // object, not array
    lattice_db_t* db = lattice_db_create_with_sync_options(
        path.str().c_str(), &ps.schema, 1, nullptr, nullptr, nullptr, &opts);
    EXPECT_EQ(db, nullptr);
    EXPECT_NE(lattice_last_error(), nullptr);
}

TEST(CAPISyncOptions, ShorterCallerStructIsAccepted) {
    TempPath path("capi_syncopts_short");
    PersonSchema ps;
    // Simulate an old caller compiled against a struct that ended after the
    // tuning knobs: the impl must read only the declared prefix and default
    // the rest (the pointers land at their NULL defaults).
    lattice_sync_options_t opts;
    lattice_sync_options_init(&opts);
    opts.chunk_size = 64;
    opts.struct_size = offsetof(lattice_sync_options_t, sync_filter_json);
    // Poison the tail: a size-respecting impl must never read past struct_size.
    opts.sync_filter_json = reinterpret_cast<const char*>(0x1);
    opts.sync_id = reinterpret_cast<const char*>(0x1);

    lattice_db_t* db = lattice_db_create_with_sync_options(
        path.str().c_str(), &ps.schema, 1, nullptr, nullptr, nullptr, &opts);
    ASSERT_NE(db, nullptr) << lattice_last_error();
    lattice_db_close(db);
    lattice_db_release(db);
}

// ============================================================================
// Sync progress
// ============================================================================

TEST(CAPISyncProgress, ZeroedOnSyncLessDb) {
    TempPath path("capi_progress");
    PersonSchema ps;
    lattice_db_t* db = lattice_db_create_with_schemas(path.str().c_str(), &ps.schema, 1);
    ASSERT_NE(db, nullptr) << lattice_last_error();

    // A live db with neither WSS nor IPC sync: LATTICE_OK, all counters zero.
    lattice_sync_progress_t progress;
    std::memset(&progress, 0xCD, sizeof(progress));  // poison
    progress.struct_size = sizeof(progress);
    ASSERT_EQ(lattice_db_get_sync_progress(db, &progress), LATTICE_OK)
        << lattice_last_error();
    EXPECT_EQ(progress.struct_size, sizeof(progress));
    EXPECT_EQ(progress.pending_upload, 0);
    EXPECT_EQ(progress.total_upload, 0);
    EXPECT_EQ(progress.acked, 0);
    EXPECT_EQ(progress.received, 0);

    // Writes don't invent progress without a synchronizer.
    lattice_object_t* p = add_person(db, "noprog", 3);
    ASSERT_NE(p, nullptr);
    lattice_object_release(p);
    progress.struct_size = sizeof(progress);
    ASSERT_EQ(lattice_db_get_sync_progress(db, &progress), LATTICE_OK);
    EXPECT_EQ(progress.pending_upload, 0);
    EXPECT_EQ(progress.received, 0);

    // Size-prefix contract: a shorter caller struct gets only its prefix.
    lattice_sync_progress_t small;
    std::memset(&small, 0, sizeof(small));
    small.struct_size = offsetof(lattice_sync_progress_t, acked);
    small.acked = -99;  // beyond declared size: must NOT be written
    ASSERT_EQ(lattice_db_get_sync_progress(db, &small), LATTICE_OK);
    EXPECT_EQ(small.struct_size, offsetof(lattice_sync_progress_t, acked));
    EXPECT_EQ(small.acked, -99);

    // Invalid args.
    EXPECT_EQ(lattice_db_get_sync_progress(nullptr, &progress), LATTICE_ERROR_NULL_POINTER);
    EXPECT_EQ(lattice_db_get_sync_progress(db, nullptr), LATTICE_ERROR_NULL_POINTER);
    lattice_sync_progress_t zero_size;
    std::memset(&zero_size, 0, sizeof(zero_size));
    EXPECT_EQ(lattice_db_get_sync_progress(db, &zero_size), LATTICE_ERROR_INVALID_ARGUMENT);

    lattice_db_close(db);
    lattice_db_release(db);
}

// ============================================================================
// Sync observers (registration surface; callbacks need a live transport)
// ============================================================================

namespace {
struct ObserverProbe {
    std::atomic<int> destroyed{0};
};
void probe_destroy(void* ctx) { static_cast<ObserverProbe*>(ctx)->destroyed++; }
void noop_progress(void*, const lattice_sync_progress_t*) {}
void noop_state(void*, bool) {}
void noop_error(void*, const char*) {}
}  // namespace

TEST(CAPISyncObservers, RegisterRemoveAndDestroySemantics) {
    TempPath path("capi_syncobs");
    PersonSchema ps;
    lattice_db_t* db = lattice_db_create_with_schemas(path.str().c_str(), &ps.schema, 1);
    ASSERT_NE(db, nullptr) << lattice_last_error();

    ObserverProbe p1, p2, p3;
    uint64_t t1 = lattice_db_observe_sync_progress(db, &p1, noop_progress, probe_destroy);
    uint64_t t2 = lattice_db_observe_sync_state(db, &p2, noop_state, probe_destroy);
    uint64_t t3 = lattice_db_observe_sync_error(db, &p3, noop_error, probe_destroy);
    ASSERT_NE(t1, 0u);
    ASSERT_NE(t2, 0u);
    ASSERT_NE(t3, 0u);
    // Tokens are shared across the three kinds: all distinct.
    EXPECT_NE(t1, t2);
    EXPECT_NE(t2, t3);
    EXPECT_NE(t1, t3);

    // Removal fires destroy exactly once, for the removed observer only.
    lattice_db_remove_sync_observer(db, t2);
    EXPECT_EQ(p2.destroyed.load(), 1);
    EXPECT_EQ(p1.destroyed.load(), 0);
    EXPECT_EQ(p3.destroyed.load(), 0);

    // Unknown token / double-remove: documented no-op.
    lattice_db_remove_sync_observer(db, t2);
    lattice_db_remove_sync_observer(db, 424242);
    EXPECT_EQ(p2.destroyed.load(), 1);

    // Invalid registrations return 0.
    EXPECT_EQ(lattice_db_observe_sync_progress(nullptr, &p1, noop_progress, nullptr), 0u);
    EXPECT_EQ(lattice_db_observe_sync_progress(db, &p1, nullptr, nullptr), 0u);

    // close() removes remaining observers and fires their destroys.
    lattice_db_close(db);
    EXPECT_EQ(p1.destroyed.load(), 1);
    EXPECT_EQ(p3.destroyed.load(), 1);
    EXPECT_EQ(p2.destroyed.load(), 1);  // not double-destroyed

    lattice_db_release(db);
}

TEST(CAPISyncObservers, MultipleObserversPerKind) {
    TempPath path("capi_syncobs_multi");
    PersonSchema ps;
    lattice_db_t* db = lattice_db_create_with_schemas(path.str().c_str(), &ps.schema, 1);
    ASSERT_NE(db, nullptr) << lattice_last_error();

    ObserverProbe a, b;
    uint64_t ta = lattice_db_observe_sync_progress(db, &a, noop_progress, probe_destroy);
    uint64_t tb = lattice_db_observe_sync_progress(db, &b, noop_progress, probe_destroy);
    ASSERT_NE(ta, 0u);
    ASSERT_NE(tb, 0u);
    EXPECT_NE(ta, tb);

    lattice_db_remove_sync_observer(db, ta);
    EXPECT_EQ(a.destroyed.load(), 1);
    EXPECT_EQ(b.destroyed.load(), 0);
    lattice_db_remove_sync_observer(db, tb);
    EXPECT_EQ(b.destroyed.load(), 1);

    lattice_db_close(db);
    lattice_db_release(db);
}

// ============================================================================
// Detach + last_attach_error
// ============================================================================

TEST(CAPIAttachDetach, RoundTripAndIdempotence) {
    TempPath a_path("capi_att_a"), b_path("capi_att_b");
    PersonSchema ps;
    lattice_db_t* a = lattice_db_create_with_schemas(a_path.str().c_str(), &ps.schema, 1);
    lattice_db_t* b = lattice_db_create_with_schemas(b_path.str().c_str(), &ps.schema, 1);
    ASSERT_NE(a, nullptr) << lattice_last_error();
    ASSERT_NE(b, nullptr) << lattice_last_error();

    lattice_object_t* pa = add_person(a, "in-a", 1);
    lattice_object_t* pb = add_person(b, "in-b", 2);
    ASSERT_NE(pa, nullptr);
    ASSERT_NE(pb, nullptr);

    EXPECT_EQ(lattice_db_last_attach_error(a), nullptr);

    ASSERT_EQ(lattice_db_attach(a, b), LATTICE_OK) << lattice_last_error();
    EXPECT_EQ(lattice_db_count(a, "Person", nullptr), 2u);  // union view

    ASSERT_EQ(lattice_db_detach(a, b), LATTICE_OK) << lattice_last_error();
    EXPECT_EQ(lattice_db_count(a, "Person", nullptr), 1u);  // main only

    // Idempotent: detaching a non-attached database succeeds.
    EXPECT_EQ(lattice_db_detach(a, b), LATTICE_OK) << lattice_last_error();
    EXPECT_EQ(lattice_db_last_attach_error(a), nullptr);

    // Invalid args.
    EXPECT_EQ(lattice_db_detach(nullptr, b), LATTICE_ERROR_NULL_POINTER);
    EXPECT_EQ(lattice_db_detach(a, nullptr), LATTICE_ERROR_NULL_POINTER);

    lattice_object_release(pa);
    lattice_object_release(pb);
    lattice_db_close(a);
    lattice_db_close(b);
    lattice_db_release(a);
    lattice_db_release(b);
}

TEST(CAPIAttachDetach, SchemaMismatchSurfacesAttachError) {
    TempPath a_path("capi_att_mm_a"), c_path("capi_att_mm_c");
    PersonSchema ps;
    PersonSchema ps_extra(/*with_extra_column=*/true);
    lattice_db_t* a = lattice_db_create_with_schemas(a_path.str().c_str(), &ps.schema, 1);
    lattice_db_t* c = lattice_db_create_with_schemas(c_path.str().c_str(), &ps_extra.schema, 1);
    ASSERT_NE(a, nullptr) << lattice_last_error();
    ASSERT_NE(c, nullptr) << lattice_last_error();

    lattice_object_t* pa = add_person(a, "main", 1);
    ASSERT_NE(pa, nullptr);

    // Same table name, diverged columns: attach must FAIL LOUDLY (slice 1
    // fixed the silent-LATTICE_OK regression) and expose the reason.
    EXPECT_EQ(lattice_db_attach(a, c), LATTICE_ERROR_DATABASE);
    EXPECT_NE(lattice_last_error(), nullptr);
    const char* reason = lattice_db_last_attach_error(a);
    ASSERT_NE(reason, nullptr);
    EXPECT_GT(std::strlen(reason), 0u);

    // Main database unaffected by the failed attach.
    EXPECT_EQ(lattice_db_count(a, "Person", nullptr), 1u);

    lattice_object_release(pa);
    lattice_db_close(a);
    lattice_db_close(c);
    lattice_db_release(a);
    lattice_db_release(c);
}

// ============================================================================
// Row cache + increment
// ============================================================================

TEST(CAPIRowCache, LifecycleOnManagedObject) {
    TempPath path("capi_rowcache");
    PersonSchema ps;
    lattice_db_t* db = lattice_db_create_with_schemas(path.str().c_str(), &ps.schema, 1);
    ASSERT_NE(db, nullptr) << lattice_last_error();

    lattice_object_t* p = add_person(db, "cached", 30);
    ASSERT_NE(p, nullptr);

    EXPECT_FALSE(lattice_object_is_row_cache_enabled(p));
    ASSERT_EQ(lattice_object_enable_row_cache(p), LATTICE_OK) << lattice_last_error();
    EXPECT_TRUE(lattice_object_is_row_cache_enabled(p));

    // Snapshot reads are correct.
    EXPECT_STREQ(lattice_object_get_string(p, "name"), "cached");
    EXPECT_EQ(lattice_object_get_int(p, "age"), 30);

    // Write-through: read-your-writes holds while cached.
    lattice_object_set_int(p, "age", 31);
    EXPECT_EQ(lattice_object_get_int(p, "age"), 31);

    // Refresh (staleness escape hatch) keeps values consistent.
    ASSERT_EQ(lattice_object_refresh_row_cache(p), LATTICE_OK) << lattice_last_error();
    EXPECT_EQ(lattice_object_get_int(p, "age"), 31);

    ASSERT_EQ(lattice_object_disable_row_cache(p), LATTICE_OK);
    EXPECT_FALSE(lattice_object_is_row_cache_enabled(p));
    EXPECT_EQ(lattice_object_get_int(p, "age"), 31);  // live path agrees

    // Null-arg contract.
    EXPECT_EQ(lattice_object_enable_row_cache(nullptr), LATTICE_ERROR_NULL_POINTER);
    EXPECT_FALSE(lattice_object_is_row_cache_enabled(nullptr));

    lattice_object_release(p);
    lattice_db_close(db);
    lattice_db_release(db);
}

TEST(CAPIRowCache, NoOpOnUnmanagedObject) {
    PersonSchema ps;
    lattice_object_t* obj =
        lattice_object_create_with_schema("Person", ps.props, ps.schema.property_count);
    ASSERT_NE(obj, nullptr) << lattice_last_error();
    // Unmanaged objects are already value snapshots: enable is a documented
    // no-op and the flag stays false.
    EXPECT_EQ(lattice_object_enable_row_cache(obj), LATTICE_OK);
    EXPECT_FALSE(lattice_object_is_row_cache_enabled(obj));
    lattice_object_release(obj);
}

TEST(CAPIIncrement, SqlSideIncrementPersists) {
    TempPath path("capi_incr");
    PersonSchema ps;
    lattice_db_t* db = lattice_db_create_with_schemas(path.str().c_str(), &ps.schema, 1);
    ASSERT_NE(db, nullptr) << lattice_last_error();

    lattice_object_t* p = add_person(db, "counter", 40);
    ASSERT_NE(p, nullptr);
    int64_t id = lattice_object_get_id(p);
    ASSERT_GT(id, 0);

    ASSERT_EQ(lattice_object_increment_int(p, "age", 2), LATTICE_OK) << lattice_last_error();
    ASSERT_EQ(lattice_object_increment_int(p, "age", -1), LATTICE_OK) << lattice_last_error();
    EXPECT_EQ(lattice_object_get_int(p, "age"), 41);

    // The increment is SQL-side: a FRESH handle reads the same value.
    lattice_object_t* fresh = lattice_db_find(db, "Person", id);
    ASSERT_NE(fresh, nullptr) << lattice_last_error();
    EXPECT_EQ(lattice_object_get_int(fresh, "age"), 41);
    lattice_object_release(fresh);

    EXPECT_EQ(lattice_object_increment_int(nullptr, "age", 1), LATTICE_ERROR_NULL_POINTER);
    EXPECT_EQ(lattice_object_increment_int(p, nullptr, 1), LATTICE_ERROR_NULL_POINTER);

    lattice_object_release(p);
    lattice_db_close(db);
    lattice_db_release(db);
}

TEST(CAPIIncrement, InMemoryIncrementOnUnmanagedObject) {
    PersonSchema ps;
    lattice_object_t* obj =
        lattice_object_create_with_schema("Person", ps.props, ps.schema.property_count);
    ASSERT_NE(obj, nullptr) << lattice_last_error();
    lattice_object_set_int(obj, "age", 5);
    ASSERT_EQ(lattice_object_increment_int(obj, "age", 3), LATTICE_OK);
    EXPECT_EQ(lattice_object_get_int(obj, "age"), 8);
    lattice_object_release(obj);
}

// ============================================================================
// Statement counters
// ============================================================================

TEST(CAPIStatementCounters, CountersAdvanceWithQueries) {
    TempPath path("capi_counters");
    PersonSchema ps;
    lattice_db_t* db = lattice_db_create_with_schemas(path.str().c_str(), &ps.schema, 1);
    ASSERT_NE(db, nullptr) << lattice_last_error();

    uint64_t total0 = lattice_db_total_statement_count();
    uint64_t thread0 = lattice_db_thread_statement_count();

    lattice_object_t* p = add_person(db, "count-me", 7);
    ASSERT_NE(p, nullptr);
    EXPECT_EQ(lattice_db_count(db, "Person", nullptr), 1u);

    EXPECT_GT(lattice_db_total_statement_count(), total0);
    EXPECT_GT(lattice_db_thread_statement_count(), thread0);
    // The process-global counter includes at least everything this thread did.
    EXPECT_GE(lattice_db_total_statement_count() - total0,
              lattice_db_thread_statement_count() - thread0);

    lattice_object_release(p);
    lattice_db_close(db);
    lattice_db_release(db);
}

// ============================================================================
// Checkpoint
// ============================================================================

TEST(CAPICheckpoint, PassiveAndTruncateModes) {
    TempPath path("capi_ckpt");
    PersonSchema ps;
    lattice_db_t* db = lattice_db_create_with_schemas(path.str().c_str(), &ps.schema, 1);
    ASSERT_NE(db, nullptr) << lattice_last_error();

    for (int i = 0; i < 10; i++) {
        lattice_object_t* p = add_person(db, "walrow", i);
        ASSERT_NE(p, nullptr);
        lattice_object_release(p);
    }

    EXPECT_EQ(lattice_db_checkpoint(db, 0), LATTICE_OK) << lattice_last_error();  // passive
    EXPECT_EQ(lattice_db_checkpoint(db, 1), LATTICE_OK) << lattice_last_error();  // truncate
    // Data intact after both.
    EXPECT_EQ(lattice_db_count(db, "Person", nullptr), 10u);

    EXPECT_EQ(lattice_db_checkpoint(db, 2), LATTICE_ERROR_INVALID_ARGUMENT);
    EXPECT_EQ(lattice_db_checkpoint(db, -1), LATTICE_ERROR_INVALID_ARGUMENT);
    EXPECT_EQ(lattice_db_checkpoint(nullptr, 0), LATTICE_ERROR_NULL_POINTER);

    lattice_db_close(db);
    lattice_db_release(db);
}

// ============================================================================
// Upload floor
// ============================================================================

TEST(CAPIUploadFloor, ZeroWithoutSlotAndInvalidArgs) {
    TempPath path("capi_floor");
    PersonSchema ps;
    lattice_db_t* db = lattice_db_create_with_schemas(path.str().c_str(), &ps.schema, 1);
    ASSERT_NE(db, nullptr) << lattice_last_error();

    // No synchronizer has ever registered this slot: floor is 0.
    EXPECT_EQ(lattice_db_read_upload_floor(db, "wss:wss://nowhere.example/sync"), 0);
    EXPECT_EQ(lattice_db_read_upload_floor(db, "ipc:none"), 0);

    EXPECT_EQ(lattice_db_read_upload_floor(nullptr, "wss:x"), -1);
    EXPECT_EQ(lattice_db_read_upload_floor(db, nullptr), -1);

    lattice_db_close(db);
    lattice_db_release(db);
}

// ============================================================================
// Slice-1 behavioral pins
// ============================================================================

namespace {
struct XprocProbe {
    std::atomic<int> fired{0};
    std::string last_op;
    std::mutex op_mutex;
};

void xproc_callback(void* ctx, const char* operation, int64_t /*row_id*/,
                    const char* /*global_id*/) {
    auto* probe = static_cast<XprocProbe*>(ctx);
    {
        std::lock_guard<std::mutex> lock(probe->op_mutex);
        probe->last_op = operation ? operation : "";
    }
    probe->fired++;
}
}  // namespace

// Slice 1 implemented the two formerly-phantom symbols. Pin the BEHAVIOR:
// an observer registered through lattice_db_observe_cross_process fires when
// a DIFFERENT database instance on the same path commits a write (the same
// shared dispatch path cross-process delivery rides; a sibling in-process
// instance is the deterministic way to exercise it in one test process).
TEST(CAPICrossProcessObservation, ObserverFiresForSiblingInstanceWrites) {
    TempPath path("capi_xproc");
    PersonSchema ps;

    // Instance A: plain open (immediate scheduler → callbacks fire inline).
    lattice_db_t* a = lattice_db_create_with_schemas(path.str().c_str(), &ps.schema, 1);
    ASSERT_NE(a, nullptr) << lattice_last_error();

    // Instance B: same path, DIFFERENT cache key (explicit scheduler) →
    // a genuinely distinct instance whose writes reach A only through the
    // shared change-dispatch path.
    lattice_scheduler_t* sched = lattice_scheduler_create(nullptr, inline_invoke, nullptr);
    ASSERT_NE(sched, nullptr);
    lattice_db_t* b = lattice_db_create_with_scheduler(path.str().c_str(), &ps.schema, 1, sched);
    ASSERT_NE(b, nullptr) << lattice_last_error();

    XprocProbe probe;
    uint64_t token = lattice_db_observe_cross_process(a, "Person", &probe, xproc_callback);
    ASSERT_NE(token, 0u) << lattice_last_error();

    lattice_object_t* p = add_person(b, "from-b", 11);
    ASSERT_NE(p, nullptr);

    ASSERT_TRUE(wait_for([&] { return probe.fired.load() > 0; }))
        << "cross-process observer never fired for a sibling-instance write";
    {
        std::lock_guard<std::mutex> lock(probe.op_mutex);
        EXPECT_EQ(probe.last_op, "INSERT");
    }

    // Removal stops delivery. Settle any in-flight dispatch first.
    std::this_thread::sleep_for(std::chrono::milliseconds(500));
    lattice_db_remove_cross_process_observer(a, token);
    int fired_at_removal = probe.fired.load();

    lattice_object_t* p2 = add_person(b, "after-remove", 12);
    ASSERT_NE(p2, nullptr);
    std::this_thread::sleep_for(std::chrono::milliseconds(750));
    EXPECT_EQ(probe.fired.load(), fired_at_removal)
        << "observer fired after removal";

    lattice_object_release(p);
    lattice_object_release(p2);
    lattice_db_close(b);
    lattice_db_release(b);
    lattice_scheduler_release(sched);
    lattice_db_close(a);
    lattice_db_release(a);
}

// Slice 1 rerouted lattice_db_receive_sync_data through the core
// apply_remote_changes path. Pin the per-entry isolation contract: one bad
// entry in a batch is skipped, the good entries apply, and ONLY the applied
// ids come back (unapplied entries must not be acked).
TEST(CAPIReceiveSyncData, PerEntryErrorIsolation) {
    TempPath src_path("capi_recv_src"), dst_path("capi_recv_dst");
    PersonSchema ps;
    lattice_db_t* src = lattice_db_create_with_schemas(src_path.str().c_str(), &ps.schema, 1);
    lattice_db_t* dst = lattice_db_create_with_schemas(dst_path.str().c_str(), &ps.schema, 1);
    ASSERT_NE(src, nullptr) << lattice_last_error();
    ASSERT_NE(dst, nullptr) << lattice_last_error();

    lattice_object_t* p1 = add_person(src, "good-1", 1);
    lattice_object_t* p2 = add_person(src, "good-2", 2);
    ASSERT_NE(p1, nullptr);
    ASSERT_NE(p2, nullptr);

    char* entries = lattice_db_events_after(src, nullptr);
    ASSERT_NE(entries, nullptr) << lattice_last_error();
    std::string entries_json(entries);
    lattice_string_free(entries);

    // Tamper the FIRST entry to target a table the receiver doesn't have —
    // that entry must fail to apply while the second still lands.
    //
    // The name is deliberately underscore-prefixed (an INTERNAL table). A3's
    // schema-skew tolerance gates on `is_model_table` (first char != '_'), so
    // an unknown MODEL table is now a defined, acked no-op — that contract is
    // pinned separately by SkewTolerance.UnknownTableSkippedAndAcked. An
    // unknown internal table bypasses both skew gates and still hard-fails,
    // which is the failure mode this test needs to keep pinning per-entry
    // isolation. Do not "simplify" this back to a bare table name.
    const std::string needle = "\"tableName\":\"Person\"";
    auto pos = entries_json.find(needle);
    ASSERT_NE(pos, std::string::npos) << entries_json;
    entries_json.replace(pos, needle.size(), "\"tableName\":\"_NoSuchTable\"");
    ASSERT_NE(entries_json.find("\"tableName\":\"Person\""), std::string::npos)
        << "expected a second, untampered entry";

    char* message = lattice_create_sync_message(entries_json.c_str());
    ASSERT_NE(message, nullptr) << lattice_last_error();

    char* applied = lattice_db_receive_sync_data(
        dst, reinterpret_cast<const uint8_t*>(message), std::strlen(message));
    ASSERT_NE(applied, nullptr)
        << "one bad entry must not fail the whole batch: "
        << (lattice_last_error() ? lattice_last_error() : "(no error)");

    // Exactly ONE id applied (the untampered entry), and exactly one Person
    // row landed in the receiver.
    EXPECT_EQ(count_json_strings(applied), 1u) << applied;
    EXPECT_EQ(lattice_db_count(dst, "Person", nullptr), 1u);

    lattice_string_free(applied);
    lattice_string_free(message);
    lattice_object_release(p1);
    lattice_object_release(p2);
    lattice_db_close(src);
    lattice_db_close(dst);
    lattice_db_release(src);
    lattice_db_release(dst);
}

// ============================================================================
// lattice_object_to_json (C1 slice 3) — contract pinned to Swift's
// DynamicObject.jsonObject(maxDepth:) shape (see lattice.h for the full
// contract). Output is PARSED, never string-compared: key order within JSON
// objects is explicitly unspecified.
// ============================================================================

namespace {

// Author {name, bio, note TEXT; score REAL; photo BLOB; pet -> Pet;
// friends -> [Author]} / Pet {name TEXT; owner -> Author}.
struct GraphSchema {
    lattice_property_t author_props[7];
    lattice_property_t pet_props[2];
    lattice_schema_t schemas[2];

    GraphSchema() {
        std::memset(author_props, 0, sizeof(author_props));
        std::memset(pet_props, 0, sizeof(pet_props));
        auto text = [](lattice_property_t& p, const char* name) {
            p.name = name;
            p.type = LATTICE_TYPE_TEXT;
            p.kind = LATTICE_KIND_PRIMITIVE;
            p.nullable = true;
        };
        text(author_props[0], "name");
        text(author_props[1], "bio");
        text(author_props[2], "note");
        author_props[3].name = "score";
        author_props[3].type = LATTICE_TYPE_REAL;
        author_props[3].kind = LATTICE_KIND_PRIMITIVE;
        author_props[3].nullable = true;
        author_props[4].name = "photo";
        author_props[4].type = LATTICE_TYPE_BLOB;
        author_props[4].kind = LATTICE_KIND_PRIMITIVE;
        author_props[4].nullable = true;
        author_props[5].name = "pet";
        author_props[5].type = LATTICE_TYPE_TEXT;
        author_props[5].kind = LATTICE_KIND_LINK;
        author_props[5].target_table = "Pet";
        author_props[5].nullable = true;
        author_props[6].name = "friends";
        author_props[6].type = LATTICE_TYPE_TEXT;
        author_props[6].kind = LATTICE_KIND_LINK_LIST;
        author_props[6].target_table = "Author";
        author_props[6].nullable = true;

        text(pet_props[0], "name");
        pet_props[1].name = "owner";
        pet_props[1].type = LATTICE_TYPE_TEXT;
        pet_props[1].kind = LATTICE_KIND_LINK;
        pet_props[1].target_table = "Author";
        pet_props[1].nullable = true;

        std::memset(schemas, 0, sizeof(schemas));
        schemas[0].table_name = "Author";
        schemas[0].properties = author_props;
        schemas[0].property_count = 7;
        schemas[1].table_name = "Pet";
        schemas[1].properties = pet_props;
        schemas[1].property_count = 2;
    }
};

// to_json + parse, freeing the C string.
nlohmann::json parsed_json(lattice_object_t* obj, int32_t max_depth) {
    char* json = lattice_object_to_json(obj, max_depth);
    EXPECT_NE(json, nullptr) << (lattice_last_error() ? lattice_last_error() : "");
    if (!json) return nlohmann::json::value_t::discarded;
    auto parsed = nlohmann::json::parse(json, nullptr, /*allow_exceptions=*/false);
    EXPECT_FALSE(parsed.is_discarded()) << json;
    lattice_string_free(json);
    return parsed;
}

std::string global_id_of(lattice_object_t* obj) {
    const char* gid = lattice_object_get_global_id(obj);
    return gid ? gid : "";
}

}  // namespace

TEST(CAPIToJson, ScalarTypesBlobBase64AndEmbeddedJson) {
    TempPath path("capi_tojson_scalars");
    GraphSchema gs;
    lattice_db_t* db = lattice_db_create_with_schemas(path.str().c_str(), gs.schemas, 2);
    ASSERT_NE(db, nullptr) << lattice_last_error();

    lattice_object_t* a = lattice_db_create_object(db, "Author");
    ASSERT_NE(a, nullptr) << lattice_last_error();
    lattice_object_set_string(a, "name", "Ada");
    lattice_object_set_string(a, "bio", "[1,2,3]");        // embedded JSON -> inlined
    lattice_object_set_string(a, "note", "{not json");     // '{' but unparseable -> raw
    lattice_object_set_double(a, "score", 2.5);
    const uint8_t photo[] = {0x00, 0x01, 0xFF};
    lattice_object_set_blob(a, "photo", photo, sizeof(photo));
    ASSERT_NE(lattice_db_add(db, a), nullptr) << lattice_last_error();
    lattice_object_release(a);  // drop the add's extra retain

    nlohmann::json j = parsed_json(a, 0);
    EXPECT_EQ(j["name"], "Ada");
    EXPECT_EQ(j["bio"], nlohmann::json::parse("[1,2,3]"));  // inlined, not a string
    EXPECT_EQ(j["note"], "{not json");                       // raw string preserved
    EXPECT_EQ(j["score"], 2.5);
    EXPECT_EQ(j["photo"], "AAH/");                           // base64, matching Swift
    EXPECT_TRUE(j.contains("globalId"));
    EXPECT_EQ(j["globalId"], global_id_of(a));
    EXPECT_TRUE(j.contains("id"));
    EXPECT_EQ(j["id"], lattice_object_get_id(a));
    // Unset link/columns: keys omitted, not null.
    EXPECT_FALSE(j.contains("pet"));

    lattice_object_release(a);
    lattice_db_close(db);
    lattice_db_release(db);
}

TEST(CAPIToJson, LinkDepthAndStubs) {
    TempPath path("capi_tojson_links");
    GraphSchema gs;
    lattice_db_t* db = lattice_db_create_with_schemas(path.str().c_str(), gs.schemas, 2);
    ASSERT_NE(db, nullptr) << lattice_last_error();

    lattice_object_t* author = lattice_db_create_object(db, "Author");
    lattice_object_set_string(author, "name", "Mary");
    ASSERT_NE(lattice_db_add(db, author), nullptr) << lattice_last_error();
    lattice_object_release(author);

    lattice_object_t* pet = lattice_db_create_object(db, "Pet");
    lattice_object_set_string(pet, "name", "Rex");
    ASSERT_NE(lattice_db_add(db, pet), nullptr) << lattice_last_error();
    lattice_object_release(pet);

    lattice_object_set_object(author, "pet", pet);
    const std::string pet_gid = global_id_of(pet);
    const std::string author_gid = global_id_of(author);
    ASSERT_FALSE(pet_gid.empty());
    ASSERT_FALSE(author_gid.empty());

    // Depth 0: the link collapses to a {"globalId"} stub.
    nlohmann::json j0 = parsed_json(author, 0);
    ASSERT_TRUE(j0.contains("pet"));
    EXPECT_EQ(j0["pet"], nlohmann::json({{"globalId", pet_gid}}));

    // Depth 1: the link expands one hop.
    nlohmann::json j1 = parsed_json(author, 1);
    ASSERT_TRUE(j1.contains("pet"));
    EXPECT_EQ(j1["pet"]["name"], "Rex");
    EXPECT_EQ(j1["pet"]["globalId"], pet_gid);

    lattice_object_release(author);
    lattice_object_release(pet);
    lattice_db_close(db);
    lattice_db_release(db);
}

TEST(CAPIToJson, CycleCollapsesToStubAndTerminates) {
    TempPath path("capi_tojson_cycle");
    GraphSchema gs;
    lattice_db_t* db = lattice_db_create_with_schemas(path.str().c_str(), gs.schemas, 2);
    ASSERT_NE(db, nullptr) << lattice_last_error();

    lattice_object_t* author = lattice_db_create_object(db, "Author");
    lattice_object_set_string(author, "name", "Ouro");
    ASSERT_NE(lattice_db_add(db, author), nullptr) << lattice_last_error();
    lattice_object_release(author);
    lattice_object_t* pet = lattice_db_create_object(db, "Pet");
    lattice_object_set_string(pet, "name", "Boros");
    ASSERT_NE(lattice_db_add(db, pet), nullptr) << lattice_last_error();
    lattice_object_release(pet);

    // Author -> Pet -> Author cycle.
    lattice_object_set_object(author, "pet", pet);
    lattice_object_set_object(pet, "owner", author);

    // Generous depth: must terminate, with the back-link collapsing to the
    // visited author's stub (cycle guard), not recursing.
    nlohmann::json j = parsed_json(author, 16);
    ASSERT_TRUE(j.contains("pet"));
    EXPECT_EQ(j["pet"]["name"], "Boros");
    ASSERT_TRUE(j["pet"].contains("owner"));
    EXPECT_EQ(j["pet"]["owner"],
              nlohmann::json({{"globalId", global_id_of(author)}}));

    lattice_object_release(author);
    lattice_object_release(pet);
    lattice_db_close(db);
    lattice_db_release(db);
}

TEST(CAPIToJson, ListsExpandAtDepthAndSummarizeAtBoundary) {
    TempPath path("capi_tojson_lists");
    GraphSchema gs;
    lattice_db_t* db = lattice_db_create_with_schemas(path.str().c_str(), gs.schemas, 2);
    ASSERT_NE(db, nullptr) << lattice_last_error();

    lattice_object_t* a = lattice_db_create_object(db, "Author");
    lattice_object_set_string(a, "name", "Hub");
    ASSERT_NE(lattice_db_add(db, a), nullptr) << lattice_last_error();
    lattice_object_release(a);

    lattice_link_list_t* friends = lattice_object_get_link_list(a, "friends");
    ASSERT_NE(friends, nullptr) << lattice_last_error();
    for (const char* name : {"F1", "F2"}) {
        lattice_object_t* f = lattice_db_create_object(db, "Author");
        lattice_object_set_string(f, "name", name);
        ASSERT_NE(lattice_db_add(db, f), nullptr) << lattice_last_error();
        lattice_object_release(f);
        lattice_link_list_push_back(friends, f);
        lattice_object_release(f);
    }
    ASSERT_EQ(lattice_link_list_size(friends), 2u);

    // Depth 0: the list is a {"count"} summary.
    nlohmann::json j0 = parsed_json(a, 0);
    ASSERT_TRUE(j0.contains("friends"));
    EXPECT_EQ(j0["friends"], nlohmann::json({{"count", 2}}));

    // Depth 1: elements expand; THEIR lists summarize at the boundary.
    nlohmann::json j1 = parsed_json(a, 1);
    ASSERT_TRUE(j1["friends"].is_array());
    ASSERT_EQ(j1["friends"].size(), 2u);
    std::set<std::string> names;
    for (const auto& el : j1["friends"]) {
        ASSERT_TRUE(el.contains("name"));
        names.insert(el["name"].get<std::string>());
        ASSERT_TRUE(el.contains("friends"));
        EXPECT_EQ(el["friends"], nlohmann::json({{"count", 0}}));
    }
    EXPECT_EQ(names, (std::set<std::string>{"F1", "F2"}));

    lattice_link_list_release(friends);
    lattice_object_release(a);
    lattice_db_close(db);
    lattice_db_release(db);
}

TEST(CAPIToJson, UnmanagedObjectAndErrorContract) {
    GraphSchema gs;
    lattice_object_t* obj = lattice_object_create_with_schema(
        "Author", gs.author_props, gs.schemas[0].property_count);
    ASSERT_NE(obj, nullptr) << lattice_last_error();
    lattice_object_set_string(obj, "name", "Loose");
    lattice_object_set_double(obj, "score", 1.0);

    // Unmanaged objects serialize their staged scalars; no identity keys.
    nlohmann::json j = parsed_json(obj, 1);
    EXPECT_EQ(j["name"], "Loose");
    EXPECT_EQ(j["score"], 1.0);
    EXPECT_FALSE(j.contains("globalId"));
    EXPECT_FALSE(j.contains("id"));
    lattice_object_release(obj);

    EXPECT_EQ(lattice_object_to_json(nullptr, 5), nullptr);
    ASSERT_NE(lattice_last_error(), nullptr);
}

// ============================================================================
// Per-property unique constraints (conformance: cross-SDK divergence fix)
// ============================================================================

// A property flagged `is_unique` over the C ABI must produce the SAME schema
// object the Swift bridge's constraint pass creates for `@Unique` on the same
// field — a unique index named `unique_<table>_<ordinal>`, ordinals assigned
// in property declaration order. Identical names are load-bearing: a database
// created by Swift and reopened through the C ABI (or vice versa) must see
// the index already present instead of growing a second one.
TEST(CAPIUniqueConstraint, IsUniqueCreatesBridgeNamedIndexAndEnforces) {
    TempPath path("capi_unique");

    lattice_property_t props[3];
    std::memset(props, 0, sizeof(props));
    props[0].name = "email";
    props[0].type = LATTICE_TYPE_TEXT;
    props[0].kind = LATTICE_KIND_PRIMITIVE;
    props[0].nullable = true;
    props[0].is_unique = true;
    props[1].name = "age";
    props[1].type = LATTICE_TYPE_INTEGER;
    props[1].kind = LATTICE_KIND_PRIMITIVE;
    props[1].nullable = true;
    props[2].name = "code";
    props[2].type = LATTICE_TYPE_TEXT;
    props[2].kind = LATTICE_KIND_PRIMITIVE;
    props[2].nullable = true;
    props[2].is_unique = true;

    lattice_schema_t schema;
    std::memset(&schema, 0, sizeof(schema));
    schema.table_name = "UniquePerson";
    schema.properties = props;
    schema.property_count = 3;

    lattice_db_t* db = lattice_db_create_with_schemas(path.str().c_str(), &schema, 1);
    ASSERT_NE(db, nullptr) << lattice_last_error();

    // Index names: ordinal 0 = email (first unique property), 1 = code.
    EXPECT_EQ(lattice_db_count(db, "sqlite_master",
                  "type = 'index' AND tbl_name = 'UniquePerson' AND "
                  "name = 'unique_UniquePerson_0'"),
              1u);
    EXPECT_EQ(lattice_db_count(db, "sqlite_master",
                  "type = 'index' AND tbl_name = 'UniquePerson' AND "
                  "name = 'unique_UniquePerson_1'"),
              1u);
    // ... and nothing else — exactly the two.
    EXPECT_EQ(lattice_db_count(db, "sqlite_master",
                  "type = 'index' AND tbl_name = 'UniquePerson' AND "
                  "name LIKE 'unique_%'"),
              2u);

    // Enforcement: duplicate email is rejected.
    lattice_object_t* first = lattice_db_create_object(db, "UniquePerson");
    ASSERT_NE(first, nullptr) << lattice_last_error();
    lattice_object_set_string(first, "email", "a@example.com");
    lattice_object_set_string(first, "code", "c-1");
    lattice_object_t* first_managed = lattice_db_add(db, first);
    ASSERT_NE(first_managed, nullptr) << lattice_last_error();
    lattice_object_release(first_managed);

    lattice_object_t* dup = lattice_db_create_object(db, "UniquePerson");
    ASSERT_NE(dup, nullptr) << lattice_last_error();
    lattice_object_set_string(dup, "email", "a@example.com");
    lattice_object_set_string(dup, "code", "c-2");
    lattice_object_t* dup_managed = lattice_db_add(db, dup);
    EXPECT_EQ(dup_managed, nullptr) << "duplicate unique value must be rejected";
    ASSERT_NE(lattice_last_error(), nullptr);
    EXPECT_EQ(lattice_db_count(db, "UniquePerson", nullptr), 1u);
    lattice_object_release(dup);

    // Distinct values still insert.
    lattice_object_t* other = lattice_db_create_object(db, "UniquePerson");
    ASSERT_NE(other, nullptr) << lattice_last_error();
    lattice_object_set_string(other, "email", "b@example.com");
    lattice_object_set_string(other, "code", "c-2");
    lattice_object_t* other_managed = lattice_db_add(db, other);
    ASSERT_NE(other_managed, nullptr) << lattice_last_error();
    lattice_object_release(other_managed);
    EXPECT_EQ(lattice_db_count(db, "UniquePerson", nullptr), 2u);

    lattice_object_release(first);
    lattice_object_release(other);
    lattice_db_close(db);
    lattice_db_release(db);

    // Reopen: the pass is idempotent — still exactly two unique indexes.
    lattice_db_t* db2 = lattice_db_create_with_schemas(path.str().c_str(), &schema, 1);
    ASSERT_NE(db2, nullptr) << lattice_last_error();
    EXPECT_EQ(lattice_db_count(db2, "sqlite_master",
                  "type = 'index' AND tbl_name = 'UniquePerson' AND "
                  "name LIKE 'unique_%'"),
              2u);
    lattice_db_close(db2);
    lattice_db_release(db2);
}

// ============================================================================
// Transaction read visibility (conformance: cross-SDK divergence fix)
// ============================================================================

// Under WAL the dedicated read-only connection cannot see another
// connection's open transaction. lattice_db_count/lattice_db_query issued
// between lattice_db_begin_transaction and commit/rollback must therefore
// route through the write connection — uncommitted writes are visible inside
// the transaction and gone after rollback.
TEST(CAPITransactionVisibility, ReadsInsideOpenTransactionSeeUncommittedWrites) {
    TempPath path("capi_txn_vis");
    PersonSchema ps;
    lattice_db_t* db = lattice_db_create_with_schemas(path.str().c_str(), &ps.schema, 1);
    ASSERT_NE(db, nullptr) << lattice_last_error();

    // Committed baseline.
    lattice_object_t* base = add_person(db, "committed", 1);
    ASSERT_NE(base, nullptr);
    lattice_object_release(base);
    ASSERT_EQ(lattice_db_count(db, "Person", nullptr), 1u);

    ASSERT_EQ(lattice_db_begin_transaction(db), LATTICE_OK) << lattice_last_error();

    lattice_object_t* staged = lattice_db_create_object(db, "Person");
    ASSERT_NE(staged, nullptr) << lattice_last_error();
    lattice_object_set_string(staged, "name", "uncommitted");
    lattice_object_set_int(staged, "age", 99);
    lattice_object_t* managed = lattice_db_add(db, staged);
    ASSERT_NE(managed, nullptr) << lattice_last_error();
    lattice_object_release(managed);

    // Visible to count and query on the same handle while the txn is open.
    EXPECT_EQ(lattice_db_count(db, "Person", nullptr), 2u)
        << "count missed uncommitted writes inside an open transaction";
    EXPECT_EQ(lattice_db_count(db, "Person", "age = 99"), 1u);

    lattice_results_t* res = lattice_db_query(db, "Person", "age = 99", nullptr, 0, 0);
    ASSERT_NE(res, nullptr) << lattice_last_error();
    ASSERT_EQ(lattice_results_count(res), 1u)
        << "query missed uncommitted writes inside an open transaction";
    lattice_object_t* row = lattice_results_get(res, 0);
    ASSERT_NE(row, nullptr);
    EXPECT_STREQ(lattice_object_get_string(row, "name"), "uncommitted");
    lattice_object_release(row);
    lattice_results_free(res);

    ASSERT_EQ(lattice_db_rollback(db), LATTICE_OK) << lattice_last_error();

    // After rollback the staged row is gone from both read routes.
    EXPECT_EQ(lattice_db_count(db, "Person", nullptr), 1u);
    EXPECT_EQ(lattice_db_count(db, "Person", "age = 99"), 0u);
    lattice_results_t* res2 = lattice_db_query(db, "Person", "age = 99", nullptr, 0, 0);
    ASSERT_NE(res2, nullptr) << lattice_last_error();
    EXPECT_EQ(lattice_results_count(res2), 0u);
    lattice_results_free(res2);

    lattice_object_release(staged);
    lattice_db_close(db);
    lattice_db_release(db);
}

// The in-transaction read routing is THREAD-SCOPED: only the thread that
// opened the transaction reads through the write connection. Every other
// thread keeps the dedicated reader and must see ONLY committed state —
// leaking uncommitted rows to concurrent readers would break reader
// isolation (caught by the Swift suite against 1.0.0, fixed in 1.0.1).
TEST(CAPITransactionVisibility, OtherThreadsNeverSeeTheOpenTransaction) {
    TempPath path("capi_txn_thread_scope");
    PersonSchema ps;
    lattice_db_t* db = lattice_db_create_with_schemas(path.str().c_str(), &ps.schema, 1);
    ASSERT_NE(db, nullptr) << lattice_last_error();

    lattice_object_t* base = add_person(db, "committed", 1);
    ASSERT_NE(base, nullptr);
    lattice_object_release(base);

    ASSERT_EQ(lattice_db_begin_transaction(db), LATTICE_OK) << lattice_last_error();
    lattice_object_t* staged = lattice_db_create_object(db, "Person");
    ASSERT_NE(staged, nullptr);
    lattice_object_set_string(staged, "name", "uncommitted");
    lattice_object_set_int(staged, "age", 99);
    lattice_object_t* managed = lattice_db_add(db, staged);
    ASSERT_NE(managed, nullptr) << lattice_last_error();
    lattice_object_release(managed);

    // Owning thread: read-your-writes.
    EXPECT_EQ(lattice_db_count(db, "Person", nullptr), 2u);

    // Foreign thread: committed state only.
    uint64_t other_count = 0, other_filtered = ~0ull;
    std::thread([&] {
        other_count = lattice_db_count(db, "Person", nullptr);
        other_filtered = lattice_db_count(db, "Person", "age = 99");
    }).join();
    EXPECT_EQ(other_count, 1u)
        << "a foreign thread observed another thread's open transaction";
    EXPECT_EQ(other_filtered, 0u);

    ASSERT_EQ(lattice_db_rollback(db), LATTICE_OK) << lattice_last_error();
    lattice_object_release(staged);
    lattice_db_close(db);
    lattice_db_release(db);
}

// Commit is the positive control: the same routing must not break the
// ordinary committed-visibility contract.
TEST(CAPITransactionVisibility, CommitKeepsTransactionWrites) {
    TempPath path("capi_txn_commit");
    PersonSchema ps;
    lattice_db_t* db = lattice_db_create_with_schemas(path.str().c_str(), &ps.schema, 1);
    ASSERT_NE(db, nullptr) << lattice_last_error();

    ASSERT_EQ(lattice_db_begin_transaction(db), LATTICE_OK) << lattice_last_error();
    lattice_object_t* p = add_person(db, "kept", 7);
    ASSERT_NE(p, nullptr);
    EXPECT_EQ(lattice_db_count(db, "Person", nullptr), 1u);
    ASSERT_EQ(lattice_db_commit(db), LATTICE_OK) << lattice_last_error();

    EXPECT_EQ(lattice_db_count(db, "Person", nullptr), 1u);
    EXPECT_EQ(lattice_db_count(db, "Person", "age = 7"), 1u);
    lattice_object_release(p);
    lattice_db_close(db);
    lattice_db_release(db);
}

// ============================================================================
// Geo-bounds on the dynamic add path (conformance: cross-SDK divergence fix)
// ============================================================================

// An `is_geo_bounds` property is stored as four expanded REAL columns
// (`<name>_minLat/_maxLat/_minLon/_maxLon`). Objects created through
// lattice_object_create_with_schema used to lose the flag, so the add path
// built its INSERT against the raw property name and SQLite rejected it with
// "table has no column named <name>". The add must succeed and the four
// columns must round-trip.
TEST(CAPIGeoBounds, DynamicAddExpandsGeoBoundsColumns) {
    TempPath path("capi_geo_add");

    lattice_property_t props[2];
    std::memset(props, 0, sizeof(props));
    props[0].name = "name";
    props[0].type = LATTICE_TYPE_TEXT;
    props[0].kind = LATTICE_KIND_PRIMITIVE;
    props[0].nullable = true;
    props[1].name = "bounds";
    props[1].type = LATTICE_TYPE_REAL;
    props[1].kind = LATTICE_KIND_PRIMITIVE;
    props[1].nullable = false;
    props[1].is_geo_bounds = true;

    lattice_schema_t schema;
    std::memset(&schema, 0, sizeof(schema));
    schema.table_name = "GeoPlace";
    schema.properties = props;
    schema.property_count = 2;

    lattice_db_t* db = lattice_db_create_with_schemas(path.str().c_str(), &schema, 1);
    ASSERT_NE(db, nullptr) << lattice_last_error();

    // The table has the four expanded columns and NOT the raw property.
    EXPECT_EQ(lattice_db_count(db, "pragma_table_info('GeoPlace')",
                               "name = 'bounds_minLat'"), 1u);
    EXPECT_EQ(lattice_db_count(db, "pragma_table_info('GeoPlace')",
                               "name = 'bounds_maxLat'"), 1u);
    EXPECT_EQ(lattice_db_count(db, "pragma_table_info('GeoPlace')",
                               "name = 'bounds_minLon'"), 1u);
    EXPECT_EQ(lattice_db_count(db, "pragma_table_info('GeoPlace')",
                               "name = 'bounds_maxLon'"), 1u);
    EXPECT_EQ(lattice_db_count(db, "pragma_table_info('GeoPlace')",
                               "name = 'bounds'"), 0u);

    // Standalone with-schema creation — the path bindings use and the one
    // that used to drop the geo flag.
    lattice_object_t* obj = lattice_object_create_with_schema("GeoPlace", props, 2);
    ASSERT_NE(obj, nullptr) << lattice_last_error();
    lattice_object_set_string(obj, "name", "sf");
    lattice_object_set_double(obj, "bounds_minLat", 37.70);
    lattice_object_set_double(obj, "bounds_maxLat", 37.83);
    lattice_object_set_double(obj, "bounds_minLon", -122.52);
    lattice_object_set_double(obj, "bounds_maxLon", -122.35);

    lattice_object_t* managed = lattice_db_add(db, obj);
    ASSERT_NE(managed, nullptr)
        << "dynamic add with geo bounds failed: " << lattice_last_error();
    lattice_object_release(managed);

    // Round-trip the four columns through a fresh query.
    lattice_results_t* res = lattice_db_query(db, "GeoPlace", nullptr, nullptr, 0, 0);
    ASSERT_NE(res, nullptr) << lattice_last_error();
    ASSERT_EQ(lattice_results_count(res), 1u);
    lattice_object_t* row = lattice_results_get(res, 0);
    ASSERT_NE(row, nullptr);
    EXPECT_STREQ(lattice_object_get_string(row, "name"), "sf");
    EXPECT_DOUBLE_EQ(lattice_object_get_double(row, "bounds_minLat"), 37.70);
    EXPECT_DOUBLE_EQ(lattice_object_get_double(row, "bounds_maxLat"), 37.83);
    EXPECT_DOUBLE_EQ(lattice_object_get_double(row, "bounds_minLon"), -122.52);
    EXPECT_DOUBLE_EQ(lattice_object_get_double(row, "bounds_maxLon"), -122.35);
    lattice_object_release(row);
    lattice_results_free(res);

    lattice_object_release(obj);
    lattice_db_close(db);
    lattice_db_release(db);
}
