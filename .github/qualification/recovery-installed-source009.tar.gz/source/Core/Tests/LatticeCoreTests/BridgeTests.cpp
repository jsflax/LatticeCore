#include "CanonicalWriterTestAccess.hpp" // actual public Native-v1 escape before source-private fault fixture
#include "TestHelpers.hpp"
#ifndef __linux__
#include <cstring>
#include "CanonicalWriterTestAccess.hpp"
#include <lattice.hpp>          // swift_lattice, swift_lattice_ref
#include <dynamic_object.hpp>   // dynamic_object, dynamic_object_ref

// ============================================================================
// Bridge Layer Tests — swift_lattice + dynamic_object (what Swift actually uses)
// ============================================================================

// Helper: create a swift_schema_entry for a simple table
static lattice::swift_schema_entry make_schema(
    const std::string& table_name,
    std::initializer_list<std::pair<std::string, lattice::property_descriptor>> props) {
    lattice::swift_schema_entry entry;
    entry.table_name = table_name;
    for (const auto& [name, desc] : props) {
        entry.properties[name] = desc;
    }
    return entry;
}

// Helper: create a swift_dynamic_object with properties properly set
static lattice::swift_dynamic_object make_sdo(
    const std::string& table_name,
    const lattice::SwiftSchema& schema) {
    lattice::swift_dynamic_object sdo;
    sdo.table_name = table_name;
    sdo.properties = schema;
    return sdo;
}

static lattice::property_descriptor text_prop(const std::string& name) {
    lattice::property_descriptor desc;
    desc.name = name;
    desc.type = lattice::column_type::text;
    desc.kind = lattice::property_kind::primitive;
    return desc;
}

static lattice::property_descriptor int_prop(const std::string& name) {
    lattice::property_descriptor desc;
    desc.name = name;
    desc.type = lattice::column_type::integer;
    desc.kind = lattice::property_kind::primitive;
    return desc;
}

static lattice::property_descriptor real_prop(const std::string& name) {
    lattice::property_descriptor desc;
    desc.name = name;
    desc.type = lattice::column_type::real;
    desc.kind = lattice::property_kind::primitive;
    return desc;
}

static lattice::property_descriptor blob_prop(const std::string& name) {
    lattice::property_descriptor desc;
    desc.name = name;
    desc.type = lattice::column_type::blob;
    desc.kind = lattice::property_kind::primitive;
    desc.is_vector = true;
    return desc;
}

// ============================================================================
// swift_lattice CRUD via dynamic_object
// ============================================================================

TEST(Bridge, CreateAndReadViaDynamicObject) {
    TempDB tmp{"bridge_crud"};
    lattice::SchemaVector schemas = {
        make_schema("BridgePerson", {
            {"name", text_prop("name")},
            {"age", int_prop("age")},
        })
    };

    lattice::swift_configuration config(tmp.str());
    auto* lattice_ref = lattice::swift_lattice_ref::create(config, schemas);
    auto& db = *lattice_ref->get();

    // Create via dynamic_object (use scope to destroy before query)
    {
        auto sdo = make_sdo("BridgePerson", schemas[0].properties);
        sdo.values["name"] = std::string("Alice");
        sdo.values["age"] = int64_t(30);
        lattice::dynamic_object obj(sdo);
        db.add(obj);
    }

    // Query — verify DB state
    auto results = db.objects("BridgePerson");
    ASSERT_EQ(results.size(), 1u);
    EXPECT_EQ(results[0].get_string("name"), "Alice");
    EXPECT_EQ(int(results[0].get_int("age")), 30);
}

// Deterministic regression for the close-during-read crash: evict() (which
// swift_lattice::close() calls) must NOT erase ptr_cache_ while the instance is
// still alive — a live managed object resolves its lattice via get_by_pointer(),
// and erasing the entry returns null → use-after-free during a concurrent read.
// (The Swift-level repro, CloseGuardTests.test_ConcurrentReadsDuringClose, is
// timing-based; this asserts the invariant directly.)
TEST(Bridge, EvictPreservesPtrCacheWhileInstanceAlive) {
    TempDB tmp{"bridge_evict"};
    lattice::SchemaVector schemas = {
        make_schema("EvictPerson", {
            {"name", text_prop("name")},
            {"age", int_prop("age")},
        })
    };
    lattice::swift_configuration config(tmp.str());
    auto* lattice_ref = lattice::swift_lattice_ref::create(config, schemas);
    lattice::swift_lattice* ptr = lattice_ref->get();

    // Resolvable before eviction.
    ASSERT_NE(lattice::detail::LatticeCache::instance().get_by_pointer(ptr), nullptr);

    // Evict — exactly what swift_lattice::close() does. The instance is STILL
    // alive (lattice_ref holds the shared_ptr), so it must still resolve.
    lattice::detail::LatticeCache::instance().evict(ptr);

    EXPECT_NE(lattice::detail::LatticeCache::instance().get_by_pointer(ptr), nullptr)
        << "evict() must not erase ptr_cache_ for a still-alive instance";
}

TEST(Bridge, UpdateViaDynamicObject) {
    TempDB tmp{"bridge_update"};
    lattice::SchemaVector schemas = {
        make_schema("BridgePerson", {
            {"name", text_prop("name")},
            {"age", int_prop("age")},
        })
    };

    lattice::swift_configuration config(tmp.str());
    auto* lattice_ref = lattice::swift_lattice_ref::create(config, schemas);
    auto& db = *lattice_ref->get();

    auto sdo = make_sdo("BridgePerson", schemas[0].properties);
    sdo.values["name"] = std::string("Bob");
    sdo.values["age"] = int64_t(25);

    { lattice::dynamic_object obj(sdo); db.add(obj); }

    // Update via managed object from query
    auto results = db.objects("BridgePerson");
    ASSERT_EQ(results.size(), 1u);
    results[0].set_value("name", std::string("Bobby"));
    results[0].set_value("age", int64_t(26));

    auto updated = db.objects("BridgePerson");
    ASSERT_EQ(updated.size(), 1u);
    EXPECT_EQ(updated[0].get_string("name"), "Bobby");
    EXPECT_EQ(int(updated[0].get_int("age")), 26);
}

TEST(Bridge, DeleteViaDynamicObject) {
    TempDB tmp{"bridge_delete"};
    lattice::SchemaVector schemas = {
        make_schema("BridgePerson", {
            {"name", text_prop("name")},
            {"age", int_prop("age")},
        })
    };

    lattice::swift_configuration config(tmp.str());
    auto* lattice_ref = lattice::swift_lattice_ref::create(config, schemas);
    auto& db = *lattice_ref->get();

    auto sdo = make_sdo("BridgePerson", schemas[0].properties);
    sdo.values["name"] = std::string("Charlie");
    sdo.values["age"] = int64_t(35);

    { lattice::dynamic_object obj(sdo); db.add(obj); }
    EXPECT_EQ(db.objects("BridgePerson").size(), 1u);

    // Remove via managed object from query
    auto to_delete = db.objects("BridgePerson");
    ASSERT_EQ(to_delete.size(), 1u);
    db.remove(to_delete[0]);
    EXPECT_EQ(db.objects("BridgePerson").size(), 0u);
}

// ============================================================================
// BLOB / Vector data through the bridge layer
// ============================================================================

TEST(Bridge, BlobSetGetRoundTrip) {
    TempDB tmp{"bridge_blob"};
    lattice::SchemaVector schemas = {
        make_schema("BridgeVec", {
            {"label", text_prop("label")},
            {"embedding", blob_prop("embedding")},
        })
    };

    lattice::swift_configuration config(tmp.str());
    auto* lattice_ref = lattice::swift_lattice_ref::create(config, schemas);
    auto& db = *lattice_ref->get();

    // Create object with BLOB data
    std::vector<float> original = {1.0f, 2.0f, 3.0f, 4.5f, -0.5f};
    auto blob = pack_floats(original);

    auto sdo = make_sdo("BridgeVec", schemas[0].properties);
    sdo.values["label"] = std::string("test vec");
    sdo.values["embedding"] = blob;

    { lattice::dynamic_object obj(sdo); db.add(obj); }

    // Read back via query
    auto results = db.objects("BridgeVec");
    ASSERT_EQ(results.size(), 1u);
    EXPECT_EQ(results[0].get_string("label"), "test vec");

    // Get BLOB back and verify float data
    // managed<swift_dynamic_object> doesn't expose get_data directly —
    // read BLOB from raw SQL to verify storage
    auto blob_rows = db.db().query(
        "SELECT embedding FROM BridgeVec WHERE globalId = ?",
        {std::string(results[0].global_id())});
    ASSERT_EQ(blob_rows.size(), 1u);
    auto stored_blob = std::get<std::vector<uint8_t>>(blob_rows[0].at("embedding"));
    ASSERT_EQ(stored_blob.size(), blob.size());
    auto stored_floats = unpack_floats(stored_blob);
    ASSERT_EQ(stored_floats.size(), original.size());
    for (size_t i = 0; i < original.size(); i++) {
        EXPECT_NEAR(stored_floats[i], original[i], 0.001)
            << "Float mismatch at index " << i;
    }
}

TEST(Bridge, BlobVec0NearestNeighbors) {
    TempDB tmp{"bridge_vec0"};
    lattice::SchemaVector schemas = {
        make_schema("BridgeVec", {
            {"label", text_prop("label")},
            {"embedding", blob_prop("embedding")},
        })
    };

    lattice::swift_configuration config(tmp.str());
    auto* lattice_ref = lattice::swift_lattice_ref::create(config, schemas);
    auto& db = *lattice_ref->get();

    // Insert documents with embeddings via the bridge
    auto insert_doc = [&](const std::string& label, const std::vector<float>& vec) {
        auto sdo = make_sdo("BridgeVec", schemas[0].properties);
        sdo.values["label"] = label;
        sdo.values["embedding"] = pack_floats(vec);
        { lattice::dynamic_object obj(sdo); db.add(obj); }

        // Get globalId from the just-inserted row
        auto rows = db.db().query(
            "SELECT globalId FROM BridgeVec WHERE label = ?", {label});
        if (!rows.empty()) {
            auto gid = std::get<std::string>(rows[0].at("globalId"));
            db.upsert_vec0("BridgeVec", "embedding", gid, pack_floats(vec));
        }
    };

    insert_doc("doc_a", {1.0f, 0.0f, 0.0f});
    insert_doc("doc_b", {0.0f, 1.0f, 0.0f});
    insert_doc("doc_c", {0.0f, 0.0f, 1.0f});

    // KNN query through the bridge
    auto qvec = pack_floats({1.0f, 0.0f, 0.0f});
    auto results = db.knn_query("BridgeVec", "embedding", qvec, 3,
                                 lattice::lattice_db::distance_metric::l2);
    ASSERT_EQ(results.size(), 3u);

    // First result should be doc_a (exact match)
    auto first_row = db.db().query(
        "SELECT label FROM BridgeVec WHERE globalId = ?",
        {results[0].global_id});
    ASSERT_EQ(first_row.size(), 1u);
    EXPECT_EQ(std::get<std::string>(first_row[0].at("label")), "doc_a");
    EXPECT_NEAR(results[0].distance, 0.0, 0.001);
}

// ============================================================================
// combined_nearest_query — metric-correct ordering (the path Swift queries use)
// ============================================================================
//
// vec0 MATCH retrieves candidates by L2 distance; non-L2 metrics are re-scored
// in SQL. Regression tests for two bugs found by the conformance corpus:
//   1. The re-scored ORDER BY lived only in a subquery — SQL drops a
//      subquery's ordering, so rows came back in vec0's L2 candidate order.
//   2. The candidate fetch was truncated to k BEFORE re-scoring, so the true
//      top-k under the requested metric could be missing rows entirely.
//
// Fixture: query [1,0,0,0] over
//   p=[ 2,0,0,0]  cosine 0.0      L1 1  L2 1.0
//   q=[ 1,1,0,0]  cosine 0.29289  L1 1  L2 1.0
//   r=[ 0,3,0,0]  cosine 1.0      L1 4  L2 3.162
//   s=[-1,0,0,0]  cosine 2.0      L1 2  L2 2.0
// Correct cosine order: [p,q,r,s]. L2 candidate order: {p,q} tie, then s, then r.

static lattice::SchemaVector metric_vec_schemas() {
    return {
        make_schema("MetricVec", {
            {"label", text_prop("label")},
            {"embedding", blob_prop("embedding")},
        })
    };
}

static void seed_metric_vec_docs(lattice::swift_lattice& db,
                                 const lattice::SchemaVector& schemas) {
    auto insert_doc = [&](const std::string& label, const std::vector<float>& vec) {
        auto sdo = make_sdo("MetricVec", schemas[0].properties);
        sdo.values["label"] = label;
        sdo.values["embedding"] = pack_floats(vec);
        { lattice::dynamic_object obj(sdo); db.add(obj); }
        auto rows = db.db().query(
            "SELECT globalId FROM MetricVec WHERE label = ?", {label});
        ASSERT_EQ(rows.size(), 1u) << "insert failed for " << label;
        auto gid = std::get<std::string>(rows[0].at("globalId"));
        db.upsert_vec0("MetricVec", "embedding", gid, pack_floats(vec));
    };
    insert_doc("p", {2.0f, 0.0f, 0.0f, 0.0f});
    insert_doc("q", {1.0f, 1.0f, 0.0f, 0.0f});
    insert_doc("r", {0.0f, 3.0f, 0.0f, 0.0f});
    insert_doc("s", {-1.0f, 0.0f, 0.0f, 0.0f});
}

TEST(Bridge, CombinedNearestCosineOrdersByRescoredDistance) {
    TempDB tmp{"bridge_cnq_cosine"};
    auto schemas = metric_vec_schemas();
    lattice::swift_configuration config(tmp.str());
    auto* lattice_ref = lattice::swift_lattice_ref::create(config, schemas);
    auto& db = *lattice_ref->get();
    seed_metric_vec_docs(db, schemas);

    auto qvec = pack_floats({1.0f, 0.0f, 0.0f, 0.0f});
    lattice::VectorConstraintVector vecs = {
        lattice::vector_constraint("embedding", qvec, /*k=*/4, /*metric=*/1)  // cosine
    };
    // No explicit sort: the result order itself must be the cosine order.
    auto results = db.combined_nearest_query(
        "MetricVec", {}, vecs, {}, {}, std::nullopt,
        lattice::sort_descriptor{}, /*limit=*/10);

    ASSERT_EQ(results.size(), 4u);
    EXPECT_EQ(results[0].object.get_string("label"), "p");
    EXPECT_EQ(results[1].object.get_string("label"), "q");
    EXPECT_EQ(results[2].object.get_string("label"), "r");
    EXPECT_EQ(results[3].object.get_string("label"), "s");

    ASSERT_EQ(results[0].distances.size(), 1u);
    EXPECT_NEAR(results[0].distances[0].distance, 0.0, 0.001);
    EXPECT_NEAR(results[1].distances[0].distance, 0.29289, 0.001);
    EXPECT_NEAR(results[2].distances[0].distance, 1.0, 0.001);
    EXPECT_NEAR(results[3].distances[0].distance, 2.0, 0.001);
}

TEST(Bridge, CombinedNearestCosineTopKSurvivesRescore) {
    // k=3: the L2 top-3 is {p, q, s} (L2 1, 1, 2 — r is 3.162 away), but the
    // cosine top-3 is {p, q, r}. Truncating to k before re-scoring silently
    // drops r; the oversampled fetch + order-then-limit must keep it.
    TempDB tmp{"bridge_cnq_topk"};
    auto schemas = metric_vec_schemas();
    lattice::swift_configuration config(tmp.str());
    auto* lattice_ref = lattice::swift_lattice_ref::create(config, schemas);
    auto& db = *lattice_ref->get();
    seed_metric_vec_docs(db, schemas);

    auto qvec = pack_floats({1.0f, 0.0f, 0.0f, 0.0f});
    lattice::VectorConstraintVector vecs = {
        lattice::vector_constraint("embedding", qvec, /*k=*/3, /*metric=*/1)  // cosine
    };
    auto results = db.combined_nearest_query(
        "MetricVec", {}, vecs, {}, {}, std::nullopt,
        lattice::sort_descriptor{}, /*limit=*/10);

    ASSERT_EQ(results.size(), 3u);
    EXPECT_EQ(results[0].object.get_string("label"), "p");
    EXPECT_EQ(results[1].object.get_string("label"), "q");
    EXPECT_EQ(results[2].object.get_string("label"), "r")
        << "true cosine top-3 must include r, not the L2 candidate s";
}

TEST(Bridge, CombinedNearestL1OrdersByRescoredDistance) {
    // L1 (metric=2) is the other re-scored metric. L1 distances: p=1, q=1,
    // s=2, r=4. p and q tie, so pin the tail order and monotone distances.
    TempDB tmp{"bridge_cnq_l1"};
    auto schemas = metric_vec_schemas();
    lattice::swift_configuration config(tmp.str());
    auto* lattice_ref = lattice::swift_lattice_ref::create(config, schemas);
    auto& db = *lattice_ref->get();
    seed_metric_vec_docs(db, schemas);

    auto qvec = pack_floats({1.0f, 0.0f, 0.0f, 0.0f});
    lattice::VectorConstraintVector vecs = {
        lattice::vector_constraint("embedding", qvec, /*k=*/4, /*metric=*/2)  // L1
    };
    auto results = db.combined_nearest_query(
        "MetricVec", {}, vecs, {}, {}, std::nullopt,
        lattice::sort_descriptor{}, /*limit=*/10);

    ASSERT_EQ(results.size(), 4u);
    // First two are {p, q} in either order (both L1 distance 1).
    std::string first = results[0].object.get_string("label");
    std::string second = results[1].object.get_string("label");
    EXPECT_TRUE((first == "p" && second == "q") || (first == "q" && second == "p"))
        << "got [" << first << ", " << second << "]";
    EXPECT_EQ(results[2].object.get_string("label"), "s");
    EXPECT_EQ(results[3].object.get_string("label"), "r");
    for (size_t i = 0; i + 1 < results.size(); ++i) {
        ASSERT_EQ(results[i].distances.size(), 1u);
        EXPECT_LE(results[i].distances[0].distance,
                  results[i + 1].distances[0].distance)
            << "distances must be non-decreasing at index " << i;
    }
}

// ============================================================================
// receive_sync_data — the complete sync ingest path through the bridge
// ============================================================================

TEST(Bridge, ReceiveSyncDataInsert) {
    TempDB tmp{"bridge_sync"};
    lattice::SchemaVector schemas = {
        make_schema("BridgePerson", {
            {"name", text_prop("name")},
            {"age", int_prop("age")},
        })
    };

    lattice::swift_configuration config(tmp.str());
    auto* lattice_ref = lattice::swift_lattice_ref::create(config, schemas);
    auto& db = *lattice_ref->get();

    // Build a sync event JSON
    lattice::audit_log_entry entry;
    entry.global_id = "sync-entry-1";
    entry.table_name = "BridgePerson";
    entry.operation = "INSERT";
    entry.row_id = 1;
    entry.global_row_id = "bridge-person-uuid";
    entry.changed_fields = {
        {"name", lattice::any_property("Synced Person")},
        {"age", lattice::any_property(42)}
    };
    entry.changed_fields_names = {"name", "age"};
    entry.timestamp = "2024-01-01T00:00:00Z";

    auto sse = lattice::server_sent_event::make_audit_log({entry});
    auto json = sse.to_json();
    lattice::ByteVector data(json.begin(), json.end());

    // Call receive_sync_data — the entry point Swift uses
    auto applied = db.receive_sync_data(data);
    EXPECT_FALSE(applied.empty());
    EXPECT_FALSE(db.last_receive_error().has_value());

    // Verify object was created
    auto results = db.objects("BridgePerson");
    ASSERT_EQ(results.size(), 1u);
    EXPECT_EQ(results[0].get_string("name"), "Synced Person");
    EXPECT_EQ(int(results[0].get_int("age")), 42);
}

TEST(Bridge, ReceiveSyncDataWithBlob) {
    // THE KEY TEST: BLOB data through the full sync bridge path
    TempDB tmp{"bridge_sync_blob"};
    lattice::SchemaVector schemas = {
        make_schema("BridgeVec", {
            {"label", text_prop("label")},
            {"embedding", blob_prop("embedding")},
        })
    };

    lattice::swift_configuration config(tmp.str());
    auto* lattice_ref = lattice::swift_lattice_ref::create(config, schemas);
    auto& db = *lattice_ref->get();

    // Simulate the source side: object with BLOB → AuditLog → hex encoding
    std::vector<float> original = {1.0f, 2.0f, 3.0f, 4.5f, -0.5f};
    auto blob = pack_floats(original);

    // The AuditLog trigger stores BLOB as hex(embedding) → string_kind
    std::string hex_str;
    for (auto byte : blob) {
        char buf[3];
        snprintf(buf, sizeof(buf), "%02X", byte);
        hex_str += buf;
    }

    lattice::audit_log_entry entry;
    entry.global_id = "blob-sync-1";
    entry.table_name = "BridgeVec";
    entry.operation = "INSERT";
    entry.row_id = 1;
    entry.global_row_id = "bridge-vec-uuid";
    // The embedding is hex-encoded (string_kind), matching what the audit trigger produces
    entry.changed_fields = {
        {"label", lattice::any_property("synced vec")},
        {"embedding", lattice::any_property(hex_str)}  // hex string, not raw bytes
    };
    entry.changed_fields_names = {"label", "embedding"};
    entry.timestamp = "2024-01-01T00:00:00Z";

    // Full round-trip through SSE JSON
    auto sse = lattice::server_sent_event::make_audit_log({entry});
    auto json = sse.to_json();
    lattice::ByteVector data(json.begin(), json.end());

    auto applied = db.receive_sync_data(data);
    EXPECT_FALSE(applied.empty()) << "receive_sync_data should succeed";

    auto err = db.last_receive_error();
    EXPECT_FALSE(err.has_value()) << "No error expected, got: " << (err ? *err : "");

    // Verify the object was created with correct BLOB data
    auto results = db.objects("BridgeVec");
    ASSERT_EQ(results.size(), 1u);
    EXPECT_EQ(results[0].get_string("label"), "synced vec");

    // Read back BLOB and verify it matches original
    // managed<swift_dynamic_object> doesn't expose get_data directly —
    // read BLOB from raw SQL to verify storage
    auto blob_rows = db.db().query(
        "SELECT embedding FROM BridgeVec WHERE globalId = ?",
        {std::string(results[0].global_id())});
    ASSERT_EQ(blob_rows.size(), 1u);
    auto stored_blob = std::get<std::vector<uint8_t>>(blob_rows[0].at("embedding"));
    auto stored_floats = unpack_floats(stored_blob);
    ASSERT_EQ(stored_floats.size(), original.size())
        << "BLOB size mismatch after sync: expected " << original.size()
        << " floats, got " << stored_floats.size();
    for (size_t i = 0; i < original.size(); i++) {
        EXPECT_NEAR(stored_floats[i], original[i], 0.001)
            << "Float mismatch at index " << i << " after sync round-trip";
    }
}

TEST(Bridge, ReceiveSyncDataBlobWithRawBytes) {
    // Test what happens if BLOB comes as data_kind (raw bytes) instead of
    // string_kind (hex). This is what json_to_any_property produces when
    // deserializing {kind:6, value:"hex_str"}.
    TempDB tmp{"bridge_sync_blob_raw"};
    lattice::SchemaVector schemas = {
        make_schema("BridgeVec", {
            {"label", text_prop("label")},
            {"embedding", blob_prop("embedding")},
        })
    };

    lattice::swift_configuration config(tmp.str());
    auto* lattice_ref = lattice::swift_lattice_ref::create(config, schemas);
    auto& db = *lattice_ref->get();

    std::vector<float> original = {1.0f, 2.0f, 3.0f};
    auto blob = pack_floats(original);

    // Build entry with data_kind (raw bytes) — this is what happens
    // after a from_json round-trip of a {kind:6, value:"hex"} property
    lattice::audit_log_entry entry;
    entry.global_id = "blob-raw-1";
    entry.table_name = "BridgeVec";
    entry.operation = "INSERT";
    entry.row_id = 1;
    entry.global_row_id = "bridge-raw-uuid";
    entry.changed_fields = {
        {"label", lattice::any_property("raw bytes test")},
        {"embedding", lattice::any_property(blob)}  // data_kind with raw bytes
    };
    entry.changed_fields_names = {"label", "embedding"};
    entry.timestamp = "2024-01-01T00:00:00Z";

    // Full SSE round-trip
    auto sse = lattice::server_sent_event::make_audit_log({entry});
    auto json = sse.to_json();
    lattice::ByteVector data(json.begin(), json.end());

    auto applied = db.receive_sync_data(data);
    auto err = db.last_receive_error();
    EXPECT_FALSE(err.has_value()) << "Error: " << (err ? *err : "");
    EXPECT_FALSE(applied.empty());

    // Verify BLOB survived
    auto results = db.objects("BridgeVec");
    ASSERT_EQ(results.size(), 1u);

    // managed<swift_dynamic_object> doesn't expose get_data directly —
    // read BLOB from raw SQL to verify storage
    auto blob_rows = db.db().query(
        "SELECT embedding FROM BridgeVec WHERE globalId = ?",
        {std::string(results[0].global_id())});
    ASSERT_EQ(blob_rows.size(), 1u);
    auto stored_blob = std::get<std::vector<uint8_t>>(blob_rows[0].at("embedding"));
    auto stored_floats = unpack_floats(stored_blob);
    ASSERT_EQ(stored_floats.size(), original.size())
        << "data_kind BLOB failed: expected " << original.size()
        << " floats, got " << stored_floats.size();
    for (size_t i = 0; i < original.size(); i++) {
        EXPECT_NEAR(stored_floats[i], original[i], 0.001);
    }
}

// ============================================================================
// events_after — the complete sync outbound path
// ============================================================================

TEST(Bridge, EventsAfterWithBlob) {
    // Verify that when an object with a BLOB is added, the AuditLog entry
    // produced by events_after() has the BLOB correctly hex-encoded.
    TempDB tmp{"bridge_events"};
    lattice::SchemaVector schemas = {
        make_schema("BridgeVec", {
            {"label", text_prop("label")},
            {"embedding", blob_prop("embedding")},
        })
    };

    lattice::swift_configuration config(tmp.str());
    auto* lattice_ref = lattice::swift_lattice_ref::create(config, schemas);
    auto& db = *lattice_ref->get();

    // Add object with BLOB
    std::vector<float> original = {1.0f, 2.0f, 3.0f};
    auto sdo = make_sdo("BridgeVec", schemas[0].properties);
    sdo.values["label"] = std::string("outbound test");
    sdo.values["embedding"] = pack_floats(original);

    { lattice::dynamic_object obj(sdo); db.add(obj); }

    // Get events
    auto events = db.events_after(std::nullopt);
    ASSERT_FALSE(events.empty());

    // Find the BridgeVec INSERT entry
    bool found = false;
    for (const auto& e : events) {
        if (e.table_name == "BridgeVec" && e.operation == "INSERT") {
            found = true;

            // The embedding field should be in changedFields as a hex string
            auto it = e.changed_fields.find("embedding");
            ASSERT_NE(it, e.changed_fields.end())
                << "embedding field missing from AuditLog changedFields";

            // Serialize to JSON and back (simulates send over wire)
            auto sse = lattice::server_sent_event::make_audit_log({e});
            auto json = sse.to_json();

            // Apply on a second instance
            TempDB tmp2{"bridge_events_target"};
            lattice::swift_configuration config2(tmp2.str());
            lattice::swift_lattice db2(config2, schemas);

            lattice::ByteVector data(json.begin(), json.end());
            auto applied = db2.receive_sync_data(data);
            EXPECT_FALSE(applied.empty());

            // Verify BLOB round-tripped correctly
            auto results = db2.objects("BridgeVec");
            ASSERT_EQ(results.size(), 1u);
            EXPECT_EQ(results[0].get_string("label"), "outbound test");

            auto blob_rows2 = db2.db().query(
                "SELECT embedding FROM BridgeVec WHERE globalId = ?",
                {std::string(results[0].global_id())});
            ASSERT_EQ(blob_rows2.size(), 1u);
            auto stored = std::get<std::vector<uint8_t>>(blob_rows2[0].at("embedding"));
            auto floats = unpack_floats(stored);
            ASSERT_EQ(floats.size(), original.size());
            for (size_t i = 0; i < original.size(); i++) {
                EXPECT_NEAR(floats[i], original[i], 0.001);
            }
            break;
        }
    }
    EXPECT_TRUE(found) << "No BridgeVec INSERT entry in events_after()";
}

// ============================================================================
// dynamic_object_ref (Swift's primary handle)
// ============================================================================

TEST(Bridge, DynamicObjectRefCRUD) {
    TempDB tmp{"bridge_ref"};
    lattice::SchemaVector schemas = {
        make_schema("BridgePerson", {
            {"name", text_prop("name")},
            {"age", int_prop("age")},
        })
    };

    lattice::swift_configuration config(tmp.str());
    auto* lattice_ref = lattice::swift_lattice_ref::create(config, schemas);
    auto& db = *lattice_ref->get();

    // Create via ref with properties (what Swift does)
    auto sdo = make_sdo("BridgePerson", schemas[0].properties);
    sdo.values["name"] = std::string("RefPerson");
    sdo.values["age"] = int64_t(28);
    lattice::dynamic_object_ref ref(sdo);

    db.add(ref);

    // Query — verify it was inserted
    auto results = db.objects("BridgePerson");
    ASSERT_EQ(results.size(), 1u);
    EXPECT_EQ(results[0].get_string("name"), "RefPerson");
    EXPECT_EQ(int(results[0].get_int("age")), 28);
}

// ============================================================================
// Observation through the bridge
// ============================================================================

TEST(Bridge, TableObserverViaBridge) {
    TempDB tmp{"bridge_obs"};
    lattice::SchemaVector schemas = {
        make_schema("BridgePerson", {
            {"name", text_prop("name")},
            {"age", int_prop("age")},
        })
    };

    lattice::swift_configuration config(tmp.str());
    auto* lattice_ref = lattice::swift_lattice_ref::create(config, schemas);
    auto& db = *lattice_ref->get();

    // Use the lattice_db parent's observer API (std::function based,
    // batched). One fire per WAL flush; the single-row insert below
    // produces a count=1 batch.
    int callback_count = 0;
    auto obs_id = static_cast<lattice::lattice_db&>(db).add_table_observer("BridgePerson",
        [&](const std::vector<lattice::lattice_db::change_event>&) {
            callback_count++;
        });

    auto sdo = make_sdo("BridgePerson", schemas[0].properties);
    sdo.values["name"] = std::string("Observed");
    sdo.values["age"] = int64_t(30);

    { lattice::dynamic_object obj(sdo); db.add(obj); }

    EXPECT_GE(callback_count, 1);

    static_cast<lattice::lattice_db&>(db).remove_table_observer("BridgePerson", obs_id);
}

// ============================================================================
// swift_lattice_ref (cached factory, Swift's primary entry point)
// ============================================================================

TEST(Bridge, SwiftLatticeRefCreate) {
    TempDB tmp{"bridge_lattice_ref"};
    lattice::SchemaVector schemas = {
        make_schema("BridgePerson", {
            {"name", text_prop("name")},
            {"age", int_prop("age")},
        })
    };

    lattice::swift_configuration config(tmp.str());
    auto* ref = lattice::swift_lattice_ref::create(config, schemas);
    ASSERT_NE(ref, nullptr);

    // Add object through the ref
    auto sdo = make_sdo("BridgePerson", schemas[0].properties);
    sdo.values["name"] = std::string("ViaRef");
    sdo.values["age"] = int64_t(40);

    { lattice::dynamic_object obj(sdo); ref->get()->add(obj); }

    auto results = ref->get()->objects("BridgePerson");
    ASSERT_EQ(results.size(), 1u);
    EXPECT_EQ(results[0].get_string("name"), "ViaRef");

    // Cleanup
    delete ref;
}

// ============================================================================
// LatticeCache concurrency — on-disk get_or_create builds outside the lock and
// de-dups concurrent opens of the same key to a single instance.
// ============================================================================

TEST(Bridge, CacheConcurrentSamePathDedup) {
    TempDB tmp{"bridge_cache_dedup"};
    lattice::SchemaVector schemas = {
        make_schema("BridgePerson", {
            {"name", text_prop("name")},
            {"age", int_prop("age")},
        })
    };

    constexpr int kThreads = 16;
    std::atomic<bool> go{false};
    std::vector<std::thread> threads;
    std::vector<lattice::swift_lattice_ref*> refs(kThreads, nullptr);

    for (int i = 0; i < kThreads; ++i) {
        threads.emplace_back([&, i] {
            // All threads target the SAME on-disk path. Release into the lock
            // simultaneously to maximize the chance of racing construction.
            lattice::swift_configuration config(tmp.str());
            while (!go.load(std::memory_order_acquire)) std::this_thread::yield();
            refs[i] = lattice::swift_lattice_ref::create(config, schemas);
        });
    }
    go.store(true, std::memory_order_release);
    for (auto& t : threads) t.join();

    // Every concurrent open of the same key must resolve to ONE instance —
    // no duplicate SQLite connection to the same file.
    ASSERT_NE(refs[0], nullptr);
    auto* first = refs[0]->get();
    ASSERT_NE(first, nullptr);
    for (int i = 0; i < kThreads; ++i) {
        ASSERT_NE(refs[i], nullptr) << "create() returned null on thread " << i;
        EXPECT_EQ(refs[i]->get(), first)
            << "thread " << i << " got a different swift_lattice instance";
        EXPECT_EQ(refs[i]->hash_value(), refs[0]->hash_value());
    }

    // The shared instance is usable.
    auto sdo = make_sdo("BridgePerson", schemas[0].properties);
    sdo.values["name"] = std::string("Concurrent");
    sdo.values["age"] = int64_t(1);
    { lattice::dynamic_object obj(sdo); first->add(obj); }
    EXPECT_EQ(first->objects("BridgePerson").size(), 1u);

    for (auto* r : refs) delete r;
}

TEST(BridgeCacheReadOnlyPolicy, WritableFirstKeepsReadOnlyOwnerSeparate) {
    TempDB file{"bridge-cache-writable-first"};
    const lattice::SchemaVector schemas={make_schema("ReadOnlyCacheRow",{{"name",text_prop("name")}})};
    lattice::swift_configuration write_config(file.str());
    auto& cache=lattice::detail::LatticeCache::instance();
    auto writer=cache.get_or_create(write_config,schemas);
    writer->db().execute("INSERT INTO ReadOnlyCacheRow(globalId,name) VALUES('00000000-0000-4000-8000-000000000001','original')");
    auto read_config=write_config;read_config.read_only=true;
    auto reader=cache.get_or_create(read_config,schemas);
    ASSERT_NE(reader.get(),writer.get());
    EXPECT_EQ(lattice_sqlite3541_db_readonly(lattice::detail::canonical_writer_custody_test_access::escaped_handle(reader->db()),"main"),1);
    EXPECT_EQ(lattice_sqlite3541_db_readonly(lattice::detail::canonical_writer_custody_test_access::escaped_handle(writer->db()),"main"),0);
    EXPECT_EQ(cache.get_or_create(read_config,schemas),reader);
    EXPECT_EQ(cache.get_or_create(write_config,schemas),writer);
    EXPECT_THROW(reader->db().execute("UPDATE ReadOnlyCacheRow SET name='forbidden'"),lattice::db_error);
    writer->db().execute("UPDATE ReadOnlyCacheRow SET name='committed'");
    EXPECT_EQ(std::get<std::string>(reader->db().query("SELECT name FROM ReadOnlyCacheRow").at(0).at("name")),"committed");
}

TEST(BridgeCacheReadOnlyPolicy, ReadOnlyFirstDoesNotReplaceRequestedWritableOwner) {
    TempDB file{"bridge-cache-readonly-first"};
    const lattice::SchemaVector schemas={make_schema("ReadOnlyCacheRow",{{"name",text_prop("name")}})};
    lattice::swift_configuration write_config(file.str());
    {
        lattice::swift_lattice seed(write_config,schemas);
        seed.db().execute("INSERT INTO ReadOnlyCacheRow(globalId,name) VALUES('00000000-0000-4000-8000-000000000002','original')");
    }
    auto read_config=write_config;read_config.read_only=true;
    auto& cache=lattice::detail::LatticeCache::instance();
    auto reader=cache.get_or_create(read_config,schemas);
    auto writer=cache.get_or_create(write_config,schemas);
    ASSERT_NE(reader.get(),writer.get());
    EXPECT_EQ(lattice_sqlite3541_db_readonly(lattice::detail::canonical_writer_custody_test_access::escaped_handle(reader->db()),"main"),1);
    EXPECT_EQ(lattice_sqlite3541_db_readonly(lattice::detail::canonical_writer_custody_test_access::escaped_handle(writer->db()),"main"),0);
    EXPECT_EQ(cache.get_or_create(read_config,schemas),reader);
    EXPECT_EQ(cache.get_or_create(write_config,schemas),writer);
    EXPECT_NO_THROW(writer->db().execute("UPDATE ReadOnlyCacheRow SET name='writable'"));
    EXPECT_EQ(std::get<std::string>(reader->db().query("SELECT name FROM ReadOnlyCacheRow").at(0).at("name")),"writable");
}

TEST(Bridge, CacheConcurrentCreateResolveStress) {
    // TSan target: hammer get_or_create's cache-hit path and get_by_pointer
    // (the per-object hot path) concurrently. A seed ref keeps the cached
    // instance alive so every create() resolves to it.
    TempDB tmp{"bridge_cache_stress"};
    lattice::SchemaVector schemas = {
        make_schema("BridgePerson", {
            {"name", text_prop("name")},
            {"age", int_prop("age")},
        })
    };

    auto* seed = lattice::swift_lattice_ref::create(
        lattice::swift_configuration(tmp.str()), schemas);
    ASSERT_NE(seed, nullptr);
    auto seed_hash = seed->hash_value();

    constexpr int kThreads = 12;
    constexpr int kIters = 25;
    std::atomic<bool> go{false};
    std::atomic<int> failures{0};
    std::vector<std::thread> threads;

    for (int i = 0; i < kThreads; ++i) {
        threads.emplace_back([&] {
            lattice::swift_configuration config(tmp.str());
            while (!go.load(std::memory_order_acquire)) std::this_thread::yield();
            for (int j = 0; j < kIters; ++j) {
                auto* ref = lattice::swift_lattice_ref::create(config, schemas);
                if (!ref || ref->hash_value() != seed_hash) { failures++; if (ref) delete ref; continue; }
                // Reverse lookup exercises get_by_pointer under contention.
                auto back = lattice::swift_lattice_ref::shared_for_lattice(ref->get());
                if (!back || back.get() != ref->get()) failures++;
                delete ref;
            }
        });
    }
    go.store(true, std::memory_order_release);
    for (auto& t : threads) t.join();

    EXPECT_EQ(failures.load(), 0);
    delete seed;
}

// ============================================================================
// Bridge fingerprint fast path — write-free reopen at the swift_lattice layer
// ============================================================================

TEST(Bridge, ReopenIsWriteFree) {
    TempDB tmp{"bridge_writefree"};
    lattice::SchemaVector schemas = {
        make_schema("BridgeFpPerson", {
            {"name", text_prop("name")},
            {"age", int_prop("age")},
        })
    };

    // NOTE: direct swift_lattice construction (no swift_lattice_ref) — safe
    // for SQL + objects() but NOT for dynamic_object add(), which requires a
    // registered ref. Writes below go through raw SQL so the audit triggers
    // (and their sync_disabled() call) still exercise the trigger path.

    // Opens #1-#3 settle the schema + close-time stats; each open really
    // re-runs the ensure path (no LatticeCache involved).
    {
        lattice::swift_configuration config(tmp.str());
        lattice::swift_lattice db(config, schemas);
        db.db().execute(
            "INSERT INTO BridgeFpPerson(name, age) VALUES('Alice', 30)");
    }
    {
        lattice::swift_configuration config(tmp.str());
        lattice::swift_lattice db(config, schemas);
    }
    {
        lattice::swift_configuration config(tmp.str());
        lattice::swift_lattice db(config, schemas);
    }

    // Open #4 must be write-free AND fully functional from in-memory state.
    {
        lattice::swift_configuration config(tmp.str());
        lattice::swift_lattice db(config, schemas);
        EXPECT_EQ(lattice_sqlite3541_total_changes(lattice::detail::canonical_writer_custody_test_access::escaped_handle(db.db())), 0);

        // Hydration works (schemas_ populated by the fast path)
        auto results = db.objects("BridgeFpPerson");
        ASSERT_EQ(results.size(), 1u);
        EXPECT_EQ(results[0].get_string("name"), "Alice");

        // Writes still work: the INSERT fires the audit trigger, which calls
        // sync_disabled() — this throws if the per-connection SQL function
        // wasn't registered on the fast path.
        db.db().execute(
            "INSERT INTO BridgeFpPerson(name, age) VALUES('Bob', 25)");
        EXPECT_EQ(db.objects("BridgeFpPerson").size(), 2u);
    }
}

// ============================================================================
// Link-list position coherence — dangling junction rows must not shift
// positions off the element cache (EXC_BAD_ACCESS via ListSlice.first)
// ============================================================================

static lattice::property_descriptor list_prop(const std::string& name,
                                              const std::string& target) {
    lattice::property_descriptor desc;
    desc.name = name;
    desc.kind = lattice::property_kind::list;
    desc.target_table = target;
    desc.type = lattice::column_type::text;
    return desc;
}

TEST(Bridge, ListPositionsSkipDanglingLinks) {
    TempDB tmp{"bridge_dangling"};
    lattice::SchemaVector schemas = {
        make_schema("FpBand", {
            {"name", text_prop("name")},
            {"albums", list_prop("albums", "FpAlbum")},
        }),
        make_schema("FpAlbum", {
            {"title", text_prop("title")},
            {"year", int_prop("year")},
        }),
    };

    auto* lattice_ref = lattice::swift_lattice_ref::create(
        lattice::swift_configuration(tmp.str()), schemas);
    auto& db = *lattice_ref->get();

    db.db().execute("INSERT INTO FpBand(globalId, name) VALUES('band-1', 'Zeppelin')");
    db.db().execute("INSERT INTO FpAlbum(globalId, title, year) VALUES('al-1', 'IV', 1971)");
    db.db().execute("INSERT INTO FpAlbum(globalId, title, year) VALUES('al-2', 'Houses', 1973)");
    db.db().execute("INSERT INTO FpAlbum(globalId, title, year) VALUES('al-3', 'Graffiti', 1975)");
    db.db().execute("INSERT INTO _FpBand_FpAlbum_albums(lhs, rhs) VALUES('band-1', 'al-1')");
    db.db().execute("INSERT INTO _FpBand_FpAlbum_albums(lhs, rhs) VALUES('band-1', 'al-2')");
    db.db().execute("INSERT INTO _FpBand_FpAlbum_albums(lhs, rhs) VALUES('band-1', 'al-3')");

    // Dangle the FIRST link: target row deleted, junction row lingers (what
    // upsert churn / cross-process deletes leave behind). The element cache
    // skips it, so positions numbered over ALL link rows would shift by one —
    // hydrating the wrong element or walking off the end of the cache.
    db.db().execute("DELETE FROM FpAlbum WHERE globalId = 'al-1'");

    auto bands = db.objects("FpBand");
    ASSERT_EQ(bands.size(), 1u);
    auto field = bands[0].get_managed_field<std::vector<lattice::swift_dynamic_object*>>("albums");
    lattice::link_list list(field, lattice::swift_lattice_ref::shared_for_lattice(&db));

    EXPECT_EQ(list.size(), 2u);  // live membership only

    // Newest-first positions — the exact ListSlice.sortedBy(...).first shape
    // that crashed in the field.
    auto positions = list.find_indices("", "year", /*ascending=*/false);
    ASSERT_EQ(positions.size(), 2u);
    for (auto pos : positions) {
        EXPECT_LT(pos, list.size()) << "position indexes past the element cache";
    }

    auto top = list[positions[0]];
    EXPECT_EQ(int(top.object->get_int("year")), 1975);
    auto next = list[positions[1]];
    EXPECT_EQ(int(next.object->get_int("year")), 1973);

    // Out-of-range access is a catchable error, not undefined behavior.
    EXPECT_THROW(list[99].object->get_int("year"), std::out_of_range);

    delete lattice_ref;
}

TEST(Bridge, UpsertRebindsToExistingRowAndAppendIsIdempotent) {
    TempDB tmp{"bridge_upsert_rebind"};
    lattice::swift_schema_entry sig_entry = make_schema("FpSig", {
        {"key", text_prop("key")},
        {"val", int_prop("val")},
    });
    sig_entry.constraints.push_back(lattice::swift_constraint({"key"}, /*upsert=*/true));
    lattice::SchemaVector schemas = {
        make_schema("FpOwner", {
            {"name", text_prop("name")},
            {"sigs", list_prop("sigs", "FpSig")},
        }),
        sig_entry,
    };

    auto* lattice_ref = lattice::swift_lattice_ref::create(
        lattice::swift_configuration(tmp.str()), schemas);
    auto& db = *lattice_ref->get();

    db.db().execute("INSERT INTO FpOwner(globalId, name) VALUES('own-1', 'O')");

    // First write: plain insert.
    {
        auto sdo = make_sdo("FpSig", schemas[1].properties);
        sdo.values["key"] = std::string("k1");
        sdo.values["val"] = int64_t(1);
        lattice::dynamic_object obj(sdo);
        db.add(obj);
    }
    auto gid_rows = db.db().query("SELECT globalId FROM FpSig");
    ASSERT_EQ(gid_rows.size(), 1u);
    auto original_gid = std::get<std::string>(gid_rows[0].at("globalId"));

    // Second write: same unique key — ON CONFLICT DO UPDATE. The object MUST
    // rebind to the surviving row's identity; binding to the freshly
    // generated globalId points every later link write at a row that doesn't
    // exist (this is how signal lists accumulated dangling junction rows).
    auto sdo2 = make_sdo("FpSig", schemas[1].properties);
    sdo2.values["key"] = std::string("k1");
    sdo2.values["val"] = int64_t(2);
    lattice::dynamic_object obj2(sdo2);
    db.add(obj2);

    EXPECT_EQ(obj2.get_string("globalId"), original_gid)
        << "upsert did not rebind to the existing row";
    auto rows = db.db().query("SELECT COUNT(*) AS c, MAX(val) AS v FROM FpSig");
    EXPECT_EQ(std::get<int64_t>(rows[0].at("c")), 1);
    EXPECT_EQ(std::get<int64_t>(rows[0].at("v")), 2);

    // Append the rebound object to the owner's list — buildSignalHistory's
    // add-then-append flow. The junction row must reference the REAL row.
    auto owners = db.objects("FpOwner");
    ASSERT_EQ(owners.size(), 1u);
    auto field = owners[0].get_managed_field<std::vector<lattice::swift_dynamic_object*>>("sigs");
    lattice::link_list list(field, lattice::swift_lattice_ref::shared_for_lattice(&db));
    auto* obj2_ref = lattice::dynamic_object_ref::wrap(obj2);
    list.push_back(*obj2_ref);

    auto junction = db.db().query(
        "SELECT rhs FROM _FpOwner_FpSig_sigs WHERE lhs = 'own-1'");
    ASSERT_EQ(junction.size(), 1u);
    EXPECT_EQ(std::get<std::string>(junction[0].at("rhs")), original_gid)
        << "junction row references a phantom globalId (dangling link)";

    // Re-append is a set-semantics no-op, not a PRIMARY KEY violation.
    list.push_back(*obj2_ref);
    delete obj2_ref;
    auto recount = db.db().query(
        "SELECT COUNT(*) AS c FROM _FpOwner_FpSig_sigs WHERE lhs = 'own-1'");
    EXPECT_EQ(std::get<int64_t>(recount[0].at("c")), 1);

    delete lattice_ref;
}

// ============================================================================
// Row cache — materialized reads (see dynamic_object.hpp contract)
// ============================================================================
// Stays inside the !__linux__ guard: these tests exercise the Swift bridge
// (swift_lattice_ref/dynamic_object), which the test target only links on
// Apple platforms — same constraint as everything above.

namespace {
lattice::property_descriptor nullable_text_prop(const std::string& name) {
    lattice::property_descriptor desc;
    desc.name = name;
    desc.type = lattice::column_type::text;
    desc.kind = lattice::property_kind::primitive;
    desc.nullable = true;
    return desc;
}
}  // namespace

TEST(Bridge, RowCacheMaterializedReads) {
    TempDB tmp{"rowcache"};
    lattice::SchemaVector schemas = {
        make_schema("RcPerson", {
            {"name", text_prop("name")},
            {"age", int_prop("age")},
        })
    };
    auto* ref = lattice::swift_lattice_ref::create(
        lattice::swift_configuration(tmp.str()), schemas);
    ASSERT_NE(ref, nullptr);
    auto& db = *ref->get();

    {
        auto sdo = make_sdo("RcPerson", schemas[0].properties);
        sdo.values["name"] = std::string("Alice");
        sdo.values["age"] = int64_t(30);
        lattice::dynamic_object obj(sdo);
        db.add(obj);
    }

    auto results = db.objects("RcPerson");
    ASSERT_EQ(results.size(), 1u);

    // Materialized reads: the query already hydrated the row — ZERO further
    // SQL for any number of property reads.
    lattice::dynamic_object cached(results[0]);
    cached.enable_row_cache();
    // Thread-local counter throughout: pacer/maintenance threads issue SQL on
    // their own schedule, so zero-delta asserts on the GLOBAL counter flake.
    const auto base = lattice::database::thread_statement_count();
    for (int i = 0; i < 5; ++i) {
        EXPECT_EQ(cached.get_string("name"), "Alice");
        EXPECT_EQ(cached.get_int("age"), 30);
    }
    EXPECT_EQ(lattice::database::thread_statement_count() - base, 0u)
        << "materialized reads issued SQL";

    // The live path (default) pays one statement per read — the recall
    // N-statements pathology this exists to kill. Documents the contrast.
    lattice::dynamic_object live(results[0]);
    const auto live_base = lattice::database::thread_statement_count();
    for (int i = 0; i < 5; ++i) {
        (void)live.get_string("name");
        (void)live.get_int("age");
    }
    EXPECT_GE(lattice::database::thread_statement_count() - live_base, 10u)
        << "expected the live path to issue one statement per read";

    // Write-through: DB row updates AND the cached read sees the new value.
    cached.set_int("age", 31);
    const auto after_write = lattice::database::thread_statement_count();
    EXPECT_EQ(cached.get_int("age"), 31);
    EXPECT_EQ(lattice::database::thread_statement_count() - after_write, 0u)
        << "read-your-writes should be served from the cache";
    auto verify = db.objects("RcPerson");
    EXPECT_EQ(verify[0].get_int("age"), 31) << "write-through missed the DB";

    // Atomic SQL-side increment: lands in the DB, drops the cached key so
    // the next materialized read falls through live (no stale value).
    cached.increment_int_field("age", 1);
    EXPECT_EQ(cached.get_int("age"), 32);
    auto verify2 = db.objects("RcPerson");
    EXPECT_EQ(verify2[0].get_int("age"), 32) << "increment missed the DB";

    delete ref;
}

TEST(Bridge, ManagedPrimaryKeyDoesNotReadOrMaterializeRows) {
    TempDB tmp{"bridge_bound_identity"};
    lattice::SchemaVector schemas = {
        make_schema("IdentityPerson", {{"age", int_prop("age")}})
    };
    auto* ref = lattice::swift_lattice_ref::create(
        lattice::swift_configuration(tmp.str()), schemas);
    auto& db = *ref->get();
    for (int i = 0; i < 25; ++i) {
        auto sdo = make_sdo("IdentityPerson", schemas[0].properties);
        sdo.values["age"] = int64_t(i);
        lattice::dynamic_object obj(sdo);
        db.add(obj);
    }
    auto rows = db.objects("IdentityPerson", std::nullopt, std::string("id ASC"));
    ASSERT_EQ(rows.size(), 25u);

    // Page identity reads must not grow the query count with page cardinality.
    // Exercise both bridge forms without enabling or refreshing the row cache.
    const auto page_base = lattice::database::thread_statement_count();
    for (auto& row : rows) {
        lattice::dynamic_object object(row);
        lattice::dynamic_object_ref object_ref(row);
        EXPECT_EQ(object.managed_primary_key(), row.id());
        EXPECT_EQ(object_ref.managed_primary_key(), row.id());
        EXPECT_FALSE(object.is_row_cache_enabled());
        EXPECT_FALSE(object_ref.is_row_cache_enabled());
    }
    EXPECT_EQ(lattice::database::thread_statement_count() - page_base, 0u);

    lattice::dynamic_object_ref live(rows[0]);
    lattice::dynamic_object_ref snapshot(rows[0]);
    snapshot.enable_row_cache();
    const int64_t id = rows[0].id();
    db.db().execute("UPDATE IdentityPerson SET age = 99 WHERE id = ?", {id});
    const auto identity_base = lattice::database::thread_statement_count();
    EXPECT_EQ(live.managed_primary_key(), id);
    EXPECT_EQ(snapshot.managed_primary_key(), id);
    EXPECT_EQ(lattice::database::thread_statement_count() - identity_base, 0u);
    EXPECT_FALSE(live.is_row_cache_enabled());
    EXPECT_TRUE(snapshot.is_row_cache_enabled());
    EXPECT_EQ(live.get_int("age"), 99);
    EXPECT_EQ(snapshot.get_int("age"), 0) << "identity access must not refresh a snapshot";

    db.db().execute("DELETE FROM IdentityPerson WHERE id = ?", {id});
    const auto deleted_base = lattice::database::thread_statement_count();
    EXPECT_EQ(live.managed_primary_key(), id) << "bound identity is not an existence check";
    EXPECT_EQ(lattice::database::thread_statement_count() - deleted_base, 0u);

    auto unmanaged_sdo = make_sdo("IdentityPerson", schemas[0].properties);
    unmanaged_sdo.values["id"] = int64_t(123);
    lattice::dynamic_object unmanaged(unmanaged_sdo);
    lattice::dynamic_object_ref unmanaged_ref(unmanaged_sdo);
    EXPECT_EQ(unmanaged.managed_primary_key(), 0);
    EXPECT_EQ(unmanaged_ref.managed_primary_key(), 0);
    EXPECT_FALSE(unmanaged.has_query_row_image());
    EXPECT_EQ(unmanaged_ref.query_row_value_type("id"), -1);
    EXPECT_TRUE(lattice::column_value_is_null(unmanaged_ref.query_row_value("id")));
    unmanaged_ref.release_query_row_image();
#if LATTICE_HAS_FRT
    auto* empty_ref = lattice::dynamic_object_ref::_make(nullptr);
    EXPECT_EQ(empty_ref->managed_primary_key(), 0);
    EXPECT_FALSE(empty_ref->has_query_row_image());
    EXPECT_EQ(empty_ref->query_row_value_type("id"), -1);
    empty_ref->release_query_row_image();
    delete empty_ref;
#else
    auto empty_ref = lattice::dynamic_object_ref::_make(nullptr);
    EXPECT_EQ(empty_ref.managed_primary_key(), 0);
    EXPECT_FALSE(empty_ref.has_query_row_image());
    EXPECT_EQ(empty_ref.query_row_value_type("id"), -1);
    empty_ref.release_query_row_image();
#endif
    delete ref;
}

TEST(Bridge, ManagedPrimaryKeyPreservesAttachedWriteRouting) {
    TempDB local_path{"identity_local"}, attached_path{"identity_attached"};
    lattice::SchemaVector schemas = {
        make_schema("IdentityArm", {{"age", int_prop("age")}})
    };
    auto* local_ref = lattice::swift_lattice_ref::create(
        lattice::swift_configuration(local_path.str()), schemas);
    auto* attached_ref = lattice::swift_lattice_ref::create(
        lattice::swift_configuration(attached_path.str()), schemas);
    auto& local = *local_ref->get();
    auto& attached = *attached_ref->get();
    for (auto* db : {&local, &attached}) {
        auto sdo = make_sdo("IdentityArm", schemas[0].properties);
        sdo.values["age"] = int64_t(db == &local ? 10 : 20);
        lattice::dynamic_object obj(sdo);
        db->add(obj);
    }
    local.attach(attached);
    auto rows = local.objects("IdentityArm", std::nullopt, std::string("age ASC"));
    ASSERT_EQ(rows.size(), 2u);
    ASSERT_EQ(rows[0].id(), rows[1].id()) << "fixture requires colliding per-file keys";

    lattice::dynamic_object_ref local_row(rows[0]);
    lattice::dynamic_object_ref attached_row(rows[1]);
    const auto base = lattice::database::thread_statement_count();
    EXPECT_EQ(local_row.managed_primary_key(), rows[0].id());
    EXPECT_EQ(attached_row.managed_primary_key(), rows[1].id());
    EXPECT_TRUE(attached_row.has_query_row_image());
    EXPECT_EQ(attached_row.query_row_value_type("age"), 1);
    EXPECT_EQ(std::get<int64_t>(attached_row.query_row_value("age")), 20);
    EXPECT_EQ(attached_row.query_row_value_type("_source"), 3);
    EXPECT_EQ(lattice::database::thread_statement_count() - base, 0u);
    EXPECT_FALSE(attached_row.is_row_cache_enabled());

    attached_row.set_int("age", 44);
    EXPECT_EQ(std::get<int64_t>(attached_row.query_row_value("age")), 20)
        << "a write must not mutate the query-position image";
    attached_row.release_query_row_image();
    EXPECT_FALSE(attached_row.has_query_row_image());
    EXPECT_FALSE(attached_row.is_row_cache_enabled());
    // A fresh file connection, not a held/cached handle, proves persistence in
    // the attached arm and catches the lost-write class from the cache revert.
    lattice::database local_check(local_path.str());
    lattice::database attached_check(attached_path.str());
    auto local_values = local_check.query("SELECT age FROM IdentityArm");
    auto attached_values = attached_check.query("SELECT age FROM IdentityArm");
    ASSERT_EQ(local_values.size(), 1u);
    ASSERT_EQ(attached_values.size(), 1u);
    EXPECT_EQ(std::get<int64_t>(local_values[0].at("age")), 10);
    EXPECT_EQ(std::get<int64_t>(attached_values[0].at("age")), 44);
    delete local_ref;
    delete attached_ref;
}

TEST(Bridge, QueryRowImageKeepsGenerationValuesSeparateFromMaterialization) {
    TempDB tmp{"query_row_image"};
    auto data_prop = blob_prop("payload");
    data_prop.is_vector = false;
    lattice::SchemaVector schemas = {
        make_schema("QueryImage", {
            {"age", int_prop("age")},
            {"score", real_prop("score")},
            {"name", text_prop("name")},
            {"email", nullable_text_prop("email")},
            {"payload", data_prop},
        })
    };
    const auto config = lattice::swift_configuration(tmp.str());
    auto* ref = lattice::swift_lattice_ref::create(config, schemas);
    auto& db = *ref->get();
    {
        auto sdo = make_sdo("QueryImage", schemas[0].properties);
        sdo.values["age"] = int64_t(7);
        sdo.values["score"] = 1.25;
        sdo.values["name"] = std::string("before");
        sdo.values["email"] = nullptr;
        sdo.values["payload"] = std::vector<uint8_t>{0, 1, 255};
        lattice::dynamic_object obj(sdo);
        db.add(obj);
    }
    auto* writer_ref = lattice::swift_lattice_ref::create_uncached(config, schemas);
    auto& writer = *writer_ref->get();
    auto generation = ref->acquire_read_generation();
    ASSERT_NE(generation, 0u);
    auto rows = ref->objects_at(generation, "QueryImage");
    ASSERT_FALSE(ref->last_generation_read_stale());
    ASSERT_EQ(rows.size(), 1u);
    lattice::dynamic_object_ref live(rows[0]);
    lattice::dynamic_object_ref snapshot(rows[0]);
    const int64_t id = rows[0].id();

    // Mutate the sort key on another connection BEFORE anchor extraction.
    // The immutable query image must retain the value selected by the keeper.
    writer.db().execute("UPDATE QueryImage SET age = 99, name = 'after' WHERE id = ?", {id});
    const auto base = lattice::database::thread_statement_count();
    EXPECT_TRUE(live.has_query_row_image());
    EXPECT_EQ(live.query_row_value_type("id"), 1);
    EXPECT_EQ(live.query_row_value_type("age"), 1);
    EXPECT_EQ(live.query_row_value_type("score"), 2);
    EXPECT_EQ(live.query_row_value_type("name"), 3);
    EXPECT_EQ(live.query_row_value_type("payload"), 4);
    EXPECT_EQ(live.query_row_value_type("email"), 0);
    EXPECT_EQ(live.query_row_value_type("missing"), -1);
    EXPECT_EQ(std::get<int64_t>(live.query_row_value("id")), id);
    EXPECT_EQ(std::get<int64_t>(live.query_row_value("age")), 7);
    EXPECT_EQ(std::get<double>(live.query_row_value("score")), 1.25);
    EXPECT_EQ(std::get<std::string>(live.query_row_value("name")), "before");
    EXPECT_EQ(std::get<std::vector<uint8_t>>(live.query_row_value("payload")),
              (std::vector<uint8_t>{0, 1, 255}));
    EXPECT_TRUE(lattice::column_value_is_null(live.query_row_value("email")));
    EXPECT_TRUE(lattice::column_value_is_null(live.query_row_value("missing")));
    EXPECT_TRUE(live.last_query_error_message().empty());
    EXPECT_FALSE(live.is_row_cache_enabled());
    EXPECT_EQ(lattice::database::thread_statement_count() - base, 0u);
    EXPECT_EQ(live.get_int("age"), 99) << "ordinary property reads must stay live";

    // Materialization is a separate, explicitly refreshed snapshot. It must
    // neither consume the old query image nor replace it with a new row image.
    snapshot.enable_row_cache();
    EXPECT_EQ(snapshot.get_int("age"), 99);
    EXPECT_EQ(std::get<int64_t>(snapshot.query_row_value("age")), 7);
    writer.db().execute("UPDATE QueryImage SET age = 100 WHERE id = ?", {id});
    snapshot.refresh_row_cache();
    EXPECT_EQ(snapshot.get_int("age"), 100);
    EXPECT_EQ(std::get<int64_t>(snapshot.query_row_value("age")), 7);
    live.set_int("age", 101);
    EXPECT_EQ(std::get<int64_t>(live.query_row_value("age")), 7);

    const auto release_base = lattice::database::thread_statement_count();
    snapshot.release_query_row_image();
    EXPECT_FALSE(snapshot.has_query_row_image());
    EXPECT_EQ(snapshot.query_row_value_type("age"), -1);
    EXPECT_TRUE(lattice::column_value_is_null(snapshot.query_row_value("age")));
    EXPECT_TRUE(snapshot.is_row_cache_enabled());
    EXPECT_EQ(snapshot.get_int("age"), 100);
    EXPECT_TRUE(live.has_query_row_image()) << "releasing one copy must not erase another's image";
    EXPECT_EQ(lattice::database::thread_statement_count() - release_base, 0u);

    writer.db().execute("DELETE FROM QueryImage WHERE id = ?", {id});
    const auto deleted_base = lattice::database::thread_statement_count();
    EXPECT_EQ(std::get<int64_t>(live.query_row_value("age")), 7);
    live.release_query_row_image();
    EXPECT_FALSE(live.has_query_row_image());
    EXPECT_FALSE(live.is_row_cache_enabled());
    EXPECT_EQ(lattice::database::thread_statement_count() - deleted_base, 0u);
    ref->release_read_generation(generation);
    delete writer_ref;
    delete ref;
}

TEST(Bridge, RowCacheSnapshotAndRefresh) {
    TempDB tmp{"rowcache_refresh"};
    lattice::SchemaVector schemas = {
        make_schema("RcSnap", {
            {"name", text_prop("name")},
            {"age", int_prop("age")},
        })
    };
    auto* ref = lattice::swift_lattice_ref::create(
        lattice::swift_configuration(tmp.str()), schemas);
    auto& db = *ref->get();
    {
        auto sdo = make_sdo("RcSnap", schemas[0].properties);
        sdo.values["name"] = std::string("Snap");
        sdo.values["age"] = int64_t(1);
        lattice::dynamic_object obj(sdo);
        db.add(obj);
    }
    auto results = db.objects("RcSnap");
    lattice::dynamic_object cached(results[0]);
    cached.enable_row_cache();
    ASSERT_EQ(cached.get_int("age"), 1);

    // External write behind the object's back: the materialized object is a
    // SNAPSHOT — stale until explicitly refreshed. That is the documented
    // trade (and exactly what recall wants).
    db.db().execute("UPDATE RcSnap SET age = 99");
    EXPECT_EQ(cached.get_int("age"), 1) << "snapshot unexpectedly saw an external write";
    cached.refresh_row_cache();
    EXPECT_EQ(cached.get_int("age"), 99) << "refreshRowCache did not pick up the external write";

    // Disabled → live reads again.
    cached.disable_row_cache();
    db.db().execute("UPDATE RcSnap SET age = 100");
    EXPECT_EQ(cached.get_int("age"), 100);

    delete ref;
}

TEST(Bridge, RowCacheNullRoundTrip) {
    TempDB tmp{"rowcache_null"};
    lattice::SchemaVector schemas = {
        make_schema("RcOpt", {
            {"name", text_prop("name")},
            {"email", nullable_text_prop("email")},
        })
    };
    auto* ref = lattice::swift_lattice_ref::create(
        lattice::swift_configuration(tmp.str()), schemas);
    auto& db = *ref->get();
    {
        auto sdo = make_sdo("RcOpt", schemas[0].properties);
        sdo.values["name"] = std::string("Opt");
        sdo.values["email"] = std::string("a@b.c");
        lattice::dynamic_object obj(sdo);
        db.add(obj);
    }
    auto results = db.objects("RcOpt");
    lattice::dynamic_object cached(results[0]);
    cached.enable_row_cache();

    const auto base = lattice::database::thread_statement_count();
    EXPECT_TRUE(cached.has_value("email"));
    EXPECT_EQ(lattice::database::thread_statement_count() - base, 0u);

    // set_nil must write through: a cached read after setNil returning the
    // stale value would be silent wrong-value corruption for optionals.
    cached.set_nil("email");
    EXPECT_FALSE(cached.has_value("email"))
        << "cache returned stale non-nil after setNil";
    // And back:
    cached.set_field<std::string>("email", "x@y.z");
    const auto reread = lattice::database::thread_statement_count();
    EXPECT_TRUE(cached.has_value("email"));
    EXPECT_EQ(cached.get_string("email"), "x@y.z");
    EXPECT_EQ(lattice::database::thread_statement_count() - reread, 0u);

    delete ref;
}


// P0 review pins (Jul 11): tuning must differentiate the instance cache, and
// nonsensical tuning values must be ignored at the bridge boundary.
TEST(BridgeTuning, DifferentTuningDoesNotShareInstance) {
    auto path = std::filesystem::temp_directory_path() / "bridge_tuning_key.sqlite";
    std::filesystem::remove(path);
    lattice::swift_configuration a(path.string());
    lattice::swift_configuration b(path.string());
    b.set_sync_chunk_size(1);

    auto ia = lattice::detail::LatticeCache::instance().get_or_create(a, lattice::SchemaVector{});
    auto ib = lattice::detail::LatticeCache::instance().get_or_create(b, lattice::SchemaVector{});
    EXPECT_NE(ia.get(), ib.get())
        << "different sync tuning must not share a cached instance";
    // Same tuning still dedups.
    lattice::swift_configuration c(path.string());
    c.set_sync_chunk_size(1);
    auto ic = lattice::detail::LatticeCache::instance().get_or_create(c, lattice::SchemaVector{});
    EXPECT_EQ(ib.get(), ic.get());
}

// A selected WAL bound must survive both cached and derived owner openings.
TEST(BridgeWalPolicy, CachedUnboundedOwnerCannotSatisfyBoundedRequest) {
    const auto path=std::filesystem::temp_directory_path()/
        ("bridge_wal_policy_"+lattice::uuid_t::generate().to_string()+".sqlite");
    lattice::swift_configuration legacy(path.string());
    auto& cache=lattice::detail::LatticeCache::instance();
    auto unbounded=cache.get_or_create(legacy,lattice::SchemaVector{});
    auto bounded=legacy;bounded.wal_extent_limit_bytes=1024*1024;
    auto first=cache.get_or_create(bounded,lattice::SchemaVector{});
    ASSERT_NE(first.get(),unbounded.get());
    EXPECT_EQ(first->config().wal_extent_limit_bytes,bounded.wal_extent_limit_bytes);
    auto same=cache.get_or_create(bounded,lattice::SchemaVector{});
    EXPECT_EQ(same.get(),first.get());
    auto tighter=bounded;tighter.wal_extent_limit_bytes=512*1024;
    // Cache identity is tested on an actually eligible tighter WAL. Bootstrap
    // traffic may already exceed512KiB; do not turn this into a cap exception.
    const auto wal=path.string()+"-wal";
    const auto prior_extent=std::filesystem::exists(wal)?std::filesystem::file_size(wal):0;
    RecordProperty("pre_tighter_wal_bytes",std::to_string(prior_extent));
    const auto checkpoint=first->db().wal_checkpoint(/*truncate=*/true,/*busy_budget_ms=*/250);
    RecordProperty("tighter_checkpoint_rc",checkpoint.rc);
    RecordProperty("tighter_checkpoint_busy",checkpoint.busy);
    RecordProperty("tighter_checkpoint_log",std::to_string(checkpoint.log_frames));
    RecordProperty("tighter_checkpoint_done",std::to_string(checkpoint.checkpointed));
    ASSERT_EQ(checkpoint.rc,LATTICE_SQLITE3541_OK);ASSERT_EQ(checkpoint.busy,0);
    ASSERT_EQ(checkpoint.log_frames,0);ASSERT_EQ(checkpoint.checkpointed,0);
    const auto admitted_extent=std::filesystem::exists(wal)?std::filesystem::file_size(wal):0;
    RecordProperty("admitted_tighter_wal_bytes",std::to_string(admitted_extent));
    ASSERT_EQ(admitted_extent,0u);
    auto second=cache.get_or_create(tighter,lattice::SchemaVector{});
    EXPECT_NE(second.get(),first.get());
    EXPECT_EQ(second->config().wal_extent_limit_bytes,tighter.wal_extent_limit_bytes);
    auto read_only=bounded;read_only.read_only=true;
    EXPECT_THROW(cache.get_or_create(read_only,lattice::SchemaVector{}),std::runtime_error);
    auto invalid=bounded;invalid.wal_extent_limit_bytes=0;
    EXPECT_THROW(cache.get_or_create(invalid,lattice::SchemaVector{}),std::runtime_error);
    second->close();first->close();unbounded->close();
    second.reset();same.reset();first.reset();unbounded.reset();
    std::filesystem::remove(path);
    std::filesystem::remove(path.string()+"-wal");
    std::filesystem::remove(path.string()+"-shm");
}

TEST(BridgeTuning, InvalidTuningValuesAreIgnored) {
    lattice::swift_configuration cfg(":memory:");
    cfg.set_sync_chunk_size(0);
    cfg.set_sync_chunk_size(-5);
    cfg.set_sync_base_delay_seconds(0);
    cfg.set_sync_base_delay_seconds(-1);
    cfg.set_sync_upload_coalesce_ms(-100);
    EXPECT_FALSE(cfg.tuning.chunk_size.has_value());
    EXPECT_FALSE(cfg.tuning.base_delay_seconds.has_value());
    EXPECT_FALSE(cfg.tuning.upload_coalesce_ms.has_value());

    // And the second boundary: apply() drops a zero smuggled into the struct.
    cfg.tuning.chunk_size = 0;
    lattice::sync_config sc;
    auto default_chunk = sc.chunk_size;
    cfg.tuning.apply(sc);
    EXPECT_EQ(sc.chunk_size, default_chunk);
}

TEST(BridgeTuning, CreateUncachedNeverAliasesParent) {
    auto path = std::filesystem::temp_directory_path() / "bridge_uncached.sqlite";
    std::filesystem::remove(path);
    lattice::swift_configuration cfg(path.string());
    auto parent = lattice::detail::LatticeCache::instance().get_or_create(cfg, lattice::SchemaVector{});
    auto clone = lattice::detail::LatticeCache::instance().create_uncached(cfg, lattice::SchemaVector{});
    EXPECT_NE(parent.get(), clone.get())
        << "query-clone must be a distinct instance even with an identical config";
}

// ============================================================================
// Read generations + synchronous invalidation hooks through the bridge —
// Live Results item A, Commit 4 (lattice repo docs/design-results-item-A-SPEC.md).
// Stays inside the !__linux__ guard: these exercise swift_lattice_ref, which
// the test target only links on Apple platforms.
// ============================================================================

namespace {

struct HookCapture {
    std::mutex m;  // leaf lock — never held across SQL anywhere in the test
    std::atomic<int> fires{0};
    std::thread::id last_thread{};
    std::vector<std::string> last_tables;
    std::vector<int> reasons;
};

struct FieldsHookCapture {
    std::mutex m;
    std::vector<std::pair<std::string, std::string>> entries;  // (table, fields)
};

lattice::swift_schema_entry gen_person_schema(const std::string& table) {
    return make_schema(table, {
        {"name", text_prop("name")},
        {"age", int_prop("age")},
    });
}

void gen_insert_person(lattice::swift_lattice& db, const lattice::SchemaVector& schemas,
                       const std::string& name, int64_t age) {
    auto sdo = make_sdo(schemas[0].table_name, schemas[0].properties);
    sdo.values["name"] = name;
    sdo.values["age"] = age;
    lattice::dynamic_object obj(sdo);
    db.add(obj);
}

}  // namespace

// The whole point of the new hook (§2.3): delivery is INLINE on the writer's
// thread, before the write returns — no scheduler pump, no sleep, no Task hop
// (the T2 failure mode of the observer trampoline, pinned at the bridge).
TEST(BridgeGeneration, InvalidationHookFiresSynchronouslyThroughBridge) {
    TempDB tmp{"gen_hook_sync"};
    lattice::SchemaVector schemas = {gen_person_schema("GenHookPerson")};
    auto* ref = lattice::swift_lattice_ref::create(
        lattice::swift_configuration(tmp.str()), schemas);
    auto& db = *ref->get();

    HookCapture cap;
    auto token = ref->add_invalidation_hook(
        &cap,
        [](void* ctx, const char* const* tables, size_t count, int reason) {
            auto* c = static_cast<HookCapture*>(ctx);
            std::lock_guard<std::mutex> lock(c->m);
            c->last_thread = std::this_thread::get_id();
            c->last_tables.clear();
            for (size_t i = 0; i < count; ++i) c->last_tables.emplace_back(tables[i]);
            c->reasons.push_back(reason);
            c->fires.fetch_add(1, std::memory_order_release);
        });

    gen_insert_person(db, schemas, "Sync", 1);

    // The write returned ⇒ the hook already fired, on THIS thread.
    EXPECT_GE(cap.fires.load(std::memory_order_acquire), 1)
        << "hook did not fire synchronously with the write";
    {
        std::lock_guard<std::mutex> lock(cap.m);
        EXPECT_EQ(cap.last_thread, std::this_thread::get_id())
            << "hook fired off the writer's thread";
        EXPECT_NE(std::find(cap.last_tables.begin(), cap.last_tables.end(),
                            std::string("GenHookPerson")),
                  cap.last_tables.end())
            << "changed-table payload missing the written table";
        ASSERT_FALSE(cap.reasons.empty());
        EXPECT_EQ(cap.reasons.front(), 0) << "expected invalidation_reason::commit";
    }

    // Removal is effective immediately: no further fires.
    const int fires_before = cap.fires.load(std::memory_order_acquire);
    ref->remove_invalidation_hook(token);
    gen_insert_person(db, schemas, "After", 2);
    EXPECT_EQ(cap.fires.load(std::memory_order_acquire), fires_before)
        << "hook fired after remove_invalidation_hook";

    delete ref;
}

// Generation read round-trip through the bridge: acquire → read (same SQL
// builders, keeper-routed) → writer commits → the held generation still
// serves its MVCC snapshot → release.
TEST(BridgeGeneration, GenerationReadRoundTrip) {
    TempDB tmp{"gen_round_trip"};
    lattice::SchemaVector schemas = {gen_person_schema("GenTripPerson")};
    auto* ref = lattice::swift_lattice_ref::create(
        lattice::swift_configuration(tmp.str()), schemas);
    auto& db = *ref->get();
    for (int64_t i = 1; i <= 3; ++i) gen_insert_person(db, schemas, "P", i);

    auto gen = ref->acquire_read_generation();
    ASSERT_NE(gen, 0u) << "file DB refused a keeper";
    EXPECT_EQ(ref->read_generations_outstanding(), 1u);

    auto rows = ref->objects_at(gen, "GenTripPerson", std::nullopt,
                                std::string("age ASC"));
    EXPECT_FALSE(ref->last_generation_read_stale());
    ASSERT_EQ(rows.size(), 3u);
    EXPECT_EQ(int(rows[0].get_int("age")), 1);
    EXPECT_EQ(int(rows[2].get_int("age")), 3);
    EXPECT_EQ(ref->count_at(gen, "GenTripPerson"), 3);
    EXPECT_FALSE(ref->last_generation_read_stale());

    // Writer commits a 4th row: live reads see it, the held generation must not.
    gen_insert_person(db, schemas, "P", 4);
    EXPECT_EQ(ref->objects("GenTripPerson").size(), 4u);
    EXPECT_EQ(ref->count_at(gen, "GenTripPerson"), 3) << "generation lost its MVCC pin";
    EXPECT_EQ(ref->objects_at(gen, "GenTripPerson").size(), 3u);
    EXPECT_FALSE(ref->last_generation_read_stale());

    // retain adds a second hold: the first release keeps the keeper alive.
    EXPECT_TRUE(ref->retain_read_generation(gen));
    ref->release_read_generation(gen);
    EXPECT_EQ(ref->count_at(gen, "GenTripPerson"), 3)
        << "generation retired while a retain hold was live";
    ref->release_read_generation(gen);
    EXPECT_EQ(ref->read_generations_outstanding(), 0u);

    delete ref;
}

// Catch-all/sentinel contract: reads on a retired or unknown generation return
// the sentinel (empty / -1) plus the per-thread stale flag — never a throw
// across the interop boundary.
TEST(BridgeGeneration, RetiredGenerationReadReturnsSentinelNotThrow) {
    TempDB tmp{"gen_retired"};
    lattice::SchemaVector schemas = {gen_person_schema("GenRetiredPerson")};
    auto* ref = lattice::swift_lattice_ref::create(
        lattice::swift_configuration(tmp.str()), schemas);
    auto& db = *ref->get();
    for (int64_t i = 1; i <= 2; ++i) gen_insert_person(db, schemas, "P", i);

    auto gen = ref->acquire_read_generation();
    ASSERT_NE(gen, 0u);
    ref->retire_all_read_generations();  // §3.6 lifecycle path, bridged
    EXPECT_EQ(ref->read_generations_outstanding(), 0u);

    auto rows = ref->objects_at(gen, "GenRetiredPerson");
    EXPECT_TRUE(rows.empty());
    EXPECT_TRUE(ref->last_generation_read_stale())
        << "empty-from-retired must be flagged stale (not a genuine empty)";
    EXPECT_EQ(ref->count_at(gen, "GenRetiredPerson"), -1);
    EXPECT_TRUE(ref->last_generation_read_stale());

    EXPECT_FALSE(ref->retain_read_generation(gen)) << "retain on retired must refuse";
    ref->release_read_generation(gen);  // releasing a retired id is a no-op

    // Unknown id: same sentinel path.
    EXPECT_EQ(ref->count_at(999999, "GenRetiredPerson"), -1);
    EXPECT_TRUE(ref->last_generation_read_stale());

    // A successful read on a fresh generation clears the per-thread flag.
    auto gen2 = ref->acquire_read_generation();
    ASSERT_NE(gen2, 0u);
    EXPECT_EQ(ref->count_at(gen2, "GenRetiredPerson"), 2);
    EXPECT_FALSE(ref->last_generation_read_stale());
    ref->release_read_generation(gen2);

    delete ref;
}

// Refusal path (§4.1): memory-family stores refuse keepers — acquire returns 0
// through the bridge — while the §4.1 materialized-id capture (query_ids_at)
// still serves them.
TEST(BridgeGeneration, MemoryLatticeAcquireRefusedThroughBridge) {
    lattice::SchemaVector schemas = {gen_person_schema("GenMemPerson")};
    lattice::swift_configuration config;  // default = private :memory:
    auto* ref = lattice::swift_lattice_ref::create(config, schemas);
    auto& db = *ref->get();
    for (int64_t i = 1; i <= 2; ++i) gen_insert_person(db, schemas, "M", i);

    EXPECT_EQ(ref->acquire_read_generation(), 0u)
        << "memory lattice must refuse read generations";
    EXPECT_EQ(ref->read_generations_outstanding(), 0u);

    // Feeding the 0 sentinel into a generation read is the tolerant-ladder
    // path, not a throw.
    EXPECT_EQ(ref->count_at(0, "GenMemPerson"), -1);
    EXPECT_TRUE(ref->last_generation_read_stale());

    // The §4.1 id capture (capture transaction + gate + LOCKED retry) works.
    auto ids = ref->query_ids_at("GenMemPerson", std::nullopt, std::string("age ASC"));
    EXPECT_FALSE(ref->last_generation_read_stale());
    EXPECT_EQ(ids.size(), 2u);

    delete ref;
}

// Spec Commit 4 test: id-vector order ≡ row query order (same SQL builder,
// `id` select list), including under WHERE + ORDER BY.
TEST(BridgeGeneration, IdVectorOrderMatchesRowQueryOrder) {
    TempDB tmp{"gen_id_order"};
    lattice::SchemaVector schemas = {gen_person_schema("GenOrderPerson")};
    auto* ref = lattice::swift_lattice_ref::create(
        lattice::swift_configuration(tmp.str()), schemas);
    auto& db = *ref->get();
    for (int64_t age : {5, 1, 9, 3}) gen_insert_person(db, schemas, "O", age);

    auto rows = ref->objects("GenOrderPerson", std::nullopt,
                             std::string("age DESC, id ASC"));
    auto ids = ref->query_ids_at("GenOrderPerson", std::nullopt,
                                 std::string("age DESC, id ASC"));
    ASSERT_EQ(rows.size(), 4u);
    ASSERT_EQ(ids.size(), rows.size());
    for (size_t i = 0; i < rows.size(); ++i) {
        EXPECT_EQ(ids[i], rows[i].get_int("id")) << "order diverged at index " << i;
    }

    auto rows2 = ref->objects("GenOrderPerson", std::string("age > 2"),
                              std::string("age ASC"));
    auto ids2 = ref->query_ids_at("GenOrderPerson", std::string("age > 2"),
                                  std::string("age ASC"));
    ASSERT_EQ(rows2.size(), 3u);
    ASSERT_EQ(ids2.size(), rows2.size());
    for (size_t i = 0; i < rows2.size(); ++i) {
        EXPECT_EQ(ids2[i], rows2[i].get_int("id")) << "filtered order diverged at " << i;
    }

    delete ref;
}

// Spec Commit 4 fault injection: a throwing core read (bad WHERE on a LIVE
// generation) surfaces as empty + stale, process alive — and the generation
// itself remains serviceable afterwards.
TEST(BridgeGeneration, ThrowingReadSurfacesAsEmptyPlusStale) {
    TempDB tmp{"gen_fault"};
    lattice::SchemaVector schemas = {gen_person_schema("GenFaultPerson")};
    auto* ref = lattice::swift_lattice_ref::create(
        lattice::swift_configuration(tmp.str()), schemas);
    auto& db = *ref->get();
    for (int64_t i = 1; i <= 2; ++i) gen_insert_person(db, schemas, "F", i);

    auto gen = ref->acquire_read_generation();
    ASSERT_NE(gen, 0u);

    auto rows = ref->objects_at(gen, "GenFaultPerson", std::string("no_such_column = 1"));
    EXPECT_TRUE(rows.empty());
    EXPECT_TRUE(ref->last_generation_read_stale());

    EXPECT_EQ(ref->count_at(gen, "GenFaultPerson", std::string("no_such_column = 1")), -1);
    EXPECT_TRUE(ref->last_generation_read_stale());

    auto ids = ref->query_ids_at("GenFaultPerson", std::string("no_such_column = 1"));
    EXPECT_TRUE(ids.empty());
    EXPECT_TRUE(ref->last_generation_read_stale());

    // Still alive: the fault did not kill the keeper or the process.
    EXPECT_EQ(ref->count_at(gen, "GenFaultPerson"), 2);
    EXPECT_FALSE(ref->last_generation_read_stale());
    ref->release_read_generation(gen);

    delete ref;
}

// Spec Commit 4 test: data_version changes on foreign-connection commit only —
// it is read on the dedicated non-transaction xproc connection, so this
// handle's own reads never move it, and any writer commit (a different
// connection by construction) does.
TEST(BridgeGeneration, DataVersionChangesOnForeignCommitOnly) {
    TempDB tmp{"gen_data_version"};
    lattice::SchemaVector schemas = {gen_person_schema("GenDvPerson")};
    auto* ref = lattice::swift_lattice_ref::create(
        lattice::swift_configuration(tmp.str()), schemas);
    auto& db = *ref->get();

    const auto v1 = ref->data_version();
    ASSERT_GT(v1, 0) << "data_version unavailable on a file DB";
    EXPECT_EQ(ref->data_version(), v1) << "data_version moved with no commit";
    (void)ref->objects("GenDvPerson");  // reads must not move it either
    EXPECT_EQ(ref->data_version(), v1);

    gen_insert_person(db, schemas, "DV", 1);  // write-connection commit
    EXPECT_NE(ref->data_version(), v1)
        << "foreign-connection commit did not move data_version";

    delete ref;
}

// Commit 4 additive overload: changed_fields delivery. An INSERT batch
// delivers EMPTY fields for its table (membership may change); a list append
// flushes as an UPDATE-only parent batch carrying the list property name.
TEST(BridgeGeneration, ChangedFieldsDeliveredThroughHookPayload) {
    TempDB tmp{"gen_changed_fields"};
    lattice::SchemaVector schemas = {
        make_schema("CfOwner", {
            {"name", text_prop("name")},
            {"sigs", list_prop("sigs", "CfSig")},
        }),
        make_schema("CfSig", {
            {"key", text_prop("key")},
            {"val", int_prop("val")},
        }),
    };
    auto* ref = lattice::swift_lattice_ref::create(
        lattice::swift_configuration(tmp.str()), schemas);
    auto& db = *ref->get();
    db.db().execute("INSERT INTO CfOwner(globalId, name) VALUES('own-1', 'O')");

    FieldsHookCapture cap;
    auto token = ref->add_invalidation_hook_with_fields(
        &cap,
        [](void* ctx, const char* const* tables, const char* const* fields,
           size_t count, int reason) {
            if (reason != 0) return;  // commits only
            auto* c = static_cast<FieldsHookCapture*>(ctx);
            std::lock_guard<std::mutex> lock(c->m);
            for (size_t i = 0; i < count; ++i) {
                c->entries.emplace_back(tables[i], fields[i]);
            }
        });

    // INSERT: fields for the inserted table must be EMPTY (must-invalidate).
    auto sdo = make_sdo("CfSig", schemas[1].properties);
    sdo.values["key"] = std::string("k1");
    sdo.values["val"] = int64_t(1);
    lattice::dynamic_object obj(sdo);
    db.add(obj);
    {
        std::lock_guard<std::mutex> lock(cap.m);
        bool saw_sig = false;
        for (const auto& [table, fields] : cap.entries) {
            if (table == "CfSig") {
                saw_sig = true;
                EXPECT_TRUE(fields.empty())
                    << "INSERT batch delivered non-empty changed_fields: " << fields;
            }
        }
        EXPECT_TRUE(saw_sig) << "hook never saw the CfSig insert";
        cap.entries.clear();
    }

    // List append: flush translates the link-table write into a parent
    // UPDATE whose changed_fields names the list property — an UPDATE-only
    // batch for CfOwner, so the union ("sigs") is delivered.
    auto owners = db.objects("CfOwner");
    ASSERT_EQ(owners.size(), 1u);
    auto field = owners[0].get_managed_field<std::vector<lattice::swift_dynamic_object*>>("sigs");
    lattice::link_list list(field, lattice::swift_lattice_ref::shared_for_lattice(&db));
    auto* obj_ref = lattice::dynamic_object_ref::wrap(obj);
    list.push_back(*obj_ref);
    delete obj_ref;
    {
        std::lock_guard<std::mutex> lock(cap.m);
        bool delivered = false;
        for (const auto& [table, fields] : cap.entries) {
            if (table == "CfOwner" && fields == "sigs") delivered = true;
        }
        EXPECT_TRUE(delivered)
            << "UPDATE-only parent batch did not deliver changed_fields 'sigs'";
    }

    ref->remove_invalidation_hook(token);
    delete ref;
}

// ============================================================================
// Unique-index name parity — bridge constraint pass vs C-ABI is_unique shape
// ============================================================================

TEST(Bridge, UniqueIndexNameParityAcrossSwiftAndCapiSchemaShapes) {
    TempDB tmp{"bridge_unique_parity"};

    // Swift-shaped schema: uniqueness arrives ONLY as a constraint (what the
    // @Unique macro emits). Phase 8 must name the index unique_<table>_0.
    {
        lattice::swift_schema_entry entry = make_schema("ParityDoc", {
            {"code", text_prop("code")},
            {"label", text_prop("label")},
        });
        entry.constraints.push_back(lattice::swift_constraint({"code"}, /*upsert=*/false));
        lattice::SchemaVector schemas = {entry};

        auto* ref = lattice::swift_lattice_ref::create(
            lattice::swift_configuration(tmp.str()), schemas);
        auto& db = *ref->get();

        auto rows = db.db().query(
            "SELECT name FROM sqlite_master "
            "WHERE type='index' AND tbl_name='ParityDoc' AND name LIKE 'unique_%'");
        ASSERT_EQ(rows.size(), 1u);
        EXPECT_EQ(std::get<std::string>(rows[0].at("name")), "unique_ParityDoc_0");
        delete ref;
    }

    // C-ABI-shaped schema for the SAME logical model: per-property is_unique
    // plus the single-column constraint the C ABI's convert_schemas derives
    // from it. Reopening the Swift-created file must find the index already
    // present — same name, so NO second unique index appears.
    {
        auto code = text_prop("code");
        code.is_unique = true;
        lattice::swift_schema_entry entry = make_schema("ParityDoc", {
            {"code", code},
            {"label", text_prop("label")},
        });
        entry.constraints.push_back(lattice::swift_constraint({"code"}, /*upsert=*/false));
        lattice::SchemaVector schemas = {entry};

        auto* ref = lattice::swift_lattice_ref::create(
            lattice::swift_configuration(tmp.str()), schemas);
        auto& db = *ref->get();

        auto rows = db.db().query(
            "SELECT name FROM sqlite_master "
            "WHERE type='index' AND tbl_name='ParityDoc' AND name LIKE 'unique_%'");
        ASSERT_EQ(rows.size(), 1u) << "reopen double-indexed the unique column";
        EXPECT_EQ(std::get<std::string>(rows[0].at("name")), "unique_ParityDoc_0");

        // Enforcement through the bridge write path: same code twice → reject.
        {
            auto sdo = make_sdo("ParityDoc", schemas[0].properties);
            sdo.values["code"] = std::string("C-1");
            sdo.values["label"] = std::string("first");
            lattice::dynamic_object obj(sdo);
            db.add(obj);
        }
        auto sdo2 = make_sdo("ParityDoc", schemas[0].properties);
        sdo2.values["code"] = std::string("C-1");
        sdo2.values["label"] = std::string("second");
        lattice::dynamic_object obj2(sdo2);
        EXPECT_THROW(db.add(obj2), lattice::db_error);

        auto count = db.db().query("SELECT COUNT(*) AS c FROM ParityDoc");
        EXPECT_EQ(std::get<int64_t>(count[0].at("c")), 1);
        delete ref;
    }
}

#endif // !__linux__

#ifndef __linux__
namespace {
std::unique_ptr<lattice::swift_lattice_ref> managed_row_factory_owner(
    const std::string& path, const lattice::SchemaVector& schemas) {
#if LATTICE_HAS_FRT
    auto owner = std::unique_ptr<lattice::swift_lattice_ref>(
        lattice::swift_lattice_ref::create_uncached(lattice::swift_configuration(path), schemas));
#else
    auto owner = std::make_unique<lattice::swift_lattice_ref>(
        lattice::swift_lattice_ref::create_uncached(lattice::swift_configuration(path), schemas));
#endif
    owner->get()->stop_audit_maintenance();
    return owner;
}

std::unique_ptr<lattice::dynamic_object_ref> managed_row_factory_box(
    const lattice::managed<lattice::swift_dynamic_object>& row, bool legacy = false) {
    auto result = legacy
        ? lattice::dynamic_object_ref::wrap(lattice::dynamic_object(row).make_shared())
        : lattice::dynamic_object_ref::wrap_managed(row);
#if LATTICE_HAS_FRT
    return std::unique_ptr<lattice::dynamic_object_ref>(result);
#else
    return std::make_unique<lattice::dynamic_object_ref>(std::move(result));
#endif
}
}

TEST(Bridge, ManagedRowFactoryPreservesGenerationImageAndLiveReads) {
    TempDB path{"managed_row_factory_image"};
    lattice::SchemaVector schemas = {make_schema("FactoryImage", {
        {"age", int_prop("age")}, {"score", real_prop("score")},
        {"name", text_prop("name")}, {"email", nullable_text_prop("email")},
    })};
    auto owner = managed_row_factory_owner(path.str(), schemas);
    {
        auto source = make_sdo("FactoryImage", schemas[0].properties);
        source.values["age"] = int64_t(7);
        source.values["score"] = 1.25;
        source.values["name"] = std::string("before");
        source.values["email"] = nullptr;
        lattice::dynamic_object object(source);
        owner->get()->add(object);
    }
    const auto generation = owner->acquire_read_generation();
    ASSERT_NE(generation, 0u);
    std::unique_ptr<lattice::dynamic_object_ref> direct, legacy, sibling;
    int64_t id = 0;
    {
        auto rows = owner->objects_at(generation, "FactoryImage");
        ASSERT_FALSE(owner->last_generation_read_stale());
        ASSERT_EQ(rows.size(), 1u);
        id = rows[0].id();
        const auto before_boxing = lattice::database::thread_statement_count();
        direct = managed_row_factory_box(rows[0]);
        legacy = managed_row_factory_box(rows[0], true);
        sibling = managed_row_factory_box(rows[0]);
        EXPECT_EQ(lattice::database::thread_statement_count() - before_boxing, 0u);
    } // Destroy the input vector before inspecting either owning result.
    owner->release_read_generation(generation);
    ASSERT_NE(direct->get(), legacy->get());
    ASSERT_NE(direct->get(), sibling->get());
    owner->get()->db().execute("UPDATE FactoryImage SET age=99,score=2.5,name='after'");
    const auto before_metadata = lattice::database::thread_statement_count();
    for (auto* object : {direct.get(), legacy.get(), sibling.get()}) {
        EXPECT_EQ(object->get()->lattice.get(), owner->get());
        EXPECT_EQ(object->managed_primary_key(), id);
        EXPECT_EQ(object->get_table_name(), "FactoryImage");
        EXPECT_FALSE(object->is_row_cache_enabled());
        ASSERT_TRUE(object->has_query_row_image());
        ASSERT_EQ(object->query_row_value_type("age"), 1);
        ASSERT_EQ(object->query_row_value_type("score"), 2);
        ASSERT_EQ(object->query_row_value_type("name"), 3);
        EXPECT_EQ(object->query_row_value_type("email"), 0);
        EXPECT_EQ(object->query_row_value_type("missing"), -1);
        EXPECT_EQ(std::get<int64_t>(object->query_row_value("age")), 7);
        EXPECT_EQ(std::get<double>(object->query_row_value("score")), 1.25);
        EXPECT_EQ(std::get<std::string>(object->query_row_value("name")), "before");
        EXPECT_TRUE(lattice::column_value_is_null(object->query_row_value("email")));
    }
    direct->release_query_row_image();
    EXPECT_FALSE(direct->has_query_row_image());
    EXPECT_TRUE(legacy->has_query_row_image());
    EXPECT_TRUE(sibling->has_query_row_image());
    EXPECT_EQ(lattice::database::thread_statement_count() - before_metadata, 0u);
    const auto before_live_reads = lattice::database::thread_statement_count();
    for (auto* object : {direct.get(), legacy.get()}) {
        EXPECT_EQ(object->get_int("age"), 99);
        EXPECT_DOUBLE_EQ(object->get_double("score"), 2.5);
        EXPECT_EQ(object->get_string("name"), "after");
    }
    EXPECT_EQ(lattice::database::thread_statement_count() - before_live_reads, 6u);
}

TEST(Bridge, ManagedRowFactoryOwnsRowAndLatticeAfterInputsAreDestroyed) {
    std::unique_ptr<lattice::dynamic_object_ref> object;
    std::weak_ptr<lattice::swift_lattice> weak_owner;
    int64_t id = 0;
    {
        lattice::SchemaVector schemas = {make_schema("FactoryLifetime", {
            {"age", int_prop("age")}, {"name", text_prop("name")},
        })};
        auto owner = managed_row_factory_owner(":memory:", schemas);
        weak_owner = lattice::swift_lattice_ref::shared_for_lattice(owner->get());
        ASSERT_FALSE(weak_owner.expired());
        {
            auto source = make_sdo("FactoryLifetime", schemas[0].properties);
            source.values["age"] = int64_t(8);
            source.values["name"] = std::string("owned");
            lattice::dynamic_object inserted(source);
            owner->get()->add(inserted);
        }
        auto rows = owner->get()->objects("FactoryLifetime");
        ASSERT_EQ(rows.size(), 1u);
        id = rows[0].id();
        const auto before_boxing = lattice::database::thread_statement_count();
        object = managed_row_factory_box(rows[0]);
        EXPECT_EQ(object->get()->lattice.get(), owner->get());
        EXPECT_EQ(lattice::database::thread_statement_count() - before_boxing, 0u);
    } // Row vector, original schema, insertion object and owner ref are gone.
    EXPECT_FALSE(weak_owner.expired());
    EXPECT_EQ(object->managed_primary_key(), id);
    EXPECT_EQ(object->get_table_name(), "FactoryLifetime");
    EXPECT_EQ(object->get_string("name"), "owned");
    object->set_int("age", 19);
    EXPECT_TRUE(object->last_query_error_message().empty());
    EXPECT_EQ(object->get_int("age"), 19);
    // Serialization enumerates the retained schema after the source row and
    // caller's schema have been destroyed, rather than only reading by name.
    const auto json = object->to_json(0);
    EXPECT_NE(json.find("\"age\":19"), std::string::npos);
    EXPECT_NE(json.find("\"name\":\"owned\""), std::string::npos);
    EXPECT_EQ(std::get<int64_t>(object->query_row_value("age")), 8);
    object->release_query_row_image();
    EXPECT_FALSE(object->is_row_cache_enabled());
    object.reset();
    EXPECT_TRUE(weak_owner.expired()) << "the final owning row must release its lattice";
}

TEST(Bridge, ManagedRowFactoryKeepsAttachedEqualIDsOnTheirPhysicalRoute) {
    TempDB local_path{"factory_local"}, arm_path{"factory_arm_\"quote"};
    lattice::SchemaVector schemas = {make_schema("FactoryArm", {{"age", int_prop("age")}})};
    auto local = managed_row_factory_owner(local_path.str(), schemas);
    auto arm = managed_row_factory_owner(arm_path.str(), schemas);
    for (auto* owner : {local.get(), arm.get()}) {
        auto source = make_sdo("FactoryArm", schemas[0].properties);
        source.values["age"] = int64_t(owner == local.get() ? 10 : 20);
        lattice::dynamic_object inserted(source);
        owner->get()->add(inserted);
    }
    ASSERT_TRUE(local->get()->attach(*arm->get()));
    std::unique_ptr<lattice::dynamic_object_ref> local_row, attached_row, legacy_attached;
    {
        auto rows = local->get()->objects("FactoryArm", std::nullopt, std::string("age ASC"));
        ASSERT_EQ(rows.size(), 2u);
        ASSERT_EQ(rows[0].id(), rows[1].id());
        const auto before_boxing = lattice::database::thread_statement_count();
        local_row = managed_row_factory_box(rows[0]);
        attached_row = managed_row_factory_box(rows[1]);
        legacy_attached = managed_row_factory_box(rows[1], true);
        EXPECT_EQ(lattice::database::thread_statement_count() - before_boxing, 0u);
    }
    EXPECT_EQ(attached_row->get()->lattice.get(), local->get());
    EXPECT_EQ(attached_row->get()->lattice.get(), legacy_attached->get()->lattice.get());
    EXPECT_EQ(local_row->managed_primary_key(), attached_row->managed_primary_key());
    EXPECT_EQ(attached_row->get_table_name(), legacy_attached->get_table_name());
    EXPECT_NE(local_row->get_table_name(), attached_row->get_table_name());
    ASSERT_EQ(attached_row->query_row_value_type("_source"), 3);
    EXPECT_EQ(std::get<std::string>(attached_row->query_row_value("_source")),
              std::get<std::string>(legacy_attached->query_row_value("_source")));
    attached_row->set_int("age", 44);
    EXPECT_TRUE(attached_row->last_query_error_message().empty());
    EXPECT_EQ(legacy_attached->get_int("age"), 44);
    EXPECT_EQ(local_row->get_int("age"), 10);
    EXPECT_EQ(std::get<int64_t>(attached_row->query_row_value("age")), 20);
    lattice::database local_check(local_path.str()), arm_check(arm_path.str());
    auto local_values = local_check.query("SELECT age FROM FactoryArm");
    auto arm_values = arm_check.query("SELECT age FROM FactoryArm");
    ASSERT_EQ(local_values.size(), 1u);
    ASSERT_EQ(arm_values.size(), 1u);
    EXPECT_EQ(std::get<int64_t>(local_values[0].at("age")), 10);
    EXPECT_EQ(std::get<int64_t>(arm_values[0].at("age")), 44);
}


namespace {
lattice::SchemaVector readonly_version_schemas() {
    return {make_schema("ReadOnlyVersionRow",{{"name",text_prop("name")}})};
}
void make_readonly_version_file(const std::string& path) {
    lattice::swift_configuration config(path);config.target_schema_version=40;
    lattice::swift_lattice writer(config,readonly_version_schemas());
    writer.db().execute("INSERT INTO ReadOnlyVersionRow(globalId,name) VALUES('readonly-version-row','original')");
}
struct readonly_version_snapshot {
    std::vector<lattice::database::row_t> meta,schema,rows,cookie;
};
readonly_version_snapshot read_version_snapshot(lattice::database& reader) {
    return {reader.query("SELECT key,value FROM _lattice_meta ORDER BY key"),
        reader.query("SELECT type,name,tbl_name,sql FROM sqlite_master ORDER BY type,name"),
        reader.query("SELECT globalId,name FROM ReadOnlyVersionRow ORDER BY id"),
        reader.query("PRAGMA schema_version")};
}
void expect_same_version_snapshot(const readonly_version_snapshot& a,const readonly_version_snapshot& b) {
    EXPECT_EQ(a.meta,b.meta);EXPECT_EQ(a.schema,b.schema);EXPECT_EQ(a.rows,b.rows);EXPECT_EQ(a.cookie,b.cookie);
}
void count_readonly_migration(const char*,void* raw) {++*static_cast<int*>(raw);}
}

TEST(BridgeReadOnlySchemaVersion, ConstAndRvalueTypedOpensRefuseNewerRealFileWithoutMutation) {
    TempDB file{"readonly-version-newer"};make_readonly_version_file(file.str());
    lattice::database observer(file.str(),lattice::database::open_mode::read_only);
    const auto before=read_version_snapshot(observer);int callbacks=0;
    const auto schemas=readonly_version_schemas();
    lattice::swift_configuration old(file.str());old.read_only=true;old.target_schema_version=36;
    old.setRowMigrationCallback(&callbacks,count_readonly_migration);
    const auto& const_config=old;
    try {lattice::swift_lattice refused(const_config,schemas);FAIL()<<"newer schema was admitted";}
    catch(const std::runtime_error& e){EXPECT_NE(std::string(e.what()).find("(40) is newer than this binary supports (36)"),std::string::npos);}
    old.target_schema_version=37;
    try {lattice::swift_lattice refused(std::move(old),schemas);FAIL()<<"newer schema was admitted";}
    catch(const std::runtime_error& e){EXPECT_NE(std::string(e.what()).find("(40) is newer than this binary supports (37)"),std::string::npos);}
    EXPECT_EQ(callbacks,0);expect_same_version_snapshot(before,read_version_snapshot(observer));
}

TEST(BridgeReadOnlySchemaVersion, SupportedTypedVersionsReadWithoutMigrationOrSchemaWrites) {
    TempDB file{"readonly-version-supported"};make_readonly_version_file(file.str());
    lattice::database observer(file.str(),lattice::database::open_mode::read_only);
    const auto before=read_version_snapshot(observer);int callbacks=0;
    const auto schemas=readonly_version_schemas();
    lattice::swift_configuration exact(file.str());exact.read_only=true;exact.target_schema_version=40;
    exact.setRowMigrationCallback(&callbacks,count_readonly_migration);
    {
        const auto& const_config=exact;lattice::swift_lattice reader(const_config,schemas);
        EXPECT_EQ(std::get<std::string>(reader.db().query("SELECT name FROM ReadOnlyVersionRow").at(0).at("name")),"original");
        EXPECT_EQ(lattice_sqlite3541_db_readonly(lattice::detail::canonical_writer_custody_test_access::escaped_handle(reader.db()),"main"),1);
    }
    exact.target_schema_version=41; // Read-only admission never requests migration to the larger supported bound.
    {
        lattice::swift_lattice reader(std::move(exact),schemas);
        EXPECT_EQ(std::get<std::string>(reader.db().query("SELECT name FROM ReadOnlyVersionRow").at(0).at("name")),"original");
    }
    EXPECT_EQ(callbacks,0);expect_same_version_snapshot(before,read_version_snapshot(observer));
}

TEST(BridgeReadOnlySchemaVersion, MalformedAndUnreadableMetadataRefuseWithoutDefaultingToZero) {
    TempDB file{"readonly-version-malformed"};make_readonly_version_file(file.str());
    const auto schemas=readonly_version_schemas();
    for(const auto& value:{std::string("not-a-version"),std::string("40trailing"),std::string("999999999999999999999999")}) {
        {lattice::database writer(file.str());writer.execute("UPDATE _lattice_meta SET value=? WHERE key='schema_version'",{value});}
        lattice::database observer(file.str(),lattice::database::open_mode::read_only);const auto before=read_version_snapshot(observer);
        lattice::swift_configuration config(file.str());config.read_only=true;config.target_schema_version=36;
        const auto& const_config=config;EXPECT_THROW({lattice::swift_lattice refused(const_config,schemas);},std::exception);
        EXPECT_THROW({lattice::swift_lattice refused(std::move(config),schemas);},std::exception);
        expect_same_version_snapshot(before,read_version_snapshot(observer));
    }
    {lattice::database writer(file.str());writer.execute("DROP TABLE _lattice_meta");}
    lattice::swift_configuration unreadable(file.str());unreadable.read_only=true;unreadable.target_schema_version=36;
    const auto& const_config=unreadable;EXPECT_THROW({lattice::swift_lattice refused(const_config,schemas);},std::exception);
    EXPECT_THROW({lattice::swift_lattice refused(std::move(unreadable),schemas);},std::exception);
    lattice::database observer(file.str(),lattice::database::open_mode::read_only);
    EXPECT_FALSE(observer.table_exists("_lattice_meta"));
    EXPECT_EQ(std::get<std::string>(observer.query("SELECT name FROM ReadOnlyVersionRow").at(0).at("name")),"original");
}

TEST(BridgeReadOnlySchemaVersion, NoSchemaDynamicAndEmptySchemaOpensKeepTheirUnversionedContract) {
    TempDB file{"readonly-version-dynamic"};make_readonly_version_file(file.str());
    lattice::database observer(file.str(),lattice::database::open_mode::read_only);const auto before=read_version_snapshot(observer);
    lattice::swift_configuration config(file.str());config.read_only=true; // Default target1 is not a typed schema claim.
    {
        auto copy=config;lattice::swift_lattice dynamic(std::move(copy));dynamic.open_dynamic();
        EXPECT_EQ(std::get<std::string>(dynamic.db().query("SELECT name FROM ReadOnlyVersionRow").at(0).at("name")),"original");
    }
    {const auto& const_config=config;lattice::swift_lattice empty(const_config,{});}
    {lattice::swift_lattice empty(std::move(config),{});}
    expect_same_version_snapshot(before,read_version_snapshot(observer));
}


// Regression for the real Swift factory lifetime: logical close alone does
// not run the database destructor. Every wrapper and linked object must end
// before checking the persisted fingerprint cookie and reopening.
TEST(Bridge, ClosedCreatorFinalReleasePreservesCheckedMountedFingerprint) {
    TempDB file{"closed_creator_fingerprint"};
    auto value=text_prop("value");value.nullable=false;
    auto child=make_schema("ClosedCreatorFpChild",{{"value",value}});
    auto link=int_prop("child");link.kind=lattice::property_kind::link;
    link.target_table=child.table_name;link.link_table="ClosedCreatorFpParent";link.nullable=true;
    auto parent=make_schema("ClosedCreatorFpParent",{{"value",value},{"child",link}});
    lattice::SchemaVector schemas{parent,child};
    lattice::swift_configuration config(file.str());config.audit_retention_seconds=0;config.busy_timeout_ms=100;
    int64_t original_cookie=-1;
    std::vector<lattice::database::row_t> original_markers;
    std::weak_ptr<lattice::swift_lattice> actual_creator;
    const auto marker_sql="SELECT key,value FROM main._lattice_meta WHERE key LIKE 'schema_fingerprint:%' ORDER BY key";
    const auto stat_sql="SELECT count(*) AS n FROM main.sqlite_schema WHERE type='table' AND name='sqlite_stat1'";
    {
#if LATTICE_HAS_FRT
        std::unique_ptr<lattice::swift_lattice_ref> creator(lattice::swift_lattice_ref::create(config,schemas));
        auto* view=creator.get();
#else
        auto creator=lattice::swift_lattice_ref::create(config,schemas);auto* view=&creator;
#endif
        ASSERT_TRUE(view);auto* owner=view->get();ASSERT_TRUE(owner);
        actual_creator=lattice::detail::LatticeCache::instance().get_by_pointer(owner);
        ASSERT_FALSE(actual_creator.expired());
        auto child_row=make_sdo(child.table_name,child.properties);child_row.values["value"]=std::string("preserved-child");
        auto managed_child=std::make_shared<lattice::dynamic_object>(child_row);owner->add(*managed_child);
        auto parent_row=make_sdo(parent.table_name,parent.properties);parent_row.values["value"]=std::string("preserved-parent");
        parent_row.link_values["child"]=managed_child;lattice::dynamic_object managed_parent(parent_row);owner->add(managed_parent);
        original_cookie=std::get<int64_t>(owner->db().query("PRAGMA main.schema_version").at(0).at("schema_version"));
        original_markers=owner->db().query(marker_sql);ASSERT_GE(original_markers.size(),2u);
        for(const auto& marker:original_markers)EXPECT_EQ(std::get<std::string>(marker.at("value")),std::to_string(original_cookie));
        ASSERT_EQ(std::get<int64_t>(owner->db().query(stat_sql).at(0).at("n")),0);
        const auto closed=owner->close_checked();EXPECT_FALSE(closed.error);EXPECT_FALSE(closed.cleanup_error);EXPECT_TRUE(closed.cleanup_complete);
    }
    ASSERT_TRUE(actual_creator.expired()); // Real final owner release, not a logical-close proxy.
    {
        lattice::database observed(file.str(),lattice::database::open_mode::read_only,100);
        EXPECT_EQ(std::get<int64_t>(observed.query("PRAGMA main.schema_version").at(0).at("schema_version")),original_cookie);
        EXPECT_EQ(observed.query(marker_sql),original_markers);
        EXPECT_EQ(std::get<int64_t>(observed.query(stat_sql).at(0).at("n")),0);
    }
    for(int attempt=0;attempt<2;++attempt) {
#if LATTICE_HAS_FRT
        std::unique_ptr<lattice::swift_lattice_ref> checked(lattice::swift_lattice_ref::create_checked_mounted_server(config,schemas));
        auto* view=checked.get();
#else
        auto checked=lattice::swift_lattice_ref::create_checked_mounted_server(config,schemas);auto* view=&checked;
#endif
        ASSERT_TRUE(view);auto* owner=view->get();ASSERT_TRUE(owner)<<lattice::last_bridge_error();
        EXPECT_EQ(std::get<int64_t>(owner->db().query("SELECT count(*) AS n FROM ClosedCreatorFpParent").at(0).at("n")),1);
        EXPECT_EQ(std::get<int64_t>(owner->db().query("SELECT count(*) AS n FROM ClosedCreatorFpChild").at(0).at("n")),1);
        const auto closed=owner->close_checked();EXPECT_FALSE(closed.error);EXPECT_FALSE(closed.cleanup_error);EXPECT_TRUE(closed.cleanup_complete);
    }
    // Genuine unrelated DDL must still invalidate the strict checked cookie.
    {lattice::database changed(file.str());changed.execute("CREATE TABLE ClosedCreatorExternalDDL(x INTEGER)");changed.close();}
#if LATTICE_HAS_FRT
    std::unique_ptr<lattice::swift_lattice_ref> refused(lattice::swift_lattice_ref::create_checked_mounted_server(config,schemas));
    EXPECT_TRUE(!refused||!refused->get());
#else
    auto refused=lattice::swift_lattice_ref::create_checked_mounted_server(config,schemas);EXPECT_FALSE(refused.get());
#endif
    EXPECT_NE(lattice::last_bridge_error().find("fingerprint/cookie differs"),std::string::npos);
}



namespace {
// Use the normal cached Swift factory and destroy every creator wrapper
// before any later checked reopen. No direct-constructor substitution.
template<class Body>
void with_live_stats_creator(const lattice::swift_configuration& config,
    const lattice::SchemaVector& schemas, Body&& body) {
#if LATTICE_HAS_FRT
    std::unique_ptr<lattice::swift_lattice_ref> creator(lattice::swift_lattice_ref::create(config,schemas));
    auto* view=creator.get();
#else
    auto creator=lattice::swift_lattice_ref::create(config,schemas);auto* view=&creator;
#endif
    ASSERT_TRUE(view);auto* owner=view->get();ASSERT_TRUE(owner)<<lattice::last_bridge_error();
    body(*owner);
    const auto closed=owner->close_checked();EXPECT_FALSE(closed.error);EXPECT_FALSE(closed.cleanup_error);EXPECT_TRUE(closed.cleanup_complete);
}
const char* live_stats_markers="SELECT key,value FROM main._lattice_meta WHERE key LIKE 'schema_fingerprint:%' ORDER BY key";
const char* live_stats_count="SELECT count(*) AS n FROM main.sqlite_schema WHERE type='table' AND name='sqlite_stat1'";
int64_t live_stats_cookie(lattice::database& db) {
    return std::get<int64_t>(db.query("PRAGMA main.schema_version").at(0).at("schema_version"));
}
void seed_live_stats_row(lattice::swift_lattice& owner,const lattice::swift_schema_entry& schema) {
    auto row=make_sdo(schema.table_name,schema.properties);row.values["value"]=std::string("preserved-live-statistics-row");
    lattice::dynamic_object object(row);owner.add(object);
}
struct LiveStatsCommitDenial {
    lattice_sqlite3541_connection* actual;unsigned commits=0,rollbacks=0;int installed=LATTICE_SQLITE3541_MISUSE,removed=LATTICE_SQLITE3541_MISUSE;
    static int authorize(void* raw,int action,const char* one,const char*,const char*,const char*) {
        auto& self=*static_cast<LiveStatsCommitDenial*>(raw);
        if(action==LATTICE_SQLITE3541_TRANSACTION&&one) {
            if(std::strcmp(one,"COMMIT")==0){++self.commits;return LATTICE_SQLITE3541_DENY;}
            if(std::strcmp(one,"ROLLBACK")==0)++self.rollbacks;
        }
        return LATTICE_SQLITE3541_OK;
    }
    explicit LiveStatsCommitDenial(lattice::database& db):actual(lattice::detail::canonical_writer_custody_test_access::fault_handle(db)) {
        installed=lattice_sqlite3541_set_authorizer(actual,&authorize,this);
    }
    ~LiveStatsCommitDenial(){removed=lattice_sqlite3541_set_authorizer(actual,nullptr,nullptr);EXPECT_EQ(removed,LATTICE_SQLITE3541_OK);}
};
}

TEST(Bridge, LiveOptimizeCreatesStatsAndPreservesCheckedMountedReopen) {
    TempDB file{"live_optimize_reopen"};auto value=text_prop("value");value.nullable=false;
    auto schema=make_schema("LiveStatsReopenRow",{{"value",value}});lattice::SchemaVector schemas{schema};
    lattice::swift_configuration config(file.str());config.audit_retention_seconds=0;config.busy_timeout_ms=100;
    std::weak_ptr<lattice::swift_lattice> actual_creator;
    with_live_stats_creator(config,schemas,[&](lattice::swift_lattice& owner){
        actual_creator=lattice::detail::LatticeCache::instance().get_by_pointer(&owner);
        ASSERT_FALSE(actual_creator.expired());seed_live_stats_row(owner,schema);
        const auto cookie=live_stats_cookie(owner.db());const auto markers=owner.db().query(live_stats_markers);ASSERT_EQ(markers.size(),2u);
        ASSERT_EQ(std::get<int64_t>(owner.db().query(live_stats_count).at(0).at("n")),0);
        owner.optimize();const auto current=live_stats_cookie(owner.db());EXPECT_GT(current,cookie);
        EXPECT_EQ(std::get<int64_t>(owner.db().query(live_stats_count).at(0).at("n")),1);
        const auto refreshed=owner.db().query(live_stats_markers);ASSERT_EQ(refreshed.size(),markers.size());
        for(size_t n=0;n<markers.size();++n){EXPECT_EQ(refreshed[n].at("key"),markers[n].at("key"));EXPECT_EQ(std::get<std::string>(refreshed[n].at("value")),std::to_string(current));}
        owner.optimize();EXPECT_EQ(owner.db().query(live_stats_markers),refreshed);
        EXPECT_EQ(std::get<int64_t>(owner.db().query("SELECT count(*) AS n FROM LiveStatsReopenRow").at(0).at("n")),1);
    });
    ASSERT_TRUE(actual_creator.expired());
    for(int attempt=0;attempt<2;++attempt){
#if LATTICE_HAS_FRT
        std::unique_ptr<lattice::swift_lattice_ref> checked(lattice::swift_lattice_ref::create_checked_mounted_server(config,schemas));auto* view=checked.get();
#else
        auto checked=lattice::swift_lattice_ref::create_checked_mounted_server(config,schemas);auto* view=&checked;
#endif
        ASSERT_TRUE(view);auto* owner=view->get();ASSERT_TRUE(owner)<<lattice::last_bridge_error();
        EXPECT_EQ(std::get<int64_t>(owner->db().query("SELECT count(*) AS n FROM LiveStatsReopenRow").at(0).at("n")),1);
        const auto closed=owner->close_checked();EXPECT_FALSE(closed.error);EXPECT_FALSE(closed.cleanup_error);EXPECT_TRUE(closed.cleanup_complete);
    }
}

TEST(Bridge, LiveOptimizeDoesNotJoinOrSettleCallerTransaction) {
    TempDB file{"live_optimize_caller"};auto schema=make_schema("LiveStatsCallerRow",{{"value",text_prop("value")}});
    lattice::swift_configuration config(file.str());config.audit_retention_seconds=0;config.busy_timeout_ms=100;
    with_live_stats_creator(config,{schema},[&](lattice::swift_lattice& owner){
        const auto cookie=live_stats_cookie(owner.db());const auto markers=owner.db().query(live_stats_markers);
        owner.begin_transaction();seed_live_stats_row(owner,schema);ASSERT_TRUE(owner.db().is_in_transaction());
        owner.optimize();EXPECT_TRUE(owner.db().is_in_transaction());EXPECT_EQ(live_stats_cookie(owner.db()),cookie);
        EXPECT_EQ(owner.db().query(live_stats_markers),markers);EXPECT_EQ(std::get<int64_t>(owner.db().query(live_stats_count).at(0).at("n")),0);
        EXPECT_EQ(std::get<int64_t>(owner.db().query("SELECT count(*) AS n FROM LiveStatsCallerRow").at(0).at("n")),1);
        owner.rollback();EXPECT_FALSE(owner.db().is_in_transaction());
        EXPECT_EQ(std::get<int64_t>(owner.db().query("SELECT count(*) AS n FROM LiveStatsCallerRow").at(0).at("n")),0);
    });
}

TEST(Bridge, LiveOptimizeCommitDenialRollsBackStatsAndMarkerUpdatesTogether) {
    TempDB file{"live_optimize_commit"};auto schema=make_schema("LiveStatsCommitRow",{{"value",text_prop("value")}});
    lattice::swift_configuration config(file.str());config.audit_retention_seconds=0;config.busy_timeout_ms=100;
    with_live_stats_creator(config,{schema},[&](lattice::swift_lattice& owner){
        seed_live_stats_row(owner,schema);const auto cookie=live_stats_cookie(owner.db());const auto markers=owner.db().query(live_stats_markers);
        {LiveStatsCommitDenial fault(owner.db());ASSERT_EQ(fault.installed,LATTICE_SQLITE3541_OK);owner.optimize();EXPECT_EQ(fault.commits,1u);EXPECT_EQ(fault.rollbacks,1u);}
        EXPECT_FALSE(owner.db().is_in_transaction());EXPECT_EQ(live_stats_cookie(owner.db()),cookie);EXPECT_EQ(owner.db().query(live_stats_markers),markers);
        EXPECT_EQ(std::get<int64_t>(owner.db().query(live_stats_count).at(0).at("n")),0);
        EXPECT_EQ(std::get<int64_t>(owner.db().query("SELECT count(*) AS n FROM LiveStatsCommitRow").at(0).at("n")),1);
        owner.optimize();EXPECT_GT(live_stats_cookie(owner.db()),cookie);
        EXPECT_EQ(std::get<int64_t>(owner.db().query(live_stats_count).at(0).at("n")),1);
    });
}

TEST(Bridge, LiveOptimizeCannotRepairForeignDDLOrNoncanonicalMarkerText) {
    for(unsigned kind=0;kind<5;++kind){
        SCOPED_TRACE(kind);TempDB file{"live_optimize_foreign"};auto schema=make_schema("LiveStatsForeignRow",{{"value",text_prop("value")}});
        lattice::swift_configuration config(file.str());config.audit_retention_seconds=0;config.busy_timeout_ms=100;
        with_live_stats_creator(config,{schema},[&](lattice::swift_lattice& owner){
            seed_live_stats_row(owner,schema);
            if(kind==1){lattice::database outside(file.str());outside.execute("CREATE TABLE LiveStatsUnrelatedDDL(x INTEGER)");outside.close();}
            else if(kind==2)owner.db().execute("DELETE FROM main._lattice_meta WHERE key='schema_version'");
            else if(kind==3)owner.db().execute("UPDATE main._lattice_meta SET value='1junk' WHERE key='schema_version'");
            else {const auto first=owner.db().query(live_stats_markers).at(0);owner.db().execute("UPDATE main._lattice_meta SET value=? WHERE key=?",{kind==4?std::string(65536,'9'):std::get<std::string>(first.at("value"))+"junk",first.at("key")});}
            const auto cookie=live_stats_cookie(owner.db());const auto markers=owner.db().query(live_stats_markers);
            const auto shape=owner.db().query("SELECT type,name,tbl_name,rootpage,sql FROM main.sqlite_schema ORDER BY type,name");
            const auto version=owner.db().query("SELECT key,value FROM main._lattice_meta WHERE key='schema_version'");
            owner.optimize();EXPECT_EQ(live_stats_cookie(owner.db()),cookie);EXPECT_EQ(owner.db().query(live_stats_markers),markers);
            EXPECT_EQ(owner.db().query("SELECT key,value FROM main._lattice_meta WHERE key='schema_version'"),version);
            EXPECT_EQ(std::get<int64_t>(owner.db().query("SELECT count(*) AS n FROM LiveStatsForeignRow").at(0).at("n")),1);
            EXPECT_EQ(owner.db().query("SELECT type,name,tbl_name,rootpage,sql FROM main.sqlite_schema ORDER BY type,name"),shape);
            EXPECT_EQ(std::get<int64_t>(owner.db().query(live_stats_count).at(0).at("n")),0);
        });
    }
}

// The public Bridge scan must retain Core's real writer commit delivery.
// Observe actual committed model IDs; do not query/replace the SQLite hook.
TEST(Bridge, FileVectorTrainingRetainsActualCommitNotifications) {
    TempDB file{"ivf_training_commit_delivery"};
    auto schema=make_schema("TrainingCommitDoc",{
        {"title",text_prop("title")},{"embedding",blob_prop("embedding")}});
    lattice::swift_configuration config(file.str());
    config.audit_retention_seconds=0;config.busy_timeout_ms=100;
    with_live_stats_creator(config,{schema},[&](lattice::swift_lattice& owner){
        owner.wait_for_vec0_training();
        auto insert=[&](const std::string& title,float value){
            auto raw=make_sdo(schema.table_name,schema.properties);
            raw.values["title"]=title;
            raw.values["embedding"]=pack_floats({value,1.0f,2.0f,3.0f});
            lattice::dynamic_object row(raw);owner.add(row);
        };
        for(int i=0;i<32;++i)insert("seed-"+std::to_string(i),float(i));
        lattice::lattice_db& native=owner;
        std::vector<std::string> observed;
        const auto token=native.add_table_observer(schema.table_name,
            [&](const std::vector<lattice::lattice_db::change_event>& events){
                for(const auto& event:events)observed.push_back(std::get<3>(event));
            });
        struct remove_observer {
            lattice::lattice_db& owner;std::string table;decltype(token) id;
            ~remove_observer(){owner.remove_table_observer(table,id);}
        } remove{native,schema.table_name,token};
        ASSERT_NO_THROW(owner.train_untrained_vec0_tables());
        EXPECT_TRUE(observed.empty()) << "derived-index training must not invent model edits";
        // No intervening diagnostic query/drain may hide a missing training tail.
        ASSERT_NO_THROW(insert("after-training-0",100.0f));
        EXPECT_EQ(observed.size(),1u);
        ASSERT_NO_THROW(insert("after-training-1",101.0f));
        EXPECT_EQ(observed.size(),2u);
        const auto rows=owner.db().query(
            "SELECT globalId FROM main.TrainingCommitDoc "
            "WHERE title LIKE 'after-training-%' ORDER BY title");
        ASSERT_EQ(rows.size(),2u);ASSERT_EQ(observed.size(),rows.size());
        for(size_t i=0;i<rows.size();++i)
            EXPECT_EQ(observed[i],std::get<std::string>(rows[i].at("globalId")));
        const auto centroids=owner.db().query(
            "SELECT count(*) AS n FROM _TrainingCommitDoc_embedding_vec_ivf_centroids00");
        ASSERT_EQ(centroids.size(),1u);EXPECT_GT(std::get<int64_t>(centroids[0].at("n")),0);
        EXPECT_FALSE(owner.db().is_in_transaction());
    });
}

// A key-only allows-upsert model naturally uses DO NOTHING on a collision.
// Append the original bulk outputs so a cached phantom identity cannot hide
// behind a live getter or a freshly queried replacement object.
TEST(Bridge, BulkDoNothingBindsExistingIdentityAndPersistsRealLinks) {
    TempDB file{"bulk_do_nothing_identity"};
    auto item_schema = make_schema("BulkNothingItem", {{"key", text_prop("key")}});
    item_schema.constraints.push_back(lattice::swift_constraint({"key"}, true));
    auto parent_schema = make_schema("BulkNothingOwner", {
        {"name", text_prop("name")}, {"items", list_prop("items", item_schema.table_name)}});
    lattice::SchemaVector schemas{parent_schema, item_schema};
    lattice::swift_configuration config(file.str());
    config.audit_retention_seconds = 0; config.busy_timeout_ms = 100;
    with_live_stats_creator(config, schemas, [&](lattice::swift_lattice& owner) {
        auto parent_raw = make_sdo(parent_schema.table_name, parent_schema.properties);
        parent_raw.values["name"] = std::string("owner");
        lattice::dynamic_object parent(parent_raw);
        owner.add(parent);
        const auto parent_gid = parent.get_string("globalId");
        auto wanted_raw = make_sdo(item_schema.table_name, item_schema.properties);
        wanted_raw.values["key"] = std::string("wanted");
        lattice::dynamic_object wanted(wanted_raw);
        owner.add(wanted);
        const auto original = owner.db().query(
            "SELECT id, globalId FROM BulkNothingItem WHERE key = 'wanted'");
        ASSERT_EQ(original.size(), 1u);
        const auto wanted_id = std::get<int64_t>(original[0].at("id"));
        const auto wanted_gid = std::get<std::string>(original[0].at("globalId"));
        ASSERT_GT(wanted_id, 0);

        auto fresh_raw = make_sdo(item_schema.table_name, item_schema.properties);
        fresh_raw.values["key"] = std::string("fresh");
        lattice::dynamic_object fresh(fresh_raw), duplicate(wanted_raw);
        // A real fresh INSERT precedes DO NOTHING in the same batch, so the
        // last INSERT identity cannot accidentally be the wanted row's ID.
        std::vector<lattice::dynamic_object*> offered{&fresh, &duplicate};
        ASSERT_NO_THROW(owner.add_bulk(offered));
        EXPECT_EQ(duplicate.managed_primary_key(), wanted_id);
        ASSERT_GT(fresh.managed_primary_key(), 0);
        EXPECT_NE(fresh.managed_primary_key(), wanted_id);
        EXPECT_EQ(duplicate.get_string("globalId"), wanted_gid);
        const auto stored = owner.db().query(
            "SELECT id, globalId FROM BulkNothingItem ORDER BY globalId");
        ASSERT_EQ(stored.size(), 2u);
        const auto surviving = owner.db().query(
            "SELECT id, globalId FROM BulkNothingItem WHERE key = 'wanted'");
        EXPECT_EQ(surviving, original);

        auto parents = owner.objects(parent_schema.table_name);
        ASSERT_EQ(parents.size(), 1u);
        auto field = parents[0].get_managed_field<std::vector<lattice::swift_dynamic_object*>>("items");
        lattice::link_list list(field, lattice::swift_lattice_ref::shared_for_lattice(&owner));
        for (auto* object : {&duplicate, &fresh}) {
#if LATTICE_HAS_FRT
            std::unique_ptr<lattice::dynamic_object_ref> ref(lattice::dynamic_object_ref::wrap(*object));
            list.push_back(*ref);
#else
            auto ref = lattice::dynamic_object_ref::wrap(*object);
            list.push_back(ref);
#endif
        }
        const auto junction = owner.db().query(
            "SELECT rhs FROM _BulkNothingOwner_BulkNothingItem_items WHERE lhs = ? ORDER BY rhs",
            {parent_gid});
        ASSERT_EQ(junction.size(), stored.size());
        for (size_t i = 0; i < stored.size(); ++i)
            EXPECT_EQ(std::get<std::string>(junction[i].at("rhs")),
                      std::get<std::string>(stored[i].at("globalId")));
        EXPECT_EQ(list.size(), 2u);
        EXPECT_FALSE(owner.db().is_in_transaction());
    });
}

// SQL NULL does not collide with another NULL in a UNIQUE key. Both fresh
// bulk outputs must retain their own identities and remain usable as links.
TEST(Bridge, BulkNullableUniqueKeysInsertDistinctRowsAndPersistRealLinks) {
    TempDB file{"bulk_nullable_unique_identity"};
    auto key = nullable_text_prop("key");
    auto item_schema = make_schema("BulkNullableItem", {{"key", key}});
    item_schema.constraints.push_back(lattice::swift_constraint({"key"}, true));
    auto parent_schema = make_schema("BulkNullableOwner", {
        {"name", text_prop("name")}, {"items", list_prop("items", item_schema.table_name)}});
    lattice::SchemaVector schemas{parent_schema, item_schema};
    lattice::swift_configuration config(file.str());
    config.audit_retention_seconds = 0; config.busy_timeout_ms = 100;
    with_live_stats_creator(config, schemas, [&](lattice::swift_lattice& owner) {
        auto parent_raw = make_sdo(parent_schema.table_name, parent_schema.properties);
        parent_raw.values["name"] = std::string("owner");
        lattice::dynamic_object parent(parent_raw);
        owner.add(parent);
        const auto parent_gid = parent.get_string("globalId");
        auto raw = make_sdo(item_schema.table_name, item_schema.properties);
        raw.values["key"] = nullptr;
        lattice::dynamic_object first(raw), second(raw);
        std::vector<lattice::dynamic_object*> offered{&first, &second};
        ASSERT_NO_THROW(owner.add_bulk(offered));
        ASSERT_GT(first.managed_primary_key(), 0);
        ASSERT_GT(second.managed_primary_key(), 0);
        EXPECT_NE(first.managed_primary_key(), second.managed_primary_key());
        const auto stored = owner.db().query(
            "SELECT id, globalId FROM BulkNullableItem WHERE key IS NULL ORDER BY globalId");
        ASSERT_EQ(stored.size(), 2u);
        EXPECT_NE(std::get<std::string>(stored[0].at("globalId")),
                  std::get<std::string>(stored[1].at("globalId")));
        const auto total = owner.db().query("SELECT count(*) AS n FROM BulkNullableItem");
        EXPECT_EQ(std::get<int64_t>(total.at(0).at("n")), 2);
        auto parents = owner.objects(parent_schema.table_name);
        ASSERT_EQ(parents.size(), 1u);
        auto field = parents[0].get_managed_field<std::vector<lattice::swift_dynamic_object*>>("items");
        lattice::link_list list(field, lattice::swift_lattice_ref::shared_for_lattice(&owner));
        for (auto* object : {&first, &second}) {
            const auto bound = owner.db().query(
                "SELECT globalId FROM BulkNullableItem WHERE id = ?", {object->managed_primary_key()});
            ASSERT_EQ(bound.size(), 1u);
            EXPECT_EQ(object->get_string("globalId"), std::get<std::string>(bound[0].at("globalId")));
#if LATTICE_HAS_FRT
            std::unique_ptr<lattice::dynamic_object_ref> ref(lattice::dynamic_object_ref::wrap(*object));
            list.push_back(*ref);
#else
            auto ref = lattice::dynamic_object_ref::wrap(*object);
            list.push_back(ref);
#endif
        }
        const auto junction = owner.db().query(
            "SELECT rhs FROM _BulkNullableOwner_BulkNullableItem_items WHERE lhs = ? ORDER BY rhs",
            {parent_gid});
        ASSERT_EQ(junction.size(), stored.size());
        for (size_t i = 0; i < stored.size(); ++i)
            EXPECT_EQ(std::get<std::string>(junction[i].at("rhs")),
                      std::get<std::string>(stored[i].at("globalId")));
        EXPECT_EQ(list.size(), 2u);
        EXPECT_FALSE(owner.db().is_in_transaction());
    });
}

#endif // !__linux__
